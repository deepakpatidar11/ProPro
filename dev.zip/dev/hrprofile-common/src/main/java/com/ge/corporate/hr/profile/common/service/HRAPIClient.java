/**
 * Consumer class for the HR API RESTFul Service. It returns Job structure.
 */
package com.ge.corporate.hr.profile.common.service;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

import javax.net.ssl.HttpsURLConnection;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.corporate.hr.profile.common.dto.EmployeeJobDto;
import com.ge.corporate.hr.profile.common.dto.PotentialNextRoleDto;
import com.ge.corporate.hr.profile.common.dto.RecommendedLearningDto;
import com.ge.corporate.hr.profile.common.dto.EducationDto;

@Component
public class HRAPIClient {
	
	@Value("${careerexplorerapi}")
	private String careerExplorerApi;
	
	@Value("${careerexplorerJobapi}")
	private String careerexplorerJobApi;
	
	@Value("${recommendedlearningapi}")
	private String recommendedLearningApi;
	
	@Value("${swoopapi}")
	private String swoopEducationApi;
	
	private static Logger log = Logger.getLogger(HRAPIClient.class);
	
	@SuppressWarnings("deprecation")
	public PotentialNextRoleDto getPotentialNextRoles(String accessToken, String currentJob) throws Exception {
		int retryCount = 0;
		URL url = null;
	
		String urlStr = careerExplorerApi  +URLEncoder.encode("\""+currentJob+"\"") + "&pagesize=10&page=1";//+ " \"" + currentJob + "\"";
		while(true){
			
			retryCount++;
			try {
			
				// Job structure search
				url = new URL(urlStr);
				HttpURLConnection conn = (HttpURLConnection)url.openConnection();
				conn = (HttpsURLConnection) url.openConnection();
				conn.setDoOutput(true);
				conn.setRequestMethod("GET");
				conn.setRequestProperty("Authorization", "Bearer " +  accessToken);
				
				if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
					log.info("HTTP status code : " + conn.getResponseCode());
				}
				
				ObjectMapper mapper = new ObjectMapper();
				PotentialNextRoleDto nextRoles = mapper.readValue(conn.getInputStream(), PotentialNextRoleDto.class);
				conn.disconnect();
				
				return nextRoles;
				
			} catch (MalformedURLException e) {
				log.error(e);
				throw e;
			} catch (IOException e) {
				log.error("Attempt:"+ retryCount, e);
				Thread.sleep(1*30*1000); // 1/2 min
				if(retryCount == 5)
					throw e;
			}
		}
	}

	public RecommendedLearningDto[] getRecommendedLearnings(String accessToken, long sso, boolean loadMostPopular) throws Exception {
		int retryCount = 0;
		URL url = null;
		String urlStr = "";
		if(loadMostPopular){
			urlStr = recommendedLearningApi + "most-popular";
		}else{
			urlStr = recommendedLearningApi + "followed-by-you&sso=" + sso;
		}
		while(true){
			retryCount++;
			try {
				
				// Job structure search
				url = new URL(urlStr);
				HttpURLConnection conn = (HttpURLConnection)url.openConnection();
				conn = (HttpsURLConnection) url.openConnection();
				conn.setDoOutput(true);
				conn.setRequestMethod("GET");
				conn.setRequestProperty("Authorization", "Bearer " +  accessToken);
				
				if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
					log.info("HTTP status code : " + conn.getResponseCode());
				}
				
				ObjectMapper mapper = new ObjectMapper();
				RecommendedLearningDto[] nextRoles = mapper.readValue(conn.getInputStream(), RecommendedLearningDto[].class);
				conn.disconnect();
				
				return nextRoles;
				
			} catch (MalformedURLException e) {
				log.error(e);
				throw e;
			} catch (IOException e) {
				log.error("Attempt:"+ retryCount, e);
				Thread.sleep(1*30*1000); // 1/2 min
				if(retryCount == 3)
					throw e;
			}
		}
	}
	
	public EmployeeJobDto getJobDetails(String accessToken, long sso) throws Exception {
		int retryCount = 0;
		URL url = null;
		
		@SuppressWarnings("deprecation")
		String urlStr = careerexplorerJobApi + URLEncoder.encode("\""+sso+"\"");//+ " \"" + currentJob + "\"";
		while(true){
			retryCount++;
			try {
				
				// Job structure search
				url = new URL(urlStr);
				HttpURLConnection conn = (HttpURLConnection)url.openConnection();
				conn = (HttpsURLConnection) url.openConnection();
				conn.setDoOutput(true);
				conn.setRequestMethod("GET");
				conn.setRequestProperty("Authorization", "Bearer " +  accessToken);
				
				if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
					log.info("HTTP status code : " + conn.getResponseCode());
				}
				
				ObjectMapper mapper = new ObjectMapper();
				EmployeeJobDto nextRoles =   mapper.readValue(conn.getInputStream(), EmployeeJobDto.class);
				conn.disconnect();
				
				return nextRoles;
				
			} catch (MalformedURLException e) {
				log.error(e);
				throw e;
			} catch (IOException e) {
				log.error("Attempt:"+ retryCount, e);
				Thread.sleep(3*60*1000); // 3 mins
				if(retryCount == 3)
					throw e;
			}
		}
	}

	public EducationDto getSwoopEducationData(String accessToken, Long sso) {
		//int retryCount = 0;
		URL url = null;
		EducationDto educationList = new EducationDto();
		@SuppressWarnings("deprecation")
		String urlStr = swoopEducationApi + URLEncoder.encode(""+sso+"");
		//String urlStr = "https://stage.api.ge.com:443/digital/hrapi/v1/ms/swoop/education/" + URLEncoder.encode(""+sso+"");
		//while(true){
			//retryCount++;
			try {
				
				// Job structure search
				url = new URL(urlStr);
				HttpURLConnection conn = (HttpURLConnection)url.openConnection();
				conn = (HttpsURLConnection) url.openConnection();
				conn.setDoOutput(true);
				conn.setRequestMethod("GET");
				conn.setRequestProperty("Authorization", "Bearer " +  accessToken);
				
				if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
					log.info("HTTP status code : " + conn.getResponseCode());
				}
				
				ObjectMapper mapper = new ObjectMapper();
				educationList =   mapper.readValue(conn.getInputStream(), EducationDto.class);
				conn.disconnect();
				
				
			} catch (MalformedURLException e) {
				log.error(e);
			} catch (IOException e) {
				//log.error("Attempt:"+ retryCount, e);
				/*Thread.sleep(3*60*1000); // 3 mins
				if(retryCount == 3)
					throw e;*/
				log.error(e);
			}
			return educationList;
		//}
	}
}
