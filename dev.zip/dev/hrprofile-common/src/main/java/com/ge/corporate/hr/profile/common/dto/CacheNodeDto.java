/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.common.dto;

import java.util.Set;

public class CacheNodeDto extends AbstractBaseDtoSupport {

	private static final long serialVersionUID = 1L;

	Set<String> childNames;
	Set<String> keys;
	
	public Set<String> getChildNames() {
		return childNames;
	}

	public void setChildNames(Set<String> childNames) {
		this.childNames = childNames;
	}

	public Set<String> getKeys() {
		return keys;
	}

	public void setKeys(Set<String> keys) {
		this.keys = keys;
	}

	public long getId() {
		// TODO Auto-generated method stub
		return 0;
	}

}
