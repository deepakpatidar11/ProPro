package com.ge.corporate.hr.profile.common.cache.infinispan;

import java.io.Serializable;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.infinispan.notifications.Listener;
import org.infinispan.notifications.cachelistener.annotation.CacheEntryCreated;
import org.infinispan.notifications.cachelistener.annotation.CacheEntryModified;
import org.infinispan.notifications.cachelistener.annotation.CacheEntryRemoved;
import org.infinispan.notifications.cachelistener.annotation.TopologyChanged;
import org.infinispan.notifications.cachelistener.event.CacheEntryCreatedEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryModifiedEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryRemovedEvent;
import org.infinispan.notifications.cachelistener.event.TopologyChangedEvent;

@Listener
public class InfinispanCacheListener {
  private static Log log = LogFactory.getLog(InfinispanCacheListener.class);
  
  @CacheEntryCreated
  public void observeAdd(CacheEntryCreatedEvent<Serializable, Serializable> event) {
     if (event.isPre())
        return;

     log.info("Cache entry "+event.getKey()+" added in cache "+event.getCache());
  }

  @CacheEntryModified
  public void observeUpdate(CacheEntryModifiedEvent<Serializable, Serializable> event) {
     if (event.isPre())
        return;

     log.info("Cache entry "+event.getKey()+" = "+event.getValue()+" modified in cache "+event.getCache());
  }

  @CacheEntryRemoved
  public void observeRemove(CacheEntryRemovedEvent<Serializable, Serializable> event) {
     if (event.isPre())
        return;

     log.info("Cache entry "+event.getKey()+" removed in cache "+event.getCache());
  }

  @TopologyChanged
  public void observeTopologyChange(TopologyChangedEvent<Serializable, Serializable> event) {
     if (event.isPre())
        return;

     log.info("Cache "+event.getCache().getName()+" topology changed, new membership is "+ event.getConsistentHashAtEnd().getMembers());
  }
  
}

