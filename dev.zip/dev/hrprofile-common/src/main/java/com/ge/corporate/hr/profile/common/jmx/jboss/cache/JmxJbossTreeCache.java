/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.common.jmx.jboss.cache;

import java.util.Set;

import javax.annotation.Resource;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanException;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.ReflectionException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.infinispan.tree.Fqn;

import com.ge.corporate.hr.profile.common.jmx.MBreanServer;

public class JmxJbossTreeCache {
	
	@Resource(name="mBreanServer")
	private MBreanServer  server;
	
	public MBreanServer getServer() {
		return server;
	}

	public void setServer(MBreanServer server) {
		this.server = server;
	}

	private ObjectName name;
	private final Log logger = LogFactory.getLog(JmxJbossTreeCache.class);
	
	public JmxJbossTreeCache(){
		try{
			name = new ObjectName("jboss.infinispan.TreeCacheManager:type=TreeCache");
		}catch(MalformedObjectNameException mfe){
			logger.debug("Error Creating name");
		}
		
	}
	
	@SuppressWarnings("unchecked")
	public Set getChildrenNames(String fqn) throws ReflectionException,MBeanException,InstanceNotFoundException{
		
		if(server!=null && name != null){
			Object[] params = {new String(fqn)};
			String[] signature = {new String("java.lang.String")};				
			return (Set)server.invoke( name,"getChildrenNames", params, signature);
		}
		return null;		
	}		
	
	@SuppressWarnings("unchecked")
	public Set getKeys(String fqn) throws ReflectionException,MBeanException,InstanceNotFoundException{
		
		if(server!=null && name != null){
			Object[] params = {new String(fqn)};
			String[] signature = {new String("java.lang.String")};				
			return (Set)server.invoke( name,"getKeys", params, signature);
		}		
		return null;		
	}		
	
	
	public Object get(String fqn, String key) throws ReflectionException,MBeanException,InstanceNotFoundException{
		
		if(server!=null && name != null){
			Object[] params = {new String(fqn),(Object)(new String(key))};
			String[] signature = {new String("java.lang.String"), new String("java.lang.Object")};				
			return (Object)server.invoke( name,"get", params, signature);
		}		
		return null;		
	}
	
	public void evict(String sFqn) throws ReflectionException,MBeanException,InstanceNotFoundException{
		if(sFqn != null && sFqn.length() > 0){			
			sFqn = sFqn.substring(1);		
			Fqn fqn = Fqn.fromString(sFqn);			
			if(server!=null && name != null && fqn!=null){
				Object[] params = {fqn};
				String[] signature = {new String("org.infinispan.tree.Fqn")};				
				server.invoke( name,"evict", params, signature);
			}		
		}
	}
}
