package com.ge.corporate.hr.profile.common.dto;

public class EmployeeJobDetails {
	 private int number;
		private String startDate;
		private String corporateBand;
		private String sso;
		private String jobType;
		private String jobFamily;
		private String currentFlag;
		public int getNumber() {
			return number;
		}
		public void setNumber(int number) {
			this.number = number;
		}
		
		public String getStartDate() {
			return startDate;
		}
		public void setStartDate(String startDate) {
			this.startDate = startDate;
		}
		public String getCorporateBand() {
			return corporateBand;
		}
		public void setCorporateBand(String corporateBand) {
			this.corporateBand = corporateBand;
		}
		public String getSso() {
			return sso;
		}
		public void setSso(String sso) {
			this.sso = sso;
		}
		public String getJobType() {
			return jobType;
		}
		public void setJobType(String jobType) {
			this.jobType = jobType;
		}
		public String getJobFamily() {
			return jobFamily;
		}
		public void setJobFamily(String jobFamily) {
			this.jobFamily = jobFamily;
		}
		public String getCurrentFlag() {
			return currentFlag;
		}
		public void setCurrentFlag(String currentFlag) {
			this.currentFlag = currentFlag;
		}
		

}
