/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.common.exception;

public class EmptyResultDataAccessException extends AbstractBaseException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2198348197599312124L;

	public EmptyResultDataAccessException(String message) {
		super(message);		
	}
}
