package com.ge.corporate.hr.profile.common.cache;

import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;

import org.infinispan.jmx.MBeanServerLookup;

import java.util.Properties;

/**
 * Creates an MBeanServer on each thread.
 *
 */
public class PerThreadMBeanServerLookup implements MBeanServerLookup {

   static ThreadLocal<MBeanServer> threadMBeanServer = new ThreadLocal<MBeanServer>();

   public MBeanServer getMBeanServer(Properties properties) {
      return getThreadMBeanServer();
   }

   public static MBeanServer getThreadMBeanServer() {
      MBeanServer beanServer = threadMBeanServer.get();
      if (beanServer == null) {
         beanServer = MBeanServerFactory.createMBeanServer();
         threadMBeanServer.set(beanServer);
      }
      return beanServer;
   }
}