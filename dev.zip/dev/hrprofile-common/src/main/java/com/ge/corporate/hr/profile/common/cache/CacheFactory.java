package com.ge.corporate.hr.profile.common.cache;

public abstract interface CacheFactory {

	public abstract CacheSupport getCache(String cacheName) throws Exception;
	
	public abstract void clearCache(String cacheName) throws Exception;
	
	public abstract void clearCache() throws Exception;

}
