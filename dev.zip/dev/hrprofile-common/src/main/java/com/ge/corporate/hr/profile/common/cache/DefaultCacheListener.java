package com.ge.corporate.hr.profile.common.cache;

import java.io.Serializable;

public class DefaultCacheListener
  implements CacheListener
{
  public void onPut(Serializable key, Serializable value, CacheSupport cacheSupport)
    throws CacheException
  {}
}
