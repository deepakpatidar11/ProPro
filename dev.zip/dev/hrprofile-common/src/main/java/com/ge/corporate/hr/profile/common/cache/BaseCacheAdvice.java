package com.ge.corporate.hr.profile.common.cache;

import java.io.Serializable;
import java.util.concurrent.ConcurrentHashMap;

import org.aspectj.lang.ProceedingJoinPoint;

import com.ge.corporate.hr.profile.common.cache.CacheFactory;

public abstract class BaseCacheAdvice {

	public static final String HRCOMMON_CACHE_DISABLE = "disableCache";

	protected CacheFactory cacheFactory;

	public CacheFactory getCacheFactory() {
		return this.cacheFactory;
	}

	public void setCacheFactory(
			CacheFactory cacheFactory) {
		this.cacheFactory = cacheFactory;
	}

	protected String createRegionName(ProceedingJoinPoint pjp,
			KeyGenerator<String> rgen) throws CacheException, Throwable {
		// generate the key
		String region = rgen.generateKey(pjp.getSignature()
				.getDeclaringTypeName(), pjp.getSignature().getName(), pjp
				.getArgs());

		return region;
	}

	protected Serializable createKey(ProceedingJoinPoint pjp,
			KeyGenerator<? extends Serializable> kgen) throws CacheException,
			Throwable {
		// generate the key
		Serializable key = kgen.generateKey(pjp.getSignature()
				.getDeclaringTypeName(), pjp.getSignature().getName(), pjp
				.getArgs());

		return key;
	}

	private CacheComponentFactory<KeyGenerator<String>> regionNameGeneratorFactory = new CacheComponentFactory<KeyGenerator<String>>();
	private CacheComponentFactory<KeyGenerator<? extends Serializable>> keyGeneratorFactory = new CacheComponentFactory<KeyGenerator<? extends Serializable>>();

	protected KeyGenerator<String> getRegionNameGenerator(
			Class<? extends KeyGenerator<String>> clazz) throws Throwable {
		return this.regionNameGeneratorFactory.getComponent(clazz);
	}

	protected KeyGenerator<? extends Serializable> getKeyGenerator(
			Class<? extends KeyGenerator<? extends Serializable>> clazz)
			throws Throwable {
		return this.keyGeneratorFactory.getComponent(clazz);
	}

	protected boolean isCacheEnabled() {
		boolean enabled = false;
		if ("true".equals(System.getProperty(HRCOMMON_CACHE_DISABLE))) {
			enabled = false;
		} else {
			enabled = true;
		}
		return enabled;
	}

	protected class CacheComponentFactory<T> {
		private ConcurrentHashMap<Class<? extends T>, T> component = new ConcurrentHashMap<Class<? extends T>, T>();

		public T getComponent(Class<? extends T> clazz) throws Throwable {
			T c = null;
			if (component.containsKey(clazz)) {
				c = component.get(clazz);
			} else {
				c = clazz.newInstance();
				component.put(clazz, c);
			}
			return c;
		}
	}
}
