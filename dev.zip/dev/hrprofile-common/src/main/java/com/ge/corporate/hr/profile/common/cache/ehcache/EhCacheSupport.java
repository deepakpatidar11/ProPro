package com.ge.corporate.hr.profile.common.cache.ehcache;

import java.io.Serializable;

import javax.annotation.PreDestroy;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ge.corporate.hr.profile.common.cache.CacheException;
import com.ge.corporate.hr.profile.common.cache.CacheSupport;

public class EhCacheSupport implements CacheSupport {
	private static Log log = LogFactory.getLog(EhCacheSupport.class);
	
	private String cacheName;
	
	private CacheManager cacheManager;

	public EhCacheSupport(CacheManager cacheManager, String cacheName) {
		this.cacheManager = cacheManager;
		this.cacheName = cacheName;
	}
	
	private Cache getCache(String cacheName){
	    return this.cacheManager.getCache(cacheName);
	}

	public boolean exists(Serializable key) throws CacheException {
		if (getCache(this.cacheName) != null) {
			if (getCache(this.cacheName).get(key) != null) {
	    		return true;
	    	}
		}
		return false;
	}

	public Serializable get(Serializable key) throws CacheException {
		if (getCache(this.cacheName) != null) {
			 Element element = getCache(this.cacheName).get(key);
			 if (element != null) {
			      return (Serializable) element.getObjectValue();
			 }
		}
		return null;
	}

	public void put(Serializable key, Serializable value) throws CacheException {
		if (getCache(this.cacheName) != null) {
			getCache(this.cacheName).put(new Element(key, value));
		}
	}

	public void remove(Serializable key) throws CacheException {
		if (getCache(this.cacheName) != null) {
			getCache(this.cacheName).remove(key);
		}
	}

	@PreDestroy
	public void destroy() throws Exception {
		CacheManager.getInstance().shutdown();
	}

	public void clear() throws Exception {
		getCache(this.cacheName).removeAll();
	}

}
