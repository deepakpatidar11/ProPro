package com.ge.corporate.hr.profile.common.util;

import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * <p>
 * This class is used to reduce the memory footprint of our cached entities.
 * There are certain attributes on such as Job Title and Job Function, Location
 * Style, etc., which are repeated across many entities and result in many
 * thousands of redundant Immutable objects in the Heap. The intent of this class is to
 * eliminate redundant instances of Immutable objects in memory.
 * </p>
 * <p>
 * Flyweight object instances are stored in a WeakHashMap so that they are
 * garbage collected when nothing else in the heap references them.
 * </p>
 * <p>
 * The WeakHashMap is a singleton per JVM, so we wrap it in a syncrhonized
 * collection to avoid thread safety issues.
 * </p>
 * <p>
 * BE CAREFUL, INCORRECT USE OF THIS CLASS MAY RESULT IN MEMORY LEAKS. IT ALSO
 * USES A SYNCHRONIZED MAP FOR STORAGE, SO MAY CREATE LOCK CONTENTION IN
 * MULTI-THREADED ENVIRONMENTS. ONLY USE THIS CLASS IF YOU ARE SURE YOU KNOW
 * WHAT YOU ARE DOING.
 * </p>
 * 
 * @author 200017779
 * 
 */
final public class StringFlyweight {

	private StringFlyweight() {
	}

	/**
	 * 
	 * Use a weakly referenced hashmap so that our flyweights are garbage
	 * collection if nothing else in the heap references them.
	 */
	private static final Map<String, WeakReference<String>> map = Collections
			.synchronizedMap(new WeakHashMap<String, WeakReference<String>>(
					100000));

	/**
	 * Converts a immutable object into it's Flyweight equivalent. Consistent use of
	 * getFlyweight will ensure that duplicate instances of objects are shared.
	 * 
	 * <p>
	 * EX: The following strings will be separate instances on the heap String
	 * s1 = new String("foo"); String s2 = new String("foo");
	 * </p>
	 * <p>
	 * EX: The following strings will share a single instance and use 50% less
	 * heap space String s1 =  (String) StringFlyweight.getFlyWeight(new String("foo"));
	 * String s2 = (String)StringFlyweight.getFlyWeight(new String("foo"));
	 * </p>
	 * 
	 * @param input
	 *            Any immutable object
	 * @return a Flyweight instance of the object provided
	 */
	public static String getFlyweight(String input) {
		if (input == null) {
			return null;
		}
		synchronized (map) {
			WeakReference<String> reference = map.get(input);
			// check to see if the string exists
			if (reference != null) {
				// check again if we get just in case GC happened
				// concurrently
				String result = reference.get();
				if (result != null) {
					return result;
				}
			}
			// flyweight not present. Create a new one and return
			map.put(input, new WeakReference<String>(input));
			return input;
		}
	}
}
