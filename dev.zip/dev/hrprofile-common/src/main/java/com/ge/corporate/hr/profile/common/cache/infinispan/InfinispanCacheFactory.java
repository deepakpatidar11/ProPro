package com.ge.corporate.hr.profile.common.cache.infinispan;

import javax.annotation.PostConstruct;

import com.ge.corporate.hr.profile.common.cache.CacheFactory;
import com.ge.corporate.hr.profile.common.cache.CacheSupport;

public class InfinispanCacheFactory implements CacheFactory {

	public static final String DEFAULTCACHE = "profile-cache";
	public static final String EMPSERVICECACHE = "profile-employee-service";
	public static final String EMPDAOCACHE = "profile-employee-dao";
	public static final String AUTHEVALCACHE = "profile-auth-profileAuthorityEvaluator";
	public static final String AUTHDAOCACHE = "profile-auth-dao";
	public static final String SEARCHCACHE = "profile-search";
	public static final String PROPERTYCACHE = "profile-properties";

	private CacheSupport defaultCacheSupport;
	private CacheSupport empServiceCacheSupport;
	private CacheSupport empDaoCacheSupport;
	private CacheSupport authEvalCacheSupport;
	private CacheSupport authDaoCacheSupport;
	private CacheSupport searchCacheSupport;
	private CacheSupport propertyCacheSupport;

	@PostConstruct
	public void initCache() throws Exception {

	}

	public InfinispanCacheFactory() throws Exception {
		this.defaultCacheSupport = new InfinispanCacheSupport(DEFAULTCACHE);
		this.empServiceCacheSupport = new InfinispanCacheSupport(EMPSERVICECACHE);
		this.empDaoCacheSupport = new InfinispanCacheSupport(EMPDAOCACHE);
		this.authEvalCacheSupport = new InfinispanCacheSupport(AUTHEVALCACHE);
		this.authDaoCacheSupport = new InfinispanCacheSupport(AUTHDAOCACHE);
		this.searchCacheSupport = new InfinispanCacheSupport(SEARCHCACHE);
		this.propertyCacheSupport = new InfinispanCacheSupport(PROPERTYCACHE);
	}

	public CacheSupport getCache(String cacheName) throws Exception {
		switch (cacheName) {
		case EMPSERVICECACHE:
			return this.empServiceCacheSupport;
		case EMPDAOCACHE:
			return this.empDaoCacheSupport;
		case AUTHEVALCACHE:
			return this.authEvalCacheSupport;
		case AUTHDAOCACHE:
			return this.authDaoCacheSupport;
		case SEARCHCACHE:
			return this.searchCacheSupport;
		case PROPERTYCACHE:
			return this.propertyCacheSupport;
		default:
			return this.defaultCacheSupport;
		}

	}

	public void clearCache(String cacheName) throws Exception {
		switch (cacheName) {
		case EMPSERVICECACHE:
			this.empServiceCacheSupport.clear();
		case EMPDAOCACHE:
			this.empDaoCacheSupport.clear();
		case AUTHEVALCACHE:
			this.authEvalCacheSupport.clear();
		case AUTHDAOCACHE:
			this.authDaoCacheSupport.clear();
		case SEARCHCACHE:
			this.searchCacheSupport.clear();
		case PROPERTYCACHE:
			this.propertyCacheSupport.clear();
		default:
			this.defaultCacheSupport.clear();
		}
	}

	public void clearCache() throws Exception {
		this.empServiceCacheSupport.clear();
		this.empDaoCacheSupport.clear();
		this.authEvalCacheSupport.clear();
		this.authDaoCacheSupport.clear();
		this.searchCacheSupport.clear();
		this.propertyCacheSupport.clear();
		this.defaultCacheSupport.clear();
	}

}
