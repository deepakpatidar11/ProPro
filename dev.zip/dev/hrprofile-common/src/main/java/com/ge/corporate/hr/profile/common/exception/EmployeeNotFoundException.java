package com.ge.corporate.hr.profile.common.exception;

public class EmployeeNotFoundException extends AbstractBaseException {

	private static final long serialVersionUID = 8055378176632521072L;
	
	public EmployeeNotFoundException(String message) {
		super(message);
	}
}
