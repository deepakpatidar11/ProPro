package com.ge.corporate.hr.profile.common.dto;

public class RecommendedLearningDto {

	private String description;
	private LearningVotes votes;
	private long likes;
	private long shares;
	private long comment_count;
	private long id;
	private String image;
	private String asset_type;
	private String cost;
	private String title;
	private long like_count;
	private long share_count;
	private String course_price;
	private long nid;
	private String image_small;
	private LearningVotes rating_count;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public LearningVotes getVotes() {
		return votes;
	}

	public void setVotes(LearningVotes votes) {
		this.votes = votes;
	}

	public long getLikes() {
		return likes;
	}

	public void setLikes(long likes) {
		this.likes = likes;
	}

	public long getShares() {
		return shares;
	}

	public void setShares(long shares) {
		this.shares = shares;
	}

	public long getComment_count() {
		return comment_count;
	}

	public void setComment_count(long comment_count) {
		this.comment_count = comment_count;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getAsset_type() {
		return asset_type;
	}

	public void setAsset_type(String asset_type) {
		this.asset_type = asset_type;
	}

	public String getCost() {
		return cost;
	}

	public void setCost(String cost) {
		this.cost = cost;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public long getLike_count() {
		return like_count;
	}

	public void setLike_count(long like_count) {
		this.like_count = like_count;
	}

	public long getShare_count() {
		return share_count;
	}

	public void setShare_count(long share_count) {
		this.share_count = share_count;
	}

	public String getCourse_price() {
		return course_price;
	}

	public void setCourse_price(String course_price) {
		this.course_price = course_price;
	}

	public long getNid() {
		return nid;
	}

	public void setNid(long nid) {
		this.nid = nid;
	}

	public String getImage_small() {
		return image_small;
	}

	public void setImage_small(String image_small) {
		this.image_small = image_small;
	}
	public LearningVotes getRating_count() {
		return rating_count;
	}
	public void setRating_count(LearningVotes rating_count) {
		this.rating_count = rating_count;
	}
}
