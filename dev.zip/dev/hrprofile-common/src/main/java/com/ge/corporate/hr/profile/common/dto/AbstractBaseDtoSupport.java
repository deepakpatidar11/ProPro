/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.common.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

/**
 * Base DTO Support
 * @author enrique.romero
 *
 */
@XmlAccessorType(XmlAccessType.NONE)
public abstract class AbstractBaseDtoSupport implements BaseDtoSupport,Serializable{

	private static final long serialVersionUID = 4210631282590961008L;

	/**
	 * Flag that helps to know if a rest service failed or succeeded
	 */
	@XmlTransient
	private boolean success = true;
	
	/**
	 * Error Message in case application fails
	 */	
	@XmlTransient
	private String errorMessage;	
	
	public boolean getSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getErrorMesage() {
		return errorMessage;
	}
	public void setErrorMesage(String mesage) {
		this.errorMessage = mesage;
	}
	
}
