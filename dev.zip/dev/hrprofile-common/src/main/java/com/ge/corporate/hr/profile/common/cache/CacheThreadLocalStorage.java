package com.ge.corporate.hr.profile.common.cache;

public class CacheThreadLocalStorage
{
  private static ThreadLocal<Boolean> cacheOverwriteOnRead = new ThreadLocal<Boolean>();
  
  public static void setCacheOverwriteOnRead(Boolean value)
  {
    cacheOverwriteOnRead.set(value);
  }
  
  public static Boolean getCacheOverwriteOnRead()
  {
    return cacheOverwriteOnRead.get();
  }
  
  public static void remove()
  {
    cacheOverwriteOnRead.remove();
  }
}
