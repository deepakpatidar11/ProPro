package com.ge.corporate.hr.profile.common.cache;

public abstract interface KeyGenerator<T>
{
  public abstract T generateKey(String paramString1, String paramString2, Object[] paramArrayOfObject);
}
