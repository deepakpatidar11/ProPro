/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.common.jmx;

import javax.management.InstanceNotFoundException;
import javax.management.MBeanException;
import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.ObjectName;
import javax.management.ReflectionException;

public class MBreanServer {
	
	private MBeanServer server = null;
	
	MBreanServer(){
		server = (MBeanServer) MBeanServerFactory.findMBeanServer(null).get(0);
	}
	
	public Object invoke(ObjectName name,
            String operationName,
            Object[] params,
            String[] signature)
            throws InstanceNotFoundException,
                   MBeanException,
                   ReflectionException{		
		return server.invoke(name, operationName,params, signature);	
	}
	
}
