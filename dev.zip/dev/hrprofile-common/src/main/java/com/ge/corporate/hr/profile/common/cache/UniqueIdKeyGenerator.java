package com.ge.corporate.hr.profile.common.cache;

import java.io.Serializable;

public class UniqueIdKeyGenerator
  implements KeyGenerator<Serializable>
{
  public Serializable generateKey(String declaringTypeName, String name, Object[] args)
  {
    return (Serializable)args[0];
  }
}
