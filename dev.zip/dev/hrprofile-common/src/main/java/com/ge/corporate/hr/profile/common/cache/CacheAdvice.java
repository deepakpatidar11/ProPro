package com.ge.corporate.hr.profile.common.cache;

import java.io.Serializable;

import org.apache.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class CacheAdvice extends BaseCacheAdvice {

	private static final String EXCEPTION_CACHE_NAME_POSTFIX = "exception";

	private static final Logger LOG = Logger.getLogger(CacheAdvice.class);

	@Around("@annotation(cache)")
	public Object cache(ProceedingJoinPoint pjp, Cache cache) throws Throwable {
		return cache(pjp, cache.nodeName(), cache.regionNameGeneratorClass(),
				cache.keyGeneratorClass(), cache.cacheListenerClass(),
				cache.cacheExceptions(), cache.cacheName());
	}

	public Object cache(
			ProceedingJoinPoint pjp,
			String nodeName,
			Class<? extends KeyGenerator<String>> regionNameGeneratorClass,
			Class<? extends KeyGenerator<? extends Serializable>> keyGeneratorClass,
			Class<? extends CacheListener> cacheListenerClass,
			boolean cacheExceptions, String cacheName) throws Throwable {
		Object rval = null;
		String region = null;
		Serializable key = null;
		KeyGenerator<String> rgen = null;
		KeyGenerator<? extends Serializable> kgen = null;
		CacheListener list = null;
		CacheSupport cacheSupport = null;

		if (isCacheEnabled()) {

			list = (CacheListener) this.cacheListenerFactory
					.getComponent(cacheListenerClass);
			//rgen = getRegionNameGenerator(regionNameGeneratorClass);
			kgen = getKeyGenerator(keyGeneratorClass);

			//region = nodeName;		

			/*
			 * if(createRegionName(pjp, rgen).equalsIgnoreCase("")){ region =
			 * "/" + createRegionName(pjp, rgen); }
			 */

			// Changed the above logic

//			String dynamicRegionName = createRegionName(pjp, rgen);
//			if (!"".equalsIgnoreCase(dynamicRegionName)) {
//				region = region + "/" + dynamicRegionName;
//			}

			key = createKey(pjp, kgen);

			cacheSupport = this.cacheFactory.getCache(cacheName);

			if (cacheSupport.exists(key)) {
				// if ((CacheThreadLocalStorage.getCacheOverwriteOnRead() ==
				// null) ||
				// (!CacheThreadLocalStorage.getCacheOverwriteOnRead().booleanValue()))
				// {
				rval = loadFromCache(cacheSupport, key);
			}
			if (rval != null) {
				return rval;
			}
			if (cacheExceptions) {
				Throwable ex = loadExceptionFromCache(cacheSupport, key);
				if (ex != null) {
					throw ex;
				}
			}
		}
		try {
			rval = (Serializable) pjp.proceed(pjp.getArgs());
		} catch (Exception ex) {
			if ((isCacheEnabled()) && (cacheExceptions)) {
				storeExceptionToCache(cacheSupport, key, ex);
			}
			throw ex;
		}
		if (isCacheEnabled()) {
			storeToCache(cacheSupport, key, (Serializable) rval, list);
		}
		return rval;
	}

	private Object loadFromCache(CacheSupport cacheSupport,
			Serializable key) throws CacheException {
		if (cacheSupport.exists(key)) {
			return cacheSupport.get(key);
		}
		return null;
	}

	private Throwable loadExceptionFromCache(CacheSupport cacheSupport,
			Serializable key) throws CacheException {
		if (cacheSupport.exists(createExceptionRegion(key))) {
			return (Throwable) cacheSupport.get(createExceptionRegion(key));
		}
		return null;
	}

	private void storeToCache(CacheSupport cacheSupport,
			Serializable key, Serializable value, CacheListener listener)
			throws CacheException {
		cacheSupport.put(key, value);
		if (listener != null) {
			listener.onPut(key, value, cacheSupport);
		}
	}

	private void storeExceptionToCache(CacheSupport cacheSupport,
			Serializable key, Throwable t) throws CacheException {
		cacheSupport.put(createExceptionRegion(key), t);
	}

	private Serializable createExceptionRegion(Serializable key) {
		return (Serializable)String.format("%s_%s", new Object[] { key, "exception" });
	}

	private BaseCacheAdvice.CacheComponentFactory<CacheListener> cacheListenerFactory = new BaseCacheAdvice.CacheComponentFactory<CacheListener>();
}
