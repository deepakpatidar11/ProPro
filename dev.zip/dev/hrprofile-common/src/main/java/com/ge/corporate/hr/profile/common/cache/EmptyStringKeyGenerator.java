package com.ge.corporate.hr.profile.common.cache;

public class EmptyStringKeyGenerator
  implements KeyGenerator<String>
{
  public String generateKey(String declaringTypeName, String methodName, Object[] args)
  {
    return "";
  }
}
