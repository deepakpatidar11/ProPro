package com.ge.corporate.hr.profile.common.util;

public class ProfileStringUtil {
	
	/**
	 * Replaces characters encoded as [$HEX] to Unicode HEX value.
	 * This encoding is used to bypass GE's server single quote secuirty restrictions
	 * as single quote is considered to be part of malicious code attaks.
	 * 
	 * @param var
	 * @return
	 */
	public static String replaceHexadecimalCharacters(String var){				
		int startIndex = -1;
		
		startIndex = var.indexOf("[$");
		
		while(startIndex!= -1){
			String temp;
			int endIndex = var.indexOf("]", startIndex);
			if(endIndex != -1){
				temp = var.substring(startIndex+2,endIndex);			
				int intVal= Integer.parseInt(temp,16);
				
				var = var.replace(var.substring(startIndex,endIndex+1), String.valueOf((char)intVal));
				startIndex = var.indexOf("[$",endIndex);				
			}else{
				break;
			}				
		}		
		return var;		
	}
	/**
	 * Removes comas and extra spaces between two strings 
	 * 
	 * @param query
	 * @return
	 */
	public static String searchQueryCleanUp(String query){
		
		query = query.replace(",","").trim();
		query = query.replaceAll("\\s{2,}", " ");
		query = ProfileStringUtil.replaceHexadecimalCharacters(query);
		
		return query;
	}
	
	/**
	 * Compares the input string and returns true if the value is an Integer.
	 * @param input
	 * @return
	 */
	public static boolean isInteger( String input )   
	{   
	   try  
	   {   
	      Integer.parseInt( input );   
	      return true;   
	   }catch (NumberFormatException nfe){		
		   return false;
	   }
	   
	}
}
