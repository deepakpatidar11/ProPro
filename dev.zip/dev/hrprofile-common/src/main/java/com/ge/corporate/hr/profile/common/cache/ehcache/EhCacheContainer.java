package com.ge.corporate.hr.profile.common.cache.ehcache;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;

public class EhCacheContainer {

	private static final String EHCACHE_CONFIGURATION = "ehcache.xml";

	private static final CacheManager CACHE_MANAGER;

	static {
		try {		
			CACHE_MANAGER = CacheManager.newInstance(EHCACHE_CONFIGURATION);
		} catch (Exception e) {
			throw new RuntimeException("Unable to configure EhCache", e);
		}
	}

	public static Cache getCache(String cacheName) {
		if (cacheName == null)
			throw new NullPointerException("Cache name cannot be null!");
		return CACHE_MANAGER.getCache(cacheName);
	}

	public static CacheManager getCacheContainer() {
		return CACHE_MANAGER;
	}
	
}