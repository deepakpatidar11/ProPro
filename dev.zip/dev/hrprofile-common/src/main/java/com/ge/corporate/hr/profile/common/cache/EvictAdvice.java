package com.ge.corporate.hr.profile.common.cache;

import java.io.Serializable;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

import com.ge.corporate.hr.profile.common.cache.BaseCacheAdvice;

@Aspect
public class EvictAdvice extends BaseCacheAdvice {
	private static Log log = LogFactory.getLog(EvictAdvice.class);

	@Around("@annotation(evict)")
	public Object evict(ProceedingJoinPoint pjp, Evict evict) throws Throwable {

		Object rval = null;
		String region = null;
		Serializable key = null;
		KeyGenerator<String> rgen = null;
		KeyGenerator<? extends Serializable> kgen = null;
		CacheSupport cacheSupport = null;

		if (isCacheEnabled()) {
			//rgen = getRegionNameGenerator(evict.regionNameGeneratorClass());
			kgen = getKeyGenerator(evict.keyGeneratorClass());

			//region = evict.nodeName() + "/" + createRegionName(pjp, rgen);
			key = createKey(pjp, kgen);
			cacheSupport = this.cacheFactory.getCache(evict
					.cacheName());
			try {
				if ((key != null)
						&& ((!(key instanceof String)) || (((String) key)
								.length() > 0))) {
					evictFromCache(cacheSupport, key);
				}
			} catch (Exception e) {
				log.warn(String.format("eviction failed.  region: %s key: %s",
						new Object[] { region, key }), e);
			}
		}
		rval = (Serializable) pjp.proceed(pjp.getArgs());

		return rval;
	}

	private void evictFromCache(CacheSupport cacheSupport, Serializable key) throws CacheException {
		cacheSupport.remove(key);
	}

}
