package com.ge.corporate.hr.profile.common.cache;

import java.io.Serializable;
import java.lang.annotation.Documented;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ java.lang.annotation.ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface Cache {
	String nodeName();

	boolean cacheExceptions() default false;

	Class<? extends KeyGenerator<String>> regionNameGeneratorClass() default EmptyStringKeyGenerator.class;

	Class<? extends KeyGenerator<? extends Serializable>> keyGeneratorClass() default UniqueIdKeyGenerator.class;

	Class<? extends CacheListener> cacheListenerClass() default DefaultCacheListener.class;

	String cacheName() default "profile-cache";

}
