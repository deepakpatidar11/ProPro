package com.ge.corporate.hr.profile.common.cache;

public class MethodSignatureKeyGenerator
  implements KeyGenerator<String>
{
  public String generateKey(String className, String methodName, Object[] args)
  {
    StringBuilder sb = new StringBuilder();
    sb.append(className).append("_").append(methodName);
    for (Object a : args) {
      sb.append("_").append(a);
    }
    return sb.toString();
  }
}