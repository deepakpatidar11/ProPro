package com.ge.corporate.hr.profile.common.dto;

import java.util.List;

public class EmployeeJobDto {
	private int totalEECount;
	private int page;
	private int totalPageCount;
	private int pageSize;
	private int totalResultCount;
	private List<EmployeeJobDetails> data;

	public List<EmployeeJobDetails> getData() {
		return data;
	}

	public void setData(List<EmployeeJobDetails> data) {
		this.data = data;
	}

	public int getTotalEECount() {
		return totalEECount;
	}

	public void setTotalEECount(int totalEECount) {
		this.totalEECount = totalEECount;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getTotalPageCount() {
		return totalPageCount;
	}

	public void setTotalPageCount(int totalPageCount) {
		this.totalPageCount = totalPageCount;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getTotalResultCount() {
		return totalResultCount;
	}

	public void setTotalResultCount(int totalResultCount) {
		this.totalResultCount = totalResultCount;
	}

}
