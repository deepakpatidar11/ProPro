/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.common.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;


/**
 * @author sv808137
 *
 */
@XmlRootElement(name="education")
@XmlAccessorType(XmlAccessType.FIELD)
public class Education extends AbstractBaseModelSupport {
	
	private static final long serialVersionUID = -7194589138135889739L;

	@XmlElement(name="sso")
	private Long sso;
	
	@XmlElement(name="eduType")
	private String eduType;
	
	@XmlElement(name="degree")
	private String degree;	
	
	@XmlElement(name="major")
	private String major;	
	
	@XmlElement(name="university")
	private String university;
	
	@XmlElement(name="country")
	private String country;
	
	@XmlElement(name="major2")
	private String major2;
	
	@XmlElement(name="graduationYear")
	private Short graduationYear;
	
	@XmlElement(name="school")
	private String school;
	
	@XmlElement(name="diplomaCertificate")
	private String diplomaCertificate;
	
	@XmlElement(name="location")
	private String location;
	
	@XmlElement(name="status")
	private String status;

	@XmlElement(name="countryCode")
	private String countryCode;

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public String getEduType() {
		return eduType;
	}

	public void setEduType(String eduType) {
		this.eduType = eduType;
	}

	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public String getUniversity() {
		return university;
	}

	public void setUniversity(String university) {
		this.university = university;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getMajor2() {
		return major2;
	}

	public void setMajor2(String major2) {
		this.major2 = major2;
	}

	public Short getGraduationYear() {
		return graduationYear;
	}

	public void setGraduationYear(Short graduationYear) {
		this.graduationYear = graduationYear;
	}

	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

	public String getDiplomaCertificate() {
		return diplomaCertificate;
	}

	public void setDiplomaCertificate(String diplomaCertificate) {
		this.diplomaCertificate = diplomaCertificate;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}


}
