package com.ge.corporate.hr.profile.common.dto;

public class PotentialNextRole {

	private String jobTypeFrom;
	private String jobTypeTo;
	private int eeCount;
	private String countryList;
	private String functionList;
	private String ifgList;
	private int vacancyCount;
	public String getJobTypeFrom() {
		return jobTypeFrom;
	}
	public void setJobTypeFrom(String jobTypeFrom) {
		this.jobTypeFrom = jobTypeFrom;
	}
	public String getJobTypeTo() {
		return jobTypeTo;
	}
	public void setJobTypeTo(String jobTypeTo) {
		this.jobTypeTo = jobTypeTo;
	}
	public int getEeCount() {
		return eeCount;
	}
	public void setEeCount(int eeCount) {
		this.eeCount = eeCount;
	}
	public String getCountryList() {
		return countryList;
	}
	public void setCountryList(String countryList) {
		this.countryList = countryList;
	}
	public String getFunctionList() {
		return functionList;
	}
	public void setFunctionList(String functionList) {
		this.functionList = functionList;
	}
	public String getIfgList() {
		return ifgList;
	}
	public void setIfgList(String ifgList) {
		this.ifgList = ifgList;
	}
	public int getVacancyCount() {
		return vacancyCount;
	}
	public void setVacancyCount(int vacancyCount) {
		this.vacancyCount = vacancyCount;
	}
	
}
