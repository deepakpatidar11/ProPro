/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.common.dao;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;
/**
 * Base Dao for each dao in project, this class initializes daos, 
 * contains a map that stores all queries for the dao that extends this abstract class  
 * @author enrique.romero
 *
 */
public abstract class AbstractBaseDaoSupport extends SimpleJdbcDaoSupport{
   
	protected static final String PLACEHOLDER = "?";
	protected static final String PLACEHOLDER_TUPLE = "(?,0)";
    protected static final String PLACEHOLDER_NEEDLE = "[?]";
    protected static final String PLACEHOLDER_SEP = ",";
    protected static final String WILDCARD = "%";
    
    private Map<String, String> sqlMap; 
    public void setSqlMap(Map<String, String> sqlMap) {
        this.sqlMap = sqlMap;
    }
    public String getSql(String id) { 
    	return this.sqlMap.get(id);
    }
    
    /**
     * 
     * @param initialQuery
     * @param parameterList
     * @return
     */
    protected String dynamicPlaceHolderSet(String initialQuery, Collection<?> parameterList){
    	StringBuilder placeHolders = new StringBuilder();
    	String query;
    	for(int cc = 0; cc < parameterList.size(); cc++){
    		String separator = ( (cc +1)== parameterList.size() )? "": PLACEHOLDER_SEP;
    		placeHolders.append( PLACEHOLDER + separator);
    	}
    	
    	query = initialQuery.replace( PLACEHOLDER_NEEDLE, placeHolders.toString());
    	
    	
    	return query;
    }
    
    protected String dynamicPlaceHolderSetForTuple(String initialQuery, Collection<?> parameterList){
    	StringBuilder placeHolders = new StringBuilder();
    	String query;
    	for(int cc = 0; cc < parameterList.size(); cc++){
    		String separator = ( (cc +1)== parameterList.size() )? "": PLACEHOLDER_SEP;
    		placeHolders.append( PLACEHOLDER_TUPLE + separator);
    	}
    	
    	query = initialQuery.replace( PLACEHOLDER_NEEDLE, placeHolders.toString());
    	
    	
    	return query;
    }
    /**
     * 
     * @param initialQuery
     * @param parameterList
     * @return
     */
    protected String dynamicMultiplePlaceHolderSet(String initialQuery, Collection<Collection<?>> parameterList){
    	
    	for(Collection<?> item : parameterList){
    		if(item instanceof Collection){
    			initialQuery = dynamicPlaceHolderSet(initialQuery, item);
    		}
    	}
    	
    	return initialQuery;
    }
    
    /*
		to replace "-" with ","
     */
    protected List<String> replaceHyphenWithComma(List<String> parameterList){
    	
    	for(int i=0; i<parameterList.size(); i++){
    		parameterList.set(i, parameterList.get(i).replaceAll("-", ","));
			}
    	
    	return parameterList;
    }
    
    
}