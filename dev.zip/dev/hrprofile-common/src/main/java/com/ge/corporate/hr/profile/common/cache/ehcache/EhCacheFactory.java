package com.ge.corporate.hr.profile.common.cache.ehcache;

import javax.annotation.PostConstruct;

import net.sf.ehcache.CacheManager;

import com.ge.corporate.hr.profile.common.cache.CacheFactory;
import com.ge.corporate.hr.profile.common.cache.CacheSupport;

public class EhCacheFactory implements CacheFactory {

	public static final String DEFAULTCACHE = "com.ge.corporate.hr";
	public static final String EMPCACHE = "com.ge.corporate.hr";

	private CacheSupport defaultCacheSupport;
	private CacheSupport empCacheSupport;
	
	private final CacheManager cacheManager;

	@PostConstruct
	public void initCache() throws Exception {

	}

	public EhCacheFactory(CacheManager cacheManager) throws Exception {
		this.cacheManager = cacheManager;
		this.defaultCacheSupport = new EhCacheSupport(this.cacheManager, DEFAULTCACHE);
		this.empCacheSupport = new EhCacheSupport(this.cacheManager, EMPCACHE);
	}

	public CacheSupport getCache(String cacheName) throws Exception {
		switch (cacheName) {
		case EMPCACHE:
			return this.empCacheSupport;
		default:
			return this.defaultCacheSupport;
		}

	}

	public void clearCache(String cacheName) throws Exception {
		switch (cacheName) {
		case EMPCACHE:
			this.empCacheSupport.clear();
		default:
			this.defaultCacheSupport.clear();
		}
	}

	public void clearCache() throws Exception {
		this.empCacheSupport.clear();
		this.defaultCacheSupport.clear();
		
	}

}
