package com.ge.corporate.hr.profile.common.cache.hashtable;

import com.ge.corporate.hr.profile.common.cache.CacheException;
import com.ge.corporate.hr.profile.common.cache.CacheSupport;
import java.io.Serializable;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class HashtableCacheSupport
  implements CacheSupport
{
  private Map<Serializable, Map<Serializable, Serializable>> cache = Collections.synchronizedMap(new HashMap());
  
  public void destroy()
  {
    this.cache = Collections.synchronizedMap(new HashMap());
  }
  
  public void clear()
  {
    this.cache = Collections.synchronizedMap(new HashMap());
  }
  
  public boolean exists(String nodeId)
    throws CacheException
  {
    return this.cache.containsKey(nodeId);
  }
  
  public boolean exists(String nodeId, Serializable key)
	throws CacheException
  {
	  if(this.cache.containsKey(nodeId)){
		  return ((Map)this.cache.get(nodeId)).containsKey(key);
	  }else{
		  return false;
	  }
  }
  
  public Set<Serializable> getKeys(String nodeId)
    throws CacheException
  {
    return ((Map)this.cache.get(nodeId)).keySet();
  }
  
  public Map<Serializable, Serializable> get(String nodeId)
    throws CacheException
  {
    return (Map)this.cache.get(nodeId);
  }
  
  public void put(String nodeId, Map<Serializable, Serializable> entries)
    throws CacheException
  {
    this.cache.put(nodeId, entries);
  }
  
  public void put(String nodeId, Serializable key, Serializable value)
    throws CacheException
  {
    if (exists(nodeId))
    {
      get(nodeId).put(key, value);
    }
    else
    {
      Map<Serializable, Serializable> cache = Collections.synchronizedMap(new HashMap());
      
      put(nodeId, cache);
      cache.put(key, value);
    }
  }
  
  public Serializable get(String nodeId, Serializable key)
    throws CacheException
  {
    return (Serializable)get(nodeId).get(key);
  }
  
  public void remove(String nodeId, Serializable key)
    throws CacheException
  {
    if ((this.cache.containsKey(nodeId)) && 
      (((Map)this.cache.get(nodeId)).containsKey(key))) {
      ((Map)this.cache.get(nodeId)).remove(key);
    }
  }
  
  public void remove(String nodeId)
    throws CacheException
  {
    if (this.cache.containsKey(nodeId)) {
      this.cache.remove(nodeId);
    }
  }
  
  public Set<Object> getChildNodes(String nodeId)
    throws CacheException
  {
    throw new CacheException("getChildNodes not implemented by hashtable cache");
  }

@Override
public boolean exists(Serializable paramSerializable) throws CacheException {
	// TODO Auto-generated method stub
	return false;
}

@Override
public Serializable get(Serializable paramSerializable) throws CacheException {
	// TODO Auto-generated method stub
	return null;
}

@Override
public void put(Serializable paramSerializable1, Serializable paramSerializable2)
		throws CacheException {
	// TODO Auto-generated method stub
	
}

@Override
public void remove(Serializable paramSerializable1) throws CacheException {
	// TODO Auto-generated method stub
	
}
}
