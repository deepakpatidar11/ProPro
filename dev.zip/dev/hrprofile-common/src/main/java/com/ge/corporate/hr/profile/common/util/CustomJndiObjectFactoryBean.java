/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.common.util;

import org.apache.commons.lang.StringUtils;
import org.springframework.jndi.JndiObjectFactoryBean;

public class CustomJndiObjectFactoryBean extends JndiObjectFactoryBean{
	
	private String jndiName;
	
	public CustomJndiObjectFactoryBean(){
		super();
	}

	public String getJndiName() {
		return jndiName;
	}
	public void setJndiName(String jndiName) {
		
		//If applition runs in Tomcat and its a local enviroment		
		// "comp/env/jdbc/" must be added to jndiName 
		if( System.getProperty("app.environment")!=null && System.getProperty("app.environment").equals("local") 
				&& System.getProperty("app.server.type")!=null && System.getProperty("app.server.type").equals("tomcat")){			
			this.jndiName=StringUtils.replace(jndiName, "jboss", "comp/env");			
		}else{
			this.jndiName =jndiName;
		}
		super.setJndiName(this.jndiName);
	}
}
