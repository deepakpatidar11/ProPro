/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.common.aspect;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.annotation.Order;

import com.ge.corporate.hr.profile.common.exception.AbstractBaseException;
import com.ge.corporate.hr.profile.common.exception.EmployeeNotFoundException;

@Aspect
@Order(value=1)
public class ExceptionLoggerAspect {
	
	private final Log logger = LogFactory.getLog(ExceptionLoggerAspect.class);
	
	@AfterThrowing(pointcut = "execution(* com.ge.corporate.hr.profile..*.*(..))",
					throwing="ex")
	public void logExceptions(Exception ex){		
	    // ...		
		final Writer message = new StringWriter();
		final PrintWriter printWriter = new PrintWriter(message);
		
		// if exception is a AccessDeniedException, then the exception has to to be logged
		if( ex instanceof org.springframework.security.access.AccessDeniedException){
			return;
		}else if(ex instanceof AbstractBaseException){
			if(ex instanceof EmployeeNotFoundException){
				logger.debug(ex.getMessage());
			}else{		
				logger.error(ex.getMessage());
			}
			return;
		}else{
			// Log exception
			ex.printStackTrace(printWriter);
			logger.error(message);
		}
				
	}
}
