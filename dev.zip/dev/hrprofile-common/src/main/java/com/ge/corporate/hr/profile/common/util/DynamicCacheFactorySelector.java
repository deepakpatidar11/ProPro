package com.ge.corporate.hr.profile.common.util;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;

import com.ge.corporate.hr.profile.common.cache.CacheException;
import com.ge.corporate.hr.profile.common.cache.CacheFactory;
import com.ge.corporate.hr.profile.common.cache.CacheSupport;
import com.ge.corporate.hr.profile.common.cache.ehcache.EhCacheFactory;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;

public class DynamicCacheFactorySelector implements CacheFactory {

	@Autowired
	CacheFactory ehCacheFactory;
	
	@Autowired
	CacheFactory infinispanCacheFactory;
	
	CacheFactory cacheFactory;
	
	@PostConstruct
	public void initCache() throws CacheException{
		try{	
			if (System.getProperty("disableJbossCache") != null
					&& System.getProperty("disableJbossCache").equals("Yes")) {
				cacheFactory = ehCacheFactory;
			}else{
				cacheFactory = infinispanCacheFactory;
			}
			System.setProperty("writeEnabledOnDisabledCache", "true");
		}catch(Exception e){
			throw new CacheException(e.getMessage());
		}
	}

	public CacheSupport getCache(String cacheName) throws Exception {
		return cacheFactory.getCache(cacheName);
	}

	public void clearCache(String cacheName) throws Exception {
		cacheFactory.clearCache(cacheName);
	}

	public void clearCache() throws Exception {
		cacheFactory.clearCache();
	}

}
