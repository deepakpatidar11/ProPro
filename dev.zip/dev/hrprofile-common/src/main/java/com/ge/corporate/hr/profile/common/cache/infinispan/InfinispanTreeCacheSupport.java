package com.ge.corporate.hr.profile.common.cache.infinispan;

import java.io.Serializable;
import java.util.Map;
import java.util.Set;

import javax.annotation.PreDestroy;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.infinispan.Cache;
import org.infinispan.manager.DefaultCacheManager;
import org.infinispan.manager.EmbeddedCacheManager;
import org.infinispan.tree.Node;
import org.infinispan.tree.TreeCache;
import org.infinispan.tree.TreeCacheFactory;

import com.ge.corporate.hr.profile.common.cache.CacheException;
import com.ge.corporate.hr.profile.common.cache.CacheSupport;

public class InfinispanTreeCacheSupport implements CacheSupport {

	private static Log log = LogFactory
			.getLog(InfinispanTreeCacheSupport.class);

	private Cache<Serializable, Serializable> cache;
	private TreeCache<Serializable, Serializable> tree;

	private String cacheName;

	public InfinispanTreeCacheSupport(String cacheName) throws Exception {
		this.cacheName = cacheName;
		if ((System.getProperty("disableJbossCache") != null)
				&& (System.getProperty("disableJbossCache").equals("Yes"))) {
			log.info("Jboss Cache support disabled");
		} else {

			EmbeddedCacheManager cacheManager = new DefaultCacheManager(
					"infinispan.xml");

			if (this.cacheName != null || this.cacheName.isEmpty()) {
				this.cache = cacheManager.getCache();
			} else {
				this.cache = cacheManager.getCache(this.cacheName);
			}

			TreeCacheFactory tcf = new TreeCacheFactory();
			this.tree = tcf.createTreeCache(this.cache);

		}
	}

	public boolean exists(String nodeId) throws CacheException {
		if (this.tree != null) {
			Node<Serializable, Serializable> n = this.tree.getNode(nodeId);
			if (n != null) {
				return true;
			}
		}
		return false;
	}

	public boolean exists(String nodeId, Serializable key)
			throws CacheException {
		if (this.tree != null) {
			Node<Serializable, Serializable> n = this.tree.getNode(nodeId);
			if (n != null) {
				if (n.get(key) != null) {
					return true;
				}
			}
		}
		return false;
	}

	public Set<Serializable> getKeys(String nodeId) throws CacheException {
		if (this.tree != null) {
			return this.tree.getKeys(nodeId);
		}
		return null;
	}

	public Map<Serializable, Serializable> get(String nodeId)
			throws CacheException {
		if (this.tree != null) {
			Node<Serializable, Serializable> n = this.tree.getNode(nodeId);
			if (n != null) {
				return n.getData();
			}
		}
		return null;
	}

	public Serializable get(String nodeId, Serializable key)
			throws CacheException {
		if (this.tree != null) {
			Node<Serializable, Serializable> n = this.tree.getNode(nodeId);
			if (n != null) {
				return (Serializable) n.get(key);
			}
		}
		return null;
	}

	public void put(String nodeId, Map<Serializable, Serializable> entries)
			throws CacheException {
		if (this.tree != null) {
			this.tree.put(nodeId, entries);
		}
	}

	public void put(String nodeId, Serializable key, Serializable value)
			throws CacheException {
		if (this.tree != null) {
			this.tree.put(nodeId, key, value);
		}
	}

	public Set<Object> getChildNodes(String nodeId) {
		if (this.tree != null) {
			Node<Serializable, Serializable> n = this.tree.getNode(nodeId);
			if (n != null) {
				return n.getChildrenNames();
			}
		}
		return null;
	}

	public void remove(String nodeId) throws CacheException {
		if (this.tree != null) {
			this.tree.removeNode(nodeId);
		}
	}

	public void remove(String nodeId, Serializable key) throws CacheException {
		if (this.tree != null) {
			this.tree.remove(nodeId, key);
		}
	}

	@PreDestroy
	public void destroy() throws Exception {
		this.tree.stop();
	}

	public void clear() throws Exception {
		this.tree.getRoot().clearData();
	}

	public boolean exists(Serializable key) throws CacheException {
		return false;
	}

	public Serializable get(Serializable key) throws CacheException {
		return null;
	}

	public void put(Serializable key, Serializable value) throws CacheException {
		
	}

	public void remove(Serializable paramSerializable1) throws CacheException {

	}

}