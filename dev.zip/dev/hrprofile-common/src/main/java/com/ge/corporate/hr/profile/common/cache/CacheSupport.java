package com.ge.corporate.hr.profile.common.cache;

import java.io.Serializable;

public abstract interface CacheSupport {

	public abstract boolean exists(Serializable key)
			throws CacheException;

	public abstract Serializable get(Serializable key)
			throws CacheException;

	public abstract void put(Serializable key,
			Serializable value) throws CacheException;
	
	public abstract void remove(Serializable key) throws CacheException;
	
	public abstract void destroy() throws Exception;

	public abstract void clear() throws Exception;
}
