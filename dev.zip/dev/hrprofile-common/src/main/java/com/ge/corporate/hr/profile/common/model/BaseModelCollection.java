/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.common.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class BaseModelCollection<T> extends AbstractBaseModelSupport {
	
	private static final long serialVersionUID = -6095054028539176487L;
	
	private Collection<T> list = new ArrayList<T>();

	public Collection<T> getList() {
		return list;
	}

	public void setList(Collection<T> list) {
		this.list = list;
	}
	
	public int size(){
		return list != null ? list.size() : 0;
	}
	
	public T get(int index){
		T element = null;
		
		if(list instanceof List<?>){
			element = ((List<T>) list).get(index);
		}
		
		return element;
	}
	
	public void add(T element){
		list.add(element);
	}
	
	public void addAll(Collection<T> list){
		this.list.addAll(list);
	}
	
	public boolean isEmpty(){
		return list.isEmpty();
	}
	
}
