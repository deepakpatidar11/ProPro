package com.ge.corporate.hr.profile.common.cache;

import java.io.Serializable;

public abstract interface CacheListener
{
  public abstract void onPut(Serializable paramSerializable1, Serializable paramSerializable2, CacheSupport paramCacheSupport)
    throws CacheException;
}
