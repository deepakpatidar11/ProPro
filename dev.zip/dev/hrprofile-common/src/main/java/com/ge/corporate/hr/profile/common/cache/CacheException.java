package com.ge.corporate.hr.profile.common.cache;

public class CacheException
  extends Exception
{
  private static final long serialVersionUID = -8700479233210401396L;
  
  public CacheException() {}
  
  public CacheException(String message, Throwable cause)
  {
    super(message, cause);
  }
  
  public CacheException(String message)
  {
    super(message);
  }
  
  public CacheException(Throwable cause)
  {
    super(cause);
  }
}
