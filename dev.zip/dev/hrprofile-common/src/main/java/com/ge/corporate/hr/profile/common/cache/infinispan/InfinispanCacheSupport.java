package com.ge.corporate.hr.profile.common.cache.infinispan;

import java.io.Serializable;

import javax.annotation.PreDestroy;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.infinispan.Cache;

import com.ge.corporate.hr.profile.common.cache.CacheException;
import com.ge.corporate.hr.profile.common.cache.CacheSupport;

public class InfinispanCacheSupport implements CacheSupport {
	
	private static Log log = LogFactory.getLog(InfinispanCacheSupport.class);
	
	private String cacheName;
	
	private Cache<Serializable, Serializable> cache;

	public InfinispanCacheSupport(String cacheName)
			throws Exception {
		this.cacheName = cacheName;
		if ((System.getProperty("disableJbossCache") != null)
				&& (System.getProperty("disableJbossCache").equals("Yes"))) {
			log.info("Infinispan Cache support disabled");
		} else {
			if ( this.cacheName==null || this.cacheName.isEmpty() || this.cacheName.equalsIgnoreCase("default")) {
				this.cache = InfinispanCacheContainer.getCache();
			} else {
				this.cache = InfinispanCacheContainer.getCache(this.cacheName);
			}
		}
	}

	public boolean exists(Serializable key) throws CacheException {
		if (this.cache != null) {
			if(key!=null){
				return this.cache.containsKey(key);
			}
		}
		return false;
	}

	public Serializable get(Serializable key) throws CacheException {
		if (this.cache != null) {
			if(key!=null){
				return this.cache.get(key);
			}
		}
		return null;
	}

	public void put(Serializable key, Serializable value) throws CacheException {
		if (this.cache != null) {
			if(key!=null && value != null){
				this.cache.put(key, value);
			}
		}
	}
	
	public void remove(Serializable key) throws CacheException {
		if (this.cache != null) {
			if(key!=null){
				this.cache.remove(key);
			}
		}
	}

	@PreDestroy
	public void destroy() throws Exception {
		InfinispanCacheContainer.getCacheContainer().stop();
	}

	public void clear() throws Exception {
		this.cache.clear();
	}
	
}
