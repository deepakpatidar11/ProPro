package com.ge.corporate.hr.profile.common.cache.infinispan;

import java.io.IOException;

import org.infinispan.Cache;
import org.infinispan.manager.DefaultCacheManager;
import org.infinispan.manager.EmbeddedCacheManager;

public class InfinispanCacheContainer {

	private static final String INFINISPAN_CONFIGURATION = "infinispan.xml";

	private static final EmbeddedCacheManager CACHE_MANAGER;

	static {
		try {
			CACHE_MANAGER = new DefaultCacheManager(INFINISPAN_CONFIGURATION);
		} catch (IOException e) {
			throw new RuntimeException("Unable to configure Infinispan", e);
		}
	}

	public static <K, V> Cache<K, V> getCache() {
		return CACHE_MANAGER.getCache();
	}

	public static <K, V> Cache<K, V> getCache(String cacheName) {
		if (cacheName == null)
			throw new NullPointerException("Cache name cannot be null!");
		return CACHE_MANAGER.getCache(cacheName);
	}

	public static EmbeddedCacheManager getCacheContainer() {
		return CACHE_MANAGER;
	}
	
}