/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.common.util;

import org.easymock.IArgumentMatcher;

import flexjson.JSONSerializer;
/**
 * This is a custom Argument matcher that compares serialized data for example: dtos, model
 * @author enrique.romero
 *
 */
public class EqualSerialized implements IArgumentMatcher {
	
	private Object expected;	
	JSONSerializer serializer = new JSONSerializer();
	
	/**
	 * Initializes matcher
	 * @param object
	 */
	public EqualSerialized(Object object){
		this.expected = object;
	}

	public void appendTo(StringBuffer buffer) {
		
	}

	public boolean matches(Object actual) {
		//if classes are not equal then return false
		if(actual.getClass()!= expected.getClass()){		
			return false;
		}				
		//if data serialized of expected and actual are equal the the matching is true.
		if(serializer.deepSerialize(actual).equals(serializer.deepSerialize(expected))){
			return true;
		}		
		return false;		
	}
	
}
