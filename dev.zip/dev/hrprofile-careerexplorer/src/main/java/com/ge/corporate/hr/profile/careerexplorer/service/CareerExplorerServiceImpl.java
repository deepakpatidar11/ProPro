package com.ge.corporate.hr.profile.careerexplorer.service;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;

import com.ge.corporate.hr.profile.careerexplorer.dao.CareerExplorerDao;
import com.ge.corporate.hr.profile.careerexplorer.model.Business;
import com.ge.corporate.hr.profile.careerexplorer.model.Country;
import com.ge.corporate.hr.profile.careerexplorer.model.Function;
import com.ge.corporate.hr.profile.careerexplorer.model.FuturePositionType;
import com.ge.corporate.hr.profile.careerexplorer.model.Job;
import com.ge.corporate.hr.profile.careerexplorer.model.JobDetail;
import com.ge.corporate.hr.profile.careerexplorer.model.JobFamily;
import com.ge.corporate.hr.profile.careerexplorer.model.JobTypeLibrary;
import com.ge.corporate.hr.profile.careerexplorer.model.Organization;
import com.ge.corporate.hr.profile.careerexplorer.model.PossibleJobType;
import com.ge.corporate.hr.profile.careerexplorer.model.Vacancies;
import com.ge.corporate.hr.profile.careerexplorer.model.Vacancy;
import com.ge.corporate.hr.profile.common.service.AbstractBaseServiceSupport;

@Service
public class CareerExplorerServiceImpl extends AbstractBaseServiceSupport implements CareerExplorerService{
	
	private final Log logger = LogFactory.getLog(CareerExplorerServiceImpl.class);
	
	@Resource(name = "careerExplorerDao")
	private CareerExplorerDao careerExplorerDao;
	
	public CareerExplorerDao getCareerExplorerDao() {
		return careerExplorerDao;
	}

	public void setCareerExplorerDao(CareerExplorerDao careerExplorerDao) {
		this.careerExplorerDao = careerExplorerDao;
	}

	public List<FuturePositionType> getFuturePositionType(Long sso,
			String business, String function, String country) {
		int sum = 0;

		List<FuturePositionType> futurepositionList = careerExplorerDao.getFuturePositionType(sso, business, function, country);

		for (FuturePositionType f : futurepositionList) {
			sum = sum + f.getCount();
		}

		for (FuturePositionType f : futurepositionList) {
			f.setPercentageOfTotalPositionTypes(percentageOfTotalSum(
					f.getCount(), sum));
			f.setSumOfCount(sum);
		}
		return futurepositionList;
	}
	
	public int percentageOfTotalSum(int count, int countSum){
		return (int) Math.round((double)(100*count)/countSum);
	}

	public List<Vacancies> getAllVacancies(String jobName){
		return this.careerExplorerDao.getAllVacancies(jobName);
	}

	public List<PossibleJobType> getPossibleJobTypes(Long sso){
		return this.careerExplorerDao.getPossibleJobTypes(sso);
	}

	public List<Business> getBusinessList(Long sso) {
		return this.careerExplorerDao.getBusinessList(sso);
	}

	public List<Function> getFunctionList(Long sso) {
		return this.careerExplorerDao.getFunctionList(sso);
	}
	
	public List<Country> getCountryList(Long sso) {
		return this.careerExplorerDao.getCountryList(sso);
	}

	public List<Job> getMostRecentJobPosting(String jobName) {
		return this.careerExplorerDao.getMostRecentJobPosting(jobName);
	}

	public JobDetail getJobDetail(String vacancyNumber) {
		return this.careerExplorerDao.getJobDetail(vacancyNumber);
	}

	public JobTypeLibrary getJobTypeLibrary(String jobType) {
		 return this.careerExplorerDao.getJobTypeLibrary(jobType);
	}

	public List<JobFamily> getPossibleMovesBasedOnJobFamily(Long sso,String business, String function, String country) {
		int sum = 0;
		
		List<JobFamily> jobFamilyList= careerExplorerDao.getPossibleMovesBasedOnJobFamily(sso,business, function, country);
		
		for (JobFamily j : jobFamilyList) {
			sum = sum + j.getCount();
		}

		for (JobFamily j : jobFamilyList) {
			j.setPercentageOfTotalJobFamilies(percentageOfTotalSum(j.getCount(), sum));
			j.setSumOfCount(sum);
		}
		return jobFamilyList;
	}

	public List<Vacancy> getVacanciesForaGivenJobFamily(String jobFamily,String business,String country) {
		return this.careerExplorerDao.getVacanciesForaGivenJobFamily(jobFamily,business,country);
	}

	public List<Organization> getIFGFiletrListForJobFamily(Long sso) {
		return this.careerExplorerDao.getIFGFiletrListForJobFamily(sso);
	}
	
	public List<Country> getCountryFilterListForJobFamily(Long sso) {
		return this.careerExplorerDao.getCountryFilterListForJobFamily(sso);
	}

	public List<Function> getJobFunctionFilterForJobFamilyMatches(Long sso) {
		return this.careerExplorerDao.getJobFunctionFilterForJobFamilyMatches(sso);
	}

}