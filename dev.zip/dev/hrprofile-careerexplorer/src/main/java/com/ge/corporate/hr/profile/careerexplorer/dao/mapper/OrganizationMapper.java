package com.ge.corporate.hr.profile.careerexplorer.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.careerexplorer.model.Organization;

public class OrganizationMapper implements RowMapper<Organization>{	
	
	public static final String ORGANIZATION_NAME = "ORG_NAME";

	public Organization mapRow(ResultSet rs, int rowNumber) throws SQLException {	
		
		Organization organization = new Organization();		
		organization.setOrganizationName(rs.getString(ORGANIZATION_NAME));		
		return organization;					
	}
}
