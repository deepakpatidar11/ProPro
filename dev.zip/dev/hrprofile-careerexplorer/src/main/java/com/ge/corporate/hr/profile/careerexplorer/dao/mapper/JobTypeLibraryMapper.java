package com.ge.corporate.hr.profile.careerexplorer.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.careerexplorer.model.JobTypeLibrary;

public class JobTypeLibraryMapper implements RowMapper<JobTypeLibrary>{	
	
	//pstd_pos_tte, rl_smry_prpse, essntl_resp, qual_req, dsrd 
	
	/*RESPONSIBILITES      VARCHAR2(4000) 
	QUALIFICATIONS       VARCHAR2(4000) 
	CHARACTERISTICS*/
	
	public static final String DATA_RESPONSIBILITIES = "RESPONSIBILITES";
	public static final String DATA_QUALIFICATION = "QUALIFICATIONS";
	public static final String DATA_DESIRED_CHAR = "CHARACTERISTICS";	
	
	
	public JobTypeLibrary mapRow(ResultSet rs, int rowNumber) throws SQLException {	
		
		JobTypeLibrary jobTypeLibrary = new JobTypeLibrary();
		
		
		jobTypeLibrary.setResponsibilites(rs.getString(DATA_RESPONSIBILITIES));
		jobTypeLibrary.setRequiredQualification(rs.getString(DATA_QUALIFICATION));
		jobTypeLibrary.setDesiredCharacteristics(rs.getString(DATA_DESIRED_CHAR));
		
		
		return jobTypeLibrary;			
	}
}
