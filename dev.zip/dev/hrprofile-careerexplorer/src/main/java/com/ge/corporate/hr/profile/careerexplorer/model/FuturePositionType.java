package com.ge.corporate.hr.profile.careerexplorer.model;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;;

public class FuturePositionType extends AbstractBaseModelSupport {
	
	private static final long serialVersionUID = 2890243282306578603L;
	
	private int sso;
	private String positionType;
	private int count;
	private int sumOfCount;
	private int PercentageOfTotalPositionTypes;
	public int getSso() {
		return sso;
	}
	public void setSso(int sso) {
		this.sso = sso;
	}
	public String getPositionType() {
		return positionType;
	}
	public void setPositionType(String positionType) {
		this.positionType = positionType;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getSumOfCount() {
		return sumOfCount;
	}
	public void setSumOfCount(int sumOfCount) {
		this.sumOfCount = sumOfCount;
	}
	public int getPercentageOfTotalPositionTypes() {
		return PercentageOfTotalPositionTypes;
	}
	public void setPercentageOfTotalPositionTypes(int percentageOfTotalPositionTypes) {
		PercentageOfTotalPositionTypes = percentageOfTotalPositionTypes;
	}
}