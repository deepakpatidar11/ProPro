package com.ge.corporate.hr.profile.careerexplorer.model;

import java.util.List;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

public class JobDetail extends AbstractBaseModelSupport{
	
	private static final long serialVersionUID = 2890243282306578603L;
	
	
	private String positionTitle;
	private String rlSummaryPurpose;
	private String responsibilities;
	private List<String> responsibilitiesList;	
	private String requiredQualification;
	private List<String> requiredQualificationList;	
	private String desiredCharacteristics;
	private List<String> desiredCharacteristicsList;
	
	
	public List<String> getRequiredQualificationList() {
		return requiredQualificationList;
	}
	public void setRequiredQualificationList(List<String> requiredQualificationList) {
		this.requiredQualificationList = requiredQualificationList;
	}
	public List<String> getDesiredCharacteristicsList() {
		return desiredCharacteristicsList;
	}
	public void setDesiredCharacteristicsList(
			List<String> desiredCharacteristicsList) {
		this.desiredCharacteristicsList = desiredCharacteristicsList;
	}
	public String getPositionTitle() {
		return positionTitle;
	}
	public void setPositionTitle(String positionTitle) {
		this.positionTitle = positionTitle;
	}
	public String getRlSummaryPurpose() {
		return rlSummaryPurpose;
	}
	public void setRlSummaryPurpose(String rlSummaryPurpose) {
		this.rlSummaryPurpose = rlSummaryPurpose;
	}
	public String getResponsibilities() {
		return responsibilities;
	}
	public void setResponsibilities(String responsibilities) {
		this.responsibilities = responsibilities;
	}
	public String getRequiredQualification() {
		return requiredQualification;
	}
	public void setRequiredQualification(String requiredQualification) {
		this.requiredQualification = requiredQualification;
	}
	public String getDesiredCharacteristics() {
		return desiredCharacteristics;
	}
	public void setDesiredCharacteristics(String desiredCharacteristics) {
		this.desiredCharacteristics = desiredCharacteristics;
	}
	
	public List<String> getResponsibilitiesList() {
		return responsibilitiesList;
	}
	public void setResponsibilitiesList(List<String> responsibilitiesList) {
		this.responsibilitiesList = responsibilitiesList;
	}	

}
