package com.ge.corporate.hr.profile.careerexplorer.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import com.ge.corporate.hr.profile.careerexplorer.model.Vacancy;

public class VacancyMapper implements RowMapper<Vacancy>{	
	
	public static final String TITLE = "title";
	public static final String JOB_POSTED_DATE = "dt_to";
	public static final String VACANCY_NUMBER = "vcncy_num";

	public Vacancy mapRow(ResultSet rs, int rowNumber) throws SQLException {	
		
		Vacancy vacancy = new Vacancy();		
		vacancy.setTitle(rs.getString(TITLE));		
		vacancy.setJobPostedDate(rs.getDate(JOB_POSTED_DATE));
		vacancy.setVacNumber(rs.getInt(VACANCY_NUMBER));
		return vacancy;					
	}

}
