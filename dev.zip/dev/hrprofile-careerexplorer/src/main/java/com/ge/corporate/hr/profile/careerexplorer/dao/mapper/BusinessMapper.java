package com.ge.corporate.hr.profile.careerexplorer.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.careerexplorer.model.Business;

public class BusinessMapper implements RowMapper<Business>{	
	
	public static final String DATA_ORG_NAME = "org_name";

	public Business mapRow(ResultSet rs, int rowNumber) throws SQLException {	
		
		Business business = new Business();		
		business.setOrgName(rs.getString(DATA_ORG_NAME));		
		return business;					
	}

}
