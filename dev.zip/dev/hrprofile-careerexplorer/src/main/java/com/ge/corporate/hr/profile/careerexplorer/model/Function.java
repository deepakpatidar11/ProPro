package com.ge.corporate.hr.profile.careerexplorer.model;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

public class Function extends AbstractBaseModelSupport{
	
	private static final long serialVersionUID = 2890243282306578603L;
	
	private String functionName;

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	

}
