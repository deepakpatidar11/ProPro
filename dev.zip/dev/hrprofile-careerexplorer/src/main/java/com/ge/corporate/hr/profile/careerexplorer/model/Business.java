package com.ge.corporate.hr.profile.careerexplorer.model;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

public class Business extends AbstractBaseModelSupport{
	
	private static final long serialVersionUID = 2890243282306578603L;
	
	private String orgName;

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

}
