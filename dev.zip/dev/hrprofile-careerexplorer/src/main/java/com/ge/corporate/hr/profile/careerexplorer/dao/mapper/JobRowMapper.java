package com.ge.corporate.hr.profile.careerexplorer.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.careerexplorer.model.Job;

public class JobRowMapper implements RowMapper<Job>{	
	
	//pstd_pos_tte as title, v.dt_to, vcncy_num
	
	public static final String DATA_TITLE = "title";
	public static final String DATA_NUM_VACANCY = "vcncy_num";	
	public static final String DATA_JOB_POST_DATE = "DT_TO";
	
	public Job mapRow(ResultSet rs, int rowNumber) throws SQLException {	
		
		Job job = new Job();		
		job.setTitle(rs.getString(DATA_TITLE));
		job.setDate(rs.getDate(DATA_JOB_POST_DATE));
		job.setVacancyNumber(rs.getInt(DATA_NUM_VACANCY));
		return job;					
	}
}
