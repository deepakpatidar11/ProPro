package com.ge.corporate.hr.profile.careerexplorer.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.careerexplorer.model.PossibleJobType;

public class PossibleJobTypeMapper implements RowMapper<PossibleJobType>{
	
	public static final String DATA_SSO = "sso";
	public static final String DATA_JOB_TYPE = "job_type";
	public static final String DATA_JOB_TYPE_COUNT = "job_type_count";
	public static final String DATA_NUMBER_VACANCIES = "num_vacancies";

	public PossibleJobType mapRow(ResultSet rs, int rowNumber) throws SQLException {
		PossibleJobType possibleJobType = new PossibleJobType();
		possibleJobType.setJobType(rs.getString(DATA_JOB_TYPE));
		possibleJobType.setJobTypeCount(rs.getInt(DATA_JOB_TYPE_COUNT));
		possibleJobType.setNumOfVacancies(rs.getInt(DATA_NUMBER_VACANCIES));
		return possibleJobType;						
	}

}