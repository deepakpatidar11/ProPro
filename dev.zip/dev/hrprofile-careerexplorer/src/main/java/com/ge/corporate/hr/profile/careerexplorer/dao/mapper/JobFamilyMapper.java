package com.ge.corporate.hr.profile.careerexplorer.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.careerexplorer.model.JobFamily;

public class JobFamilyMapper implements RowMapper<JobFamily>{	
	
	public static final String JOB_FAMILY = "job_family";
	public static final String COUNT = "count";

	public JobFamily mapRow(ResultSet rs, int rowNumber) throws SQLException {	
		
		JobFamily jobFamily = new JobFamily();	
		jobFamily.setJobFamily(rs.getString(JOB_FAMILY));
		jobFamily.setCount(rs.getInt(COUNT));
		return jobFamily;					
	}

}
