package com.ge.corporate.hr.profile.careerexplorer.service;

import java.util.List;

import com.ge.corporate.hr.profile.careerexplorer.model.Business;
import com.ge.corporate.hr.profile.careerexplorer.model.Country;
import com.ge.corporate.hr.profile.careerexplorer.model.Function;
import com.ge.corporate.hr.profile.careerexplorer.model.FuturePositionType;
import com.ge.corporate.hr.profile.careerexplorer.model.Job;
import com.ge.corporate.hr.profile.careerexplorer.model.JobDetail;
import com.ge.corporate.hr.profile.careerexplorer.model.JobFamily;
import com.ge.corporate.hr.profile.careerexplorer.model.JobTypeLibrary;
import com.ge.corporate.hr.profile.careerexplorer.model.Organization;
import com.ge.corporate.hr.profile.careerexplorer.model.PossibleJobType;
import com.ge.corporate.hr.profile.careerexplorer.model.Vacancies;
import com.ge.corporate.hr.profile.careerexplorer.model.Vacancy;

public interface CareerExplorerService {
	
	public List<FuturePositionType> getFuturePositionType(Long sso,String business,String function,String country);
	public List<Vacancies> getAllVacancies(String jobName);
	public List<PossibleJobType> getPossibleJobTypes(Long sso);
	
	// new Implementations	
	public List<Business> getBusinessList(Long sso);	
	public List<Function> getFunctionList(Long sso);	
	public List<Country> getCountryList(Long sso);	
	public List<Job> getMostRecentJobPosting(String jobName );	
	public JobDetail getJobDetail(String vacancyNumber );	
	public JobTypeLibrary getJobTypeLibrary(String jobType );
	
	// new impolemention on job type calls	
	public List<JobFamily> getPossibleMovesBasedOnJobFamily(Long sso,String business,String function,String country);
	public List<Vacancy> getVacanciesForaGivenJobFamily(String jobFamily,String business,String country );
	public List<Organization> getIFGFiletrListForJobFamily(Long sso );
	public List<Country> getCountryFilterListForJobFamily(Long sso );
	public List<Function> getJobFunctionFilterForJobFamilyMatches(Long sso );
		
	
}
