package com.ge.corporate.hr.profile.careerexplorer.model;

import java.util.Date;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

public class Vacancy extends AbstractBaseModelSupport {
	
private static final long serialVersionUID = 2890243282306578603L;
	
	private String title;
	private Integer vacNumber;
	private Date jobPostedDate;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Integer getVacNumber() {
		return vacNumber;
	}
	public void setVacNumber(Integer vacNumber) {
		this.vacNumber = vacNumber;
	}
	public Date getJobPostedDate() {
		return jobPostedDate;
	}
	public void setJobPostedDate(Date jobPostedDate) {
		this.jobPostedDate = jobPostedDate;
	}
}
