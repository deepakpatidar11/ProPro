package com.ge.corporate.hr.profile.careerexplorer.model;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

public class UserDetails extends AbstractBaseModelSupport {
	
	private static final long serialVersionUID = 2890243282306578603L;
	
	private Long sso;
	private String firstName;
	private String lastName;
	private String title;
	private String jobType;
	private String positionType;
	
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getPositionType() {
		return positionType;
	}
	public void setPositionType(String positionType) {
		this.positionType = positionType;
	}


}
