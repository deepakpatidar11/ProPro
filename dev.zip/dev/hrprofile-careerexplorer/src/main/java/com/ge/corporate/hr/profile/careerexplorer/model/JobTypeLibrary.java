package com.ge.corporate.hr.profile.careerexplorer.model;

public class JobTypeLibrary {
	
	private String responsibilites;
	private String requiredQualification;
	private String desiredCharacteristics;
	
	public String getResponsibilites() {
		return responsibilites;
	}
	public void setResponsibilites(String responsibilites) {
		this.responsibilites = responsibilites;
	}
	public String getRequiredQualification() {
		return requiredQualification;
	}
	public void setRequiredQualification(String requiredQualification) {
		this.requiredQualification = requiredQualification;
	}
	public String getDesiredCharacteristics() {
		return desiredCharacteristics;
	}
	public void setDesiredCharacteristics(String desiredCharacteristics) {
		this.desiredCharacteristics = desiredCharacteristics;
	}
	
	

}
