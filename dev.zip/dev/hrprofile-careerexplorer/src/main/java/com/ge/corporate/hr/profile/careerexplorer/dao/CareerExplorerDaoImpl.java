package com.ge.corporate.hr.profile.careerexplorer.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.security.access.prepost.PreAuthorize;

import com.ge.corporate.hr.profile.careerexplorer.dao.mapper.BusinessMapper;
import com.ge.corporate.hr.profile.careerexplorer.dao.mapper.CountryMapper;
import com.ge.corporate.hr.profile.careerexplorer.dao.mapper.FunctionMapper;
import com.ge.corporate.hr.profile.careerexplorer.dao.mapper.FuturePositionTypeMapper;
import com.ge.corporate.hr.profile.careerexplorer.dao.mapper.JobDetailMapper;
import com.ge.corporate.hr.profile.careerexplorer.dao.mapper.JobFamilyMapper;
import com.ge.corporate.hr.profile.careerexplorer.dao.mapper.JobRowMapper;
import com.ge.corporate.hr.profile.careerexplorer.dao.mapper.JobTypeLibraryMapper;
import com.ge.corporate.hr.profile.careerexplorer.dao.mapper.OrganizationMapper;
import com.ge.corporate.hr.profile.careerexplorer.dao.mapper.PossibleJobTypeMapper;
import com.ge.corporate.hr.profile.careerexplorer.dao.mapper.VacanciesMapper;
import com.ge.corporate.hr.profile.careerexplorer.dao.mapper.VacancyMapper;
import com.ge.corporate.hr.profile.careerexplorer.model.Business;
import com.ge.corporate.hr.profile.careerexplorer.model.Country;
import com.ge.corporate.hr.profile.careerexplorer.model.Function;
import com.ge.corporate.hr.profile.careerexplorer.model.FuturePositionType;
import com.ge.corporate.hr.profile.careerexplorer.model.Job;
import com.ge.corporate.hr.profile.careerexplorer.model.JobDetail;
import com.ge.corporate.hr.profile.careerexplorer.model.JobFamily;
import com.ge.corporate.hr.profile.careerexplorer.model.JobTypeLibrary;
import com.ge.corporate.hr.profile.careerexplorer.model.Organization;
import com.ge.corporate.hr.profile.careerexplorer.model.PossibleJobType;
import com.ge.corporate.hr.profile.careerexplorer.model.Vacancies;
import com.ge.corporate.hr.profile.careerexplorer.model.Vacancy;
import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;

public class CareerExplorerDaoImpl extends AbstractBaseDaoSupport implements CareerExplorerDao {
	
	private static Log logger = LogFactory.getLog(CareerExplorerDaoImpl.class);

	@PreAuthorize("hasPermission(#sso, 'CareerExplorer', read)")
	public List<FuturePositionType> getFuturePositionType(Long sso,String business,String function, String country) {
        List<FuturePositionType> rval = new ArrayList<FuturePositionType>();
       int count = 0;
        String query = getSql("getFuturePositionType");
        if(business==null || business.equalsIgnoreCase("") || business=="ALL" || business.equalsIgnoreCase("ALL")){
        	query=query.replaceAll("BUSINESS_NAME", " ");
        }
        else{
        	query=query.replaceAll("BUSINESS_NAME"," o.org_name in ('"+business+"')");
        	count = count + 1;
        	query=query.replaceAll("AND_LOGIC", " and ");
        }
        if(function==null || function.equalsIgnoreCase("") || function=="ALL" || function.equalsIgnoreCase("ALL")){
        	query=query.replaceAll("FUNCTION_NAME", " ");
        }
        else{
        	query=query.replaceAll("FUNCTION_NAME"," af.afunc_label = ('"+function+"')");
        	count = count + 1;
        	query=query.replaceAll("AND_LOGIC", " and ");
        }
        if(country==null || country.equalsIgnoreCase("") || country=="ALL" || country.equalsIgnoreCase("ALL")){
        	query=query.replaceAll("COUNTRY_NAME", " ");
        }
        else{
        	query=query.replaceAll("COUNTRY_NAME"," wa1.wa_country = (select country_code from t_country where country_label = '"+country+"')");
        	count = count + 1;
        	query=query.replaceAll("AND_LOGIC", " and ");
        }
        
        if(count==2){
        	//query=query.replaceAll("AND_LOGIC", " and ");
        	query=query.replaceAll("START_BRACKET", " ( ");
        	query=query.replaceAll("OR_LOGIC1", " or ");
        	query=query.replaceAll("END_BRACKET", " ) ");
        }if(count==3){
        	//query=query.replaceAll("AND_LOGIC", " and ");
        	query=query.replaceAll("START_BRACKET", " ( ");
        	query=query.replaceAll("OR_LOGIC1", " or ");
        	query=query.replaceAll("OR_LOGIC2", " or ");
        	query=query.replaceAll("END_BRACKET", " ) ");
        }else{
        	query=query.replaceAll("AND_LOGIC", " ");
        	query=query.replaceAll("START_BRACKET", " ");
        	query=query.replaceAll("OR_LOGIC1", " ");
        	query=query.replaceAll("OR_LOGIC2", " ");
        	query=query.replaceAll("END_BRACKET", " ");
        }
        
        
        try {                
            rval = getJdbcTemplate().query(query, new Object[] {sso}, new FuturePositionTypeMapper());        
        } catch (EmptyResultDataAccessException eex) {
        	logger.debug("Future Position Type Data not found for "+sso);
            return null;
        } 
        return rval;
	}
	

	@PreAuthorize("hasPermission(#sso, 'CareerExplorer', read)")
	public List<PossibleJobType> getPossibleJobTypes(Long sso) {
        List<PossibleJobType> rval = new ArrayList<PossibleJobType>();
        String query = getSql("getAllPossibleJobTypes");
        try {                
               rval = getJdbcTemplate().query(query, new Object[] {sso}, new PossibleJobTypeMapper());        
        } catch (EmptyResultDataAccessException eex) {
        	logger.debug("All Possible Job Type Data not found for "+sso);
            return null;
        } 
        return rval;
	}
	
	//@PreAuthorize("hasPermission(#sso, 'CareerExplorer', read)")
	public List<Vacancies> getAllVacancies(String jobName) {
        List<Vacancies> rval = new ArrayList<Vacancies>();
        String query = getSql("getAllVacancies");
        try {                
               rval = getJdbcTemplate().query(query, new Object[] {jobName}, new VacanciesMapper());        
        } catch (EmptyResultDataAccessException eex) {
        	logger.debug("All Vacancies Data not found for " + jobName);
            return null;
        } 
        return rval;
	}

	@PreAuthorize("hasPermission(#sso, 'CareerExplorer', read)")
	public List<Business> getBusinessList(Long sso) {
		 List<Business> rval = new ArrayList<Business>();
	        String query = getSql("getBusinessList");
	        try {                
	               rval = getJdbcTemplate().query(query, new Object[] {sso}, new BusinessMapper());        
	        } catch (EmptyResultDataAccessException eex) {
	        	logger.debug("Business List Data not found for " + sso);
	            return null;
	        } 
	        return rval;
	}

	@PreAuthorize("hasPermission(#sso, 'CareerExplorer', read)")
	public List<Function> getFunctionList(Long sso) {
		List<Function> rval = new ArrayList<Function>();
        String query = getSql("getFunctionList");
        try {                
               rval = getJdbcTemplate().query(query, new Object[] {sso}, new FunctionMapper());        
        } catch (EmptyResultDataAccessException eex) {
        	logger.debug("Function List Data not found for " + sso);
            return null;
        } 
        return rval;
	}
	
	@PreAuthorize("hasPermission(#sso, 'CareerExplorer', read)")
	public List<Country> getCountryList(Long sso) {
		 List<Country> rval = new ArrayList<Country>();
	        String query = getSql("getCountryList");
	        try {                
	               rval = getJdbcTemplate().query(query, new Object[] {sso}, new CountryMapper());        
	        } catch (EmptyResultDataAccessException eex) {
	        	logger.debug("Country Data not found for " + sso);
	            return null;
	        } 
	        return rval;
	}

	//@PreAuthorize("hasPermission(#sso, 'CareerExplorer', read)")
	public List<Job> getMostRecentJobPosting(String jobName) {
		List<Job> rval = new ArrayList<Job>();
        String query = getSql("getMostRecentJobPosting");
        try { 
               rval = getJdbcTemplate().query(query, new Object[] {jobName}, new JobRowMapper());        
        } catch (EmptyResultDataAccessException eex) {
        	logger.debug("Most Recent Job Posted Data not found for " + jobName);
            return null;
        } 
        return rval;
	}


	//@PreAuthorize("hasPermission(#sso, 'CareerExplorer', read)")
	public JobDetail getJobDetail(String vacancyNumber) {
		JobDetail rval = new JobDetail();
        String query = getSql("getJobDetailOnVacancyNumber");
        try { 
        	
        	rval = getJdbcTemplate().queryForObject(query,new Object[] {vacancyNumber}, new JobDetailMapper());
        	//(query, new JobDetailRowMapper())     ;  
        	/*String responsibilities = rval.getResponsibilities();
        	List<String> responsibilitiesList = tokenizer(responsibilities);
        	rval.setResponsibilitiesList(responsibilitiesList);
        	//rval.setResponsibilities(null);
        	
        	
        	String reqQualification = rval.getRequiredQualification();
        	List<String> requiredQualificationList = tokenizer(reqQualification);
        	rval.setRequiredQualificationList(requiredQualificationList);
        	//rval.setRequiredQualification(null);
        	
        	String desiredCharacteristics = rval.getDesiredCharacteristics();
        	List<String> desiredCharacteristicsList = tokenizer(desiredCharacteristics);
        	rval.setDesiredCharacteristicsList(desiredCharacteristicsList);
        	//rval.setDesiredCharacteristics(null);
*/        	
        } catch (EmptyResultDataAccessException eex) {
        	logger.debug("Job Details  Data not found for " + vacancyNumber);
            return null;
        } 
        return rval;
	}


	public List<String> tokenizer(String s){
		
		List<String> alist = new ArrayList<String>();
		
		//String[] array = StringUtils.tokenizeToStringArray(s, "�");
	//	String[] array = StringUtils.tokenizeToStringArray(s, ";");
		String[] array = s.split("�|\\;|\\<li>");
		alist = Arrays.asList(array);
		
		return alist;
	}

	//@PreAuthorize("hasPermission(#sso, 'CareerExplorer', read)")
	public JobTypeLibrary getJobTypeLibrary(String jobType) {
		
		JobTypeLibrary rval = new JobTypeLibrary();
        String query = getSql("getJobTypeLibrary");
        try {         	
        		rval = getJdbcTemplate().queryForObject(query,new Object[] {jobType}, new JobTypeLibraryMapper()); 
        	}
        	catch (EmptyResultDataAccessException eex) {
	        	logger.debug("Job Type Library Data not found for " + jobType);
	            return null;
	        } 		return rval;
	}

	
	//@PreAuthorize("hasPermission(#sso, 'CareerExplorer', read)")
			public List<JobFamily> getPossibleMovesBasedOnJobFamily(Long sso,String business,String function, String country) {
				List<JobFamily> rval = new ArrayList<JobFamily>();
				int count = 0;
		        String query = getSql("getPossibleMovesBasedOnJobFamily");
		        if(business==null || business.equalsIgnoreCase("") || business=="ALL" || business.equalsIgnoreCase("ALL")){
		        	query=query.replaceAll("BUSINESS_NAME", " ");
		        }
		        else{
		        	query=query.replaceAll("BUSINESS_NAME"," o.org_name in ('"+business+"')");
		        	count = count + 1;
		        	query=query.replaceAll("AND_LOGIC", " and ");
		        }
		        if(function==null || function.equalsIgnoreCase("") || function=="ALL" || function.equalsIgnoreCase("ALL")){
		        	query=query.replaceAll("FUNCTION_NAME", " ");
		        }
		        else{
		        	query=query.replaceAll("FUNCTION_NAME"," af.afunc_label = ('"+function+"')");
		        	count = count + 1;
		        	query=query.replaceAll("AND_LOGIC", " and ");
		        }
		        if(country==null || country.equalsIgnoreCase("") || country=="ALL" || country.equalsIgnoreCase("ALL")){
		        	query=query.replaceAll("COUNTRY_NAME", " ");
		        }
		        else{
		        	query=query.replaceAll("COUNTRY_NAME"," wa1.wa_country = (select country_code from t_country where country_label = '"+country+"')");
		        	count = count + 1;
		        	query=query.replaceAll("AND_LOGIC", " and ");
		        }
		        
		        if(count==2){
		        	//query=query.replaceAll("AND_LOGIC", " and ");
		        	query=query.replaceAll("START_BRACKET", " ( ");
		        	query=query.replaceAll("OR_LOGIC1", " or ");
		        	query=query.replaceAll("END_BRACKET", " ) ");
		        }if(count==3){
		        	//query=query.replaceAll("AND_LOGIC", " and ");
		        	query=query.replaceAll("START_BRACKET", " ( ");
		        	query=query.replaceAll("OR_LOGIC1", " or ");
		        	query=query.replaceAll("OR_LOGIC2", " or ");
		        	query=query.replaceAll("END_BRACKET", " ) ");
		        }else{
		        	query=query.replaceAll("AND_LOGIC", " ");
		        	query=query.replaceAll("START_BRACKET", " ");
		        	query=query.replaceAll("OR_LOGIC1", " ");
		        	query=query.replaceAll("OR_LOGIC2", " ");
		        	query=query.replaceAll("END_BRACKET", " ");
		        }
		    		        
		        try {                
		        	  rval = getJdbcTemplate().query(query, new Object[] {sso}, new JobFamilyMapper());        
		        } catch (EmptyResultDataAccessException eex) {
		        	logger.debug("Job Family List  Data not found for "+sso);
		            return null;
		        } 
		        return rval;
				
			}
	

	//@PreAuthorize("hasPermission(#sso, 'CareerExplorer', read)")
	public List<Vacancy> getVacanciesForaGivenJobFamily(String jobFamily,String business, String country) {
		List<Vacancy> rval = new ArrayList<Vacancy>();
        String query = getSql("getVacanciesForaGivenJobFamily");
        boolean hasBusiness = false;
        boolean hasCountry = false;
        
        if(business==null || business.equalsIgnoreCase("") || business=="ALL" || business.equalsIgnoreCase("ALL")){
        	query=query.replaceAll("BUSINESS_NAME", " ");
        }
        else{
        	query=query.replaceAll("BUSINESS_NAME"," o.org_name in ('"+business+"')");
        	hasBusiness = true;
        	query=query.replaceAll("AND_LOGIC", " and ");
        }
        if(country==null || country.equalsIgnoreCase("") || country=="ALL" || country.equalsIgnoreCase("ALL")){
        	query=query.replaceAll("COUNTRY_NAME", " ");
        }
        else{
        	query=query.replaceAll("COUNTRY_NAME"," c.country_label in ('"+country+"')");
        	hasCountry = true;
        	query=query.replaceAll("AND_LOGIC", " and ");
        }
        if(hasBusiness == true && hasCountry == true){
        	//query=query.replaceAll("AND_LOGIC", " and ");
        	query=query.replaceAll("START_BRACKET", " ( ");
        	query=query.replaceAll("OR_LOGIC", " or ");
        	query=query.replaceAll("END_BRACKET", " ) ");
        }else{
        	query=query.replaceAll("AND_LOGIC", " ");
        	query=query.replaceAll("START_BRACKET", " ");
        	query=query.replaceAll("OR_LOGIC", " ");
        	query=query.replaceAll("END_BRACKET", " ");
        }
        try {                
               rval = getJdbcTemplate().query(query, new Object[] {jobFamily}, new VacancyMapper());        
        } catch (EmptyResultDataAccessException eex) {
        	logger.debug("Vacancy List Data not found for " + jobFamily);
            return null;
        } 
        return rval;
	}

	//@PreAuthorize("hasPermission(#sso, 'CareerExplorer', read)")
	public List<Organization> getIFGFiletrListForJobFamily(Long sso) {
		List<Organization> rval = new ArrayList<Organization>();
        String query = getSql("getIFGFiletrListForJobFamily");
        try {                
               rval = getJdbcTemplate().query(query, new Object[] {sso}, new OrganizationMapper());        
        } catch (EmptyResultDataAccessException eex) {
        	logger.debug("IFG Filter List Data not found for " + sso);
            return null;
        } 
        return rval;
	}
	
	//@PreAuthorize("hasPermission(#sso, 'CareerExplorer', read)")
	public List<Function> getJobFunctionFilterForJobFamilyMatches(Long sso) {
		List<Function> rval = new ArrayList<Function>();
        String query = getSql("getJobFunctionFilterForJobFamilyMatches");
        try {                
               rval = getJdbcTemplate().query(query, new Object[] {sso}, new FunctionMapper());        
        } catch (EmptyResultDataAccessException eex) {
        	logger.debug("Job Family Filter List Data not found for " + sso);
            return null;
        } 
        return rval;
	}
	
	//@PreAuthorize("hasPermission(#sso, 'CareerExplorer', read)")
		public List<Country> getCountryFilterListForJobFamily(Long sso) {
			List<Country> rval = new ArrayList<Country>();
	        String query = getSql("getCountryFilterListForJobFamily");
	        try {                
	               rval = getJdbcTemplate().query(query, new Object[] {sso}, new CountryMapper());        
	        } catch (EmptyResultDataAccessException eex) {
	        	logger.debug("Job Family Country Filter List Data not found for " + sso);
	            return null;
	        } 
	        return rval;
		}	
	
}
