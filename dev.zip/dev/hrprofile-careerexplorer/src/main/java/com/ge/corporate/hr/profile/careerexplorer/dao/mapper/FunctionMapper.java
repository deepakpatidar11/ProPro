package com.ge.corporate.hr.profile.careerexplorer.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.careerexplorer.model.Function;

public class FunctionMapper implements RowMapper<Function>{	
	
	public static final String DATA_FUNCTION_NAME = "afunc_label";

	public Function mapRow(ResultSet rs, int rowNumber) throws SQLException {	
		
		Function function = new Function();		
		function.setFunctionName(rs.getString(DATA_FUNCTION_NAME));		
		return function;					
	}
}
