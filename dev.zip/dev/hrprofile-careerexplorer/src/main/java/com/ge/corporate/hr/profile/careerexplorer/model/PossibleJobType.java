package com.ge.corporate.hr.profile.careerexplorer.model;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

public class PossibleJobType extends AbstractBaseModelSupport {
	
	private static final long serialVersionUID = 2890243282306578603L;
	
	private Long sso;
	private String jobType;
	private Integer jobTypeCount;
	private Integer numOfVacancies;
	
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public Integer getJobTypeCount() {
		return jobTypeCount;
	}
	public void setJobTypeCount(Integer jobTypeCount) {
		this.jobTypeCount = jobTypeCount;
	}
	public Integer getNumOfVacancies() {
		return numOfVacancies;
	}
	public void setNumOfVacancies(Integer numOfVacancies) {
		this.numOfVacancies = numOfVacancies;
	}

}
