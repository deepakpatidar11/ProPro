package com.ge.corporate.hr.profile.careerexplorer.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.careerexplorer.model.Country;

public class CountryMapper implements RowMapper<Country>{	
	
	public static final String DATA_COUTNRY_NAME = "country_label";

	public Country mapRow(ResultSet rs, int rowNumber) throws SQLException {	
		
		Country country = new Country();		
		country.setCountryName(rs.getString(DATA_COUTNRY_NAME));		
		return country;					
	}

}
