package com.ge.corporate.hr.profile.careerexplorer.model;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

public class JobFamily extends AbstractBaseModelSupport{
	
	private static final long serialVersionUID = 2890243282306578603L;
	
	private String jobFamily;
	private int count;
	private int sumOfCount;
	private int percentageOfTotalJobFamilies;
	
	public int getSumOfCount() {
		return sumOfCount;
	}
	public void setSumOfCount(int sumOfCount) {
		this.sumOfCount = sumOfCount;
	}
	public int getPercentageOfTotalJobFamilies() {
		return percentageOfTotalJobFamilies;
	}
	public void setPercentageOfTotalJobFamilies(int percentageOfTotalJobFamilies) {
		this.percentageOfTotalJobFamilies = percentageOfTotalJobFamilies;
	}
	public String getJobFamily() {
		return jobFamily;
	}
	public void setJobFamily(String jobFamily) {
		this.jobFamily = jobFamily;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
}
