package com.ge.corporate.hr.profile.careerexplorer.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.careerexplorer.model.JobDetail;

public class JobDetailMapper implements RowMapper<JobDetail>{	
	
	//pstd_pos_tte, rl_smry_prpse, essntl_resp, qual_req, dsrd 
	
	
	public static final String DATA_TITLE = "title";
	public static final String DATA_SUMMARY_PURPOSE = "rl_smry_prpse";
	public static final String DATA_RESPONSIBILITIES = "ESSNTL_RESP";
	public static final String DATA_QUALIFICATION = "QUAL_REQ";
	public static final String DATA_DESIRED_CHAR = "DSRD";	
	
	
	public JobDetail mapRow(ResultSet rs, int rowNumber) throws SQLException {	
		
		JobDetail jobDetail = new JobDetail();
		
		jobDetail.setPositionTitle(rs.getString(DATA_TITLE));
		jobDetail.setRlSummaryPurpose(rs.getString(DATA_SUMMARY_PURPOSE));
		jobDetail.setResponsibilities(rs.getString(DATA_RESPONSIBILITIES));
		jobDetail.setRequiredQualification(rs.getString(DATA_QUALIFICATION));
		jobDetail.setDesiredCharacteristics(rs.getString(DATA_DESIRED_CHAR));
		
		
		return jobDetail;			
	}
}
