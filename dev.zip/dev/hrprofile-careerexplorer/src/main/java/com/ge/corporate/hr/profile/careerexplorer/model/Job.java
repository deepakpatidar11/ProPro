package com.ge.corporate.hr.profile.careerexplorer.model;

import java.util.Date;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

public class Job extends AbstractBaseModelSupport{
	
	private static final long serialVersionUID = 2890243282306578603L;
	
	private String title;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getVacancyNumber() {
		return vacancyNumber;
	}
	public void setVacancyNumber(int vacancyNumber) {
		this.vacancyNumber = vacancyNumber;
	}
	private Date date;
	private int vacancyNumber;

	

}
