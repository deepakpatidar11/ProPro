package com.ge.corporate.hr.profile.careerexplorer.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.careerexplorer.model.Vacancies;

public class VacanciesMapper implements RowMapper<Vacancies>{
	
	public static final String DATA_TITLE = "title";
	public static final String DATA_NUM_VACANCY = "vcncy_num";	
	public static final String DATA_JOB_POST_DATE = "V.DT_TO";


	public Vacancies mapRow(ResultSet rs, int rowNumber) throws SQLException {	
		Vacancies vacancies = new Vacancies();
		
		vacancies.setTitle(rs.getString(DATA_TITLE));
		vacancies.setVacNumber(rs.getInt(DATA_NUM_VACANCY));
		vacancies.setJobPostedDate(rs.getDate(DATA_JOB_POST_DATE));
		
		return vacancies;					
	}

}
