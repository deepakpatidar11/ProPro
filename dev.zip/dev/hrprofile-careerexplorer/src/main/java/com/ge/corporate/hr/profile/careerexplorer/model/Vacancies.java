package com.ge.corporate.hr.profile.careerexplorer.model;

import java.util.Date;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

public class Vacancies extends AbstractBaseModelSupport {
	
private static final long serialVersionUID = 2890243282306578603L;
	
	private Long sso;
	
	private String jobType;
	private String title;
	private String status;
	private String rlSummaryPurpose;
	private Integer vacNumber;
	
	private String responsibilities;
	private String requiredQualification;
	private String desiredCharacteristics;
	private Date jobPostedDate;
	
	private String business;
	private String jobFunction;
	private String jobFamily;
	
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRlSummaryPurpose() {
		return rlSummaryPurpose;
	}
	public void setRlSummaryPurpose(String rlSummaryPurpose) {
		this.rlSummaryPurpose = rlSummaryPurpose;
	}
	public Integer getVacNumber() {
		return vacNumber;
	}
	public void setVacNumber(Integer vacNumber) {
		this.vacNumber = vacNumber;
	}
	public String getResponsibilities() {
		return responsibilities;
	}
	public void setResponsibilities(String responsibilities) {
		this.responsibilities = responsibilities;
	}
	public String getRequiredQualification() {
		return requiredQualification;
	}
	public void setRequiredQualification(String requiredQualification) {
		this.requiredQualification = requiredQualification;
	}
	public String getDesiredCharacteristics() {
		return desiredCharacteristics;
	}
	public void setDesiredCharacteristics(String desiredCharacteristics) {
		this.desiredCharacteristics = desiredCharacteristics;
	}
	public Date getJobPostedDate() {
		return jobPostedDate;
	}
	public void setJobPostedDate(Date jobPostedDate) {
		this.jobPostedDate = jobPostedDate;
	}
	public String getBusiness() {
		return business;
	}
	public void setBusiness(String business) {
		this.business = business;
	}
	public String getJobFunction() {
		return jobFunction;
	}
	public void setJobFunction(String jobFunction) {
		this.jobFunction = jobFunction;
	}
	public String getJobFamily() {
		return jobFamily;
	}
	public void setJobFamily(String jobFamily) {
		this.jobFamily = jobFamily;
	}
	

}
