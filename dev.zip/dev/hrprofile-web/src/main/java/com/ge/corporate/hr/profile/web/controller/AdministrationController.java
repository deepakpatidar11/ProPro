/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
/**
 * 
 */
package com.ge.corporate.hr.profile.web.controller;


import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.owasp.esapi.ESAPI;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.impl.StdScheduler;
import org.springframework.scheduling.quartz.CronTriggerBean;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.ge.corporate.hr.profile.auth.service.ProfileAuthorityEvaluator;
import com.ge.corporate.hr.profile.auth.util.PersonAuthUtil;
import com.ge.corporate.hr.profile.common.dto.CacheNodeDto;
import com.ge.corporate.hr.profile.common.jmx.jboss.cache.JmxJbossTreeCache;
import com.ge.corporate.hr.profile.employee.dto.AdminCacheWarmUpDto;
import com.ge.corporate.hr.profile.employee.dto.AdminDto;
import com.ge.corporate.hr.profile.employee.dto.ExcelReport;
import com.ge.corporate.hr.profile.employee.service.ClientListExcelService;
import com.ge.corporate.hr.profile.employee.service.task.CacheWarmUpTask;
import com.ge.corporate.hr.profile.employee.service.task.CurrencyConversionTask;

/**
 * ****** WARNING! DO NOT DELETE THIS COMMENT**********
 * 
 * This comment was designed using the same cryptographic wisdom as the Bible Codes, the Nazca Drawings
 * and the Stonehenge site so there is in fact working code hidden within this apparently innocuous comment.
 *  
 * If this comment is removed that will cause the hidden code to stop working and in concequence 
 * that event will trigger the end of the world. 
 * 
 * This code is designed to activate piezoelectric array of vibrating quartz crystals hidden in 
 * all GE sites around the globe. The sonic beam produced by the array is intended to contain a mayor class-A 
 * singularity that spontaneously developed at 12.34 Km from the Earth's core. 
 * So, if you remove this comment you will disrupt the harmonic containment field and unleash a 
 * supermassive black hole that will devour the hole planet within seconds compacting it to the 
 * size of a water molecule.
 * 
 * This whole application is just an facade built only to conceal this hidden code from the world. 
 * 
 * Now you know the truth.
 * 
 * @author ?
 ********************************************************
 */
@Controller
public class AdministrationController {
	
	private final Log logger = LogFactory.getLog(AdministrationController.class);
	
	private static final String TRIGER_CACHE_WARM_UP = "cacheWarmUpCronTrigger";
	private static final String JOB_CACHE_WARM_UP = "jobCacheWarmUp";
	
	private static final long MEGABYTE = 1024L * 1024L;
	
	@Resource(name="cacheWarmUpTask")
	CacheWarmUpTask cache;
	
	@Resource(name="currencyConversionRatesTask")
	CurrencyConversionTask currencyConversion;
	
	@Resource(name="schedulerFactoryBean")
	StdScheduler schedulerFactoryBean;
	
	@Resource(name="jmxJbosstreeCache")
	JmxJbossTreeCache jmxJbosstreeCache;
	
	@Resource(name="clientListExcelService")
	ClientListExcelService clientListExcelService;
	
	@Resource(name = "authorityEvaluator")
	private ProfileAuthorityEvaluator authEvaluator;

	@PreAuthorize("hasRole('ROLE_SA') or hasRole('ROLE_SOD')")
	@RequestMapping("admins")
	public String showAdmin(Model model ){
		return ("redirect:admins/menu");
	}
	
	@PreAuthorize("hasRole('ROLE_SA') or hasRole('ROLE_SOD')")
	@RequestMapping("admins/menu")
	public String showAdminMenu(Model model,HttpSession session){
		
		model.addAttribute("cacheStatus", System.getProperty("disableCache"));
		model.addAttribute("logLevel", System.getProperty("geware.log.level"));
		model.addAttribute("logLevelPerformance", System.getProperty("geware.log.performance.level"));
		if (session.getAttribute("HAS_ROLE_SA") == null) {
			boolean hasRoleSA = false;
			List<String> rolesList = authEvaluator.getAutorizedRoles(
					PersonAuthUtil.getPrincipal(),
					PersonAuthUtil.getAuthorities());
			for (String role : rolesList) {
				if (role.equalsIgnoreCase("ROLE_SA")) {
					hasRoleSA = true;
				}
			}
			session.setAttribute("HAS_ROLE_SA", hasRoleSA);
		}
		return "adminMenu";
	}
	
	@PreAuthorize("hasRole('ROLE_SA') or hasRole('ROLE_SOD')")
	@RequestMapping("admins/cache/enable")
	public String disableCache(Model model){
		System.setProperty("disableCache", "false");
		
		model.addAttribute("message", "Cache is now enabled");
		
		return ("redirect:../../admins/menu");
	}
	
	@PreAuthorize("hasRole('ROLE_SA') or hasRole('ROLE_SOD')")
	@RequestMapping("admins/cache/disable")
	public String enableCache(Model model){
		System.setProperty("disableCache", "true");
		
		model.addAttribute("message", "Cache is now disabled");
		
		return ("redirect:../../admins/menu");
	}
	
	@PreAuthorize("hasRole('ROLE_SA') or hasRole('ROLE_SOD')")
	@RequestMapping("admins/cache/writeEnabledOnDisabledCache")
	public String writeEnabledOnDisabledCache(Model model){
		
		System.setProperty("writeEnabledOnDisabledCache", "true");
		model.addAttribute("message", "writeEnabledOnDisabledCache is now enabled");
		return ("redirect:../../admins/menu");
		
	}
	
	@PreAuthorize("hasRole('ROLE_SA') or hasRole('ROLE_SOD')")
	@RequestMapping("admins/cache/writeDisabledOnDisabledCache")
	public String writeDisabledOnDisabledCache(Model model){
		
		System.setProperty("writeEnabledOnDisabledCache", "false");
		model.addAttribute("message", "writeEnabledOnDisabledCache is now disabled");
		return ("redirect:../../admins/menu");
	}
	
	@PreAuthorize("hasRole('ROLE_SA') or hasRole('ROLE_SOD')")
	@RequestMapping("admins/cache/kill")
	public String killCache(Model model){
		
		try{
			cache.clearCache();			
			model.addAttribute("message", "Cache flushed succesfully");
		}catch (Exception e) {
			logger.error("Unable to destroy cache: "+ e.getMessage());
			model.addAttribute("message", "Cache flushed failed");
		}
		
		return ("redirect:../../admins/menu");
	}
	
	@PreAuthorize("hasRole('ROLE_SA') or hasRole('ROLE_SOD')")
	@RequestMapping("admins/login/{environment}/{defaultSso}")
	protected String setLoggingMode(@PathVariable("environment") String appEnvironment,  
									@PathVariable("defaultSso") String defaultSso){
		System.setProperty("app.environment", appEnvironment);
		System.setProperty("default.sso", defaultSso);
		
		return ("redirect:../../../admins/menu");
	}
	
	@PreAuthorize("hasRole('ROLE_SA') or hasRole('ROLE_SOD')")
	@RequestMapping("admins/logmode/{logLevel}")
	public String setLogMode(@PathVariable("logLevel") String logLevel, Model model){
		if(logLevel!= null &&  
				( logLevel.equalsIgnoreCase(Level.ERROR.toString()) || logLevel.equalsIgnoreCase(Level.DEBUG.toString()) || logLevel.equalsIgnoreCase(Level.TRACE.toString()) ) ){	
			System.setProperty("geware.log.level", logLevel.toUpperCase());
			
			Level level = Level.toLevel(logLevel.toLowerCase());
			Logger.getLogger("com.ge.corporate.hr").setLevel( level );
			
			model.addAttribute("message", "Log mode turn to "+ logLevel);
	    }
		
		return ("redirect:../../admins/menu");
	}
	
	@PreAuthorize("hasRole('ROLE_SA') or hasRole('ROLE_SOD')")
	@RequestMapping("admins/logperf/{enable}")
	public String enableLogPerformance(@PathVariable("enable") String enable, Model model){
		String sLevel = "";
		
		if(enable != null && enable.toUpperCase().equals("ENABLE")){
			sLevel = "TRACE"; 			
		}else{
			sLevel = "ERROR";
	    }
		
		Level level = Level.toLevel(sLevel);
		System.setProperty("geware.log.performance.level", sLevel);
		Logger.getLogger("org.springframework.aop.interceptor.PerformanceMonitorInterceptor").setLevel(level);
		model.addAttribute("message", "Log performace status is:"+ enable);
		
		return ("redirect:../../admins/menu");
	}
	
	@PreAuthorize("hasRole('ROLE_SA')")
	@RequestMapping("admins/viewmode")
	protected void setViewMode(){
		System.setProperty("app.force.view", "default");
	}
	
	@PreAuthorize("hasRole('ROLE_SA')")
	@RequestMapping("admins/viewmode/{viewprefix}")
	protected void setViewMode(@PathVariable("viewprefix") String viewPrefix ){
		System.setProperty("app.force.view", viewPrefix);
	}
	
	
	@SuppressWarnings("rawtypes")
	@PreAuthorize("hasRole('ROLE_SA') or hasRole('ROLE_SOD')")
	@RequestMapping("admins/cache/monitor")
	protected String monitorCache(Model model){
		String fqn="/";					
		try{
			Set children = jmxJbosstreeCache.getChildrenNames(fqn);
			if(children!=null){
				model.addAttribute("rootChildren",children );
				model.addAttribute("fqn",fqn );
			}			
		}catch(Exception ie){
			logger.error("Error - getting Cache Monitor");
		}		
				
		return "cacheMonitor";				
	}
	
	
	@SuppressWarnings("unchecked")
	@PreAuthorize("hasRole('ROLE_SA') or hasRole('ROLE_SOD')")
	@RequestMapping("admins/cache/monitor/getNode")
	public @ResponseBody CacheNodeDto getNode(@RequestParam("fqn") String fqn) {		
		CacheNodeDto nodeDto = new CacheNodeDto();
		try{
			String validatedFqn = ESAPI.validator().getValidInput("RequestParameter", fqn, "HTTPParameterValue", 1000, true);
			Set<String> children = jmxJbosstreeCache.getChildrenNames(validatedFqn);
			nodeDto.setChildNames(children);			
			Set<String> keys = jmxJbosstreeCache.getKeys(validatedFqn);
			nodeDto.setKeys(keys);
		}		catch(Exception ie){
			logger.error("Error - getting Cache Monitor");
		}		
		return nodeDto;
	}

	@PreAuthorize("hasRole('ROLE_SA') or hasRole('ROLE_SOD')")
	@RequestMapping("admins/cache/monitor/getData")
	public @ResponseBody Object getData(@RequestParam("fqn") String fqn, @RequestParam("key") String key) {
		Object res = null;
		try{
			String validatedFqn = ESAPI.validator().getValidInput("RequestParameter", fqn, "HTTPParameterValue", 1000, true);
			String validatedKey = ESAPI.validator().getValidInput("RequestParameter", key, "HTTPParameterValue", 1000, true);
			res =  jmxJbosstreeCache.get(validatedFqn,validatedKey);
		}catch(Exception ie){
			logger.error("Error - getting Cache Monitor");
		}		
		return res;
	}
	
	@PreAuthorize("hasRole('ROLE_SA') or hasRole('ROLE_SOD')")
	@RequestMapping("admins/cache/monitor/remove")
	public void removeChild(@RequestParam("fqn") String fqn) {		
		try{
			jmxJbosstreeCache.evict(fqn);
		}catch(Exception ie){
			logger.error("Error - evicting cache");
		}	
	}
		
	@PreAuthorize("hasRole('ROLE_SA') or hasRole('ROLE_SOD')")
	@RequestMapping(method = RequestMethod.GET,value="admins/cache/warmup")
	public String warmUpCache(@ModelAttribute("adminCacheWarmUpOptsCommand") AdminCacheWarmUpDto adminCommand,ModelMap model) {
		Runtime runtime = Runtime.getRuntime();
		CronTriggerBean trigger = null;
		adminCommand.setSubLevels(cache.getSubLevelsToRun());
		adminCommand.setEnabled(cache.isEnabled());
		try {
			trigger  = getCurrentCronTriger();
		} catch (SchedulerException e) {
			e.printStackTrace();
		}
		
		if(trigger!= null){
			adminCommand.setCronExpression(trigger.getCronExpression());
		}else{
			logger.error("Error - Trigger could not be retrieved");
		}
		
		addMemoryStatuToModel(model);
		
		return "adminWarmUp";
	}
	
	
	@RequestMapping(method = RequestMethod.POST)
	protected String onSubmit( @ModelAttribute("adminCacheWarmUpOptsCommand") AdminCacheWarmUpDto adminCommand,  
					final BindingResult result, final ModelMap model,
						final SessionStatus status ) throws SchedulerException{
		
		CronTriggerBean currentTrigger = null;
		CronTriggerBean newTriger = new CronTriggerBean();
		currentTrigger = getCurrentCronTriger();		
		if(currentTrigger!= null){
			
			cache.setSubLevelsToRun(adminCommand.getSubLevels());
			cache.setEnabled(adminCommand.isEnabled());
			newTriger.setJobDetail(currentTrigger.getJobDetail());
			newTriger.setJobName(currentTrigger.getJobDetail().getName());
			newTriger.setGroup(currentTrigger.getJobDetail().getGroup());
			try {
				newTriger.setName(TRIGER_CACHE_WARM_UP);
				newTriger.setCronExpression(adminCommand.getCronExpression());
				schedulerFactoryBean.rescheduleJob(currentTrigger.getName(), currentTrigger.getGroup(), newTriger);
				model.addAttribute("message", "Cache warm up opts were set properly");	
			} catch (ParseException e) {
				model.addAttribute("message", "cron trigger expresion is incorrect");
			}
			
			
		}else{
			logger.error("Error - job could not be rescheduled");
			model.addAttribute("message", "Error - job could not be rescheduled");
		}			
		status.setComplete();
		addMemoryStatuToModel(model);
		
		return ("adminWarmUp");				
    }
	
	
	
	
	@PreAuthorize("hasRole('ROLE_SA') or hasRole('ROLE_SOD')")
	@RequestMapping("admins/cache/warmUpManually")
	public String warmUpCache(Model model){		
		
		Thread thread = new Thread((Runnable) cache);		
		thread.start();		
		model.addAttribute("message", "Cache warmed up started succesfully");	
		return ("redirect:/admins/cache/warmup");
	}
	
	@PreAuthorize("hasRole('ROLE_SA') or hasRole('ROLE_SOD')")
	@RequestMapping("admins/cache/countEmployeesForLevel")
	public String countEmployeesForLevel(Model model){		
		
		cache.debugNavigateLevels();		
		model.addAttribute("message", "count Employees For evel executed succesfully, for more info view log file");	
		return ("redirect:/admins/cache/warmup");
	}
	
	
	private CronTriggerBean getCurrentCronTriger() throws SchedulerException{
		
		String groupNames[] = null;
		Trigger trigers[] = null;
		try {
			
			groupNames = schedulerFactoryBean.getJobGroupNames();			
			trigers = schedulerFactoryBean.getTriggersOfJob(JOB_CACHE_WARM_UP, groupNames[0]);
			if(trigers != null){
				return (CronTriggerBean)trigers[0];
			}
			
		} catch (SchedulerException e) {			
			e.printStackTrace();
		}
		return null;
	}
	
	
	@PreAuthorize("hasRole('ROLE_SA')")
	@RequestMapping("poc/orgChartJqueryPoc")
	public String orgChartJqueryPoc(Model model){		
		return ("views/web/org-chart-jquery/org-chart-jquery");
	}
	
	@PreAuthorize("hasRole('ROLE_SA')")
	@RequestMapping("poc/orgChartGooglePoc")
	public String orgChartGooglePoc(Model model){		
		return ("views/web/org-chart-jquery/org-chart-google");
	}
	
	
	@PreAuthorize("hasRole('ROLE_SA')")
	@RequestMapping("admins/loadCurrencyConversion")
	public @ResponseBody String loadCurrencyConversionTable(Model model){	
		currencyConversion.loadCurrencyConversionRates();
		try{
			return "Success";
		}catch(Exception e){
			return "Failure : "+e.toString();
		}
		
	}
	
	@PreAuthorize("hasRole('ROLE_SA') or hasRole('ROLE_SOD')")
	@RequestMapping("admins/menu/report")
	public ModelAndView getReport(Model model,@RequestParam(value = "type", required = false) String type){	
		List<ExcelReport> dataGroup=new ArrayList<ExcelReport>();
		dataGroup=clientListExcelService.getDataGroupReport(dataGroup,type);
		System.out.println(dataGroup.size());
		System.out.println("in contr");
		AdminDto admindto=new AdminDto();
		admindto.setType(type);
		admindto.setExcelreport(dataGroup);
		return new ModelAndView("DatagroupExcelReport", "AdminDto", admindto);
	}
	
	
	
	
	public static long bytesToMegabytes(long bytes) {
		return bytes / MEGABYTE;
	}
	
	
	void addMemoryStatuToModel(ModelMap model){
		Runtime runtime = Runtime.getRuntime();
		model.addAttribute("totalMemory", bytesToMegabytes(runtime.totalMemory()) + " MB" );
		model.addAttribute("freeMemory", bytesToMegabytes(runtime.freeMemory()) + " MB");
		model.addAttribute("maxMemory", bytesToMegabytes(runtime.maxMemory()) + " MB");
		model.addAttribute("cachedEECnt", cache.getCachedEmployeeCount() );
	}
	
}
