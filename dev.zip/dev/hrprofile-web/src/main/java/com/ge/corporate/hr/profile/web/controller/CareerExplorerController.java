package com.ge.corporate.hr.profile.web.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.corporate.hr.profile.auth.util.PersonAuthUtil;
/*
import com.ge.corporate.hr.profile.careerexplorer.model.Business;
import com.ge.corporate.hr.profile.careerexplorer.model.Country;
import com.ge.corporate.hr.profile.careerexplorer.model.Function;
import com.ge.corporate.hr.profile.careerexplorer.model.FuturePositionType;
import com.ge.corporate.hr.profile.careerexplorer.model.Job;
import com.ge.corporate.hr.profile.careerexplorer.model.JobDetail;
import com.ge.corporate.hr.profile.careerexplorer.model.JobFamily;
import com.ge.corporate.hr.profile.careerexplorer.model.JobTypeLibrary;
import com.ge.corporate.hr.profile.careerexplorer.model.Organization;
import com.ge.corporate.hr.profile.careerexplorer.model.PossibleJobType;
import com.ge.corporate.hr.profile.careerexplorer.model.Vacancies;
import com.ge.corporate.hr.profile.careerexplorer.model.Vacancy;
import com.ge.corporate.hr.profile.careerexplorer.service.CareerExplorerService;
*/
import com.ge.corporate.hr.profile.employee.model.UserInfo;
import com.ge.corporate.hr.profile.employee.service.EmployeeProfileService;

@Controller
public class CareerExplorerController {
/*
	@Resource(name = "employeeProfileService")
	private EmployeeProfileService personalInfoService;

	@Resource(name = "careerExplorerService")
	private CareerExplorerService careerExplorerService;
	
	@RequestMapping(value = { "careerexplorer", "careerexplorer/" })
	public String profileMe(Model model) {
		Long sso = PersonAuthUtil.getLoggedSSO();
		return ("redirect:/careerexplorer/" + sso);
	}

	@RequestMapping(value = "careerexplorer/{sso}")
    public String CareerHomePage(Model model,  @PathVariable Long sso, HttpSession session) {
		UserInfo userInfo = new UserInfo();
		userInfo = personalInfoService.getLoggedUserInfo(PersonAuthUtil.getLoggedSSO());
		session.setAttribute("USER_SSO", userInfo.getSso());
		session.setAttribute("USER_NAME", userInfo.getFirstName()+" "+userInfo.getLastName());
     return "career-explorer";
	}
	
	@RequestMapping(value = "careerexplorer/{sso}/futurepositionstypes")
	public @ResponseBody
	List<FuturePositionType> getPositionType(Model model, @PathVariable Long sso, @RequestParam(value="business", required=false) String business,@RequestParam(value="function", required=false) String function,@RequestParam(value="country", required=false) String country) {
		List<FuturePositionType> cList = new ArrayList<FuturePositionType>();
		try {
			business=URLDecoder.decode(business, "UTF-8");
			function=URLDecoder.decode(function, "UTF-8");
			country=URLDecoder.decode(country, "UTF-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		cList = this.careerExplorerService.getFuturePositionType(sso,business,function,country);
		return cList;
	}

	@RequestMapping(value = "careerexplorer/{sso}/possiblejobtypes")
	public @ResponseBody
	List<PossibleJobType> getPossibleJobTypes(Model model, @PathVariable Long sso) {
		List<PossibleJobType> cList = new ArrayList<PossibleJobType>();
		cList = this.careerExplorerService.getPossibleJobTypes(sso);
		return cList;
	}

	@RequestMapping(value = "careerexplorer/{sso}/vacancies")
	public @ResponseBody
	List<Vacancies> getVacancies(@RequestParam("jobName") String jobName, @PathVariable Long sso) {
		try {
			jobName=URLDecoder.decode(jobName, "UTF-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		List<Vacancies> cList = new ArrayList<Vacancies>();
		cList = this.careerExplorerService.getAllVacancies(jobName);
		return cList;
	}
	
	@RequestMapping(value = "careerexplorer/{sso}/businesslist")
	public @ResponseBody
	List<Business> getBusinessList(Model model, @PathVariable Long sso) {
		List<Business> cList = new ArrayList<Business>();
		cList = this.careerExplorerService.getBusinessList(sso);
		return cList;
	}
	
	@RequestMapping(value = "careerexplorer/{sso}/functionlist")
	public @ResponseBody
	List<Function> getFunctionList(Model model, @PathVariable Long sso) {
		List<Function> cList = new ArrayList<Function>();
		cList = this.careerExplorerService.getFunctionList(sso);
		return cList;
	}
	
	@RequestMapping(value = "careerexplorer/{sso}/countrylist")
	public @ResponseBody
	List<Country> getCountryList(Model model, @PathVariable Long sso) {
		List<Country> cList = new ArrayList<Country>();
		cList = this.careerExplorerService.getCountryList(sso);
		return cList;
	}
	
	@RequestMapping(value = "careerexplorer/{sso}/recentjobs")
	public @ResponseBody
	List<Job> getMostRecentJobPosting(@RequestParam("jobName") String jobName, @PathVariable Long sso) {
		try {
			jobName=URLDecoder.decode(jobName, "UTF-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		List<Job> cList = new ArrayList<Job>();
		cList = this.careerExplorerService.getMostRecentJobPosting(jobName);
		return cList;
	}
//	Return JobDetail
	@RequestMapping(value = "careerexplorer/{sso}/jobdetail")
	public @ResponseBody
	JobDetail getJobDetails(@RequestParam("vacancyNumber") String vacancyNumber, @PathVariable Long sso) {
		try {
			vacancyNumber=URLDecoder.decode(vacancyNumber, "UTF-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		JobDetail jobDetail = new JobDetail();
		jobDetail = this.careerExplorerService.getJobDetail(vacancyNumber);
		return jobDetail;
	}
	
	@RequestMapping(value = "careerexplorer/{sso}/jobtypelibrary")
	public @ResponseBody
	JobTypeLibrary getJobTypeLibrary(@RequestParam("jobType") String jobType,HttpServletRequest request, HttpServletResponse response, @PathVariable Long sso) {
		try {
			jobType=URLDecoder.decode(jobType, "UTF-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		JobTypeLibrary jobTypeLibrary = new JobTypeLibrary();
		jobTypeLibrary = this.careerExplorerService.getJobTypeLibrary(jobType);
		return jobTypeLibrary;
	}
	
	@RequestMapping(value = "careerexplorer/{sso}/jobfamilypositions")
	public @ResponseBody
	List<JobFamily> getPossibleMovesBasedOnJobFamily(Model model, @PathVariable Long sso, @RequestParam(value="business", required=false) String business,@RequestParam(value="function", required=false) String function,@RequestParam(value="country", required=false) String country) {
		try {
			business=URLDecoder.decode(business, "UTF-8");
			function=URLDecoder.decode(function, "UTF-8");
			country=URLDecoder.decode(country, "UTF-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}List<JobFamily> cList = new ArrayList<JobFamily>();
		cList = this.careerExplorerService.getPossibleMovesBasedOnJobFamily(sso,business,function,country);
		return cList;
	}
	
	@RequestMapping(value = "careerexplorer/{sso}/jobfamilyvacancies") //recent job posting
	public @ResponseBody
	List<Vacancy> getVacanciesForaGivenJobFamily(Model model, @PathVariable Long sso, @RequestParam(value="jobfamily", required=true) String jobFamily,@RequestParam(value="business", required=true) String business,@RequestParam(value="country", required=true) String country) {
		try {
			jobFamily=URLDecoder.decode(jobFamily, "UTF-8");
			business=URLDecoder.decode(business, "UTF-8");
			country=URLDecoder.decode(country, "UTF-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		List<Vacancy> cList = new ArrayList<Vacancy>();
		cList = this.careerExplorerService.getVacanciesForaGivenJobFamily(jobFamily,business,country);
		return cList;
	}
	
	@RequestMapping(value = "careerexplorer/{sso}/jobfamilybusinesslist")
	public @ResponseBody
	List<Organization> getIFGFiletrListForJobFamily(Model model, @PathVariable Long sso) {
		List<Organization> cList = new ArrayList<Organization>();
		cList = this.careerExplorerService.getIFGFiletrListForJobFamily(sso);
		return cList;
	}
	
	@RequestMapping(value = "careerexplorer/{sso}/jobfamilyfunctionlist")
	public @ResponseBody
	List<Function> getJobFunctionFilterForJobFamilyMatches(Model model, @PathVariable Long sso) {
		List<Function> cList = new ArrayList<Function>();
		cList = this.careerExplorerService.getJobFunctionFilterForJobFamilyMatches(sso);
		return cList;
	}
	
	@RequestMapping(value = "careerexplorer/{sso}/jobfamilycountrylist")
	public @ResponseBody
	List<Country> getCountryFilterListForJobFamily(Model model, @PathVariable Long sso) {
		List<Country> cList = new ArrayList<Country>();
		cList = this.careerExplorerService.getCountryFilterListForJobFamily(sso);
		return cList;
	}
	
	public EmployeeProfileService getPersonalInfoService() {
		return personalInfoService;
	}

	public void setPersonalInfoService(EmployeeProfileService personalInfoService) {
		this.personalInfoService = personalInfoService;
	}
	
	public CareerExplorerService getCareerExplorerService() {
		return careerExplorerService;
	}

	public void setCareerExplorerService(CareerExplorerService careerExplorerService) {
		this.careerExplorerService = careerExplorerService;
	}
	
*/
}
