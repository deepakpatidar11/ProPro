package com.ge.corporate.hr.profile.web.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.employee.dao.PropertyDao;
import com.ge.corporate.hr.profile.employee.dto.MyCWPopulationDto;
import com.ge.corporate.hr.profile.employee.dto.MyHrPopulationDto;
import com.ge.corporate.hr.profile.employee.model.CWPopulationFlexiGridColModel;
import com.ge.corporate.hr.profile.employee.model.HrPopulationFlexiGridColModel;
import com.ge.corporate.hr.profile.employee.model.MyCWPopulationFlexiGrid;
import com.ge.corporate.hr.profile.employee.model.MyHrPopulationFlexiGrid;
import com.ge.corporate.hr.profile.employee.model.MyOrgMgrClientFlexiGrid;
import com.ge.corporate.hr.profile.employee.service.ClientListExcelService;

@Controller
public class ClientListExcelController {
	
	@Resource(name = "clientListExcelService")
	private ClientListExcelService clientListExcelService;
	
	@Resource(name = "messageSource")
	private ReloadableResourceBundleMessageSource messageSource;

	@Resource(name = "propertyDao")
	private PropertyDao propertyDao;

	public PropertyDao getPropertyDao() {
		return propertyDao;
	}

	public void setPropertyDao(PropertyDao propertyDao) {
		this.propertyDao = propertyDao;
	}

	public ReloadableResourceBundleMessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(ReloadableResourceBundleMessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public ClientListExcelService getClientListExcelService() {
		return clientListExcelService;
	}

	public void setClientListExcelService(
			ClientListExcelService clientListExcelService) {
		this.clientListExcelService = clientListExcelService;
	}
	
	@RequestMapping("people/{sso}/json_myhrpopulation/getroles")
	public @ResponseBody
	List<String> MyHrPopulationRoles(@PathVariable Long sso, Model model) {
		List<String> roles = null;
		try {
			roles = clientListExcelService.getMyHrPopulationRoles(sso);

		} catch (Exception e) {

		}

		return roles;
	}

	@RequestMapping(value = {"people/{sso}/json_myhrpopulation","people/{sso}/json_myhrpopulation_suspends"})
	public @ResponseBody
	Object myHrPopulation(@PathVariable Long sso, Model model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) {
		
		String path = request.getServletPath().toLowerCase().replaceAll("/people/"+sso+"/", "").trim();
		boolean isSuspended = false;
		if(path.equalsIgnoreCase("json_myhrpopulation_suspends")){
			isSuspended = true;
		}
		
		MyHrPopulationDto myHrPopulationDto = new MyHrPopulationDto();
		ArrayList<HrPopulationFlexiGridColModel> rows = new ArrayList<HrPopulationFlexiGridColModel>();
		
        response.addHeader("Access-Control-Allow-Headers",
                "Content-Type, Authorization, Accept, Origin, X-Requested-With");
        // response.addHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Origin",
                request.getHeader("Origin"));
        response.addHeader("Access-Control-Allow-Credentials", "true");
   
        String _role = "";
		int page = 0;
		int rp = 0;
		int start = 0;
		int limit = 0;
		String param = "";
		String sortName = "";
		String sortOrder = "";
		List<String> roles=new ArrayList<String>();
		Locale locale = request.getLocale();
		
		if (request.getParameter("page") != null){
			page = Integer.parseInt(request.getParameter("page"));
		}
		
		if (request.getParameter("page") != null){
			page = Integer.parseInt(request.getParameter("page"));
		}

		if (request.getParameter("rp") != null){
			rp = Integer.parseInt(request.getParameter("rp"));
		}

		start = ((page - 1) * rp) + 1;
		limit = start + rp - 1;	
		
		if (request.getParameter("query") != null){
			param = request.getParameter("query");
		}

		if (request.getParameter("sortname") != null){
			sortName = request.getParameter("sortname");
		}

		if (request.getParameter("sortorder") != null){
			sortOrder = request.getParameter("sortorder");
		}

		myHrPopulationDto.setSso(sso);
		myHrPopulationDto.setLocale(locale);
		myHrPopulationDto.setFormat("JSON");
		
		if (request.getParameterValues("roles") != null){
			roles = java.util.Arrays.asList(request.getParameterValues("roles"));		
			
		}			
		if(StringUtils.join(roles,",").equalsIgnoreCase("SUPV") || StringUtils.join(roles,",").equalsIgnoreCase("MGR") || StringUtils.join(roles,",").equalsIgnoreCase("ORG_MGR")){
			
			if(StringUtils.join(roles,",").equalsIgnoreCase("SUPV")){
				_role="SUPV";
			}else if(StringUtils.join(roles,",").equalsIgnoreCase("MGR")){
				_role="MGR";
			}else if(StringUtils.join(roles,",").equalsIgnoreCase("ORG_MGR")){
				_role="ORG_MGR";
			}
			
			MyOrgMgrClientFlexiGrid myOrgMgrClientFlexiGrid = new MyOrgMgrClientFlexiGrid();		
	
			try {
				List<String> rel_types=new ArrayList<String>();
				
				if (request.getParameterValues("rel_type") != null){
					rel_types = java.util.Arrays.asList(request.getParameterValues("rel_type"));
				}					
				
				myHrPopulationDto = clientListExcelService.getMyOrgMgrClientListService(
						myHrPopulationDto, rel_types, param, start, limit, sortName,
						sortOrder, isSuspended);
				int size = myHrPopulationDto.getCount();
	
				myOrgMgrClientFlexiGrid.setSso(sso);
				myOrgMgrClientFlexiGrid.setTotal(myHrPopulationDto.getCount());
				myOrgMgrClientFlexiGrid.setHeadcount(myHrPopulationDto
						.getHeadcount());
				myOrgMgrClientFlexiGrid.setRelType(myHrPopulationDto.getRole());
				myOrgMgrClientFlexiGrid.setRole(_role);
				myOrgMgrClientFlexiGrid.setSelectedRelType(rel_types);
				myOrgMgrClientFlexiGrid.setPage(page);
				myOrgMgrClientFlexiGrid.setPagesize(rp);
				myOrgMgrClientFlexiGrid.setLocale(locale);
				myOrgMgrClientFlexiGrid.setFormat("JSON");
				if (limit > size) {
					rp = size - start +1;
				}
				if (page==0 && rp==0){
					rp=size;
				}
				myOrgMgrClientFlexiGrid.setRecords(rp);
	
				for (int i = 0; i < rp; i++) {
					HrPopulationFlexiGridColModel newarr = new HrPopulationFlexiGridColModel();
					newarr.setCell(myHrPopulationDto.getMyHrPopulationList().get(i));
					newarr.setId(i + 1);
					rows.add(newarr);
				}	
				myOrgMgrClientFlexiGrid.setRows(rows);	
			} catch (Exception e) {
				setErrorToDto(myHrPopulationDto);
			}
	        return myOrgMgrClientFlexiGrid;
		}else{	
			MyHrPopulationFlexiGrid myHrPopulationFlexiGrid = new MyHrPopulationFlexiGrid();	
			try {				
				myHrPopulationDto = clientListExcelService.getMyHrPopulation(
						myHrPopulationDto, roles, param, start, limit, sortName,
						sortOrder, isSuspended);
				int size = myHrPopulationDto.getCount();
	
				session.setAttribute("EXCEL_SEARCH", param);
				session.setAttribute("EXCEL_ROLES", roles);
				session.setAttribute("EXCEL_TOTAL", size);
				session.setAttribute("EXCEL_SORTNAME", sortName);
				session.setAttribute("EXCEL_SORTORDER", sortOrder);
	
				myHrPopulationFlexiGrid.setSso(sso);
				myHrPopulationFlexiGrid.setTotal(myHrPopulationDto.getCount());
				myHrPopulationFlexiGrid.setHeadcount(myHrPopulationDto
						.getHeadcount());
				myHrPopulationFlexiGrid.setRole(myHrPopulationDto.getRole());
				myHrPopulationFlexiGrid.setSelectedRoles(roles);
				myHrPopulationFlexiGrid.setPage(page);
				myHrPopulationFlexiGrid.setPagesize(rp);
				myHrPopulationFlexiGrid.setLocale(locale);
				myHrPopulationFlexiGrid.setFormat("JSON");
				if (limit > size) {
					rp = size - start + 1;
				}
				if (page==0 && rp==0){
					rp=size;
				}
				myHrPopulationFlexiGrid.setRecords(rp);
	
				for (int i = 0; i < rp; i++) {
					HrPopulationFlexiGridColModel newarr = new HrPopulationFlexiGridColModel();
					newarr.setCell(myHrPopulationDto.getMyHrPopulationList().get(i));
					newarr.setId(i + 1);
					rows.add(newarr);
				}
	
				myHrPopulationFlexiGrid.setRows(rows);
	
			} catch (Exception e) {
				setErrorToDto(myHrPopulationDto);
			}	
			return myHrPopulationFlexiGrid;
		}
	}
    
    @RequestMapping(
    		value = { 	"people/{sso}/json_myhrpopulation_adds", 
    					"people/{sso}/json_myhrpopulation_exits",
    					"people/{sso}/json_myhrpopulation_leaving",
    					"people/{sso}/json_myhrpopulation_pendingAdds"
    				})
    public @ResponseBody
    MyHrPopulationFlexiGrid myhrpopulation_otherclients(@PathVariable Long sso, Model model,
                  HttpServletRequest request, HttpServletResponse response,
                  HttpSession session) {
    	
    	String path = request.getServletPath().toLowerCase().replaceAll("/people/"+sso+"/", "").trim();

		MyHrPopulationDto myHrPopulationDto = new MyHrPopulationDto();
		MyHrPopulationFlexiGrid myHrPopulationFlexiGrid = new MyHrPopulationFlexiGrid();
		ArrayList<HrPopulationFlexiGridColModel> rows = new ArrayList<HrPopulationFlexiGridColModel>();

		try {
			int page = 0;
			int rp = 0;
			int start = 0;
			int limit = 0;
			String param = "";
			String sortName = "";
			String sortOrder = "";
			String roles = "";
			List<String> role=new ArrayList<String>();
			
			if (request.getParameterValues("roles") != null){
				roles = request.getParameter("roles");
				role.add(roles);
			}
			
			if (request.getParameter("page") != null){
				page = Integer.parseInt(request.getParameter("page"));
			}

			if (request.getParameter("rp") != null){
				rp = Integer.parseInt(request.getParameter("rp"));
			}
			
			start = ((page - 1) * rp) + 1;
			limit = start + rp - 1;			

			if (request.getParameter("query") != null){
				param = request.getParameter("query");
			}

			if (request.getParameter("sortname") != null){
				sortName = request.getParameter("sortname");
			}

			if (request.getParameter("sortorder") != null){
				sortOrder = request.getParameter("sortorder");
			}

			Locale locale = request.getLocale();
			
			myHrPopulationDto.setSso(sso);
			myHrPopulationDto.setLocale(locale);
			myHrPopulationDto.setFormat("JSON");
			
			if(path.equalsIgnoreCase("json_myhrpopulation_adds")){			
				myHrPopulationDto = clientListExcelService.getMyHrPopulationOthers(
						myHrPopulationDto, roles, param, start, limit, sortName,
						sortOrder, "ADDS");
			}else if(path.equalsIgnoreCase("json_myhrpopulation_exits")){
				myHrPopulationDto = clientListExcelService.getMyHrPopulationOthers(
						myHrPopulationDto, roles, param, start, limit, sortName,
						sortOrder, "EXIT");
			}else if(path.equalsIgnoreCase("json_myhrpopulation_leaving")){
				myHrPopulationDto = clientListExcelService.getMyHrPopulationOthers(
						myHrPopulationDto, roles, param, start, limit, sortName,
						sortOrder, "LEAVING");
			}else if(path.equalsIgnoreCase("json_myhrpopulation_pendingAdds")){
				myHrPopulationDto = clientListExcelService.getMyHrPopulationOthers(
						myHrPopulationDto, roles, param, start, limit, sortName,
						sortOrder, "PENDING");
			}
			int size = myHrPopulationDto.getCount();

			myHrPopulationFlexiGrid.setSso(sso);
			myHrPopulationFlexiGrid.setTotal(myHrPopulationDto.getCount());
			myHrPopulationFlexiGrid.setHeadcount(myHrPopulationDto
					.getHeadcount());
			myHrPopulationFlexiGrid.setRole(role);
			myHrPopulationFlexiGrid.setSelectedRoles(role);
			myHrPopulationFlexiGrid.setPage(page);
			myHrPopulationFlexiGrid.setPagesize(rp);
			myHrPopulationFlexiGrid.setLocale(locale);
			myHrPopulationFlexiGrid.setFormat("JSON");
			if (limit > size) {
				rp = size - start + 1;
			}
			if (page==0 && rp==0){
				rp=size;
			}
			myHrPopulationFlexiGrid.setRecords(rp);

			for (int i = 0; i < rp; i++) {
				HrPopulationFlexiGridColModel newarr = new HrPopulationFlexiGridColModel();
				newarr.setCell(myHrPopulationDto.getMyHrPopulationList().get(i));
				newarr.setId(i + 1);
				rows.add(newarr);
			}

			myHrPopulationFlexiGrid.setRows(rows);

		} catch (Exception e) {
			setErrorToDto(myHrPopulationDto);
		}

           response.addHeader("Access-Control-Allow-Headers",
                        "Content-Type, Authorization, Accept, Origin, X-Requested-With");
           // response.addHeader("Access-Control-Allow-Origin", "*");
           response.setHeader("Access-Control-Allow-Origin",
                        request.getHeader("Origin"));
           response.addHeader("Access-Control-Allow-Credentials", "true");

           return myHrPopulationFlexiGrid;
    }
  
	@RequestMapping(value = {"people/{sso}/excel_myhrpopulation","people/{sso}/excel_myhrpopulation_suspends"})
	public ModelAndView generateExcel(Model model, @PathVariable Long sso,
			HttpSession session, HttpServletRequest request) {
		
		String path = request.getServletPath().toLowerCase().replaceAll("/people/"+sso+"/", "").trim();
		boolean isSuspended = false;
		if(path.equalsIgnoreCase("excel_myhrpopulation_suspends")){
			isSuspended = true;
		}

		MyHrPopulationDto myHrPopulationDto = new MyHrPopulationDto();
		Locale locale = request.getLocale();
		
		myHrPopulationDto.setSso(sso);
		myHrPopulationDto.setLocale(locale);
		myHrPopulationDto.setFormat("EXCEL");

		String param = "";
		String sortName = "";
		String sortOrder = "";
		List<String> roles = new ArrayList<String>();
		List<String> rel_types = new ArrayList<String>();
		List<String> columns = new ArrayList<String>();

		if (request.getParameter("query") != null){
			param = request.getParameter("query");
		}else if (session.getAttribute("EXCEL_SEARCH") != null){
			param = (String) session.getAttribute("EXCEL_SEARCH");
		}

		if (request.getParameter("sortname") != null){
			sortName = request.getParameter("sortname");
		}else if (session.getAttribute("EXCEL_SORTNAME") != null){
			sortName = (String) session.getAttribute("EXCEL_SORTNAME");
		}

		if (request.getParameter("sortorder") != null){
			sortOrder = request.getParameter("sortorder");
		}else if (session.getAttribute("EXCEL_SORTORDER") != null){
			sortOrder = (String) session.getAttribute("EXCEL_SORTORDER");
		}
		
		if (request.getParameterValues("roles") != null){
			roles = java.util.Arrays.asList(request.getParameterValues("roles"));
		}else if (session.getAttribute("EXCEL_ROLES") != null){
			roles = (List<String>) session.getAttribute("EXCEL_ROLES");
		}
		
		if (request.getParameterValues("rel_type") != null){
			rel_types = java.util.Arrays.asList(request.getParameterValues("rel_type"));
		}
		
		if (request.getParameterValues("columns") != null){
			columns = java.util.Arrays.asList(request.getParameterValues("columns"));
		}
		try {
			if(StringUtils.join(roles,",").equalsIgnoreCase("SUPV") || StringUtils.join(roles,",").equalsIgnoreCase("MGR") || StringUtils.join(roles,",").equalsIgnoreCase("ORG_MGR")){		
				myHrPopulationDto = clientListExcelService.getMyOrgMgrClientListExcelService(
						myHrPopulationDto,
						rel_types, param, 0, Integer.parseInt(propertyDao.getByKey("excel.limit")), sortName, sortOrder, isSuspended);
			}else{		
				myHrPopulationDto = clientListExcelService.getMyHrPopulationExcel(
						myHrPopulationDto,
						roles, param, 0, Integer.parseInt(propertyDao.getByKey("excel.limit")), sortName, sortOrder, isSuspended);
			}
			myHrPopulationDto.setFullname(clientListExcelService.getFullName(sso));
			myHrPopulationDto.setColumns(columns);
			myHrPopulationDto.setLocale(locale);
			myHrPopulationDto.setFormat("EXCEL");
		}
		catch (Exception e) {
			setErrorToDto(myHrPopulationDto);
		}
		return new ModelAndView("MyHRPopulationExcelReport", "MyClientList",
				myHrPopulationDto);	
	}
	
    @RequestMapping(value = { 	"people/{sso}/excel_myhrpopulation_adds", 
								"people/{sso}/excel_myhrpopulation_exits",
								"people/{sso}/excel_myhrpopulation_leaving",
								"people/{sso}/excel_myhrpopulation_pendingAdds"
							})
    public ModelAndView generateExcelOtherClients(Model model, @PathVariable Long sso,
                  HttpSession session, HttpServletRequest request) {
    	
    	String path = request.getServletPath().toLowerCase().replaceAll("/people/"+sso+"/", "").trim();
    	
           MyHrPopulationDto myHrPopulationDto = new MyHrPopulationDto();
           Locale locale = request.getLocale();
			
           myHrPopulationDto.setSso(sso);
           myHrPopulationDto.setLocale(locale);
           myHrPopulationDto.setFormat("EXCEL");

           String param = "";
           String sortName = "";
           String sortOrder = "";
           String roles = "";
           List<String> columns = new ArrayList<String>();
        	   
           if (request.getParameter("query") != null){
             param = request.getParameter("query");
           }

           if (request.getParameter("sortname") != null){
             sortName = request.getParameter("sortname");
           }

           if (request.getParameter("sortorder") != null){
             sortOrder = request.getParameter("sortorder");
           }
           
           if (request.getParameter("roles") != null){
         		roles = request.getParameter("roles");
           }
           
           
           if (request.getParameterValues("columns") != null){
                  columns = java.util.Arrays.asList(request.getParameterValues("columns"));
           }
           try{
                if(path.equalsIgnoreCase("excel_myhrpopulation_adds")){
                	myHrPopulationDto = clientListExcelService.getMyHrPopulationOthers(
                            myHrPopulationDto,
                            roles, param, 0, Integer.parseInt(propertyDao.getByKey("excel.limit")), sortName, sortOrder,"ADDS");  
      			}else if(path.equalsIgnoreCase("excel_myhrpopulation_exits")){
      				myHrPopulationDto = clientListExcelService.getMyHrPopulationOthers(
                            myHrPopulationDto,
                            roles, param, 0, Integer.parseInt(propertyDao.getByKey("excel.limit")), sortName, sortOrder,"EXIT");
      			}else if(path.equalsIgnoreCase("excel_myhrpopulation_leaving")){
      				myHrPopulationDto = clientListExcelService.getMyHrPopulationOthers(
                            myHrPopulationDto,
                            roles, param, 0, Integer.parseInt(propertyDao.getByKey("excel.limit")), sortName, sortOrder,"LEAVING");
      			}else if(path.equalsIgnoreCase("excel_myhrpopulation_pendingAdds")){
      				myHrPopulationDto = clientListExcelService.getMyHrPopulationOthers(
                            myHrPopulationDto,
                            roles, param, 0, Integer.parseInt(propertyDao.getByKey("excel.limit")), sortName, sortOrder,"PENDING");
      			}
                myHrPopulationDto.setFullname(clientListExcelService.getFullName(sso));
                myHrPopulationDto.setColumns(columns);
                myHrPopulationDto.setLocale(locale);
                myHrPopulationDto.setFormat("EXCEL");
           }

           catch (Exception e) {
                  setErrorToDto(myHrPopulationDto);
           }
           return new ModelAndView("MyHRPopulationExcelReport", "MyClientList",
                        myHrPopulationDto);
    }
    
    @RequestMapping(value = "people/{sso}/json_mycwpopulation")
	public @ResponseBody
	Object myCWPopulation(@PathVariable Long sso, Model model,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) {
		
		MyCWPopulationDto myCWPopulationDto = new MyCWPopulationDto();
		ArrayList<CWPopulationFlexiGridColModel> rows = new ArrayList<CWPopulationFlexiGridColModel>();
		
        response.addHeader("Access-Control-Allow-Headers",
                "Content-Type, Authorization, Accept, Origin, X-Requested-With");
        // response.addHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Origin",
                request.getHeader("Origin"));
        response.addHeader("Access-Control-Allow-Credentials", "true");
   
		int page = 0;
		int rp = 0;
		int start = 0;
		int limit = 0;
		String param = "";
		String sortName = "";
		String sortOrder = "";
		Locale locale = request.getLocale();
		List<String> roles=new ArrayList<String>();
		List<String> rel_types=new ArrayList<String>();
		List<String> subpersontypes=new ArrayList<String>();

		if (request.getParameter("page") != null){
			page = Integer.parseInt(request.getParameter("page"));
		}
		
		if (request.getParameter("page") != null){
			page = Integer.parseInt(request.getParameter("page"));
		}

		if (request.getParameter("rp") != null){
			rp = Integer.parseInt(request.getParameter("rp"));
		}

		start = ((page - 1) * rp) + 1;
		limit = start + rp - 1;	
		
		if (request.getParameter("query") != null){
			param = request.getParameter("query");
		}

		if (request.getParameter("sortname") != null){
			sortName = request.getParameter("sortname");
		}

		if (request.getParameter("sortorder") != null){
			sortOrder = request.getParameter("sortorder");
		}

		myCWPopulationDto.setSso(sso);
		myCWPopulationDto.setLocale(locale);
		myCWPopulationDto.setFormat("JSON");
		
		if (request.getParameterValues("roles") != null){
			roles = java.util.Arrays.asList(request.getParameterValues("roles"));
		}
		
		if (request.getParameterValues("rel_type") != null){
			rel_types = java.util.Arrays.asList(request.getParameterValues("rel_type"));
		}
		
		if (request.getParameterValues("subpersontype") != null){
			subpersontypes = java.util.Arrays.asList(request.getParameterValues("subpersontype"));
		}
		
		MyCWPopulationFlexiGrid myCWPopulationFlexiGrid = new MyCWPopulationFlexiGrid();	
		try {				
			myCWPopulationDto = clientListExcelService.getMyCWPopulation(
					myCWPopulationDto, roles, rel_types, param, start, limit, sortName,
					sortOrder, subpersontypes);
			int size = myCWPopulationDto.getCount();

			myCWPopulationFlexiGrid.setSso(sso);
			myCWPopulationFlexiGrid.setTotal(myCWPopulationDto.getCount());
			myCWPopulationFlexiGrid.setRole(roles);
			myCWPopulationFlexiGrid.setRel_type(rel_types);
			myCWPopulationFlexiGrid.setSubpersontype(subpersontypes);
			myCWPopulationFlexiGrid.setPage(page);
			myCWPopulationFlexiGrid.setPagesize(rp);
			myCWPopulationFlexiGrid.setLocale(locale);
			myCWPopulationFlexiGrid.setFormat("JSON");
			if (limit > size) {
				rp = size - start + 1;
			}
			if (page==0 && rp==0){
				rp=size;
			}
			myCWPopulationFlexiGrid.setRecords(rp);

			for (int i = 0; i < rp; i++) {
				CWPopulationFlexiGridColModel newarr = new CWPopulationFlexiGridColModel();
				newarr.setCell(myCWPopulationDto.getMyCWPopulationList().get(i));
				newarr.setId(i + 1);
				rows.add(newarr);
			}

			myCWPopulationFlexiGrid.setRows(rows);

		} catch (Exception e) {
			setErrorToDto(myCWPopulationDto);
		}	
		return myCWPopulationFlexiGrid;
	}
    
	@RequestMapping(value = "people/{sso}/excel_mycwpopulation")
	public ModelAndView generateExcelCWClientList(Model model, @PathVariable Long sso,
			HttpSession session, HttpServletRequest request) {
		
		MyCWPopulationDto myCWPopulationDto = new MyCWPopulationDto();
		Locale locale = request.getLocale();
		
		myCWPopulationDto.setSso(sso);
		myCWPopulationDto.setLocale(locale);
		myCWPopulationDto.setFormat("EXCEL");

		String param = "";
		String sortName = "";
		String sortOrder = "";
		List<String> roles = new ArrayList<String>();
		List<String> rel_types = new ArrayList<String>();
		List<String> subpersontypes=new ArrayList<String>();
		List<String> columns = new ArrayList<String>();
		if (request.getParameter("query") != null){
			param = request.getParameter("query");
		}

		if (request.getParameter("sortname") != null){
			sortName = request.getParameter("sortname");
		}

		if (request.getParameter("sortorder") != null){
			sortOrder = request.getParameter("sortorder");
		}
		
		if (request.getParameterValues("roles") != null){
			roles = java.util.Arrays.asList(request.getParameterValues("roles"));
		}
		
		if (request.getParameterValues("rel_type") != null){
			rel_types = java.util.Arrays.asList(request.getParameterValues("rel_type"));
		}
		
		if (request.getParameterValues("subpersontype") != null){
			subpersontypes = java.util.Arrays.asList(request.getParameterValues("subpersontype"));
		}
		
		if (request.getParameterValues("columns") != null){
			columns = java.util.Arrays.asList(request.getParameterValues("columns"));
			}
		try{
				myCWPopulationDto = clientListExcelService.getMyCWPopulation(
						myCWPopulationDto,
						roles, rel_types, param, 0, Integer.parseInt(propertyDao.getByKey("excel.limit")), sortName, sortOrder, subpersontypes);
				myCWPopulationDto.setFullname(clientListExcelService.getFullName(sso));
				myCWPopulationDto.setColumns(columns);
				myCWPopulationDto.setLocale(locale);
				myCWPopulationDto.setFormat("EXCEL");
		}
		catch (Exception e) {
			setErrorToDto(myCWPopulationDto);
		}
		return new ModelAndView("MyCWPopulationExcelReport", "MyClientList",
				myCWPopulationDto);	
	}
    
	public void setErrorToDto(AbstractBaseDtoSupport baseDto) {
		baseDto.setSuccess(false);
		baseDto.setErrorMesage(messageSource.getMessage(
				"errors.internal.error", null, "Internal error", null));
	}
  
	
	
}
