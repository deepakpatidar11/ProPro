package com.ge.corporate.hr.profile.web.configurer;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

import com.ge.corporate.hr.profile.employee.dao.PropertyDao;
import com.ge.corporate.hr.profile.employee.model.Property;


public class ExposablePlaceholderConfigurer extends PropertyPlaceholderConfigurer{
	
	
	private PropertyDao propertyDao;
	
	private Map<String,String> exposableProperties;
	
	@Override
	protected void processProperties(ConfigurableListableBeanFactory beanFactoryToProcess, 
				Properties props) throws BeansException
	{				
		super.processProperties(beanFactoryToProcess, props);		
		exposableProperties = Collections.synchronizedMap(new HashMap<String, String>());
		
		for(Object key: props.keySet()){
			String keyName = key.toString();			
			exposableProperties.put(keyName, props.getProperty(keyName));
		}
		
		for(Property prop: propertyDao.getList()){
			exposableProperties.put(prop.getKey(), prop.getValue()); 
		}	
		
	}
	
	public Map<String, String> getExposableProperties() {
		return exposableProperties;
	}

	public PropertyDao getPropertyDao() {
		return propertyDao;
	}

	public void setPropertyDao(PropertyDao properyDao) {
		this.propertyDao = properyDao;
	}
	
	
	
}
