/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
/**
 * 
 */
package com.ge.corporate.hr.profile.web.controller;

/**
 * @author francisco.blanco
 *
 */



import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.ge.corporate.hr.profile.auth.model.DataGroup;
import com.ge.corporate.hr.profile.auth.service.ProfileRolesDetailsService;
import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.employee.dto.AdminDto;




@Controller
@SessionAttributes
public class AuthorizationController {
	
	
	@Resource(name = "rolesDetailService")
	private ProfileRolesDetailsService profileRolesService;
	private ReloadableResourceBundleMessageSource messageSource;
	
		
		
	public ProfileRolesDetailsService getProfileRolesService() {
		return profileRolesService;
	}

	public void setProfileRolesService(
			ProfileRolesDetailsService profileRolesService) {
		this.profileRolesService = profileRolesService;
	}

	
	
	/****
	 *  Gets dataGroups of "other" SSO, which are visible to "sso"
	 * @param sso
	 * @param history
	 * @param model
	 * /employees/{sso}/permissions
	 * @return
	 */
	@RequestMapping(method = RequestMethod.GET,value="admins/roleDataGroups")
	public String showNameForm(@ModelAttribute("adminCommand") AdminDto adminCommand,ModelMap model) {
		//final User user 							= PersonAuthUtil.getPrincipal();
		loadAdminData(adminCommand,"3");
		
		return "adminRoleDataGroups";
	}
	
	
	/**
	 * <p>Called when the user finally submits 
	 * @param classCommand
	 * @param model
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST,value="admins/update")
	public @ResponseBody String update( @ModelAttribute("param") AdminDto adminCommand ) 
			{
	
		profileRolesService.deleteDataGroups(adminCommand.getSelectedRole());
		profileRolesService.insertDataGroups(adminCommand.getSelectDataGroups(),adminCommand.getSelectedRole());
		
		//status.setComplete();
		
		//loadAdminData(adminCommand,adminCommand.getSelectedRole());
		
		return "success";
    }

	
	
	
	/**
	 * <p>Called when the user finally submits 
	 * @param classCommand
	 * @param model
	 * @return
	 */
	@RequestMapping(method= RequestMethod.GET, value="admins/datagroups")
	protected @ResponseBody AdminDto loadDatagroups(
			@RequestParam(value="roleId",required=false) String roleId,
			@ModelAttribute("adminCommand") AdminDto adminCommand,final BindingResult result, final ModelMap model,
			final SessionStatus status  )
			{
		
		 adminCommand  = new AdminDto();
		 
		 	try{
				// Get performance data
			 	loadAdminData(adminCommand, roleId);
		 	}catch(Exception e){
				setErrorToDto(adminCommand);
			}
			
		// Get performance data
		return adminCommand;
    }
	
	
	/**
	 * <p>Called when the user finally submits
	 * @param classCommand
	 * @param model
	 * @return
	 */
	@RequestMapping("admins/datagroups")
	protected String loadDatagroups(@ModelAttribute("adminCommand") AdminDto adminCommand,  
			final BindingResult result, final ModelMap model,
			final SessionStatus status ) 
			{
		
		loadAdminData(adminCommand, adminCommand.getSelectedRole());

		
		return "adminRoleDataGroups";
    }
	
	
	public void setErrorToDto(AbstractBaseDtoSupport baseDto){	
		baseDto.setSuccess(false);
		baseDto.setErrorMesage(messageSource.getMessage("errors.internal.error", null, "Internal error", null));		
	}
	
	private AdminDto loadAdminData(AdminDto adminCommand,final String roleId){
		List<DataGroup> resume=new ArrayList<DataGroup>();
		List<DataGroup> Compens=new ArrayList<DataGroup>();
		List<DataGroup> transa=new ArrayList<DataGroup>();
		List<DataGroup> orgchart=new ArrayList<DataGroup>();
		List<DataGroup> contactDemo=new ArrayList<DataGroup>();
		List<DataGroup> workcareer=new ArrayList<DataGroup>();
		List<DataGroup> edutar=new ArrayList<DataGroup>();
		List<DataGroup> other=new ArrayList<DataGroup>();
		adminCommand.setRoles(profileRolesService.loadAdminRoles());
		adminCommand.setDataGroups(profileRolesService.loadAdminDataGroup());
		List<DataGroup> datagroup=profileRolesService.loadAdminDataGroup();
		for (DataGroup dataGroup2 : datagroup) {
			DataGroup dg=new DataGroup();
			String Datagroup=dataGroup2.getName();
			if(Datagroup.contains("Resume"))
			{
				dg.setId(dataGroup2.getId());
				dg.setElements(dataGroup2.getElements());
				dg.setName(dataGroup2.getName());
				resume.add(dg);
			}
			else if(Datagroup.contains("Compensation"))
			{
				dg.setId(dataGroup2.getId());
				dg.setElements(dataGroup2.getElements());
				dg.setName(dataGroup2.getName());
				Compens.add(dg);
				
			}
			else if(Datagroup.contains("Transaction"))
			{
				dg.setId(dataGroup2.getId());
				dg.setElements(dataGroup2.getElements());
				dg.setName(dataGroup2.getName());
				transa.add(dg);
			}
			else if(Datagroup.contains("OrgChart"))
			{
				dg.setId(dataGroup2.getId());
				dg.setElements(dataGroup2.getElements());
				dg.setName(dataGroup2.getName());
				orgchart.add(dg);
				
			}
			else if(Datagroup.contains("Emergency")||Datagroup.contains("Address")||Datagroup.contains("Dates"))
			{
				dg.setId(dataGroup2.getId());
				dg.setElements(dataGroup2.getElements());
				dg.setName(dataGroup2.getName());
				contactDemo.add(dg);
				
			}
			else if(Datagroup.contains("WorkAssignment")||Datagroup.contains("WorkRegion")||Datagroup.contains("CareerExplorer"))
			{
				dg.setId(dataGroup2.getId());
				dg.setElements(dataGroup2.getElements());
				dg.setName(dataGroup2.getName());
				workcareer.add(dg);
			}
			else if(Datagroup.equalsIgnoreCase("Education")||Datagroup.equalsIgnoreCase("Training")||Datagroup.contains("SearchExcel"))
			{
				dg.setId(dataGroup2.getId());
				dg.setElements(dataGroup2.getElements());
				dg.setName(dataGroup2.getName());
				edutar.add(dg);
			}
			else{
				dg.setId(dataGroup2.getId());
				dg.setElements(dataGroup2.getElements());
				dg.setName(dataGroup2.getName());
				other.add(dg);
			}
			
		}
		/*for (DataGroup dataGroup2 : resume) {
			System.out.println(dataGroup2);
		}*/
		adminCommand.setSelectDataGroups(profileRolesService.getSelectDataGroup(roleId));
		adminCommand.setInternalResume(resume);
		adminCommand.setCompensation(Compens);
		adminCommand.setOrgChart(orgchart);
		adminCommand.setTranSa(transa);
		adminCommand.setContactDemo(contactDemo);
		adminCommand.setSelectedRole(roleId);
		adminCommand.setWorkCareer(workcareer);
		adminCommand.setEducation(edutar);
		adminCommand.setOther(other);
		return adminCommand;
		
	}

	
	
	
	
}
