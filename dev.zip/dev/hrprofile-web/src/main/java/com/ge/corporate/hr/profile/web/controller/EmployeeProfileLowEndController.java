/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.web.controller;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ge.corporate.hr.profile.auth.model.DataGroup;
import com.ge.corporate.hr.profile.auth.service.ProfileAuthorityEvaluator;
import com.ge.corporate.hr.profile.auth.util.PersonAuthUtil;
import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.employee.dto.AssignmentDto;
import com.ge.corporate.hr.profile.employee.dto.AssignmentHistoryDto;
import com.ge.corporate.hr.profile.employee.dto.CompensationDto;
import com.ge.corporate.hr.profile.employee.dto.AutoCompleteDto;
import com.ge.corporate.hr.profile.employee.dto.EducationTrainingDto;
import com.ge.corporate.hr.profile.employee.dto.EmployeeHistoryDto;
import com.ge.corporate.hr.profile.employee.dto.MyClientsDto;
import com.ge.corporate.hr.profile.employee.dto.PerformanceDto;
import com.ge.corporate.hr.profile.employee.dto.PersonalCVDto;
import com.ge.corporate.hr.profile.employee.dto.PersonalInfoDto;
import com.ge.corporate.hr.profile.employee.service.CompensationService;
import com.ge.corporate.hr.profile.employee.service.EmployeeHistoryService;
import com.ge.corporate.hr.profile.employee.service.EmployeeProfileService;
import com.ge.corporate.hr.profile.employee.service.PerformanceService;
import com.ge.corporate.hr.profile.employee.service.PersonalCVService;
import com.ge.corporate.hr.profile.employee.service.SearchService;
import com.ge.corporate.hr.profile.employee.service.WorkAssignmentService;


@Controller
public class EmployeeProfileLowEndController{

		
	@Resource
	private ProfileAuthorityEvaluator authEvaluator;	
	@Resource(name = "employeeProfileService")
	private EmployeeProfileService personalInfoService;
	@Resource(name = "workAssignmentService")
	private WorkAssignmentService workAssignmentService;
	@Resource(name = "personalCVService")
	private PersonalCVService personalCVService;
	@Resource(name = "performanceService")
	private PerformanceService performanceService;
	@Resource(name = "compensationService")
	private CompensationService compensationService;	
	@Resource(name = "messageSource")
	private ReloadableResourceBundleMessageSource messageSource;	
	@Resource(name = "searchService")
	private SearchService searchService;
	@Resource(name = "employeeHistoryService")	
	private EmployeeHistoryService employeeHistoryService;
	
	@RequestMapping("people/assignment/{sso}")
	public String assignment(
			@PathVariable Long sso, 
			Model model ) {
		
		Map<String, DataGroup> dataGroups = authEvaluator.getDataGroupsForContextAsMap(PersonAuthUtil.getPrincipal(), PersonAuthUtil.getAuthorities(), sso);
		
		AssignmentDto assignmentDto = new  AssignmentDto();
		AssignmentHistoryDto assignmentHistDto = new  AssignmentHistoryDto();
		PersonalInfoDto personalInfo = new PersonalInfoDto();
		MyClientsDto myClientsDto = new  MyClientsDto();
		
		assignmentHistDto.setSso(sso);		
		assignmentDto.setSso(sso);		
		personalInfo.setSso(sso);
		myClientsDto.setSso(sso);
		
		personalInfo = personalInfoService.getPersonalInfo(personalInfo);
		assignmentDto = workAssignmentService.getCurrentInformation(assignmentDto);
		assignmentHistDto = workAssignmentService.getJobHistoryInformation(assignmentHistDto);
		myClientsDto = workAssignmentService.getMyClients(myClientsDto);
		
		model.addAttribute("dataGroups", dataGroups);
		model.addAttribute("assignment", assignmentDto);
		model.addAttribute("assignmentHist", assignmentHistDto);
		model.addAttribute("personalInfo", personalInfo);
		model.addAttribute("myClients", myClientsDto);
		
		return "assignment";
					
	}	
	/**
	 * Load Education Information 
	 * @param sso
	 * @param history
	 * @param model
	 * @return
	 */
	@RequestMapping("people/personal_cv/{sso}")
	public String education(
			@PathVariable Long sso, 
			Model model ) {
		
		PersonalInfoDto personalInfo = new PersonalInfoDto();
		PersonalCVDto personalCVDto = new PersonalCVDto();
		EducationTrainingDto educationDto = new EducationTrainingDto();
		EmployeeHistoryDto employeeHistoryDto = new EmployeeHistoryDto(sso);
		Map<String, DataGroup> dataGroups = authEvaluator.getDataGroupsForContextAsMap(PersonAuthUtil.getPrincipal(), PersonAuthUtil.getAuthorities(), sso);
		
		
		personalInfo.setSso(sso);
		personalCVDto.setSso(sso);
		educationDto.setSso(sso);
		employeeHistoryDto.setSso(sso);
		
		
		personalInfo = personalInfoService.getPersonalInfo(personalInfo);
		// Get demographics data
		personalCVDto = personalCVService.getDemographics(personalCVDto);
		educationDto = personalCVService.getEducationAndTraining(educationDto);		
		employeeHistoryDto = employeeHistoryService.getEmployeeHistory(employeeHistoryDto);
		
				
		model.addAttribute("dataGroups", dataGroups);
		model.addAttribute("demographics", personalCVDto);
		model.addAttribute("education", educationDto);
		model.addAttribute("personalInfo", personalInfo);
		model.addAttribute("empHistory", employeeHistoryDto);
		
		return "personal_cv";				
		// Get Education data
	}

	
	/**
	 * Controller that loads Performance Information 
	 * @param sso
	 * @param history
	 * @param model
	 * @return
	 */
	@RequestMapping("people/performance/{sso}")
	public String performance(
			@PathVariable Long sso, 
			Model model ){
		
		Map<String, DataGroup> dataGroups 	= authEvaluator.getDataGroupsForContextAsMap
												(PersonAuthUtil.getPrincipal(), PersonAuthUtil.getAuthorities(), sso);
		PerformanceDto performanceDto 		= new PerformanceDto(sso);
		CompensationDto compensationDto		= new CompensationDto(sso);
		PersonalInfoDto personalInfo 		= new PersonalInfoDto();
		
		personalInfo.setSso(sso);
		performanceDto.setSso(sso);
		
		performanceDto 						= performanceService.getPerformance(performanceDto);		
		personalInfo		 				= personalInfoService.getPersonalInfo(personalInfo);
		compensationDto 					= compensationService.getCompensation(compensationDto);
		
		
		model.addAttribute("dataGroups", dataGroups);
		model.addAttribute("performance", performanceDto);
		model.addAttribute("compensation", compensationDto);
		model.addAttribute("personalInfo", personalInfo);
		
		
		return "performance";
	}
	
	
	/**
	 * Controller that searches employee using a query text 
	 * @param sso
	 * @param history
	 * @param model
	 * @return returns a list of employees
	 */
	@RequestMapping("people/search/results")
	protected String onSubmit( @RequestParam("searchInput") String searchInput , @RequestParam("currentSso") Long currentSso,						
			Model model){
		String query = searchInput;
		Map<String, DataGroup> dataGroups = null;
		AutoCompleteDto autoCompDto = new AutoCompleteDto();
		PersonalInfoDto personalInfo = new PersonalInfoDto();
		
		
		//
		if(currentSso != null){
			dataGroups = authEvaluator.getDataGroupsForContextAsMap(PersonAuthUtil.getPrincipal(), PersonAuthUtil.getAuthorities(), currentSso);
			personalInfo.setSso(currentSso);
			personalInfo = personalInfoService.getPersonalInfo(personalInfo);
		}
		
		if(query.length()>0){
			
			if (query.equals("#")){
				model.addAttribute("dataGroups", dataGroups);
				model.addAttribute("personalInfo", personalInfo);
				model.addAttribute("errorSearch", "");
			}else{
			
				query = query.replace(",","").trim();
				query = query.replaceAll("\\s{2,}", " ");			
				autoCompDto.setQuery(query);			
				autoCompDto = searchService.searchEmployeeByParam(autoCompDto,false);
				
				model.addAttribute("dataGroups", dataGroups);
				model.addAttribute("search", autoCompDto);
				model.addAttribute("personalInfo", personalInfo);
				model.addAttribute("searchInput", searchInput);
			}
			
		}else{
			model.addAttribute("dataGroups", dataGroups);
			model.addAttribute("personalInfo", personalInfo);	
			model.addAttribute("errorSearch", messageSource.getMessage("search.query.required", null, "Query search is required", null));			
		}
		
		return ("search-result");
    }
	
	
	public void setErrorToDto(AbstractBaseDtoSupport baseDto){	
		baseDto.setSuccess(false);
		baseDto.setErrorMesage(messageSource.getMessage("errors.internal.error", null, "Internal error", null));		
	}

	public ProfileAuthorityEvaluator getAuthEvaluator() {
		return authEvaluator;
	}

	public void setAuthEvaluator(ProfileAuthorityEvaluator authEvaluator) {
		this.authEvaluator = authEvaluator;
	}

	public EmployeeProfileService getPersonalInfoService() {
		return personalInfoService;
	}

	public void setPersonalInfoService(EmployeeProfileService personalInfoService) {
		this.personalInfoService = personalInfoService;
	}

	public WorkAssignmentService getWorkAssignmentService() {
		return workAssignmentService;
	}

	public void setWorkAssignmentService(WorkAssignmentService workAssignmentService) {
		this.workAssignmentService = workAssignmentService;
	}

	public PersonalCVService getPersonalCVService() {
		return personalCVService;
	}

	public void setPersonalCVService(PersonalCVService personalCVService) {
		this.personalCVService = personalCVService;
	}
	
	public PerformanceService getPerformanceService() {
		return performanceService;
	}

	public void setPerformanceService(PerformanceService performanceService) {
		this.performanceService = performanceService;
	}

	public CompensationService getCompensationService() {
		return compensationService;
	}

	public void setCompensationService(CompensationService compensationService) {
		this.compensationService = compensationService;
	}
	
	
}