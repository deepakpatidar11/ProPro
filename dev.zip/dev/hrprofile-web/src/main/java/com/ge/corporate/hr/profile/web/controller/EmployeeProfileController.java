/*******************************************************************************
  * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.web.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.owasp.esapi.ESAPI;
import org.owasp.esapi.errors.IntrusionException;
import org.owasp.esapi.errors.ValidationException;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ge.corporate.hr.profile.auth.authenticate.ClientAuthentication;
import com.ge.corporate.hr.profile.auth.model.DataGroup;
import com.ge.corporate.hr.profile.auth.model.User;
import com.ge.corporate.hr.profile.auth.service.ProfileAuthorityEvaluator;
import com.ge.corporate.hr.profile.auth.util.PersonAuthUtil;
import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.common.dto.EmployeeJobDetails;
import com.ge.corporate.hr.profile.common.dto.EmployeeJobDto;
import com.ge.corporate.hr.profile.common.dto.PotentialNextRole;
import com.ge.corporate.hr.profile.common.dto.PotentialNextRoleDto;
import com.ge.corporate.hr.profile.common.dto.RecommendedLearningDto;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.common.service.HRAPIClient;
import com.ge.corporate.hr.profile.employee.dao.PropertyDao;
import com.ge.corporate.hr.profile.employee.dto.AssignmentDto;
import com.ge.corporate.hr.profile.employee.dto.AssignmentHistoryDto;
import com.ge.corporate.hr.profile.employee.dto.CompensationDto;
import com.ge.corporate.hr.profile.employee.dto.ContactsDemographicsDto;
import com.ge.corporate.hr.profile.employee.dto.ContingAssignmentDto;
import com.ge.corporate.hr.profile.employee.dto.ContingWorkMgmntDto;
import com.ge.corporate.hr.profile.employee.dto.EducationCatalogs;
import com.ge.corporate.hr.profile.employee.dto.EducationDto;
import com.ge.corporate.hr.profile.employee.dto.EducationTrainingDto;
import com.ge.corporate.hr.profile.employee.dto.EmployeeExpertiseDto;
import com.ge.corporate.hr.profile.employee.dto.EmployeeHistoryDto;
import com.ge.corporate.hr.profile.employee.dto.InterestAffiliationDto;
import com.ge.corporate.hr.profile.employee.dto.JVAssignmentDto;
import com.ge.corporate.hr.profile.employee.dto.MyClientsDto;
import com.ge.corporate.hr.profile.employee.dto.MyReportsDto;
import com.ge.corporate.hr.profile.employee.dto.PerformanceDto;
import com.ge.corporate.hr.profile.employee.dto.PersonalCVDto;
import com.ge.corporate.hr.profile.employee.dto.PersonalInfoDto;
import com.ge.corporate.hr.profile.employee.dto.PrintPDFDto;
import com.ge.corporate.hr.profile.employee.dto.SharedData;
import com.ge.corporate.hr.profile.employee.dto.TrainingDto;
import com.ge.corporate.hr.profile.employee.model.CareerAspiration;
import com.ge.corporate.hr.profile.employee.model.CustomerandSuppliers;
import com.ge.corporate.hr.profile.employee.model.EmployeeExpertise;
import com.ge.corporate.hr.profile.employee.model.EmployeeHistory;
import com.ge.corporate.hr.profile.employee.model.HrClientsFlexiGridColModel;
import com.ge.corporate.hr.profile.employee.model.IntiativesandProject;
import com.ge.corporate.hr.profile.employee.model.Mentoring;
import com.ge.corporate.hr.profile.employee.model.MyClientFlexiGrid;
import com.ge.corporate.hr.profile.employee.model.OptinSharing;
import com.ge.corporate.hr.profile.employee.model.PDFMenuPersistence;
import com.ge.corporate.hr.profile.employee.model.ProfileCompleteness;
import com.ge.corporate.hr.profile.employee.model.ShortProfileList;
import com.ge.corporate.hr.profile.employee.model.UserInfo;
import com.ge.corporate.hr.profile.employee.model.WorkMobility;
import com.ge.corporate.hr.profile.employee.service.CompensationService;
import com.ge.corporate.hr.profile.employee.service.EmployeeHistoryService;
import com.ge.corporate.hr.profile.employee.service.EmployeeProfileService;
import com.ge.corporate.hr.profile.employee.service.InterestAffiliationService;
import com.ge.corporate.hr.profile.employee.service.OptinSharingService;
import com.ge.corporate.hr.profile.employee.service.PerformanceService;
import com.ge.corporate.hr.profile.employee.service.PersonalCVService;
import com.ge.corporate.hr.profile.employee.service.SearchService;
import com.ge.corporate.hr.profile.employee.service.WorkAssignmentService;
//import com.ge.corporate.hr.profile.employee.service.mail.SensitiveDataPopupMail;

@Controller
public class EmployeeProfileController {

	@Resource(name = "authorityEvaluator")
	private ProfileAuthorityEvaluator authEvaluator;
	@Resource(name = "employeeProfileService")
	private EmployeeProfileService personalInfoService;
	@Resource(name = "workAssignmentService")
	private WorkAssignmentService workAssignmentService;
	@Resource(name = "personalCVService")
	private PersonalCVService personalCVService;
	@Resource(name = "performanceService")
	private PerformanceService performanceService;
	@Resource(name = "compensationService")
	private CompensationService compensationService;
	@Resource(name = "messageSource")
	private ReloadableResourceBundleMessageSource messageSource;
	@Resource(name = "employeeHistoryService")
	private EmployeeHistoryService employeeHistoryService;
	@Resource(name = "propertyDao")
	private PropertyDao propertyDao;
	@Resource(name = "optinSharingService")
	private OptinSharingService optinSharingService;
	/*@Resource(name = "sensitiveDataPopupMail")
	private SensitiveDataPopupMail sensitiveDataPopupMail;*/
	@Resource(name = "advancedSearchPersistence")
	private List<ShortProfileList> persistedSearchResults;
	@Resource(name = "interestAffiliationService")
	private InterestAffiliationService interestService;
	@Resource(name = "searchService")
	private SearchService searchService;
	private Long oldSSO;
	@Resource
	private ClientAuthentication clientAuth;	
	@Resource
	private HRAPIClient apiClient;

	@RequestMapping(value = { "/", "me", "me/", "my", "my/", "people",
			"people/", "employees", "employees/" })
	public String profileMe(Model model) {
		Long sso = PersonAuthUtil.getLoggedSSO();
		return ("redirect:/people/" + sso);
	}

	@RequestMapping(value = "{deeplink}")
	public String profileMe(Model model, @PathVariable String deeplink) {
		Long sso = PersonAuthUtil.getLoggedSSO();
		return ("redirect:/people/" + sso + "/" + deeplink);
	}
	@RequestMapping(value = {"sharededucation/{sso}/json_sharededucation","sharededucation/{sso}"})
	public @ResponseBody
	SharedData sharedData(@PathVariable Long sso, Model model, HttpServletRequest request, HttpServletResponse response) {
		response.addHeader("Access-Control-Allow-Headers",
		"Content-Type, Authorization, Accept, Origin, X-Requested-With");
		//response.addHeader("Access-Control-Allow-Origin", "*");
		response.addHeader("Access-Control-Allow-Origin", request.getHeader("Origin"));
		response.addHeader("Access-Control-Allow-Credentials", "true");
	   
		SharedData sharedData = new SharedData();
		EducationTrainingDto educationdto=new EducationTrainingDto();
		educationdto.setSso(sso);
		sharedData.setSso(sso);
	   OptinSharing optinSharing = new OptinSharing();
		try {
			optinSharing = optinSharingService.getOptinSharing(sso);
			sharedData.setProfessionalSummary(workAssignmentService.getProfessionalSummary(sso));
			if(optinSharing.getEducation().equalsIgnoreCase("Y")){
				educationdto = personalCVService.getEducationBySso(educationdto);
				sharedData.setEducationList(educationdto.getEducationList());
			}

		} catch (Exception e) {
			e.getMessage();
		}

		return sharedData;
	}
	@RequestMapping(value = { "employees/{sso}", "employees/{sso}/", "people/{sso}/" })
	public String profileReDirectEmployee(Model model, @PathVariable Long sso) {
		return ("redirect:/people/" + sso);
	}

	@RequestMapping(value = "employees/{sso}/{deeplink}")
	public String profileReDirectEmployeeDeeplink(Model model,
			@PathVariable Long sso, @PathVariable String deeplink) {
		return ("redirect:/people/" + sso + "/" + deeplink);
	}

	@RequestMapping(value = "people/{sso}/{deeplink}")
	public String profileDeepLink(@PathVariable Long sso,
			@PathVariable String deeplink, Model model, HttpSession session) {
		String[] deepLinkParam = { 
				"current_information", "personal_data", "contacts_demographics", 
				"work_history", "employment_history", "ohr_history",
				"work_career","interests_affiliations", "connections", "mentoring",
				"education_training", "education", "training", "personalized_view",
				"appraisal", "compensation", "my_client_managers",
				"assignment", "current_assignment", "assignment_history",
				"internal_resume", "demographics", "performance", "tooltip" 
				};
		session.setAttribute("IS_DEEP_LINK", false);
		boolean isValidParam = false;
		for (String e : deepLinkParam) {
			if (e.equalsIgnoreCase(deeplink)) {
				session.setAttribute("DEEP_LINK", e);
				session.setAttribute("IS_DEEP_LINK", true);
				isValidParam = true;
			}
		}
		if (isValidParam) {
			return ("redirect:/people/" + sso);
		} else {
			return "generic-error";
		}
	}

	/**
	 * Generates the base Web UI considering security restrictions.<br>
	 * It also loads basic Personal Info to display the profile personal-card
	 * bar.
	 * 
	 * @param sso
	 * @param history
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "people/{sso}")
	public String profile(@PathVariable Long sso, Model model,
			HttpSession session, HttpServletRequest request) {
				
		session.setAttribute("APP_ENV", System.getProperty("app.environment"));
		UserInfo userInfo = new UserInfo();
		userInfo = personalInfoService
				.getLoggedUserInfo(PersonAuthUtil.getLoggedSSO());
		session.setAttribute("USER", userInfo);
		model.addAttribute("pageView", "Profile");
		//session.setAttribute("USER_SSO", userInfo.getSso());
		//session.setAttribute("USER_NAME", userInfo.getFirstName()+" "+userInfo.getLastName());
		//session.setAttribute("USER_IFG", userInfo.getIndustrySegment());
		//model.addAttribute("userInfo", userInfo);		
		
		session.setAttribute("VIEWED_SSO", sso);
		
		String userAgent = request.getHeader("user-agent").toLowerCase();
		EducationTrainingDto educationDto = new EducationTrainingDto();	
		
		/*if(session.getAttribute("ROLES_DELETED")!=null){
			if(((String) session.getAttribute("ROLES_DELETED")).equalsIgnoreCase("Y")){
				session.setAttribute("ROLES_DELETED",null);
				model.addAttribute("loggedSSO", PersonAuthUtil.getLoggedSSO());
				model.addAttribute("accessedSSO", sso);
				return "roles-deleted"; 
			}
		}*/

		if (session.getAttribute("IS_DEEP_LINK") != null) {
			if (session.getAttribute("IS_DEEP_LINK").equals(false)) {
				session.setAttribute("DEEP_LINK", null);
			}
		}
		session.setAttribute("IS_DEEP_LINK", false);

		Boolean isContingentWorker = authEvaluator.isContingentWorker(sso);
		Boolean isDirectoryEmployee = authEvaluator.isDirectoryEmployee(sso);
		Boolean isJVEmployee = authEvaluator.isJointVentureEmployee(sso);
		Boolean isGEAlstomEmployee = authEvaluator.isGEAlstomEmployee(sso);
		Boolean isHRManager = authEvaluator.isHRManager(userInfo.getSso());
		Boolean isGEBakerHughesEmployee = authEvaluator.isGEBakerHughesEmployee(sso);
		
		
		Boolean isPDUser = authEvaluator.isPDUser(sso);
		
		Boolean isSelf = authEvaluator.isSelf(sso);
		Boolean isSponsor = false;
		Boolean isJVSponsor = false;
		Boolean isLeadershipProgramMember = authEvaluator.isLeadershipProgramMemberBySso(sso);
		PersonalInfoDto personalInfo = new PersonalInfoDto();
		personalInfo.setSso(sso);
		personalInfo.setAlstomEmployee(isGEAlstomEmployee);
		if (persistedSearchResults != null
				&& !persistedSearchResults.isEmpty()) {
			persistedSearchResults.remove(null);
			model.addAttribute("persistedSearchResults",
					persistedSearchResults);
		}
		Map<String, DataGroup> dataGroups = null;
		/*boolean checkSensitiveDataPopup = personalInfoService
				.isValidSensitiveDataPopupService(PersonAuthUtil
						.getLoggedSSO());
		if(authEvaluator.skipSensitiveRoles(PersonAuthUtil.getLoggedSSO())){// || checkSensitiveDataPopup){
			dataGroups = authEvaluator
					.getDataGroupsForContextAsMapBypass(
							PersonAuthUtil.getPrincipal(),
							PersonAuthUtil.getAuthorities(), sso);
		}else{*/
			dataGroups = authEvaluator
					.getDataGroupsForContextAsMap(
							PersonAuthUtil.getPrincipal(),
							PersonAuthUtil.getAuthorities(), sso);	
//		}
		

		// Load Previous Search Results
		if (isContingentWorker) {
			isSponsor = authEvaluator.isSponsor(
					PersonAuthUtil.getLoggedSSO(), sso);
			personalInfo = personalInfoService
					.getContingentPersonalInfo(personalInfo);
			ContingAssignmentDto contingAssignmentDto = new ContingAssignmentDto();
			contingAssignmentDto = personalInfoService
					.getContingentWorkAssgnmtInfo(sso, contingAssignmentDto);
			model.addAttribute("contingAssignment", contingAssignmentDto);
			// if(isSponsor){
			ContingWorkMgmntDto contingWorkMgmntDto = new ContingWorkMgmntDto();
			contingWorkMgmntDto = personalInfoService
					.getContingentWorkMgmntInfo(sso, contingWorkMgmntDto);
			model.addAttribute("contingWorkMgmnt", contingWorkMgmntDto);
			// }
		}else if (isJVEmployee) {
			isJVSponsor = authEvaluator.isJVSponsor(
					PersonAuthUtil.getLoggedSSO(), sso);
			personalInfo = personalInfoService
					.getJVPersonalInfo(personalInfo);
			JVAssignmentDto jvAssignmentDto = new JVAssignmentDto();
			jvAssignmentDto = personalInfoService
					.getJVAssgnmtInfo(sso, jvAssignmentDto);
			model.addAttribute("JVEmpAssignment", jvAssignmentDto);
		} else {
			personalInfo = personalInfoService.getPersonalInfo(personalInfo);
			personalInfo.setProfessionalSummary(workAssignmentService.getProfessionalSummary(sso));
			personalInfoService.setExpertiseAsString(personalInfo);
			personalInfo.setHasEducation(personalCVService.hasEducation(sso));
			
			//if(dataGroups.get("EMSHistory") != null && dataGroups.get("Education") != null && dataGroups.get("Training") != null){
				OptinSharing optinSharing = new OptinSharing();
				optinSharing = optinSharingService.getOptinSharing(sso);
				//added for DEV testing. Change to if(isSelf)
				if(isSelf || dataGroups.get("ProfileCompleteness") != null){
					optinSharing.setTrainingList(optinSharingService.allTrainingListBySSO(sso));	
					optinSharing.setSharedTrainingList(optinSharingService.getSharedTrainingList(sso));
				}
				model.addAttribute("optinSharing", optinSharing);
			//}
				//added for DEV testing. Change to if(isSelf)
				if(isSelf || dataGroups.get("ProfileCompleteness") != null){
					ProfileCompleteness profileCompleteness = new ProfileCompleteness();
					profileCompleteness = personalInfoService.getProfileCompleteness(sso, true);
					model.addAttribute("profileCompleteness", profileCompleteness);
				}
				
		}
		
		if(propertyDao.getByKey("info.popup.show").equalsIgnoreCase("true")){
			boolean showInfoPopup = false;
			boolean showInfoPopupStatusBySSO = personalInfoService
					.showInfoPopupStatusBySSOService(PersonAuthUtil
							.getLoggedSSO());
			if (dataGroups.get("InformationPopup") != null && showInfoPopupStatusBySSO == true) {
				if(isSelf){
					if(propertyDao.getByKey("info.popup.roles.select").equalsIgnoreCase("true")){
						String rolesPopup = propertyDao.getByKey("info.popup.roles.list");
						String[] rolesPopupList = rolesPopup.split(",");
						List<String> rolesList = authEvaluator.getAutorizedRoles(
								PersonAuthUtil.getPrincipal(), PersonAuthUtil.getAuthorities());
						for(int i=0; i<rolesPopupList.length; i++){
							if(rolesList.contains(rolesPopupList[i])){
								showInfoPopup = true;
								break;
							}
						}
					}
					else{
						showInfoPopup = true;
					}
				}else{
					showInfoPopup = true;
				}
			}
			model.addAttribute("showInfoPopup", showInfoPopup);
		}
		
		if(isSelf && propertyDao.getByKey("whats.new.enabled").equalsIgnoreCase("Y")){
			boolean showWhatsNewPopup = personalInfoService
					.showInfoPopupStatusBySSOService(PersonAuthUtil
							.getLoggedSSO());
			model.addAttribute("showWhatsNewPopup", showWhatsNewPopup);
		}
		
		if (isSelf && propertyDao.getByKey("expertise.popup.enabled").equalsIgnoreCase("Y")) {
			boolean showExpertiseEmptyPopup = personalInfoService
					.showExpertiseEmptyPopupBySSOService(PersonAuthUtil.getLoggedSSO());
			model.addAttribute("showExpertiseEmptyPopup", showExpertiseEmptyPopup);
		}
		/*if (dataGroups.get("SensitiveDataPopup")!=null) {						
			if (checkSensitiveDataPopup) {
				/*User user = PersonAuthUtil.getPrincipal();
				List<String> rolesForContext = authEvaluator
						.getRoleForContext(user, sso,
								PersonAuthUtil.getAuthorities());
				List<String> roles = authEvaluator.getAutorizedRoles(
						user, PersonAuthUtil.getAuthorities());
				model.addAttribute("roles", roles);*/						
			/*model.addAttribute("checkSensitiveData", true);
			session.setAttribute("VALID_SENSITIVE_POPUP", true);
			}
		}*/
		
		User user = PersonAuthUtil.getPrincipal();
		Boolean isRoleConnect = false;
		List<String> rolesForContext = authEvaluator
				.getRoleForContext(user, sso,
						PersonAuthUtil.getAuthorities());
		String roles =StringUtils.join(rolesForContext," ") + " ";
		isRoleConnect = rolesForContext.contains("ROLE_CONNECT");
		model.addAttribute("rolesForContext", roles);
		model.addAttribute("isRoleConnect", isRoleConnect);
		model.addAttribute("personalInfo", personalInfo);
		model.addAttribute("isSelf", isSelf);
		model.addAttribute("dataGroups", dataGroups);
		model.addAttribute("isContingentWorker", isContingentWorker);
		model.addAttribute("isSponsor", isSponsor);
		model.addAttribute("isGEAlstomEmployee", isGEAlstomEmployee);
		model.addAttribute("isGEBakerHughesEmployee", isGEBakerHughesEmployee);
		model.addAttribute("isPDUser", isPDUser);
		model.addAttribute("isLeadershipProgramMember", isLeadershipProgramMember);
		model.addAttribute("isHRManager", isHRManager);
		session.setAttribute("IS_ALSTOM_EMP", isGEAlstomEmployee);
		session.setAttribute("IS_LP_BRIDGE_MEMBER", isLeadershipProgramMember);
		session.setAttribute("isJVEmployee", isJVEmployee);
		session.setAttribute("isJVSponsor", isJVSponsor);
		
		if (isDirectoryEmployee) {
			if (dataGroups.get("ViewSuspendedEmployees")==null) {
				model.addAttribute("directoryEmployee", false);
				model.addAttribute("dataGroups", null);
				model.addAttribute("personalInfo", null);
				session.setAttribute("IS_VIEW_SUSPEND_EMP", false);
				return "directory-employee";
			} else {
				model.addAttribute("dataGroups", dataGroups);
				model.addAttribute("personalInfo", personalInfo);
				session.setAttribute("IS_VIEW_SUSPEND_EMP", true);
			}
		}
		boolean bandMatched = false;
		if(isSelf || isRoleConnect) {

			Long loggedSSO = PersonAuthUtil.getLoggedSSO();
			String optOutFlag = null;
			Boolean isTargetFunc = false;
			Boolean isOtherView = false;
			
			if(session.getAttribute("USER") != null) {
				userInfo = (UserInfo) session.getAttribute("USER");
			} else {
				userInfo = personalInfoService.getLoggedUserInfo(loggedSSO);
			}
			
			if(session.getAttribute("optOutFlag") != null) {
				optOutFlag = (String) session.getAttribute("optOutFlag");
			} else {
				OptinSharing optinSharing = optinSharingService.getOptinSharing(loggedSSO);
				if(optinSharing != null) {
					optOutFlag = optinSharing.getConnections();
				}
			}
			
			Boolean isGEOilAndGasEmp = authEvaluator.isGEGasAndOilEmployee(loggedSSO);
			
			
			String bandValue = (null == personalInfo.getBand()) ? "" : personalInfo.getBand();
			
			if(isSelf && bandValue.equals(propertyDao.getByKey("connect.band.pb")) ||
				bandValue.equals(propertyDao.getByKey("connect.band.ltb")) ||
				bandValue.equals(propertyDao.getByKey("connect.band.lpb")) ||
				bandValue.equals(propertyDao.getByKey("connect.band.spb")) ||
				bandValue.equals(propertyDao.getByKey("connect.band.eb")) ||
				bandValue.equals(propertyDao.getByKey("connect.band.seb")) ||
				bandValue.equals(propertyDao.getByKey("connect.band.vp"))) {
					bandMatched = true;
			}
			
			isTargetFunc = ((isGEBakerHughesEmployee || isGEOilAndGasEmp) && bandMatched ) ? true : false;

			if(session.getAttribute("USER") == null) {
				session.setAttribute("USER", userInfo);
			}
			
			if(session.getAttribute("optOutFlag") == null) {
				session.setAttribute("optOutFlag", optOutFlag);
			}
			
			if(isTargetFunc && !isRoleConnect) {
				isOtherView = false;
			}
			if((isTargetFunc && isRoleConnect) || (!isTargetFunc && isRoleConnect)) {
				isOtherView = true;
			}
			
			model.addAttribute("viewedConnectionSSO", sso);
			model.addAttribute("isRoleConnect", isRoleConnect);
			model.addAttribute("isTargetFunc", isTargetFunc);
			model.addAttribute("isOtherView", isOtherView);
			model.addAttribute("userFirstName", personalInfo.getFirstName());
			model.addAttribute("userLastName", personalInfo.getLastName());
			model.addAttribute("userTitle", personalInfo.getTitle());
			session.setAttribute("USER_TITLE", personalInfo.getTitle());
		}
		
		// Targeting for the Personalized view page
		
		// Below if-else is for hiding the expertise of target population from non-target population
		/*PersonalInfoDto personInfo;
		boolean isCW = authEvaluator.isContingentWorker(PersonAuthUtil.getLoggedSSO());
		boolean isJV = authEvaluator.isJointVentureEmployee(PersonAuthUtil.getLoggedSSO());
		if(!isSelf && dataGroups.get("ResumeFeaturedExpertiseView") != null && !isCW) {
			isGEBakerHughesEmployee = authEvaluator.isGEBakerHughesEmployee(PersonAuthUtil.getLoggedSSO());
			personInfo = new PersonalInfoDto();
			personInfo.setSso(PersonAuthUtil.getLoggedSSO());
			personInfo = personalInfoService.getPersonalInfo(personInfo);
			String bandValue = (null == personInfo.getBand()) ? "" : personInfo.getBand();
			if(bandValue.equals(propertyDao.getByKey("connect.band.pb")) ||
					bandValue.equals(propertyDao.getByKey("connect.band.ltb")) ||
					bandValue.equals(propertyDao.getByKey("connect.band.lpb")) ||
					bandValue.equals(propertyDao.getByKey("connect.band.spb")) ||
					bandValue.equals(propertyDao.getByKey("connect.band.eb")) ||
					bandValue.equals(propertyDao.getByKey("connect.band.seb")) ||
					bandValue.equals(propertyDao.getByKey("connect.band.vp")) ||
					bandValue.equals(propertyDao.getByKey("connect.band.othsal"))) {
						bandMatched = true;
				}
		} else {
			personInfo = personalInfo;
		}*/
		// Remove above if-else after the global launch of expertise and replace "personInfo" with "personalInfo" below
		
//		Boolean isGETransPorationEmp = "GE Transportation".equals(personInfo.getIndustrySegment());
		Boolean isGEGlobalOpsEmp = "GE Global Operations".equals(personalInfo.getIndustrySegment());
		Boolean isEngTechFunction = "Engineering/Technology".equals(personalInfo.getFunction());
//		Boolean isHRFunction = "Human Resources".equals(personInfo.getFunction());
		Boolean isEuropeRegion = ("Western Europe".equals(personalInfo.getRegion()) || "Germany".equals(personalInfo.getRegion())
									|| "Eastern Europe".equals(personalInfo.getRegion()));
		Boolean isNARegion = ("United States".equals(personalInfo.getRegion()) || "Canada".equals(personalInfo.getRegion()));
		List<String> authorizedRoles = authEvaluator.getAutorizedRoles(user, PersonAuthUtil.getAuthorities());
		Boolean hasRoleConnect = authorizedRoles.contains("ROLE_CONNECT");
		session.setAttribute("HAS_ROLE_CONNECT", hasRoleConnect);
		
		// Condition for OTHSAL band start
		if(isSelf && (isEngTechFunction || isGEGlobalOpsEmp || isGEBakerHughesEmployee) && !bandMatched) {
			String othSal = propertyDao.getByKey("connect.band.othsal");
			if(null != othSal && othSal.equals(personalInfo.getBand())) {
				bandMatched = true;
			}
		} // OTHSAL condition ends
		
		Boolean isTargetPopForPV = (!isEuropeRegion && bandMatched && 
					(/*isHRFunction ||*/ (isGEGlobalOpsEmp && isNARegion) || (isEngTechFunction)));
		
		if(dataGroups.get("PersonalizedView") != null && !isTargetPopForPV && !authEvaluator.isSA() && !(hasRoleConnect && isSelf)){
			dataGroups.remove("PersonalizedView");
			/*if(!((isGEGlobalOpsEmp || isEngTechFunction || isGEBakerHughesEmployee) && bandMatched)) {
				dataGroups.remove("ResumeFeaturedExpertiseView");
				dataGroups.remove("ResumeFeaturedExpertiseEdit");
			}*/
		} /*else if(dataGroups.get("PersonalizedView") == null && dataGroups.get("ResumeFeaturedExpertiseView") != null) {
			if((!(isGEGlobalOpsEmp || isEngTechFunction || isGEBakerHughesEmployee) && !isTargetPopForPV && !hasRoleConnect) || isCW) {
				dataGroups.remove("ResumeFeaturedExpertiseView");
				dataGroups.remove("ResumeFeaturedExpertiseEdit");
			}
		}*/
		if(isSelf && dataGroups.get("ResumeFeaturedExpertiseEdit") == null) {
			ProfileCompleteness profileCompleteness = personalInfoService.getProfileCompleteness(sso, false);
			model.addAttribute("profileCompleteness", profileCompleteness);
		}
		if(isSelf && dataGroups.get("ResumeFeaturedExpertiseEdit") != null) {
			model.addAttribute("expertiseLimit", propertyDao.getByKey("home.expertise.limit"));
			model.addAttribute("expNewTermFlag", propertyDao.getByKey("home.expertise.newterm.flag"));
		}
		session.setAttribute("IS_IE", userAgent.contains("msie"));
		session.setAttribute("IS_IPHONE", userAgent.contains("iphone") || userAgent.contains("ipod"));

		if(session.getAttribute("login_metrics_enabled") == null) {
			session.setAttribute("login_metrics_enabled", propertyDao.getByKey("login.metrics.enabled"));
		}
		if("Y".equalsIgnoreCase((String) session.getAttribute("login_metrics_enabled"))) {
			personalInfoService.captureLoginMetrics("PROFILE", sso, authEvaluator.isContingentWorker(PersonAuthUtil.getLoggedSSO()), rolesForContext, session, userAgent);
		}
		
		return "profile";
	}
	
	@RequestMapping("people/{sso}/json_potentialnextroles")
	public @ResponseBody
	PotentialNextRoleDto potentialNextRoles(@PathVariable Long sso, Model model, HttpSession session) {
		PotentialNextRoleDto potentialNextRoleDto = new PotentialNextRoleDto();
		potentialNextRoleDto.setData(new ArrayList<PotentialNextRole>());
		String currentJob = (String) session.getAttribute("USER_TITLE");
		try {
			//Authentication from federation
			String accessToken = clientAuth.getAccessToken();	
			EmployeeJobDto employeedto=apiClient.getJobDetails(accessToken, sso);
			List<EmployeeJobDetails> emplyeejobdetails=employeedto.getData();
			List<PotentialNextRole> nextRoleList = potentialNextRoleDto.getData();
			Comparator<PotentialNextRole> sortByVacancyCount = new Comparator<PotentialNextRole>() {
				@Override
				public int compare(PotentialNextRole role1, PotentialNextRole role2) {
					if (role1.getVacancyCount() < role2.getVacancyCount()) {
						return 1;
					} else if (role1.getVacancyCount() > role2.getVacancyCount()) { 
						return -1;
					} else {
						if (role1.getEeCount() < role2.getEeCount()) {
							return 1;
						} else if (role1.getEeCount() > role2.getEeCount()) { 
							return -1;
						} else {
							return 0;
						}
					}
				}
			};
			
			for (EmployeeJobDetails employeeJobDetails : emplyeejobdetails) {
			
					if(nextRoleList.isEmpty() || (!nextRoleList.isEmpty() &&
							nextRoleList.size() < 10 && employeeJobDetails.getJobType() != null)){
						PotentialNextRoleDto potentialNextRoles = apiClient.getPotentialNextRoles(accessToken, employeeJobDetails.getJobType());
						if(nextRoleList.isEmpty()) {
							nextRoleList.addAll(potentialNextRoles.getData());
						} else {
							Collections.sort(potentialNextRoles.getData(), sortByVacancyCount);
							for(int i = 0; i < (10 - nextRoleList.size()); i++) {
								nextRoleList.add(potentialNextRoles.getData().get(i));
							}
						}
					}
				
				
			}
			Collections.sort(nextRoleList, sortByVacancyCount);
			//API call
		//potentialNextRoleDto = apiClient.getPotentialNextRoles(accessToken, currentJob);
			
		} catch (Exception e) {
			e.getMessage();
			//setErrorToDto(potentialNextRoleDto);
		}
		return potentialNextRoleDto;
	}
	
	@RequestMapping("people/{sso}/json_recommendedlearnings")
	public @ResponseBody
	RecommendedLearningDto[] recommendedLearnings(@PathVariable Long sso, @RequestParam(value = "loadMostPopular", required = true)  boolean loadMostPopular, Model model, HttpSession session) {
		RecommendedLearningDto[] recommendedLearnings = {};
		try {
			//Authentication from federation
			String accessToken = clientAuth.getAccessToken();		
			//API call
			recommendedLearnings = apiClient.getRecommendedLearnings(accessToken, sso, loadMostPopular);
		} catch (Exception e) {
			e.getMessage();
		}
		return recommendedLearnings;
	}

	/**
	 * Load employee assignment information
	 * 
	 * @param sso
	 * @param history
	 * @param model
	 * @return
	 */
	@RequestMapping("people/{sso}/pdf_popupmodal")
	public @ResponseBody EducationTrainingDto popupmodal(@PathVariable Long sso, Model model,HttpServletRequest request, HttpServletResponse response, HttpSession session) {

	 
		List<String> columns = new ArrayList<String>();
		Map<String, DataGroup> dataGroups = null;
		OptinSharing optinSharing = new OptinSharing();
		
		boolean isSelf = false;
		EducationTrainingDto educationDto = new EducationTrainingDto();
		educationDto.setSso(sso);
		try
		{
			dataGroups = authEvaluator
					.getDataGroupsForContextAsMap(
							PersonAuthUtil.getPrincipal(),
							PersonAuthUtil.getAuthorities(), sso);
			isSelf = authEvaluator.isSelf(sso).booleanValue();
			optinSharing = optinSharingService.getOptinSharing(sso);
			List<String> trainingList = optinSharingService.optinTrainingListBySSO(sso);
			optinSharing.setTrainingList(trainingList);
			educationDto.setSelf(isSelf);
			
			
			
		if(dataGroups.get("ResumeTrainingView") != null || optinSharing.getTraining().equalsIgnoreCase("Y")){
			educationDto = personalCVService.getTrainingBySso(educationDto, (dataGroups.get("ResumeTrainingView") != null), optinSharing);
			if(isSelf){
				educationDto.setOptinTrainingList(trainingList);
			}
		}
		if(dataGroups.get("ResumeProfessionalCertificationView") != null || (optinSharing.getTraining().equalsIgnoreCase("Y") && optinSharing.getTrainingList().contains("Professional Certifications"))){
			educationDto = personalCVService.getCertificationsBySso(educationDto);
		}
		}
		 catch (Exception e) {
				setErrorToDto(educationDto);
			}

			return educationDto;
	
	}
	
	@RequestMapping("people/{sso}/getexpertise")
	public @ResponseBody
	BaseModelCollection<EmployeeExpertise> getExpertise( @PathVariable Long sso ) {
		return personalInfoService.getExpertiseListBySSO(sso);
	}
	
	@RequestMapping("people/{sso}/getEmpMentoringInterest")
	public @ResponseBody
	Map<String, List<Integer>> getEmpMentoringInterest( @PathVariable Long sso ) {
		return personalInfoService.getEmpMentoringInterestBySSO(sso);
	}
	
	@RequestMapping(value = {"people/{sso}/updateExpertise"},method=RequestMethod.POST)
	public @ResponseBody
	BaseModelCollection<EmployeeExpertise> updateExpertise(Model model,HttpServletRequest request,
			@PathVariable Long sso, @RequestBody EmployeeExpertiseDto expertiseDto) {
		
		return personalInfoService.updateEmpExperties(sso, expertiseDto.getEmployeeExpertises());
	}
	
	@RequestMapping("people/{sso}/json_assignment")
	public @ResponseBody
	AssignmentDto assignment(@PathVariable Long sso, Model model, HttpSession session) {
		AssignmentDto assignmentDto = new AssignmentDto();
		try {
			if(session.getAttribute("IS_ALSTOM_EMP")!=null && sso.equals((Long) session.getAttribute("VIEWED_SSO"))){
				assignmentDto.setAlstomEmployee((boolean) session.getAttribute("IS_ALSTOM_EMP"));
			}else{
				assignmentDto.setAlstomEmployee(authEvaluator.isGEAlstomEmployee(sso));
			}
			if(session.getAttribute("IS_VIEW_SUSPEND_EMP") != null && sso.equals((Long) session.getAttribute("VIEWED_SSO"))){
				assignmentDto.setViewSuspendedEmployees(((Boolean) session.getAttribute("IS_VIEW_SUSPEND_EMP")).booleanValue());
			}else{
				Map<String, DataGroup> dataGroups = null;
				dataGroups = authEvaluator
						.getDataGroupsForContextAsMap(
								PersonAuthUtil.getPrincipal(),
								PersonAuthUtil.getAuthorities(), sso);
				assignmentDto.setViewSuspendedEmployees((dataGroups.get("ViewSuspendedEmployees")!=null)?true:false);
			}
			assignmentDto.setSso(sso);
			assignmentDto = workAssignmentService
					.getCurrentInformation(assignmentDto);
			if(session.getAttribute("IS_LP_BRIDGE_MEMBER") != null && sso.equals((Long) session.getAttribute("VIEWED_SSO"))){
				assignmentDto.setLpAssignment(workAssignmentService.getLeadershipAssignment(sso));
			}
			//assignmentDto.setSso(sso);
			//assignmentDto = workAssignmentService.getProfessionalSummary(assignmentDto);
		} catch (Exception e) {
			setErrorToDto(assignmentDto);
		}
		return assignmentDto;
	}

	@RequestMapping("people/{sso}/json_connectparam")
	public @ResponseBody
	AssignmentDto getConnectParams(@PathVariable Long sso, Model model, HttpSession session) {
		AssignmentDto assignmentDto = new AssignmentDto();
		try {
			
			assignmentDto.setSso(sso);
			assignmentDto = workAssignmentService.getConnectParams(assignmentDto);
			if(null != sso && !sso.equals(oldSSO)) {
				if(session.getAttribute("FACET_CONNECT_PARAMS") != null) {
					session.removeAttribute("FACET_CONNECT_PARAMS");
				}
				oldSSO = sso;
			}
			
		} catch (Exception e) {
			setErrorToDto(assignmentDto);
		}
		return assignmentDto;
	}
	/**
	 * Load employee assignment history information
	 * 
	 * @param sso
	 * @param history
	 * @param model
	 * @return
	 */
	@RequestMapping("people/{sso}/json_assignmenthistory")
	public @ResponseBody
	AssignmentHistoryDto assignmentHistory(@PathVariable Long sso, Model model) {

		AssignmentHistoryDto assignmentDto = new AssignmentHistoryDto();
		try {
			assignmentDto.setSso(sso);
			assignmentDto = workAssignmentService
					.getJobHistoryInformation(assignmentDto);
			assignmentDto.setSuccess(true);

		} catch (Exception e) {
			setErrorToDto(assignmentDto);
		}

		return assignmentDto;
	}

	/**
	 * Load employee assignment history information
	 * 
	 * @param sso
	 * @param history
	 * @param model
	 * @return
	 */
	@RequestMapping("people/{sso}/json_myclients")
	public @ResponseBody
	MyClientsDto myClients(@PathVariable Long sso, Model model) {

		MyClientsDto myClientsDto = new MyClientsDto();
		try {
			myClientsDto.setSso(sso);
			myClientsDto = workAssignmentService.getMyClients(myClientsDto);
			myClientsDto.setSuccess(true);

		} catch (Exception e) {
			setErrorToDto(myClientsDto);
		}

		return myClientsDto;
	}

	@RequestMapping("people/{sso}/json_employeehistory")
	public @ResponseBody
	EmployeeHistoryDto employeeHistory(@PathVariable Long sso, Model model) {

		EmployeeHistoryDto employeeHistoryDto = new EmployeeHistoryDto(sso);
		boolean isSelf = false;
		Map<String, DataGroup> dataGroups = null;
		OptinSharing optinSharing = new OptinSharing();
		try {
			dataGroups = authEvaluator
					.getDataGroupsForContextAsMap(
							PersonAuthUtil.getPrincipal(),
							PersonAuthUtil.getAuthorities(), sso);
			isSelf = authEvaluator.isSelf(sso).booleanValue();
			optinSharing = optinSharingService.getOptinSharing(sso);
			PersonalInfoDto personalInfo = new PersonalInfoDto();
			personalInfo.setSso(sso);
			personalInfo = personalInfoService.getPersonalInfo(personalInfo);
			User user = PersonAuthUtil.getPrincipal();
			List<String> rolesForContext = authEvaluator
					.getRoleForContext(user, sso,
							PersonAuthUtil.getAuthorities());
			boolean isRoleGEH = rolesForContext.contains("GLOBAL_EMPLOYMENT_HISTORY");
			if(isSelf && dataGroups.get("ResumeWorkHistoryView") != null){
				employeeHistoryDto = employeeHistoryService
						.getEmployeeHistoryRoleSelf(employeeHistoryDto);
			}else if(isRoleGEH)
			{
			
				String[] countryList=propertyDao.getByKey("work.history.exempt.list").split(",");
				Set<String> countrySet = new HashSet<String>(Arrays.asList(countryList)); 
				if(countrySet.contains(personalInfo.getCountry())){
					if(optinSharing.getEmp_history().equalsIgnoreCase("Y")){
						employeeHistoryDto = employeeHistoryService
								.getEmploymentHistory(employeeHistoryDto, isSelf, dataGroups.get("ResumeWorkHistoryView") != null);
					}
				}
				else{
					employeeHistoryDto = employeeHistoryService
							.getEmployeeHistory(employeeHistoryDto);
				}
			}
			else{	
			 if(dataGroups.get("ResumeWorkHistoryView") != null){
				employeeHistoryDto = employeeHistoryService
						.getEmployeeHistory(employeeHistoryDto);
			}else if(optinSharing.getEmp_history().equalsIgnoreCase("Y")){
				employeeHistoryDto = employeeHistoryService
						.getEmploymentHistory(employeeHistoryDto, isSelf, dataGroups.get("ResumeWorkHistoryView") != null);
			}
			}
			employeeHistoryDto.setWorkHistoryEdit(dataGroups.get("ResumeWorkHistoryEdit") != null);
			if(dataGroups.get("ResumeInitiativesProjectsView") != null || optinSharing.getInitiatives_projects().equalsIgnoreCase("Y")){
				BaseModelCollection<IntiativesandProject> intitivesProject =employeeHistoryService.getIntiativesAndProject(sso);
				employeeHistoryDto.setIntiativesandProject(intitivesProject);
			}
			if(dataGroups.get("ResumeCustomerSuppliersView") != null || optinSharing.getCustomers_suppliers().equalsIgnoreCase("Y")){
				BaseModelCollection<CustomerandSuppliers> customerSuppliers =employeeHistoryService.getCustomerAndSuppliers(employeeHistoryDto);
				employeeHistoryDto.setCustomerSupplier(customerSuppliers);
			}
			if(dataGroups.get("ResumeCareerAspirationView") != null || optinSharing.getCareer_aspirations().equalsIgnoreCase("Y")){
				CareerAspiration careerAspiration = employeeHistoryService.getCareerAspiration(sso);
				employeeHistoryDto.setCareerAspiration(careerAspiration);				
				if(!(dataGroups.get("WorkAssignmentRestricted") != null || isSelf)){
					employeeHistoryDto.getCareerAspiration().setOptnTalentFlag("");
				}
			}
			if(dataGroups.get("ResumeWorkMobilityView") != null || optinSharing.getWork_mobility().equalsIgnoreCase("Y")){
				WorkMobility workMobility = employeeHistoryService.getWorkMobility(sso);
				if(dataGroups.get("ResumeWorkMobilityEdit") != null){
					workMobility.setCountryList(searchService.getCountryCatalog().getCatalog());
				}
				employeeHistoryDto.setWorkMobility(workMobility);
			}
			if(dataGroups.get("ResumeCareerAspirationView") != null || optinSharing.getCareer_aspirations().equalsIgnoreCase("Y")){
				employeeHistoryDto.setCareerOpportunity(employeeHistoryService.getCareerOpportunity(sso));
			}
		} catch (Exception ex) {
			setErrorToDto(employeeHistoryDto);
		}
		
		return employeeHistoryDto;
	}
	
	
	@RequestMapping("people/countrymap")
	public @ResponseBody
	Map<String, String> getcountryMap(Model model) {

		Map<String, String> map = searchService.getCountryCodeMap();
		
		return map;
	}
	
	@RequestMapping("people/{sso}/addconnect")
	public @ResponseBody boolean addConnection(@PathVariable Long sso,
			@RequestParam(required = false) Long connectSSO, @RequestParam(required = true) int connectionType) {

		return personalInfoService.addConnection(sso, connectSSO, connectionType);
	}
	
	@RequestMapping("people/{sso}/deleteconnect")
	public @ResponseBody boolean deleteConnection(@PathVariable Long sso,
			@RequestParam(value="connectSSO") Long connectSSO, @RequestParam(required = true) int connectionType) {

		return personalInfoService.deleteConnection(sso, connectSSO, connectionType);
	}
	
	/*@RequestMapping(value = "connections/{sso}")
	public String searchConnections(Model model, @PathVariable Long sso,
			@RequestParam(value = "page", required = false) String page,
			@RequestParam(value = "query", required = false) String query,
			HttpSession session, HttpServletRequest request) {

		Long loggedSSO = PersonAuthUtil.getLoggedSSO();
		UserInfo userInfo;
		String optOutFlag = null;
		Boolean isSelf = authEvaluator.isSelf(sso);
		Boolean roleConnect = false;
		Boolean isTargetFunc = false;
		Boolean isOtherView = false;
		
		if(session.getAttribute("USER") != null) {
			userInfo = (UserInfo) session.getAttribute("USER");
		} else {
			userInfo = personalInfoService.getLoggedUserInfo(loggedSSO);
		}
		
		if(session.getAttribute("optOutFlag") != null) {
			optOutFlag = (String) session.getAttribute("optOutFlag");
		} else {
			OptinSharing optinSharing = optinSharingService.getOptinSharing(loggedSSO);
			if(optinSharing != null) {
				optOutFlag = optinSharing.getConnections();
			}
		}
		
		Boolean isGEBakerHughesEmp = authEvaluator.isGEBakerHughesEmployee(loggedSSO);
		Boolean isGEOilAndGasEmp = authEvaluator.isGEGasAndOilEmployee(loggedSSO);
//		hasRoleSA = authEvaluator.isSA(authEvaluator.castToProfileAuthority(PersonAuthUtil.getAuthorities()));
		isTargetFunc = ((isGEBakerHughesEmp || isGEOilAndGasEmp) && 
						("Engineering/Technology".equals(userInfo.getFunction()) 
								|| "Human Resources".equals(userInfo.getFunction())
								|| "Communications".equals(userInfo.getFunction()))) ? true : false;

		if(session.getAttribute("USER") == null) {
			session.setAttribute("USER", userInfo);
		}
		
		if(session.getAttribute("optOutFlag") == null) {
			session.setAttribute("optOutFlag", optOutFlag);
		}
		
		if(!isSelf || !isTargetFunc) {
			List<String> roleList = authEvaluator.getRoleForContext(PersonAuthUtil.getPrincipal(), sso, PersonAuthUtil.getAuthorities());
//			List<String> roleList = authEvaluator.getAutorizedRoles(PersonAuthUtil.getPrincipal(), PersonAuthUtil.getAuthorities());
			roleConnect = roleList.contains("ROLE_CONNECT");
		}
		
		if(isTargetFunc && !roleConnect) {
			isOtherView = false;
		}
		if((isTargetFunc && roleConnect) || (!isTargetFunc && roleConnect)) {
			isOtherView = true;
		}
		
		
		model.addAttribute("viewedConnectionSSO", sso);
		model.addAttribute("isRoleConnect", roleConnect);
		model.addAttribute("isTargetFunc", isTargetFunc);
		model.addAttribute("isSelf", isSelf);
		model.addAttribute("isOtherView", isOtherView);
		model.addAttribute("isConnectPage", true);
		
		return "searchConnections";
	}*/
	
	/**
	 * Load Education & Training Information
	 * 
	 * @param sso
	 * @param history
	 * @param model
	 * @return
	 */
	@RequestMapping("people/{sso}/json_educationtraining")
	public @ResponseBody
	EducationTrainingDto educationTraining(@PathVariable Long sso, Model model) {
		EducationTrainingDto educationDto = new EducationTrainingDto();
		educationDto.setSso(sso);
		boolean isSelf = false;
		Map<String, DataGroup> dataGroups = null;
		OptinSharing optinSharing = new OptinSharing();
		try {
			dataGroups = authEvaluator
					.getDataGroupsForContextAsMap(
							PersonAuthUtil.getPrincipal(),
							PersonAuthUtil.getAuthorities(), sso);
			isSelf = authEvaluator.isSelf(sso).booleanValue();
			optinSharing = optinSharingService.getOptinSharing(sso);
			List<String> trainingList = optinSharingService.optinTrainingListBySSO(sso);
			optinSharing.setTrainingList(trainingList);
			/*
			educationDto=personalCVService.getLanguage(educationDto);
			educationDto=personalCVService.loadLanguages(educationDto);
			*/
			educationDto.setSelf(isSelf);
			if(dataGroups.get("ResumeEducationView") != null || optinSharing.getEducation().equalsIgnoreCase("Y")){
				educationDto = personalCVService.getEducationBySso(educationDto);
			}
			if(dataGroups.get("ResumeTrainingView") != null || optinSharing.getTraining().equalsIgnoreCase("Y")){
				educationDto = personalCVService.getTrainingBySso(educationDto, (dataGroups.get("ResumeTrainingView") != null), optinSharing);
				if(isSelf){
					educationDto.setOptinTrainingList(trainingList);
				}
			}
			if(dataGroups.get("ResumeProfessionalCertificationView") != null || (optinSharing.getTraining().equalsIgnoreCase("Y") && optinSharing.getTrainingList().contains("Professional Certifications"))){
				educationDto = personalCVService.getCertificationsBySso(educationDto);
			}
			/*if(dataGroups.get("ResumeEducationView") != null && dataGroups.get("ResumeTrainingView") != null){
				educationDto.setSelf(isSelf);
			// Get Education data
				educationDto = personalCVService
					.getEducationAndTraining(educationDto);
				
				if(isSelf){
					educationDto.setOptinTrainingList(trainingList);
				}
				educationDto.setSelf(isSelf);
			}else{
				educationDto = personalCVService
						.getEducationAndTrainingOptin(educationDto, optinSharing);
			}*/
			educationDto.setSso(sso);
			if(dataGroups.get("ResumeLanguageProficiencyView") != null || optinSharing.getLanguage_proficiency().equalsIgnoreCase("Y")){
				educationDto = personalCVService.getLanguageProficieny(educationDto);
			}
			if(dataGroups.get("ResumeLanguageProficiencyEdit") != null){
				educationDto.setLanguageList(personalCVService.getLanguageList());
			}
			
		} catch (Exception e) {
			setErrorToDto(educationDto);
		}

		return educationDto;
	}
	
	/**
	 * Load employee demographic information
	 * 
	 * @param sso
	 * @param history
	 * @param model
	 * @return
	 */
	@RequestMapping("people/{sso}/json_contacts_demographics")
	public @ResponseBody
	ContactsDemographicsDto contactDemographics(@PathVariable Long sso, Model model) {
		ContactsDemographicsDto contactsDemographicsDto = new ContactsDemographicsDto();

		try {
			contactsDemographicsDto.setSso(sso);
			// Get demographics data
			contactsDemographicsDto = personalCVService.getContactsDemographics(contactsDemographicsDto);
		} catch (Exception e) {
			setErrorToDto(contactsDemographicsDto);
		}
		return contactsDemographicsDto;
	}
	
	@RequestMapping("people/{sso}/json_demographics")
	public @ResponseBody
	PersonalCVDto demographics(@PathVariable Long sso, Model model) {
		PersonalCVDto personalCVDto = new PersonalCVDto();

		try {
			personalCVDto.setSso(sso);
			// Get demographics data
			personalCVDto = personalCVService.getDemographics(personalCVDto);
		} catch (Exception e) {
			setErrorToDto(personalCVDto);
		}
		return personalCVDto;
	}

	/**
	 * Controller that loads Performance Information
	 * 
	 * @param sso
	 * @param history
	 * @param model
	 * @return
	 */
	@RequestMapping("people/{sso}/json_performance")
	public @ResponseBody
	PerformanceDto performance(@PathVariable Long sso, Model model) {
		// TODO: GrowthValue name Attribute needs to be trimmed
		PerformanceDto performanceDto = new PerformanceDto(sso);
		try {
			// Get performance data
			performanceDto = performanceService.getPerformance(performanceDto);
		} catch (Exception e) {
			setErrorToDto(performanceDto);
		}
		return performanceDto;
	}

	/**
	 * Controller that loads Compensation Information
	 * 
	 * @param sso
	 * @param history
	 * @param model
	 * @return
	 */
	@RequestMapping("people/{sso}/json_compensation")
	public @ResponseBody
	CompensationDto compensation(@PathVariable Long sso, Model model) {
		CompensationDto compensationDto = new CompensationDto(sso);
		try {
			// Get performance data
			compensationDto = compensationService
					.getCompensation(compensationDto);

		} catch (Exception e) {
			setErrorToDto(compensationDto);
		}

		return compensationDto;
	}
	
	
	@RequestMapping("people/{sso}/json_myhrclients")
	public @ResponseBody
	MyClientFlexiGrid myHrClients(@PathVariable Long sso, Model model,
			HttpServletRequest request) {

		MyClientsDto myClientsDto = new MyClientsDto();
		MyClientFlexiGrid myClientFlexiGrid = new MyClientFlexiGrid();
		ArrayList<HrClientsFlexiGridColModel> rows = new ArrayList<HrClientsFlexiGridColModel>();

		try {
			int page = Integer.parseInt(request.getParameter("page"));
			int rp = Integer.parseInt(request.getParameter("rp"));
			int start = (page - 1) * rp;
			int limit = start + rp;
			String searchQuery = request.getParameter("query");

			myClientsDto.setSso(sso);
			myClientsDto = workAssignmentService.getMyClients(myClientsDto);
			int size = myClientsDto.getMyClientsList().size();

			myClientFlexiGrid.setSso(sso);
			myClientFlexiGrid.setTotal(size);
			myClientFlexiGrid.setPage(page);

			if (limit > size) {
				limit = size;
			}

			int i = 0;
			for (i = start; i < limit; i++) {
				HrClientsFlexiGridColModel newarr = new HrClientsFlexiGridColModel();
				newarr.setCell(myClientsDto.getMyClientsList().get(i));
				newarr.setId(i + 1);
				rows.add(newarr);
			}

			myClientFlexiGrid.setRows(rows);

		} catch (Exception e) {
			setErrorToDto(myClientsDto);
		}

		return myClientFlexiGrid;
	}
	
	

	/*@RequestMapping(value = "people/{sso}/email_reportissue")
	public String reportIssue(Model model, HttpSession session,
			@PathVariable Long sso,
			@RequestParam("flag") String flag) {
		try {
			if(((Boolean) session.getAttribute("VALID_SENSITIVE_POPUP")).booleanValue()){
				if (flag.equalsIgnoreCase("Y") || flag.equalsIgnoreCase("N")) {
					personalInfoService.sensitiveDataPopupService(
							PersonAuthUtil.getLoggedSSO(), flag);
				}
				if (flag.equalsIgnoreCase("Y")) {
					User user = PersonAuthUtil.getPrincipal();
					List<String> rolesForContext = authEvaluator.getRoleForContext(
							user, sso, PersonAuthUtil.getAuthorities());
					List<String> roles = authEvaluator.getAutorizedRoles(user,
							PersonAuthUtil.getAuthorities());
					personalInfoService.sensitiveDataPopupDeleteRolesService(PersonAuthUtil.getLoggedSSO());
					sensitiveDataPopupMail.sendMail(user.getSso(), sso, roles,rolesForContext);
					//session.setAttribute("ROLES_DELETED", "Y");
				}
			}
		} catch (Exception e) {
			return "generic-error";
		}		
		return ("redirect:/people/" + sso);
	}*/
	
	public @ResponseBody
	String reportIssueOk(Model model) {
		return "Success";
	}
	
	@RequestMapping(value = "people/{sso}/info_popup")
	public  @ResponseBody
	String informationPopup(Model model, @PathVariable Long sso,
			@RequestParam("flag") String flag) {
		try {
		personalInfoService.infoPopupInsertBySSOService(PersonAuthUtil.getLoggedSSO(),flag);
		}catch(Exception e){
			return "generic-error";
		}
		return "Success";
	}
	
	@RequestMapping(value = "people/{sso}/expertise_popup")
	public  @ResponseBody
	String expertiseEmptyPopup(Model model, @PathVariable Long sso,
					@RequestParam("flag") String flag) {
		try {
			personalInfoService.insertExpertisePopupBySSOService(PersonAuthUtil.getLoggedSSO(), flag);
		} catch (Exception e) {
			return "generic-error";
		}
		return "Success";
	}
	
	@RequestMapping(value = "people/{sso}/whatsnew_popup")
	public  @ResponseBody
	String whatsNewPopup(Model model, @PathVariable Long sso,
			@RequestParam("flag") String flag) {
		try {
		personalInfoService.whatsnewInsertBySSOService(PersonAuthUtil.getLoggedSSO(),flag);
		}catch(Exception e){
			return "generic-error";
		}
		return "Success";
	}
	
	@RequestMapping(value = "people/{sso}/optin_sharing")
	public @ResponseBody
	String optinSharing(Model model, @PathVariable Long sso,
			@RequestParam(value = "type", required = true) String type,
			@RequestParam(value = "value", required = true) String value,
			HttpSession session) {

		optinSharingService.setOptinSharing(sso, type, value);
		if("connections".equals(type)) {
//			if(session.getAttribute("optOutFlag") != null) {
//				session.removeAttribute("optOutFlag");
//			}
			session.setAttribute("optOutFlag", value);
		}
		
		return "Success";
	}
	
	@RequestMapping(value = "people/{sso}/profile_breakdown")
	public @ResponseBody
	ProfileCompleteness getProfileBreakdown(Model model, @PathVariable Long sso) {
		return personalInfoService.getProfileBreakdown(sso);
	}
	
	@RequestMapping(value = "people/{sso}/optin_sharing_training_list")
	public @ResponseBody
	List<String> optinSharingTrainingList(Model model, @PathVariable Long sso) {
		List<String> list = optinSharingService.allTrainingListBySSO(sso);
		if(!list.contains("Leadership Programs")){
			list.add("Leadership Programs");
		}
		if(!list.contains("Corporate Audit Staff")){
			list.add("Corporate Audit Staff");
		}
		if(!list.contains("Six Sigma")){
			list.add("Six Sigma");
		}
		if(!list.contains("Professional Certifications")){
			list.add("Professional Certifications");
		}
		return list;
	}
	
	@RequestMapping(value = "people/{sso}/get_optin_sharing_training")
	public @ResponseBody
	List<String> getOptinSharingTrainingSelected(Model model, @PathVariable Long sso) {
		return optinSharingService.optinTrainingListBySSO(sso);
	}
	
	@RequestMapping(value = "people/{sso}/set_optin_sharing_training")
	public @ResponseBody
	String setOptinSharingTrainingSelected(Model model, @PathVariable Long sso,
			@RequestParam(value = "training", required = true) String training,
			@RequestParam(value = "delete_flag", required = true) boolean delete_flag) {
		optinSharingService.setTrainingListBySSO(PersonAuthUtil.getLoggedSSO(), training, delete_flag);
		return "Success";
	}
	
	@RequestMapping("people/{sso}/json_employmenthistory")
	public @ResponseBody
	EmployeeHistoryDto employmentHistory(@PathVariable Long sso, Model model,
			HttpServletRequest request, HttpServletResponse response) {

		if(personalInfoService.isValidSSO(sso)){
		boolean isSelf = false;
		boolean isSysAdmin = false;
		boolean hasDataGroup = false;
		EmployeeHistoryDto employeeHistoryDto = new EmployeeHistoryDto(sso);
		employeeHistoryDto.setSso(sso);
		try {
			isSelf=authEvaluator.isSelf(sso).booleanValue();
			isSysAdmin=authEvaluator.isSA().booleanValue();
			if(isSysAdmin || isSelf){
				employeeHistoryDto = employeeHistoryService
						.getEmploymentHistoryAll(employeeHistoryDto, optinSharingService.hasOptinServiceAcess(sso, "emp_history"),true,hasDataGroup);
			}else if(optinSharingService.hasOptinServiceAcess(sso, "emp_history")){
				employeeHistoryDto = employeeHistoryService
						.getEmploymentHistory(employeeHistoryDto,isSelf,hasDataGroup);
				employeeHistoryDto.setShared(true);
			}else{
				employeeHistoryDto.setShared(false);
			}
			employeeHistoryDto.setSso(sso);
			/* Map<String, DataGroup> dataGroups = null;
			   dataGroups = authEvaluator
					.getDataGroupsForContextAsMap(
							PersonAuthUtil.getPrincipal(),
							PersonAuthUtil.getAuthorities(), sso);
			if(dataGroups.get("EMSHistory") != null || optinSharingService.hasOptinServiceAcess(sso, "emp_history")){
				employeeHistoryDto = employeeHistoryService
						.getEmploymentHistory(employeeHistoryDto);
			}*/
		} catch (Exception ex) {
			setErrorToDto(employeeHistoryDto);
		}
		response.addHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, Origin, X-Requested-With");
		response.setHeader("Access-Control-Allow-Origin",
		request.getHeader("Origin"));
		response.addHeader("Access-Control-Allow-Credentials", "true");
		return employeeHistoryDto;
				}else{
			throw new ResourceNotFoundException("Data Not Found");
		}
	}
	
	@RequestMapping("people/{sso}/json_education")
	public @ResponseBody
	EducationDto education(@PathVariable Long sso, Model model,
			HttpServletRequest request, HttpServletResponse response) {
		if(personalInfoService.isValidSSO(sso)){
		EducationDto educationDto = new EducationDto();
		boolean isSelf=false;
		boolean isSysAdmin=false;
		educationDto.setSso(sso);
		try {
			isSelf=authEvaluator.isSelf(sso).booleanValue();
			isSysAdmin=authEvaluator.isSA().booleanValue();
			if(isSysAdmin || isSelf){
				educationDto = personalCVService
						.getEducationAll(educationDto, optinSharingService.hasOptinServiceAcess(sso, "education"));
			}else if(optinSharingService.hasOptinServiceAcess(sso, "education")){
				educationDto = personalCVService
						.getEducation(educationDto);
				educationDto.setShared(true);
			}else{
				educationDto.setShared(false);
			}
			educationDto.setSso(sso);
			/* Map<String, DataGroup> dataGroups = null;
			   dataGroups = authEvaluator
									.getDataGroupsForContextAsMap(
											PersonAuthUtil.getPrincipal(),
											PersonAuthUtil.getAuthorities(), sso);
			if(dataGroups.get("Education") != null || optinSharingService.hasOptinServiceAcess(sso, "education")){
				educationDto = personalCVService
						.getEducation(educationDto);				
			}*/
		} catch (Exception e) {
			setErrorToDto(educationDto);
		}
		response.addHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, Origin, X-Requested-With");
		response.setHeader("Access-Control-Allow-Origin",
		request.getHeader("Origin"));
		response.addHeader("Access-Control-Allow-Credentials", "true");
		return educationDto;
	}else{
		throw new ResourceNotFoundException("Data Not Found");
	}
	}
	
	@RequestMapping("people/{sso}/json_training")
	public @ResponseBody
	TrainingDto training(@PathVariable Long sso, Model model,
			HttpServletRequest request, HttpServletResponse response) {
		if(personalInfoService.isValidSSO(sso)){
		TrainingDto trainingDto = new TrainingDto();
		trainingDto.setSso(sso);
		boolean isSelf=false;
		boolean isSysAdmin=false;
		try {
			isSelf=authEvaluator.isSelf(sso).booleanValue();
			isSysAdmin=authEvaluator.isSA().booleanValue();		
			if(isSysAdmin || isSelf){
				trainingDto = personalCVService
						.getTrainingAll(trainingDto, optinSharingService.hasOptinServiceAcess(sso, "training"), optinSharingService.optinTrainingListBySSO(sso));
			}else if(optinSharingService.hasOptinServiceAcess(sso, "training")){
				trainingDto = personalCVService
						.getTraining(trainingDto, optinSharingService.allTrainingListBySSO(sso), optinSharingService.optinTrainingListBySSO(sso));
				trainingDto.setShared(true);
			}else{
				trainingDto.setShared(false);
			}
			trainingDto.setSso(sso);
			/*Map<String, DataGroup> dataGroups = null;
			dataGroups = authEvaluator
									.getDataGroupsForContextAsMap(
											PersonAuthUtil.getPrincipal(),
											PersonAuthUtil.getAuthorities(), sso);
			if(dataGroups.get("Training") != null || optinSharingService.hasOptinServiceAcess(sso, "training")){
				trainingDto = personalCVService
						.getTraining(trainingDto);	
			}*/
		} catch (Exception e) {
			setErrorToDto(trainingDto);
		}
		response.addHeader("Access-Control-Allow-Headers","Content-Type, Authorization, Accept, Origin, X-Requested-With");
		response.setHeader("Access-Control-Allow-Origin",
		request.getHeader("Origin"));
		response.addHeader("Access-Control-Allow-Credentials", "true");

		return trainingDto;
	}else{
		throw new ResourceNotFoundException("Data Not Found");
	}
	}	
	
	/**
	* Handle request to download a PDF document 
	*/
	
	@PreAuthorize("hasPermission(#sso, 'ShowPDFPreview', read)")
	@RequestMapping(value = "people/{sso}/pdf_preview") 
	public ModelAndView printPDF(@PathVariable Long sso, Model model,
			HttpServletRequest request, HttpServletResponse response, HttpSession session) {

	 
		List<String> columns = new ArrayList<String>();
		List<String> sortorder = new ArrayList<String>();
		boolean isSelf = false;
		PDFMenuPersistence pdfMenuPersistence = new PDFMenuPersistence();
		
		PrintPDFDto printPDFDto = new PrintPDFDto(); 
		PersonalInfoDto personalInfo = new PersonalInfoDto(); 
		isSelf = authEvaluator.isSelf(sso).booleanValue();
		personalInfo.setSso(sso); 
		printPDFDto.setSso(sso);
		printPDFDto.setNameHeaderFont(Float.parseFloat(propertyDao.getByKey("pdf.name.font.size"))); //12
		printPDFDto.setHeaderFont(Float.parseFloat(propertyDao.getByKey("pdf.header.font.size"))); //10
		printPDFDto.setSubHeaderFont(Float.parseFloat(propertyDao.getByKey("pdf.subheader.font.size"))); //9
		printPDFDto.setBodyFont(Float.parseFloat(propertyDao.getByKey("pdf.body.font.size"))); //7
	
		printPDFDto.setNameHeaderFont(Float.parseFloat(propertyDao.getByKey("pdf.name.font.size"))); //12
		printPDFDto.setHeaderFont(Float.parseFloat(propertyDao.getByKey("pdf.header.font.size"))); //10
		printPDFDto.setSubHeaderFont(Float.parseFloat(propertyDao.getByKey("pdf.subheader.font.size"))); //9
		printPDFDto.setBodyFont(Float.parseFloat(propertyDao.getByKey("pdf.body.font.size"))); //7
		if (request.getParameterValues("columns") != null){
//			columns = java.util.Arrays.asList(request.getParameterValues("columns"));
			try {
				for(String curcolumn : request.getParameterValues("columns")) {
					String validcolumn = ESAPI.validator().getValidInput("RequestParameter", curcolumn, "HTTPParameterValue", 1000, true);
					columns.add(validcolumn);
				}
			} catch (IntrusionException | ValidationException e) { }
		}
		printPDFDto.setColumns(columns);
		
		if (request.getParameterValues("sortorder") != null){
//			sortorder = java.util.Arrays.asList(request.getParameterValues("sortorder"));
			try {
				for(String cursortorder : request.getParameterValues("sortorder")) {
					String validsortorder = ESAPI.validator().getValidInput("RequestParameter", cursortorder, "HTTPParameterValue", 1000, true);
					sortorder.add(validsortorder);
				}
			} catch (IntrusionException | ValidationException e) { }
		}
		
		if (request.getParameter("stk_opt_outstanding_total") != null){
			printPDFDto.setStk_opt_outstanding_total(request.getParameter("stk_opt_outstanding_total"));
		}
		if (request.getParameter("stk_opt_vested_total") != null){
			printPDFDto.setStk_opt_vested_total(request.getParameter("stk_opt_vested_total"));
		}
		if (request.getParameter("stk_opt_unvested_total") != null){
			printPDFDto.setStk_opt_unvested_total(request.getParameter("stk_opt_unvested_total"));
		}
		if (request.getParameter("rsu_grant_hist_total") != null){
			printPDFDto.setRsu_grant_hist_total(request.getParameter("rsu_grant_hist_total"));
		}
		
		pdfMenuPersistence.setColumns(columns);
		pdfMenuPersistence.setSortorder(sortorder);
		session.setAttribute("pdfMenuPersistence", pdfMenuPersistence);
	
		printPDFDto.setDataGroupAcess(authEvaluator
		.getDataGroupsForContextAsMap(
		PersonAuthUtil.getPrincipal(),
		PersonAuthUtil.getAuthorities(), sso)); 
		
		if (!authEvaluator.isContingentWorker(sso) && !authEvaluator.isJointVentureEmployee(sso) && printPDFDto.getDataGroupAcess().get("ShowPDFPreview") != null){
		printPDFDto.setOptinSharingAccess(optinSharingService.getOptinSharing(sso));
		personalInfo = personalInfoService.getPersonalInfo(personalInfo);
		personalInfo.setProfessionalSummary(workAssignmentService.getProfessionalSummary(sso));
		personalInfoService.setExpertiseAsString(personalInfo);
		printPDFDto.setPersonalInfoDto(personalInfo);
		if ((
				printPDFDto.getDataGroupAcess().get("WorkAssignment") != null ||
				printPDFDto.getDataGroupAcess().get("WorkAssignmentRestricted") != null ||
				printPDFDto.getDataGroupAcess().get("HeadCountCostCenter") !=null || 
				printPDFDto.getDataGroupAcess().get("CostCenter") != null||
			    printPDFDto.getDataGroupAcess().get("ResumeFeaturedExpertiseView") != null||
				printPDFDto.getDataGroupAcess().get("ResumeProfessionalSummaryView") != null
				
				)&& 
				(printPDFDto.getColumns().contains("contact_information") ==true ||
				printPDFDto.getColumns().contains("expertise") ==true ||
				printPDFDto.getColumns().contains("current_assignment") ==true ||
				printPDFDto.getColumns().contains("leadership") ==true ||
				printPDFDto.getColumns().contains("team") ==true ||
				printPDFDto.getColumns().contains("cost_center") ==true ||
				printPDFDto.getColumns().contains("payroll") ==true
				||printPDFDto.getColumns().contains("professional_summary") ==true
			)) {
			printPDFDto.setAssignmentDto(assignment(sso,model,session));      
		}
		if (
				printPDFDto.getDataGroupAcess().get("WorkAssignmentHistroyInternal") != null
				&& 
				printPDFDto.getColumns().contains("work_history") ==true
				) {
			printPDFDto.setAssignmentHistoryDto(assignmentHistory(sso,model));      
		}
		if ((
				printPDFDto.getDataGroupAcess().get("HomeAddress") != null ||
				printPDFDto.getDataGroupAcess().get("EmergencyContact") != null ||
				printPDFDto.getDataGroupAcess().get("GenderCitizenship") !=null || 
				printPDFDto.getDataGroupAcess().get("PersonalIdentificationRestricted") != null
				)&& 
				(printPDFDto.getColumns().contains("home_address") ==true ||
				printPDFDto.getColumns().contains("emergency_contact") ==true ||
				printPDFDto.getColumns().contains("demographics") ==true
			)) {
			printPDFDto.setContactDemographics(contactDemographics(sso,model));      
		}
		if ((
				printPDFDto.getDataGroupAcess().get("ResumeWorkHistoryView") != null ||
				printPDFDto.getDataGroupAcess().get("ResumeCareerAspirationView") != null ||
				printPDFDto.getDataGroupAcess().get("ResumeWorkMobilityView") != null ||
				printPDFDto.getDataGroupAcess().get("ResumeCustomerSuppliersView") != null ||
				printPDFDto.getDataGroupAcess().get("ResumeInitiativesProjectsView") != null ||
				printPDFDto.getOptinSharingAccess().getEmp_history().equalsIgnoreCase("Y") ||
				printPDFDto.getOptinSharingAccess().getCareer_aspirations().equalsIgnoreCase("Y") ||
				printPDFDto.getOptinSharingAccess().getWork_mobility().equalsIgnoreCase("Y") ||
				printPDFDto.getOptinSharingAccess().getCustomers_suppliers().equalsIgnoreCase("Y") ||
				printPDFDto.getOptinSharingAccess().getInitiatives_projects().equalsIgnoreCase("Y") ||				
				printPDFDto.getDataGroupAcess().get("ServiceDates") != null
				)&& 
				(printPDFDto.getColumns().contains("employment_history") ==true ||
				printPDFDto.getColumns().contains("servicedates") ==true||
				printPDFDto.getColumns().contains("career_aspirations")==true ||
				printPDFDto.getColumns().contains("initiatives_projects")==true||
				printPDFDto.getColumns().contains("customers_suppliers")==true||
			    printPDFDto.getColumns().contains("current_job")==true
			)) {
			printPDFDto.setEmployeeHistoryDto(employeeHistory(sso,model));      
		}
		if ((
				printPDFDto.getDataGroupAcess().get("ResumeProfessionalPersonalInterestsView") != null ||
				printPDFDto.getDataGroupAcess().get("ResumeExternalGroupAffiliationsView") != null ||
				printPDFDto.getDataGroupAcess().get("ResumeOnlineNetworksView") != null ||
				printPDFDto.getOptinSharingAccess().getOnline_networks().equalsIgnoreCase("Y")||
				printPDFDto.getOptinSharingAccess().getProf_personal_interests().equalsIgnoreCase("Y")||
				printPDFDto.getOptinSharingAccess().getExternal_group_affiliations().equalsIgnoreCase("Y"))&&
				(printPDFDto.getColumns().contains("prof_personal_interests") ==true ||
				printPDFDto.getColumns().contains("online_networks") ==true||
				printPDFDto.getColumns().contains("external_group_affiliations")==true 
			)) {
			printPDFDto.setInterestAffilationDto(getInterestAffiliations(sso,model));      
		}
		if ((
				printPDFDto.getDataGroupAcess().get("ResumeEducationView") != null ||			
				printPDFDto.getDataGroupAcess().get("ResumeTrainingView") != null ||
				printPDFDto.getDataGroupAcess().get("ResumeLanguageProficiencyView") != null ||
				printPDFDto.getOptinSharingAccess().getEducation().equalsIgnoreCase("Y") ||
				printPDFDto.getOptinSharingAccess().getTraining().equalsIgnoreCase("Y")||
				printPDFDto.getOptinSharingAccess().getLanguage_proficiency().equalsIgnoreCase("Y")
				)&& 
				(printPDFDto.getColumns().contains("education") ==true ||
						printPDFDto.getColumns().contains("training") ==true||
						printPDFDto.getColumns().contains("languages")==true
			)) {
			printPDFDto.setEducationTrainingDto(educationTraining(sso,model));     
		}
		if (
				printPDFDto.getDataGroupAcess().get("Performance") != null
				&& 
				printPDFDto.getColumns().contains("appraisal") ==true
				) {
			printPDFDto.setPerformanceDto(performance(sso,model));    
		}
		if (
				printPDFDto.getDataGroupAcess().get("Compensation") != null
				&& 
				printPDFDto.getColumns().contains("compensation") ==true
				) {
			printPDFDto.setCompensationDto(compensation(sso,model));     
		}

	    	    	
		}
		return new ModelAndView("PdfSummary", "printPDFDto", printPDFDto);
	}
	
	/**
	 * Return previously set pdf menu sort order and checked parameters
	 * 
	 * @return
	 */
	@RequestMapping(value="people/{sso}/pdf_menu_persistence")
	public @ResponseBody PDFMenuPersistence getPersistedPDFMenu(@PathVariable Long sso, HttpSession session){
		PDFMenuPersistence pdfMenuPersistence = (PDFMenuPersistence)session.getAttribute("pdfMenuPersistence");	
		return pdfMenuPersistence;
	}
	
	@PreAuthorize("hasPermission(#sso, 'ViewManagerPopup', read)")
	@RequestMapping("people/{sso}/json_myreports")
	public @ResponseBody
	MyReportsDto getReportsData(@PathVariable Long sso, Model model, HttpSession session) {
		MyReportsDto myReportsDto = new MyReportsDto();
		try {
			if(session.getAttribute("IS_VIEW_SUSPEND_EMP") != null && sso.equals((Long) session.getAttribute("VIEWED_SSO"))){
				myReportsDto.setViewSuspendedEmployees(((Boolean) session.getAttribute("IS_VIEW_SUSPEND_EMP")).booleanValue());
			}else{
				Map<String, DataGroup> dataGroups = null;
				dataGroups = authEvaluator
						.getDataGroupsForContextAsMap(
								PersonAuthUtil.getPrincipal(),
								PersonAuthUtil.getAuthorities(), sso);
				myReportsDto.setViewSuspendedEmployees((dataGroups.get("ViewSuspendedEmployees")!=null)?true:false);
			}
			myReportsDto.setSso(sso);
			myReportsDto = workAssignmentService.getMyReport(myReportsDto);
			myReportsDto.setFormat("JSON");
		} catch (Exception e) {
			setErrorToDto(myReportsDto);
		}
		return myReportsDto;
	}
	
	@PreAuthorize("hasPermission(#sso, 'ViewManagerPopup', read)")
	@RequestMapping(value = {"people/{sso}/excel_myreports"})
	public ModelAndView generateReportsExcel(Model model, @PathVariable Long sso, HttpSession session) {
		MyReportsDto myReportsDto = new MyReportsDto();
		try {
			if(session.getAttribute("IS_VIEW_SUSPEND_EMP") != null && sso.equals((Long) session.getAttribute("VIEWED_SSO"))){
				myReportsDto.setViewSuspendedEmployees(((Boolean) session.getAttribute("IS_VIEW_SUSPEND_EMP")).booleanValue());
			}else{
				Map<String, DataGroup> dataGroups = null;
				dataGroups = authEvaluator
						.getDataGroupsForContextAsMap(
								PersonAuthUtil.getPrincipal(),
								PersonAuthUtil.getAuthorities(), sso);
				myReportsDto.setViewSuspendedEmployees((dataGroups.get("ViewSuspendedEmployees")!=null)?true:false);
			}
			myReportsDto.setSso(sso);
			myReportsDto = workAssignmentService.getMyReport(myReportsDto);
			myReportsDto.setFormat("EXCEL");
			myReportsDto.setFullname(workAssignmentService.getFullName(sso));
		} catch (Exception e) {
			setErrorToDto(myReportsDto);
		}
		return new ModelAndView("MyTeamExcelReportView", "MyReportsList", myReportsDto);
	}
	
	@PreAuthorize("hasPermission(#sso, 'ResumeProfessionalSummaryEdit', read)")
	@RequestMapping(value = {"people/{sso}/saveProfessionalSummary"},method=RequestMethod.POST)
	public @ResponseBody boolean setProfessionalSummary(@PathVariable Long sso, 
			@RequestParam(value = "param", required = true) String param,
			Model model, HttpSession session) {
		boolean success = false;
		try {
			param = personalInfoService.escapeSpecialCharacters(param);
			success = workAssignmentService.setProfessionalSummary(sso, param);	
		} catch(Exception e) {
		}
		return success;		
	}
	
	@PreAuthorize("hasPermission(#sso, 'ResumeLanguageProficiencyEdit', read)")
	@Transactional(isolation = Isolation.READ_COMMITTED, rollbackForClassName = "Exception.class", propagation = Propagation.REQUIRED)
	@RequestMapping(value = "people/{sso}/saveLanguageProficiency", method=RequestMethod.POST, headers = { "content-type=application/json" })
	public @ResponseBody boolean setLanguageProficiency(@PathVariable Long sso,
			@RequestBody ArrayList<Map<String, String>> langProfList,
			Model model) {
		boolean success = false;
		try {	
			success = personalCVService.setLanguageProficieny(sso, langProfList);
		} catch(Exception e) {
		}
		return success;		
	}

	@PreAuthorize("hasPermission(#sso, 'ResumeCareerAspirationEdit', read)")
	@RequestMapping("people/{sso}/saveCareerAspiration")
	public @ResponseBody boolean setCareerInterest(@PathVariable Long sso, 
			@RequestParam(value = "newCareerAsp", required = true ) String goalCombined,		
			Model model) {
	boolean flag = false;
		try {		
			goalCombined = personalInfoService.escapeSpecialCharacters(goalCombined);
			flag = 	employeeHistoryService.setCareerAspiration(sso, goalCombined);
		} catch (Exception e) {
			e.getMessage();
		}
		return flag;	
		
	}
	
	@PreAuthorize("hasPermission(#sso, 'ResumeCareerAspirationEdit', read)")
	@RequestMapping("people/{sso}/saveCareerOpp")
	public @ResponseBody boolean setCareerOpportunity(@PathVariable Long sso, 
			@RequestParam(value = "careerOppFlag", required = true) String careerOppFlag,
			Model model) {
	boolean flag = false;
		try {		
			careerOppFlag = personalInfoService.escapeSpecialCharacters(careerOppFlag);
			flag = 	employeeHistoryService.setCareerOpportunity(sso,careerOppFlag);	
		} catch (Exception e) {
			e.getMessage();
		}
		return flag;	
		
	} 

	
//	@Transactional(isolation = Isolation.READ_COMMITTED, rollbackForClassName = "Exception.class", propagation = Propagation.REQUIRED)
	@PreAuthorize("hasPermission(#sso, 'ResumeWorkMobilityEdit', read)")
	@RequestMapping(value = {"people/{sso}/saveWorkMobility"},method=RequestMethod.POST)	
	public @ResponseBody boolean setWorkMobility(@PathVariable Long sso, 
			 WorkMobility workMobility,Model model) {
	boolean flag = false;
	try {
		
		List<String> selectList=workMobility.getSelectedCountryList();
		if(selectList!=null){
			for(int i=0;i<selectList.size();i++)
			{
				
				selectList.set(i, selectList.get(i).replace('-', ','));
			}
			workMobility.setSelectedCountryList(selectList);
		}
		flag= employeeHistoryService.setWorkMobility( sso, workMobility);
		} catch (Exception e) {
			e.getMessage();
		}
		return flag;	
	}
	
//	@PreAuthorize("hasPermission(#sso, 'ResumeMentoringEdit', read)")
	@RequestMapping(value = {"people/{sso}/saveMentoring"},method=RequestMethod.POST)	
	public @ResponseBody boolean setMentoring(@PathVariable Long sso, 
			 Mentoring mentoring,Model model) {
	boolean flag = false;
	try {
		
		//mentoring.setSso(sso);
		flag= interestService.saveMentoringData( sso, mentoring);
		} catch (Exception e) {
			e.getMessage();
		}
		return flag;	
	}
	
	@RequestMapping(value = {"people/{sso}/getMentoring"})	
	public @ResponseBody Mentoring getMentoring(@PathVariable Long sso) {
		try {
			return interestService.getMentoringData(sso, true);
		} catch (Exception e) {	e.getMessage();}
		return null;
	}
	/*@RequestMapping(value={"people/{sso}/json_addNewInitaiatives"},method=RequestMethod.POST)
	 public  @ResponseBody
	String addNewInitaiatives(@PathVariable Long sso,@RequestBody IntiativesandProjectDto nintiativesandProject)
	{
		List<IntiativesandProject> intia=nintiativesandProject.getNintiativesandProject();
		System.out.println(intia.size());
		return "success";
	}
	*/
	@PreAuthorize("hasPermission(#sso, 'ResumeInitiativesProjectsEdit', read)")
	@RequestMapping(value = {"people/{sso}/saveInitiativesProjects"},method=RequestMethod.POST)
	public @ResponseBody String addNewInitaiatives(Model model,  HttpServletRequest request,@PathVariable Long sso,@RequestBody EmployeeHistoryDto newIntiativesandProject,HttpSession session) {
		newIntiativesandProject.setSso(sso);
		try {
			List<IntiativesandProject> lan=newIntiativesandProject.getNewIntiativesandProject();
			employeeHistoryService.updateIntiativesAndProject(newIntiativesandProject);
		} catch (Exception e) {
		}
		return "Success";
	}
	
	@PreAuthorize("hasPermission(#sso, 'ResumeCustomerSuppliersEdit', read)")
	@RequestMapping(value = {"people/{sso}/saveCustomerSuppliers"},method=RequestMethod.POST)
	public @ResponseBody String saveCustomerSuppliers(Model model,  HttpServletRequest request,@PathVariable Long sso,@RequestBody EmployeeHistoryDto newcustomerSupplier,HttpSession session) {
		newcustomerSupplier.setSso(sso);
		try {
			//List<CustomerandSuppliers> customerandSuppliers=newcustomerSupplier.getNewCustomerSupplier();
			employeeHistoryService.updateCustomerSuppliers(newcustomerSupplier);
		} catch (Exception e) {
		}
		return "Success";
	}
	@PreAuthorize("hasPermission(#sso, 'ResumeWorkHistoryEdit', read)")
	@RequestMapping(value = {"people/{sso}/saveEmploymentHistory"},method=RequestMethod.POST)
	public @ResponseBody BaseModelCollection<EmployeeHistory> addEmploymentHistory(Model model,HttpServletRequest request,@PathVariable Long sso, @RequestBody EmployeeHistoryDto employmentHistory,HttpSession session) {
		BaseModelCollection<EmployeeHistory> employeeHistoryList = new BaseModelCollection<EmployeeHistory>();
		boolean saved = false;
		try {
			if(employmentHistory.getEmploymentHistory().get(0).getCurrentFlag().equalsIgnoreCase("Y")){
				saved = employeeHistoryService.saveCurrentJob(employmentHistory.getEmploymentHistory().get(0), sso);
			}else{
				saved = employeeHistoryService.saveEmploymentHistory(employmentHistory.getEmploymentHistory(), sso);
			}
			if(saved){
				employeeHistoryList = employeeHistoryService.populateEmploymentHistory(sso);
			}
		} catch (Exception e) {
			throw new RuntimeException("Employment History not updated");
		}
		return employeeHistoryList;
	}
	
	@PreAuthorize("hasPermission(#sso, 'ResumeWorkHistoryEdit', read)")
	@RequestMapping(value = {"people/{sso}/deleteEmploymentHistory"},method=RequestMethod.POST)
	public @ResponseBody BaseModelCollection<EmployeeHistory> deleteEmploymentHistory(Model model,HttpServletRequest request,@PathVariable Long sso, @RequestBody EmployeeHistoryDto employmentHistory,HttpSession session) {
		BaseModelCollection<EmployeeHistory> employeeHistoryList = new BaseModelCollection<EmployeeHistory>();
		boolean saved = false;
		try {
			saved = employeeHistoryService.saveEmploymentHistory(employmentHistory.getEmploymentHistory(), sso);
			if(saved){
				employeeHistoryList = employeeHistoryService.populateEmploymentHistory(sso);
			}
		} catch (Exception e) {
			throw new RuntimeException("Employment History not updated");
		}
		return employeeHistoryList;
	}
	
	@RequestMapping("people/{sso}/json_interestaffiliations")
	public @ResponseBody InterestAffiliationDto getInterestAffiliations(@PathVariable Long sso, Model model) {
		InterestAffiliationDto interests = new InterestAffiliationDto();
		//boolean showProfInterests, showExtGroupAffiliations, showMentoring,showOnlineNetworks = false;
		boolean showProfInterests, showExtGroupAffiliations, showOnlineNetworks = false;
		Map<String, DataGroup> dataGroups = null;
		OptinSharing optinSharing= new OptinSharing();
		try {
			dataGroups = authEvaluator
					.getDataGroupsForContextAsMap(
							PersonAuthUtil.getPrincipal(),
							PersonAuthUtil.getAuthorities(), sso);
			optinSharing = optinSharingService.getOptinSharing(sso);
			showProfInterests = dataGroups.get("ResumeProfessionalPersonalInterestsEdit") != null || dataGroups.get("ResumeProfessionalPersonalInterestsView") != null || optinSharing.getProf_personal_interests().equalsIgnoreCase("Y");
			//showMentoring = dataGroups.get("ResumeMentoringEdit") != null || dataGroups.get("ResumeMentoringView") != null || optinSharing.getMentoring().equalsIgnoreCase("Y");
			showExtGroupAffiliations = dataGroups.get("ResumeExternalGroupAffiliationsEdit") != null || dataGroups.get("ResumeExternalGroupAffiliationsView") != null || optinSharing.getExternal_group_affiliations().equalsIgnoreCase("Y");
			showOnlineNetworks = dataGroups.get("ResumeOnlineNetworksEdit") != null || dataGroups.get("ResumeOnlineNetworksView") != null || optinSharing.getOnline_networks().equalsIgnoreCase("Y");
			/*if(showProfInterests || showExtGroupAffiliations || showOnlineNetworks||showMentoring){
				interests = interestService.getInterestAffiliations(sso, showProfInterests, showExtGroupAffiliations, showOnlineNetworks,showMentoring);
			}*/
			if(showProfInterests || showExtGroupAffiliations || showOnlineNetworks){
				interests = interestService.getInterestAffiliations(sso, showProfInterests, showExtGroupAffiliations, showOnlineNetworks);
			}

		} catch (Exception ex) {
			setErrorToDto(interests);
		}
		
		return interests;
	}
	
	@PreAuthorize("hasPermission(#sso, 'ResumeProfessionalPersonalInterestsEdit', read)")
	@RequestMapping(value = {"people/{sso}/saveProfessionalInterests"},method=RequestMethod.POST)
	public @ResponseBody boolean saveProfessionalInterests(@PathVariable Long sso, 
			@RequestParam(value = "param", required = true)  String param,
			Model model, HttpSession session) {
		boolean success = false;
		try {
			if(param != null){
				param = personalInfoService.escapeSpecialCharacters(param);
				success = interestService.saveProfessionalInterests(sso, param);		
			}
		} catch (Exception e) {
			throw new RuntimeException("Personal / Professional interests not updated");
		}
		return success;
	}
	
	@PreAuthorize("hasPermission(#sso, 'ResumeOnlineNetworksEdit', read)")
	@RequestMapping(value = {"people/{sso}/saveOnlineNetworks"},method=RequestMethod.POST)
	public @ResponseBody boolean saveOnlineNetworks(Model model,HttpServletRequest request,@PathVariable Long sso, @RequestBody InterestAffiliationDto networkList,HttpSession session) {
		boolean success= false;
		try {
			if(networkList != null){
				success = interestService.saveOnlineNetworks(sso, networkList.getNetworkList());
			}
		} catch (Exception e) {
			throw new RuntimeException("Employment History not updated");
		}
		return success;
	}
	
	@PreAuthorize("hasPermission(#sso, 'ResumeEducationEdit', read)")
	@RequestMapping("people/{sso}/loadEducationCatalogs")
	public @ResponseBody EducationCatalogs loadEducationCatalogs(@PathVariable Long sso, @RequestParam(value = "query", required = false)  String query, @RequestParam(value = "country", required = false)  String country, Model model) {
		EducationCatalogs catalogs = new EducationCatalogs();
		boolean hasDataGroup = false;
		Map<String, DataGroup> dataGroups = null;
		try {
			dataGroups = authEvaluator
					.getDataGroupsForContextAsMap(
							PersonAuthUtil.getPrincipal(),
							PersonAuthUtil.getAuthorities(), sso);
			hasDataGroup = dataGroups.get("Education") != null ? true : false;
			String validatedQuery = ESAPI.validator().getValidInput("RequestParameter", query, "HTTPParameterValue", 1000, true);
			String validatedCountry = ESAPI.validator().getValidInput("RequestParameter", country, "HTTPParameterValue", 1000, true);
			if(hasDataGroup){
				catalogs = personalCVService.loadEducationCatalogs(validatedCountry,validatedQuery);
			}

		} catch (Exception ex) {
			setErrorToDto(catalogs);
		}
		
		return catalogs;
	}
	
	@PreAuthorize("hasPermission(#sso, 'ResumeEducationEdit', read)")
	@RequestMapping(value = {"people/{sso}/saveEducationDetails"}, method=RequestMethod.POST)
	public @ResponseBody boolean saveEducation(Model model,HttpServletRequest request,@PathVariable Long sso, @RequestBody EducationTrainingDto educationDetailsList,HttpSession session) {
		boolean success = false;
		try {
			if(educationDetailsList.getEducationDetailsList()!=null){
				success = personalCVService.saveEducationDetails(sso, educationDetailsList);
			}			
		} catch(Exception e) {
			setErrorToDto(educationDetailsList);
		}
		return success;
	}
	
	@PreAuthorize("hasPermission(#sso, 'ResumeEducationEdit', read)")
	@RequestMapping(value = {"people/{sso}/deleteEducationDetails"},method=RequestMethod.POST)
	public @ResponseBody boolean deleteEducation(Model model,HttpServletRequest request,@PathVariable Long sso, @RequestBody EducationTrainingDto educationDetailsList,HttpSession session) {
		boolean success = false;
		try {
			if(educationDetailsList.getEducationDetailsList()!=null){
				success = personalCVService.saveEducationDetails(sso, educationDetailsList);
			}			
		} catch (Exception e) {
			throw new RuntimeException("Education details not updated");
		}
		return success;
	}
	
	@PreAuthorize("hasPermission(#sso, 'ResumeTrainingEdit', read)")
	@RequestMapping(value = {"people/{sso}/saveProfessionalCertifications"},method=RequestMethod.POST)
	public @ResponseBody boolean saveProfessionalCertifications(Model model,HttpServletRequest request,@PathVariable Long sso, @RequestBody EducationTrainingDto certificationList,HttpSession session) {
		boolean success= false;
		try {
			if(certificationList != null){
				success = personalCVService.saveProfessionalCertifications(sso, certificationList.getCertificationList());
			}
		} catch (Exception e) {
			throw new RuntimeException("Professional Certifications not updated");
		}
		return success;
	}
	
	@RequestMapping(value = {"people/{sso}/updateOptinSharing"},method=RequestMethod.POST)
	public @ResponseBody OptinSharing updateOptinSharing(Model model,HttpServletRequest request,@PathVariable Long sso, OptinSharing optinSharing,HttpSession session) {
		boolean success = false;
		try {
			optinSharing.setSso(PersonAuthUtil.getLoggedSSO());
			success = optinSharingService.updateOptinSharing(optinSharing);	
			if(success){
				optinSharing = optinSharingService.getOptinSharing(sso);
				//if(isSelf){
					optinSharing.setTrainingList(optinSharingService.allTrainingListBySSO(sso));	
					optinSharing.setSharedTrainingList(optinSharingService.getSharedTrainingList(sso));
				//}
			}
		} catch (Exception e) {
			throw new RuntimeException("Optin Sharing details not updated");
		}
		return optinSharing;
	}
	
	@RequestMapping("people/{sso}/getProfileCompleteness")
	public @ResponseBody ProfileCompleteness getProfileCompleteness(@PathVariable Long sso, @RequestParam(value = "expertiseFlag", required = false) Boolean expertiseFlag, Model model){
		ProfileCompleteness profileCompleteness = new ProfileCompleteness();
		try{
			profileCompleteness = personalInfoService.getProfileCompleteness(sso, expertiseFlag);
		} catch(Exception e) {
			throw new RuntimeException("Profile Completeness details not found for " + sso);
		}
		return profileCompleteness;
	}
	
	@PreAuthorize("hasPermission(#sso, 'ResumeExternalGroupAffiliationsEdit', read)")
	@RequestMapping(value = {"people/{sso}/saveExternalAffiliations"},method=RequestMethod.POST)
	public @ResponseBody boolean saveExternalAffiliations(Model model,HttpServletRequest request,@PathVariable Long sso, @RequestBody InterestAffiliationDto externalAffiliationsList,HttpSession session) {
		boolean success= false;
		try {
			if(externalAffiliationsList != null){
				success = interestService.saveExternalAffiliations(sso, externalAffiliationsList.getExternalAffiliationsList());
			}
		} catch (Exception e) {
			throw new RuntimeException("Employment History not updated");
		}
		return success;
	}
	
	@RequestMapping(value = {"people/{sso}/updateEmpHistoryAlertFlag"},method=RequestMethod.POST)
	public @ResponseBody boolean updateEmpHistoryAlertFlag(Model model,HttpServletRequest request,@PathVariable Long sso,HttpSession session) {
		boolean success = false;
		try {
			success = employeeHistoryService.updateEmpistoryAlertFlagService(PersonAuthUtil.getLoggedSSO());
		} catch (Exception e) {
			throw new RuntimeException("Cleared EMH Alert Flag");
		}
		return success;
	}
	
	@RequestMapping(value = "people/{sso}/vcard", method = RequestMethod.GET)
	public void downloadVcard(@PathVariable Long sso, HttpServletResponse response) throws IOException {
	
		PersonalInfoDto personalInfo = new PersonalInfoDto();
		personalInfo.setSso(sso);
		personalInfo = personalInfoService.getPersonalInfo(personalInfo);
	
		AssignmentDto assignmentDto = new AssignmentDto();
		assignmentDto.setSso(sso);
		assignmentDto.setAlstomEmployee(personalInfo.isAlstomEmployee());
		assignmentDto = workAssignmentService.getCurrentInformation(assignmentDto);
	
		response.setHeader("Content-Type", "text/vcard");
		response.setHeader("Content-Disposition", "attachment;filename=\"" + personalInfo.getLastName() + ",  "
				+ personalInfo.getFirstName() + " (" + personalInfo.getIndustrySegment() + ")" + ".vcf\"");
	
		// vCard header
		response.getWriter().println("BEGIN:VCARD");
		response.getWriter().println("VERSION:3.0");
		// vCard Name
		response.getWriter().print("N:");
		response.getWriter().print(personalInfo.getFirstName());
		response.getWriter().print(";");
		response.getWriter().print(personalInfo.getLastName());
		response.getWriter().print(";;(");
		response.getWriter().print(personalInfo.getIndustrySegment());
		response.getWriter().println(")");
	
		response.getWriter().print("FN:");
		response.getWriter().print(personalInfo.getLastName());
		response.getWriter().print(", ");
		response.getWriter().print(personalInfo.getFirstName());
		response.getWriter().print(" (");
		response.getWriter().print(personalInfo.getIndustrySegment());
		response.getWriter().println(")");
		// vCard Org
		response.getWriter().print("ORG:");
		response.getWriter().print(assignmentDto.getWorkAssignment().getLegalEntity());
		response.getWriter().print(";");
		response.getWriter().println(personalInfo.getSubBusiness());
		// vCard Title
		response.getWriter().print("TITLE:");
		response.getWriter().println(personalInfo.getTitle());
		// vCard Phone
		response.getWriter().print("TEL;TYPE=WORK,VOICE:");
		response.getWriter().println(personalInfo.getPhone());
	
		response.getWriter().print("TEL;TYPE=CELL,VOICE:");
		response.getWriter().println(personalInfo.getCell());
		// vCard Address
		response.getWriter().print("ADR;TYPE=WORK:;;");
		response.getWriter().print(personalInfo.getAddress1());
		if (personalInfo.getAddress2() != null) {
			response.getWriter().print(", ");
			response.getWriter().print(personalInfo.getAddress2());
		}
		if (personalInfo.getAddress3() != null) {
			response.getWriter().print(", ");
			response.getWriter().print(personalInfo.getAddress3());
		}
		response.getWriter().print(";");
		response.getWriter().print(personalInfo.getCity());
		response.getWriter().print(";");
		response.getWriter().print(personalInfo.getState());
		response.getWriter().print(";");
		response.getWriter().print(personalInfo.getZip());
		response.getWriter().print(";");
		response.getWriter().println(personalInfo.getCountry());
	
		// vCard E-mail
		response.getWriter().print("EMAIL:");
		response.getWriter().println(personalInfo.getEmail());
	
		response.getWriter().print("X-MS-IMADDRESS:");
		response.getWriter().println(personalInfo.getEmail());
		// vCard Footer
		response.getWriter().print("REV:");
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd'T'kkmmss'Z'");
		dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
		response.getWriter().println(dateFormat.format(new Date()));
		response.getWriter().println("END:VCARD");
	}
	
	@RequestMapping("people/{sso}/json_swoopeducation")
	public @ResponseBody
	com.ge.corporate.hr.profile.common.dto.EducationDto getSwoopEducationData(@PathVariable Long sso, Model model, HttpSession session) {
		com.ge.corporate.hr.profile.common.dto.EducationDto educationList = new com.ge.corporate.hr.profile.common.dto.EducationDto();
		try {
			//Authentication from federation
			String accessToken = clientAuth.getAccessToken();		
			//API call
			educationList = apiClient.getSwoopEducationData(accessToken, sso);
		} catch (Exception e) {
			e.getMessage();
		}
		return educationList;
	}
/*	@RequestMapping(value = "people/{sso}/ssoauth")
	public String ssoauthValidation(Model model, @PathVariable Long sso,
			@RequestParam("password") String password, HttpServletRequest request,HttpServletResponse response,HttpSession session) {
		String host = request.getHeader("Host");
		int statusCode=0;
		System.out.println("inside the ssoauthValidation controller");
		try {
			host = request.getRequestURL().toString();
			//System.out.println(request.getRequestURL());
			String authString = sso + ":" + password;
			String authEncBytes = Base64.encode(authString.getBytes());
			String basicAuth = "Basic " + authEncBytes;


			URL url = new URL(host);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestProperty("Authorization", basicAuth);		
			connection.setRequestProperty("Cookie","SMCHALLENGE=YES");
			InputStream inputStream = connection.getInputStream();
			statusCode = connection.getResponseCode();
			

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		if(statusCode==200){
			return ("redirect:/people/" + sso);
		} else {
			session.invalidate();
			handleLogOutResponseCookie(request,response);
			return "basic-auth-error";
			
			
		}		
	}
	private void handleLogOutResponseCookie(HttpServletRequest request, HttpServletResponse response) {
        
		
		Cookie myCookie = new Cookie("SMSESSION", "");
		myCookie.setMaxAge(0);
		myCookie.setPath("/");
		response.addCookie(myCookie);
		
		Cookie myCookie1 = new Cookie("JSESSIONID", "");
		myCookie1.setMaxAge(0);
		myCookie1.setPath("/");
		response.addCookie(myCookie1);
    }*/
	
	@RequestMapping(value = "better-browser")
	public String betterBrowser(Model model) {
		return "better-browser";
	}
	
	public void setErrorToDto(AbstractBaseDtoSupport baseDto) {
		baseDto.setSuccess(false);
		baseDto.setErrorMesage(messageSource.getMessage(
				"errors.internal.error", null, "Internal error", null));
	}

	public ProfileAuthorityEvaluator getAuthEvaluator() {
		return authEvaluator;
	}

	public void setAuthEvaluator(ProfileAuthorityEvaluator authEvaluator) {
		this.authEvaluator = authEvaluator;
	}

	public EmployeeProfileService getPersonalInfoService() {
		return personalInfoService;
	}

	public void setPersonalInfoService(
			EmployeeProfileService personalInfoService) {
		this.personalInfoService = personalInfoService;
	}

	public WorkAssignmentService getWorkAssignmentService() {
		return workAssignmentService;
	}

	public void setWorkAssignmentService(
			WorkAssignmentService workAssignmentService) {
		this.workAssignmentService = workAssignmentService;
	}

	public PersonalCVService getPersonalCVService() {
		return personalCVService;
	}

	public void setPersonalCVService(PersonalCVService personalCVService) {
		this.personalCVService = personalCVService;
	}

	public PerformanceService getPerformanceService() {
		return performanceService;
	}

	public void setPerformanceService(PerformanceService performanceService) {
		this.performanceService = performanceService;
	}

	public CompensationService getCompensationService() {
		return compensationService;
	}

	public void setCompensationService(CompensationService compensationService) {
		this.compensationService = compensationService;
	}

	public PropertyDao getPropertyDao() {
		return propertyDao;
	}

	public void setPropertyDao(PropertyDao propertyDao) {
		this.propertyDao = propertyDao;
	}
	
	public OptinSharingService getOptinSharingService() {
		return optinSharingService;
	}

	public void setOptinSharingService(OptinSharingService optinSharingService) {
		this.optinSharingService = optinSharingService;
	}

	public ReloadableResourceBundleMessageSource getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(ReloadableResourceBundleMessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public EmployeeHistoryService getEmployeeHistoryService() {
		return employeeHistoryService;
	}

	public void setEmployeeHistoryService(
			EmployeeHistoryService employeeHistoryService) {
		this.employeeHistoryService = employeeHistoryService;
	}

	/*public SensitiveDataPopupMail getSensitiveDataPopupMail() {
		return sensitiveDataPopupMail;
	}

	public void setSensitiveDataPopupMail(
			SensitiveDataPopupMail sensitiveDataPopupMail) {
		this.sensitiveDataPopupMail = sensitiveDataPopupMail;
	}*/

	public List<ShortProfileList> getPersistedSearchResults() {
		return persistedSearchResults;
	}

	public void setPersistedSearchResults(
			List<ShortProfileList> persistedSearchResults) {
		this.persistedSearchResults = persistedSearchResults;
	}

	public InterestAffiliationService getInterestService() {
		return interestService;
	}

	public void setInterestService(InterestAffiliationService interestService) {
		this.interestService = interestService;
	}

	public SearchService getSearchService() {
		return searchService;
	}

	public void setSearchService(SearchService searchService) {
		this.searchService = searchService;
	}
	
}