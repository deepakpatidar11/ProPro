/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.web.controller.argumentresolvers;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.mobile.device.mvc.DeviceWebArgumentResolver;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.support.WebArgumentResolver;
import org.springframework.web.servlet.mvc.annotation.AnnotationMethodHandlerAdapter;

@Component
public class CustomWebArgumentResolverInstaller {
    @Autowired
    public CustomWebArgumentResolverInstaller(AnnotationMethodHandlerAdapter controllerInvoker) {
        //WebArgumentResolver[] resolvers = new WebArgumentResolver[1];
        //resolvers[0] = new DeviceWebArgumentResolver();
        //controllerInvoker.setCustomArgumentResolvers(resolvers);
    }
}