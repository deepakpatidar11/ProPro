/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
/**
 * 
 */
package com.ge.corporate.hr.profile.employee.service.task;


import java.io.Serializable;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.wicket.util.lang.WicketObjects;
import org.springframework.mail.MailException;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;

import com.ge.corporate.hr.profile.auth.model.ProfileAuthority;
import com.ge.corporate.hr.profile.auth.model.User;
import com.ge.corporate.hr.profile.common.cache.CacheFactory;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dao.CompensationDao;
import com.ge.corporate.hr.profile.employee.dao.EmergencyContactDao;
import com.ge.corporate.hr.profile.employee.dao.EmployeeDao;
import com.ge.corporate.hr.profile.employee.dao.PerformanceDao;
import com.ge.corporate.hr.profile.employee.dao.ScheduledDao;
import com.ge.corporate.hr.profile.employee.dao.SearchDao;
import com.ge.corporate.hr.profile.employee.dao.WorkAssignmentDao;
import com.ge.corporate.hr.profile.employee.model.Person;


/** 
 * @author francisco.blanco
 *
 */

public class CacheWarmUpTaskImpl implements CacheWarmUpTask, Runnable{
	
	private final Log logger = LogFactory.getLog(CacheWarmUpTaskImpl.class);
	
	private static final String CACHE_WARMUP_TYPE = "CWUP";
	private static final String CACHE_WARMUP_LOGGER_LEVEL = "INFO";
	private static final String DEFAULT_SYSTEM_LOGGER_LEVEL = "INFO";
	
	private static final long MEGABYTE = 1024L * 1024L;
	
	private static Long globalObjectSize = 0L;
	
	@Resource(name="scheduledDao")
	private ScheduledDao scheduledDao;
	@Resource(name="workAssignmentDao")
	private WorkAssignmentDao workAssignmentDao;
	@Resource(name="employeeDao")
	private EmployeeDao employeeDao;
	@Resource(name = "emergencyContactDao")
	private EmergencyContactDao emergencyContactDao;
	@Resource(name="performanceDao")
	private PerformanceDao performanceDao;
	@Resource(name="compensationDao")
	private CompensationDao compensationDao;
	@Resource(name = "searchDao")
	private SearchDao searchDao;
	@Resource(name="dynamicCacheFactorySelector")
	private CacheFactory genericCacheFactory;
	@Resource(name="mailSender")	
	private MailSender mailSender;
	@Resource(name="templateMessageCaheWarmUp")
    private SimpleMailMessage templateMessage;
	
	private CacheFactory cacheFactory;
	
	private int subLevelsCount;
	private int employeeCount = 0;
	private int subLevelsToRun; 
	private boolean enabled = true;
	private String mailTo =  null;
	private boolean mailEnabled = false;
	
	private int debugSubLevelsCount=0;
	private int debugMaxLevels=0;
	private int debugEmployeeCount=0;
	
	private int[] debugLevelCounter = new int[30];
	
	
	private Date lastEndDate = null;

	
	public boolean isMailEnabled() {
		return mailEnabled;
	}

	public void setMailEnabled(boolean mailEnabled) {
		this.mailEnabled = mailEnabled;
	}

	public void setMailTo(String mailTo) {
		this.mailTo = mailTo;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public int getSubLevelsToRun() {
		return subLevelsToRun;
	}

	public void setSubLevelsToRun(int subLevelsToRun) {
		this.subLevelsToRun = subLevelsToRun;
	}
	
	public ScheduledDao getScheduledDao() {
		return scheduledDao;
	}

	public int getCachedEmployeeCount()
	{
	return employeeCount;
	}
	public void setScheduledDao(ScheduledDao scheduledDao) {
		this.scheduledDao = scheduledDao;
	}
	
	public void setGenericCacheFactory(CacheFactory genericCacheFactory) {
		this.genericCacheFactory = genericCacheFactory;
	}

	public EmergencyContactDao getEmergencyContactDao() {
		return emergencyContactDao;
	}

	public void setEmergencyContactDao(EmergencyContactDao emergencyContactDao) {
		this.emergencyContactDao = emergencyContactDao;
	}
	
	public CacheFactory getCacheFactory(){
		CacheFactory avaliableCacheFactory = null;
		try{	
			avaliableCacheFactory = genericCacheFactory;
		}catch(Exception e){
			logger.error("Unable to get cache support");
		}
		return avaliableCacheFactory;	
	}
	
	public WorkAssignmentDao getWorkAssignmentDao() {
		return workAssignmentDao;
	}

	public void setWorkAssignmentDao(WorkAssignmentDao workAssignmentDao) {
		this.workAssignmentDao = workAssignmentDao;
	}

	public EmployeeDao getEmployeeDao() {
		return employeeDao;
	}

	public void setEmployeeDao(EmployeeDao employeeDao) {
		this.employeeDao = employeeDao;
	}

	public PerformanceDao getPerformanceDao() {
		return performanceDao;
	}

	public void setPerformanceDao(PerformanceDao performanceDao) {
		this.performanceDao = performanceDao;
	}
	
	public CompensationDao getCompensationDao() {
		return compensationDao;
	}

	public void setCompensationDao(CompensationDao compensationDao) {
		this.compensationDao = compensationDao;
	}	
		
	public MailSender getMailSender() {
		return mailSender;
	}

	public void setMailSender(MailSender mailSender) {
		this.mailSender = mailSender;
	}

	public SimpleMailMessage getTemplateMessage() {
		return templateMessage;
	}

	public void setTemplateMessage(SimpleMailMessage templateMessage) {
		this.templateMessage = templateMessage;
	}

	/**
	 * Validates if Load process has finished. If it has, 
	 * then it flags the scheduled record indicating that the warm-up process has began
	 * in order to prevent potential concurrent warm-ups to happen when ran in cluster environments
	 */
	public void executeScheduledCacheWarmUp() {
		
		if(isEnabled()){
			logger.info("Validating Cache Warmup " + new Date(System.currentTimeMillis()));
			
			//Get date of last batch job run, and batch job should have finished.
			
			Date dateEnd =  scheduledDao.getEndDateByType(CACHE_WARMUP_TYPE);
		
			if( (dateEnd!= null && lastEndDate == null ) || (dateEnd!= null && lastEndDate!= null && lastEndDate.compareTo(dateEnd) < 0)  ){		
				//Record Last end date
				lastEndDate = dateEnd;				
				authenticate();
				executeCacheWarmUp();
				
			}else{
				logger.info("Cache Warmup was not be executed "  + new Date(System.currentTimeMillis()));
			}
		}else{
			logger.info("Cache Warmup via scheduler was not executed because is dissabled :"  + new Date(System.currentTimeMillis()));
		}		
	}
	
	private void authenticate(){
		User principal = new User();			
		Object credentials = new Object();
		Collection<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		authorities.add( new ProfileAuthority("ROLE_SA"));		
		Authentication auth = new PreAuthenticatedAuthenticationToken( principal, credentials, authorities);		
		SecurityContextHolder.getContext().setAuthentication(auth);		
	}
	/**
	 * 
	 */
	public synchronized  void executeCacheWarmUp(){
		Runtime runtime = Runtime.getRuntime();
		
		try {				
				
			String currentLoggerLevel = getLoggerLevel();
			setLoggerLevel(CACHE_WARMUP_LOGGER_LEVEL);
			//Clear Cache
			clearCache();
			
			//Invokes Garbage Collector
			runtime.gc();
			Thread.sleep(5000);
			
			logger.info("Starting Cache Warmup " + new Date(System.currentTimeMillis()));
			//Getting free Memory
			long freeMemory = runtime.freeMemory();			
			logger.info("Free Memory Before Starting Cache WarmUp:" + bytesToMegabytes(freeMemory));
			
			
			sendNotificationMail("Host: "+ InetAddress.getLocalHost().getHostName() +"\n"+
								 "Status: Starting Cache Warmup");
			//Execute Cache WarmUp
			crawlEmployeeInformation(employeeDao.getHighAutoritySupervisorHierarchy().getSso());
			
			//Load Advanced Search Catalogs
			loadCatalogs();
			
			sendNotificationMail("Host: "+ InetAddress.getLocalHost().getHostName() +"\n"+
								 "Status: Cache warm up Finished properly\n" + 
								 "Levels: " + subLevelsToRun +"\n"+
								 "Employees loaded: " + employeeCount);
			
			//Invokes Garbage Collector
			runtime.gc();
			Thread.sleep(5000);
			
			logger.info("Free Memory After Cache WarmUp:" + bytesToMegabytes(runtime.freeMemory()));
			logger.info("Memory Used By Cache WarmUp:" + bytesToMegabytes(freeMemory - runtime.freeMemory()));
			
			logger.info("Finishing Cache warm up at "+ new Date(System.currentTimeMillis()));
			
			//Restore the log Level
			if(currentLoggerLevel == null){
				currentLoggerLevel = DEFAULT_SYSTEM_LOGGER_LEVEL;
			}
			//
			logMesurements("Total Memory Size:"+ globalObjectSize);
			
			setLoggerLevel(currentLoggerLevel);			
				
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
	
	private void loadCatalogs(){
		
		searchDao.getIfgList();
		searchDao.getBusinessList();
		searchDao.getFunctionList();
		searchDao.getRegionList();
		searchDao.getCountryList();
		searchDao.getDisciplineList();
		searchDao.getLeadershipProgramList();
		searchDao.getBandList();
		searchDao.getRolesWithClientSearchAccess();
		
		logger.info("Search Catalogs Loaded Successfully");
	}
	
	
	/**
	 * 	
	 * @throws Exception
	 */
	public void clearCache() throws Exception{
		if(cacheFactory == null){
			cacheFactory = getCacheFactory();
		}				
		cacheFactory.clearCache();
		logger.debug("Cache Cleared for:" + cacheFactory);
	}
	/**
	 * 
	 * @param startWithSso
	 */
	@PreAuthorize("hasRole('ROLE_SA')")
 	private void crawlEmployeeInformation(long startWithSso) {
				
		employeeCount = 0;
		subLevelsCount = 1;
		
		//Instrumenting
		WicketObjects.setObjectSizeOfStrategy( new WicketObjects.SerializingObjectSizeOfStrategy() );
		Long totalSize = 0L;
		logger.info("Strats with sso: " + startWithSso);
		loadData(startWithSso);
		
		if (subLevelsCount < subLevelsToRun){			
	 		BaseModelCollection<Person> lstEmployee = getDirectReportLstByManager(startWithSso);
	 		
	 		totalSize += getElementSize(lstEmployee);
	 		
	 		if (!lstEmployee.isEmpty()  ) {
				getSubLevelInformation(lstEmployee);
			} 		
		}
		globalObjectSize += totalSize; 
		
		logMesurements("TopLevel Direct Reports Size:" +  totalSize );
		logger.debug("=========Employees Loaded: " +  employeeCount );
	}

 	/**
 	 * 
 	 * @param lstEmployee
 	 */
	private void getSubLevelInformation(BaseModelCollection<Person> lstEmployee) {		
		subLevelsCount ++;
		for (Person employee : lstEmployee.getList()) {
			Long currentDRSize = 0L;
			
			loadData(employee.getSso());	
			if (subLevelsCount < subLevelsToRun){	
				BaseModelCollection<Person> lstSubEmployee = getDirectReportLstByManager(employee.getSso());
				
				//this is just for logging
				if(subLevelsCount == 2){
					logger.info("loading employees that reports to: " + employee.getSso());
				}
				//
				currentDRSize += getElementSize(lstSubEmployee);
				
				if (!lstSubEmployee.isEmpty()) {
					getSubLevelInformation(lstSubEmployee);
				}
				
				logMesurements("Size for " + employee.getSso() + " Direct Reports:" + currentDRSize);
				globalObjectSize += currentDRSize;
			}						
		}
		subLevelsCount --;
	}
	
	private void loadData(Long sso){
		try{
			//Instrumenting
			Long totalSize = 0L;
			
			//Loads information from the first load (home page : profile and assginment data)
			totalSize += getElementSize( employeeDao.getEmployeeBySso(sso) );
			totalSize += getElementSize( emergencyContactDao.getEmergencyContactBySso(sso));
			totalSize += getElementSize( workAssignmentDao.getCurrentWorkAssignmentBySso(sso));
			totalSize += getElementSize( workAssignmentDao.getCurrentWorkAssignmentRestrictedBySso(sso));
			totalSize += getElementSize( compensationDao.getCurrentCompensationBySso(sso));
			totalSize += getElementSize( performanceDao.getPerformanceBySso(sso));
			totalSize += getElementSize( employeeDao.getDottedLineManagerBySso(sso));
			totalSize += getElementSize( workAssignmentDao.getMonthsInPositionBySso(sso));			
			totalSize += getElementSize( workAssignmentDao.getCurrentLocalBandBySso(sso));
			totalSize += getElementSize( workAssignmentDao.getCurrentCostCenterBySso(sso));	
			
			logMesurements("Memory size for employee " + sso +":" + totalSize);
			
			globalObjectSize += totalSize;
			
			employeeCount++;
		}catch(Exception e){
			logger.info("Exception ocurred when cache warmup loaded information for sso: " + sso );
			logger.error("Exception ocurred when cache warmup loaded information for sso: " + sso );		
		}
		
	} 

	/****
	 * 
	 * @param sso
	 * @return
	 */
	private BaseModelCollection<Person> getDirectReportLstByManager(long sso) {	
		return employeeDao.getDirectReportsListByManger(sso);
	}
	
	
	public void debugNavigateLevels(){
		debugSubLevelsCount = 1;
		debugMaxLevels = 1;
		debugEmployeeCount = 1;		
		for(int j =0; j < 30; j++){
			debugLevelCounter[j] = 0;
		}				
		debugLevelCounter[1] = 1;	
		
		Long startWithSso = employeeDao.getHighAutoritySupervisorHierarchy().getSso();
		BaseModelCollection<Person> lstEmployee = getDirectReportLstByManager(startWithSso); 		
 		if (!lstEmployee.isEmpty()  ) {
 			navigateSubLevels(lstEmployee);
		} 		
 		
 		logger.debug("Employees Loaded: " +  debugEmployeeCount);	
 		
 		logger.debug("Printing count for level:"); 
 		for(int j =0; j < 30; j++){
 			logger.debug("count for level ["+ j +"]:" + debugLevelCounter[j]);
 		}
 		
 		logger.debug("The Count of Employes for level has been finished");
 		
	}
	
	public void navigateSubLevels(BaseModelCollection<Person> lstEmployee){
		debugSubLevelsCount++;
		if(debugSubLevelsCount > debugMaxLevels){
			debugMaxLevels = debugSubLevelsCount;
		}
		for (Person employee : lstEmployee.getList()) {	
			debugEmployeeCount++;
			
			if(debugSubLevelsCount == 2){
				logger.debug("One Employee of level 2 has been loaded");
			}
			
			if(debugEmployeeCount< 30){
				debugLevelCounter[debugSubLevelsCount]++;
			}
			
			if (subLevelsCount < subLevelsToRun){	
				BaseModelCollection<Person> lstSubEmployee = getDirectReportLstByManager(employee.getSso());
				if (!lstSubEmployee.isEmpty()) {
					navigateSubLevels(lstSubEmployee);
				}
			}						
		}
		debugSubLevelsCount--;
	}
	
	
	public void sendNotificationMail(String acctionMsg) throws Exception{
		
		if(isMailEnabled()){		
			if(!(this.templateMessage.getSubject().contains(InetAddress.getLocalHost().getHostName()))){
				this.templateMessage.setSubject(this.templateMessage.getSubject()+ " - " +InetAddress.getLocalHost().getHostName());
			}
			
			SimpleMailMessage msg = new SimpleMailMessage(this.templateMessage);			
	        msg.setTo(mailTo);
	        msg.setText(acctionMsg);	            
	        try{
	            this.mailSender.send(msg);
	        }
	        catch(MailException ex) {
	            System.err.println(ex.getMessage());            
	        }
		}
	}
	/**
	 * 
	 * @param cLevel
	 */
	private void setLoggerLevel(String cLevel){
		//TODO: Consider Moving this functionality to a specialized Util.
		Level level = Level.toLevel(cLevel);				
		//Clear Cache previous to run cache warm up
		
		//Change the logger to ERROR, in order to avoid full the disk with logs				
		System.setProperty("geware.log.level", cLevel);				
		Logger.getLogger("com.ge.corporate.hr").setLevel(level);
		
	}
	/**
	 * 
	 * @return
	 */
	private String getLoggerLevel(){
		//TODO: Consider Moving this functionality to a specialized Util.
		return System.getProperty("geware.log.level");
	}
	
	/**
	 * If system property enableCacheSizeMesurement is set to true, then the warmup will log memory size mesurements.
	 * 
	 * @param element
	 * @return
	 */
	private Long getElementSize(Serializable element){
		Long size = 0L;
		if(System.getProperty("enableCacheSizeMesurement")!= null && System.getProperty("enableCacheSizeMesurement").equals("true")){
			size += WicketObjects.sizeof(element);
		}
		
		return size;
	}
	/**
	 * If system property enableCacheSizeMesurement is set to true, then the warm-up will log memory size mesurements.
	 * 
	 * @param message
	 */
	private void logMesurements(final String message){
		if(System.getProperty("enableCacheSizeMesurement")!= null && System.getProperty("enableCacheSizeMesurement").equals("true")){
			logger.info(message);
		}
	}
	
	public static long bytesToMegabytes(long bytes) {
		return bytes / MEGABYTE;
	}

	public void run() {		
		authenticate();
		executeCacheWarmUp();
	}
}
