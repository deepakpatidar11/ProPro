/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dto.AutoCompleteDto;
import com.ge.corporate.hr.profile.employee.dto.EmployeeExpertiseDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneEducationDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneEmpHistoryDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneLeadershipDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneSearchCompDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneTrainingDto;
import com.ge.corporate.hr.profile.employee.dto.PersonalInfoDto;
import com.ge.corporate.hr.profile.employee.dto.SearchAdvancedDto;
import com.ge.corporate.hr.profile.employee.dto.SearchCompListDto;
import com.ge.corporate.hr.profile.employee.dto.SearchLuceneDto;
import com.ge.corporate.hr.profile.employee.dto.StringCatalogDto;
import com.ge.corporate.hr.profile.employee.model.AffinityGroups;
import com.ge.corporate.hr.profile.employee.model.CustomerandSuppliers;
import com.ge.corporate.hr.profile.employee.model.EmployeeExpertise;
import com.ge.corporate.hr.profile.employee.model.Expertise;
import com.ge.corporate.hr.profile.employee.model.IntiativesandProject;
import com.ge.corporate.hr.profile.employee.model.LPBridgeAssignment;
import com.ge.corporate.hr.profile.employee.model.LanguageProficiency;
import com.ge.corporate.hr.profile.employee.model.Mentoring;
import com.ge.corporate.hr.profile.employee.model.MentoringInterest;
import com.ge.corporate.hr.profile.employee.model.WorkMobilityCountry;

public interface SearchService extends Serializable{
	
	public PersonalInfoDto searchEmployee(String key);
	public AutoCompleteDto searchEmployeeByParam(AutoCompleteDto autoCompletDto);
	public AutoCompleteDto searchEmployeeByParam(AutoCompleteDto autoCompletDto, boolean labelSsoAndName);
	public SearchCompListDto searchEmployeeListByParam(SearchCompListDto searchListDto); 
	public StringCatalogDto getBusinessCatalog();
	public StringCatalogDto getSubBusinessCatalog(StringCatalogDto catalogDto);
	public StringCatalogDto getBandCatalog();
	public StringCatalogDto getFunctionCatalog();
	public StringCatalogDto getRegionCatalog();
	public StringCatalogDto getCountryCatalog();
	public Map<String, String> getCountryCodeMap();
	public StringCatalogDto getCountryRegionCatalog(StringCatalogDto catalogDto);
	public StringCatalogDto getJobFamilyCatalog(StringCatalogDto catalogDto);
	public StringCatalogDto getLeadershipProgramCatalog();
	public StringCatalogDto getIfgCatalog();
	public SearchAdvancedDto searchEmployeeAdvanced(SearchAdvancedDto searchListDto);	
	public void cleanDto(SearchAdvancedDto searchListDto);	
	public List<LuceneSearchCompDto> loadEmployeeService();
	public List<Long> getAllSso();
	public Map<Long, List<LuceneEducationDto>> getEducationData();
	public Map<Long, List<LuceneEmpHistoryDto>> getWorkHistoryData();
	public Map<Long, List<LuceneTrainingDto>> getTrainingData();
	public Map<Long, List<LuceneLeadershipDto>> getLeadershipData();
	public List<String> getACLRoles(Long sso);
	public boolean hasACLRoles(Long sso);
	public boolean hasExportSearchAccess(Long sso);
	
	public String createTypeAheadQuery(String param);
	public Map<String, String> createParentQuery(SearchLuceneDto searchDto, boolean clientSearch, boolean clientSearchAll);
	public Map<String, String> createConnectionsQuery(Long sso, SearchLuceneDto searchDto, boolean facetConnect, Map<String, String> paramWeightage);
	public Map<String, String> createMentoConnectionQuery(Long sso, SearchLuceneDto searchDto, boolean facetConnect, Map<String, String> paramWeightage);
	public String createLeadershipQuery(SearchLuceneDto searchDto);
	public String getResultsLabel(int total, String string);
	public StringCatalogDto getTechnicalDiscipline();
	public StringCatalogDto getReportingIfgCatalog();
	public StringCatalogDto getReportingBusinessCatalog();
	public StringCatalogDto getLanguageList();
	public Map<Long, List<IntiativesandProject>> getInitiativeProjectData();
	public Map<Long, List<CustomerandSuppliers>> getCustomersAndSuppliersData();
	public Map<Long, List<LanguageProficiency>> getLanguagesData();
	public Map<Long, List<AffinityGroups>> getExternalAffiliationsData();
	public Map<Long, List<WorkMobilityCountry>> getWorkMobilityData();
	public StringCatalogDto getAssignmentLeaderFor();
	public StringCatalogDto getAssignmentSubBusiness();
	public Map<Long, List<LPBridgeAssignment>> getLPBridgeData();
	BaseModelCollection<Long> getAllConnections(Long sso);
	public Map<Long, List<EmployeeExpertise>> getEmpExpertiseData();
	public BaseModelCollection<Expertise> getAllExpertise();
	public EmployeeExpertiseDto getExpertiseByParams(int offset, String status, String date, String expName, boolean isExcelDownload);
	public boolean updateExpertiseTaxo(List<Expertise> expertise);
	public BaseModelCollection<Long> getAllMentors(Long sso);
	public BaseModelCollection<Long> getAllMentees(Long sso);
	public BaseModelCollection<MentoringInterest> getMentoringInterest();
	public Map<Long, List<Mentoring>> getEmpMentoringInterestData();
	public void insertSearchMetrics(PersonalInfoDto personInfo, SearchLuceneDto searchDto, boolean hasClientSearch, String userAgent);
}
