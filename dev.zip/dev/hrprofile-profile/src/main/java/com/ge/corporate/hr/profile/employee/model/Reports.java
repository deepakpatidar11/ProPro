package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="person")
@XmlAccessorType(XmlAccessType.FIELD)
public class Reports extends AbstractBaseModelSupport{
	
	private static final long serialVersionUID = 46981221793287345L;
	
	@XmlAttribute(name="sso")
	private Long sso; //SSO Id
	
	@XmlElement(name="firstName")
	private String firstName;

	@XmlElement(name="lastName")
	private String lastName;

	@XmlElement(name="email")	
	private String email;
	
	@XmlElement(name="positionTitle")	
	private String positionTitle;
	
	@XmlElement(name="fnction")	
	private String fnction;
	
	@XmlElement(name="business")	
	private String business;
	
	@XmlElement(name="subBusiness")	
	private String subBusiness;
	
	@XmlElement(name="vendor")	
	private String vendor;
	
	@XmlElement(name="program")	
	private String program;
	
	public String getProgram() {
		return program;
	}

	public void setProgram(String program) {
		this.program = program;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getSubBusiness() {
		return subBusiness;
	}
    
	public String getFnction() {
		return fnction;
	}

	public void setFnction(String fnction) {
		this.fnction = fnction;
	}

	public String getBusiness() {
		return business;
	}

	public void setBusiness(String business) {
		this.business = business;
	}

	public void setSubBusiness(String subBusiness) {
		this.subBusiness = subBusiness;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
		
	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	
	public void setPositionTitle(String positionTitle) {
		this.positionTitle = positionTitle;
	}
	public String getPositionTitle() {
		return positionTitle;
	}


}
