/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import java.util.List;
import java.util.Locale;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.MyCWPopulation;

public class MyCWPopulationDto extends AbstractBaseDtoSupport{

	/**
	 *Default serial ID 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 *Employee SSO
	 */
	
	private Long sso;
	
	private int count;
	
	private double headcount;
	
	private int excelLimit;

	private String fullname;

	private List<String> role;
	
	private List<String> subpersontype;
	
	private List<String> columns;
	
	private Locale locale;
	
	private String format;

	/**
	 * My Clients Model
	 */
	private BaseModelCollection<MyCWPopulation> myCWPopulationList;

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}
		
	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}	

	public double getHeadcount() {
		return headcount;
	}
	
	public int getExcelLimit() {
		return excelLimit;
	}

	public void setExcelLimit(int excelLimit) {
		this.excelLimit = excelLimit;
	}

	public void setHeadcount(double headcount) {
		this.headcount = headcount;
	}
	
	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	
	public List<String> getRole() {
		return role;
	}

	public void setRole(List<String> role) {
		this.role = role;
	}

	public List<String> getColumns() {
		return columns;
	}

	public void setColumns(List<String> columns) {
		this.columns = columns;
	}
	
	public BaseModelCollection<MyCWPopulation> getMyCWPopulationList() {
		return myCWPopulationList;
	}

	public void setMyCWPopulationList(
			BaseModelCollection<MyCWPopulation> myCWPopulationList) {
		this.myCWPopulationList = myCWPopulationList;
	}

	public Locale getLocale() {
		return locale;
	}

	public void setLocale(Locale locale) {
		this.locale = locale;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}
	
	public List<String> getSubpersontype() {
		return subpersontype;
	}

	public void setSubpersontype(List<String> subpersontype) {
		this.subpersontype = subpersontype;
	}

	public long getId() {
		return sso != null ? sso.longValue() : 0;
	}
		
}
