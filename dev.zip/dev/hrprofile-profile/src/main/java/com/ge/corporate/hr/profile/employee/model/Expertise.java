package com.ge.corporate.hr.profile.employee.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;
@XmlRootElement(name="expertise")
@XmlAccessorType(XmlAccessType.FIELD)
public class Expertise extends AbstractBaseModelSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2311084175829277898L;

	public Expertise() {
		// TODO Auto-generated constructor stub
	}
	
	public Expertise(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	@XmlElement(name="id")
	private int id;
	
	@XmlElement(name="parentId")
	private int parentId;
	
	@XmlElement(name="parentName")
	private String parentName;
	
	@XmlElement(name="name")
	private String name;
	
	@XmlElement(name="approvedFlag")
	private String approvedFlag;
	
	@XmlElement(name="dateAdded")
	private Date dateAdded;
	
	@XmlElement(name="addedBy")
	private Long addedBy;
	
	@XmlElement(name="usedBy")
	private int usedBy;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getApprovedFlag() {
		return approvedFlag;
	}
	public void setApprovedFlag(String approvedFlag) {
		this.approvedFlag = approvedFlag;
	}
	public Date getDateAdded() {
		return dateAdded;
	}
	public void setDateAdded(Date dateAdded) {
		this.dateAdded = dateAdded;
	}
	public void setAddedBy(Long addedBy) {
		this.addedBy = addedBy;
	}
	public Long getAddedBy() {
		return addedBy;
	}
	public void setUsedBy(int usedBy) {
		this.usedBy = usedBy;
	}
	public int getUsedBy() {
		return usedBy;
	}
	public int getParentId() {
		return parentId;
	}
	public void setParentId(int parentId) {
		this.parentId = parentId;
	}
	public String getParentName() {
		return parentName;
	}
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
}
