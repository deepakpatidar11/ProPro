/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

//jaxb
@XmlRootElement(name="emergencyContact")
@XmlAccessorType(XmlAccessType.FIELD)
public class EmergencyContact extends AbstractBaseModelSupport{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4926107505218470071L;
	
	@XmlElement(name="sso")
	private Long sso;
	@XmlAttribute(name="id")
	private Long id;	
	@XmlElement(name="fullName")
	private String fullName;
	@XmlElement(name="address1")
	private String address1;
	@XmlElement(name="address2")
	private String address2;
	@XmlElement(name="address3")
	private String address3;
	@XmlElement(name="city")
	private String city;
	@XmlElement(name="state")
	private String state;
	@XmlElement(name="country")
	private String country;
	@XmlElement(name="zip")
	private String zip;
	@XmlElement(name="primaryPhone")
	private String primaryPhone;
	@XmlElement(name="secondaryPhone")
	private String secondaryPhone;
	@XmlElement(name="email")
	private String email;
	@XmlElement(name="typeDescription")
	private String typeDescription;
	
	@XmlElement(name="relationship")
	private String relationship;

	@XmlElement(name="ownFullName")
	private String ownFullName;
	@XmlElement(name="ownAddress1")
	private String ownAddress1;
	@XmlElement(name="ownAddress2")
	private String ownAddress2;
	@XmlElement(name="ownAddress3")
	private String ownAddress3;
	@XmlElement(name="ownCity")
	private String ownCity;
	@XmlElement(name="ownState")
	private String ownState;
	@XmlElement(name="ownCountry")
	private String ownCountry;
	@XmlElement(name="ownZip")
	private String ownZip;
	@XmlElement(name="ownPrimaryPhone")
	private String ownPrimaryPhone;
	@XmlElement(name="ownSecondaryPhone")
	private String ownSecondaryPhone;
	@XmlElement(name="ownTypeDescription")
	private String ownTypeDescription;
	
	
	public void setId(Long id) {
		this.id = id;
	}	
	public Long getId() {
		return id;
	}	
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getAddress3() {
		return address3;
	}
	public void setAddress3(String address3) {
		this.address3 = address3;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getPrimaryPhone() {
		return primaryPhone;
	}
	public void setPrimaryPhone(String primaryPhone) {
		this.primaryPhone = primaryPhone;
	}
	public String getSecondaryPhone() {
		return secondaryPhone;
	}
	public void setSecondaryPhone(String secondaryPhone) {
		this.secondaryPhone = secondaryPhone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTypeDescription() {
		return typeDescription;
	}
	public void setTypeDescription(String typeDescription) {
		this.typeDescription = typeDescription;
	}		
	public String getRelationship() {
		return relationship;
	}	
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	public String getOwnFullName() {
		return ownFullName;
	}
	public void setOwnFullName(String ownFullName) {
		this.ownFullName = ownFullName;
	}
	public String getOwnAddress1() {
		return ownAddress1;
	}
	public void setOwnAddress1(String ownAddress1) {
		this.ownAddress1 = ownAddress1;
	}
	public String getOwnAddress2() {
		return ownAddress2;
	}
	public void setOwnAddress2(String ownAddress2) {
		this.ownAddress2 = ownAddress2;
	}
	public String getOwnAddress3() {
		return ownAddress3;
	}
	public void setOwnAddress3(String ownAddress3) {
		this.ownAddress3 = ownAddress3;
	}
	public String getOwnCity() {
		return ownCity;
	}
	public void setOwnCity(String ownCity) {
		this.ownCity = ownCity;
	}
	public String getOwnState() {
		return ownState;
	}
	public void setOwnState(String ownState) {
		this.ownState = ownState;
	}
	public String getOwnCountry() {
		return ownCountry;
	}
	public void setOwnCountry(String ownCountry) {
		this.ownCountry = ownCountry;
	}
	public String getOwnZip() {
		return ownZip;
	}
	public void setOwnZip(String ownZip) {
		this.ownZip = ownZip;
	}
	public String getOwnPrimaryPhone() {
		return ownPrimaryPhone;
	}
	public void setOwnPrimaryPhone(String ownPrimaryPhone) {
		this.ownPrimaryPhone = ownPrimaryPhone;
	}
	public String getOwnSecondaryPhone() {
		return ownSecondaryPhone;
	}
	public void setOwnSecondaryPhone(String ownSecondaryPhone) {
		this.ownSecondaryPhone = ownSecondaryPhone;
	}
	public String getOwnTypeDescription() {
		return ownTypeDescription;
	}
	public void setOwnTypeDescription(String ownTypeDescription) {
		this.ownTypeDescription = ownTypeDescription;
	}
}
