/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

public class ShortProfileList extends AbstractBaseModelSupport implements Comparable<Object> {

		private static final long serialVersionUID = 6589771032250834506L;
		@XmlElement(name="sso")
		private Long sso;	
		@XmlElement(name="firstName")
		private String firstName;
		@XmlElement(name="lastName")
		private String lastName;
		@XmlElement(name="empName")
		private String empName;
		@XmlElement(name="empManagerName")
		private String empManagerName;		
		@XmlElement(name="empManagerSso")
		private Long empManagerSso;
		@XmlElement(name="business")
		private String business;
		@XmlElement(name="subBusiness")
		private String subBusiness;
		@XmlElement(name="organization")
		private String organization;	
		@XmlElement(name="function")		
		private String function;
		@XmlElement(name="ifg")
		private String ifg;
		@XmlElement(name="title")
		private String title;
		
		
		public String getSubBusiness() {
			return subBusiness;
		}
		public void setSubBusiness(String subBusiness) {
			this.subBusiness = subBusiness;
		}
		public Long getEmpManagerSso() {
			return empManagerSso;
		}
		public void setEmpManagerSso(Long empManagerSso) {
			this.empManagerSso = empManagerSso;
		}

		private Boolean compareBySso = false;
		
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}		
		public String getIfg() {
			return ifg;
		}
		public void setIfg(String ifg) {
			this.ifg = ifg;
		}
		public Boolean getCompareBySso() {
			return compareBySso;
		}
		public void setCompareBySso(Boolean compareBySso) {
			this.compareBySso = compareBySso;
		}
		public Long getSso() {
			return sso;
		}
		public void setSso(Long sso) {
			this.sso = sso;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}		
		public String getEmpName() {
			return empName;
		}
		public void setEmpName(String empName) {
			this.empName = empName;
		}
		public String getEmpManagerName() {
			return empManagerName;
		}
		public void setEmpManagerName(String empManagerName) {
			this.empManagerName = empManagerName;
		}
		public String getBusiness() {
			return business;
		}
		public void setBusiness(String business) {
			this.business = business;
		}		
		public String getOrganization() {
			return organization;
		}
		public void setOrganization(String organization) {
			this.organization = organization;
		}
		public String getFunction() {
			return function;
		}
		public void setFunction(String function) {
			this.function = function;
		}
		
		public int compareTo(Object o) {
			if(compareBySso){
				if(this.sso == ((ShortProfileList)o).sso){
					return 0;
				}else{
					if(this.sso < ((ShortProfileList)o).sso){
						return -1;
					}else{						
						return 1;
					}						
				}
			}else{
				if(((ShortProfileList)o).lastName.equals(this.lastName))
				{
					return  this.firstName.compareToIgnoreCase(((ShortProfileList)o).firstName);
				}else{					
					return this.lastName.compareToIgnoreCase(((ShortProfileList)o).lastName);
				}
			}
		}		
	}

