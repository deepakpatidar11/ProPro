/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.aspect;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.annotation.Order;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;

/**
 * 
 * Ensures All models loaded from the DB are marked as granted.
 * 
 * @author hector.nevarez
 *
 */
@Aspect
@Order(value=1)
public class GrantedModelAspect {
	
	private final Log logger = LogFactory.getLog(GrantedModelAspect.class);
	
	//
	@SuppressWarnings("unchecked")
	@AfterReturning(pointcut = "execution(* com.ge.corporate.hr.profile.employee.dao.*.*(..))",
			returning="retVal")
	public void setGrantedFlag(AbstractBaseModelSupport retVal){		
		// ...		
		// if retVal is instance of AbstractBaseModelSupport, then add Granted flag
		if(retVal != null){
			retVal.setGranted(true);
			
			try{
				if(retVal instanceof BaseModelCollection<?> 
					&& ! ((BaseModelCollection<AbstractBaseModelSupport>) retVal).isEmpty()){
					 for(AbstractBaseModelSupport model : ((BaseModelCollection<AbstractBaseModelSupport>) retVal).getList()){
							 model.setGranted(true);
					 }
				}
			}catch (Exception e) {
				logger.debug("Invalid Model type conversion: " + e.getMessage());
			}
		}		
	}
	
}
