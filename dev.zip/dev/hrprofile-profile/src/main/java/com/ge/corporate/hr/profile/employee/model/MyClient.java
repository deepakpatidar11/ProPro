/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="myClients")
@XmlAccessorType(XmlAccessType.FIELD)
public class MyClient extends AbstractBaseModelSupport{
	
	private static final long serialVersionUID = 46981221793287345L;
	
	@XmlAttribute(name="sso")
	private Long sso; //SSO Id
	
	@XmlElement(name="firstName")
	private String firstName;

	@XmlElement(name="lastName")
	private String lastName;
	
	@XmlElement(name="fullName")
	private String fullName;

	@XmlElement(name="positionTitle")	
	private String positionTitle;
	
	@XmlElement(name="business")
	private String business;
	
	@XmlElement(name="subBusiness")
	private String subBusiness;
	
	@XmlElement(name="org")	
	private String org;
	
	@XmlElement(name="function")	
	private String function;

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getPositionTitle() {
		return positionTitle;
	}

	public void setPositionTitle(String positionTitle) {
		this.positionTitle = positionTitle;
	}

	public String getBusiness() {
		return business;
	}

	public void setBusiness(String business) {
		this.business = business;
	}

	public String getSubBusiness() {
		return subBusiness;
	}

	public void setSubBusiness(String subBusiness) {
		this.subBusiness = subBusiness;
	}

	public String getOrg() {
		return org;
	}

	public void setOrg(String org) {
		this.org = org;
	}
	
	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}
	
}
