package com.ge.corporate.hr.profile.employee.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.security.access.prepost.PreAuthorize;

import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;
import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dao.mapper.LanguageProficicencyMapper;
import com.ge.corporate.hr.profile.employee.model.LanguageProficiency;
import com.ge.corporate.hr.profile.employee.service.cache.SearchKeyGenerator;

public class LanguageDaoImpl extends AbstractBaseDaoSupport implements LanguageDao {

	//@PreAuthorize("hasPermission(#sso, 'ResumeLanguageProficiencyView', read)")
	public BaseModelCollection<LanguageProficiency> getlanguageProficiencyList(Long sso) {
	
		BaseModelCollection<LanguageProficiency> languageproficicencyList = new BaseModelCollection<LanguageProficiency>();
		String query = this.getSql("getLanguageProficicency");		
		try{
			languageproficicencyList.setList(getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new LanguageProficicencyMapper()));
			logger.debug("languageproficicency data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("languageproficicency data not found");
		}
		
		return languageproficicencyList;
		
	}
	
	@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public List<String> getLanguageList() {
		List<String> languages = new ArrayList<String>();
		String query = this.getSql("getLanguageList");
		try{
			languages=getJdbcTemplate().queryForList(query, String.class);
			//languageproficicencyList.setList(getJdbcTemplate().query(query, new LanguageProficicencyMapper()));
			logger.debug("languageproficicency data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("languageproficicency data not found");
		}
		return languages;
	}

	@PreAuthorize("hasPermission(#sso, 'ResumeLanguageProficiencyEdit', read)")
	public boolean addLanguages(Long sso, ArrayList<Map<String, String>> langProfList) {
		boolean success = true;
		String query = this.getSql("addlanguages");	
		try{
			for(Map<String,String> language : langProfList){
				getJdbcTemplate().update(query,new Object[]{sso, language.get("language"), language.get("level")});
			}
		}
		catch (Exception e) {
			success = false;
			logger.debug("Language Proficicency data not updated for: "+sso);
		}
		return success;	
	}

	@PreAuthorize("hasPermission(#sso, 'ResumeLanguageProficiencyEdit', read)")
	public boolean deleteLanguages(Long sso, ArrayList<Map<String, String>> langProfList){
		boolean success = true;
		String query = this.getSql("deleteLanguages");	
		try{
			for(Map<String,String> language : langProfList){
				getJdbcTemplate().update(query,new Object[]{sso, language.get("language")});
			}
		}
		catch (Exception e) {
			success = false;
			logger.debug("Language Proficicency data not updated for: "+sso);
		}
		return success;	
	}

	@PreAuthorize("hasPermission(#sso, 'ResumeLanguageProficiencyEdit', read)")
	public boolean updateLanguages(Long sso, ArrayList<Map<String, String>> langProfList) {
		boolean success = true;
		String query = this.getSql("updateLanguageLevel");
		try{
			for(Map<String,String> language : langProfList){
				getJdbcTemplate().update(query,new Object[]{language.get("level"), sso, language.get("language")});
			}
		}
		catch (Exception e) {
			success = false;
			logger.debug("Language Proficicency data not updated for: "+sso);
		}
		return success;	
	}
	
	@PreAuthorize("hasPermission(#sso, 'ResumeLanguageProficiencyEdit', read)")
	public boolean setLanguageProficieny(Long sso, ArrayList<Map<String, String>> langProfList){
		boolean success = true;
		String query1 = this.getSql("deleteAllLanguages");
		String query2 = this.getSql("addlanguages");
		try{
			getJdbcTemplate().update(query1,new Object[]{sso});
			for(Map<String,String> language : langProfList){			
				getJdbcTemplate().update(query2,new Object[]{sso, language.get("language"), language.get("level")});
			}
		}
		catch (Exception e) {
			success = false;
			logger.debug("Language Proficicency data not saved for: "+sso);
		}
		return success;	
	}
	
}
