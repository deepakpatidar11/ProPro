/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.Compensation;
/**
 * Compensation mapper
 * @author enrique.romero
 *
 */
public class CompensationMapper implements RowMapper<Compensation>{
	
	public static final String DATA_SALARY = "comp_eff_annual_salary";
	public static final String DATA_EFFECTIVE_DATE = "comp_eff_salary_change_date";
	public static final String DATA_CHANGE_AMOUNT = "comp_eff_salary_change_amnt";
	public static final String DATA_CHANGE_PERCENT = "comp_eff_salary_percent";
	public static final String DATA_CURRENCY = "comp_currency";
	public static final String DATA_IS_FUTURE_DATE = "is_future_date";
	public static final String DATA_LUMP_AMOUNT = "lump_amount";
	public static final String DATA_IS_LUMP = "is_lump";
	public static final String DATA_SLARY_REASON_CODE = "comp_salary_reason_code";
	public static final String DATA_MIN_SALARY = "comp_min_sal";
	public static final String DATA_MAX_SALARY = "comp_max_sal";
	
	
	public Compensation mapRow(ResultSet rs, int rowNum) throws SQLException {		
		Compensation compensation = new Compensation();		
		
		compensation.setSalary(rs.getLong(DATA_SALARY));	
		compensation.setEfectiveDate(rs.getDate(DATA_EFFECTIVE_DATE));
		compensation.setChangeAmount(rs.getDouble(DATA_CHANGE_AMOUNT));
		compensation.setChangePercent(rs.getDouble(DATA_CHANGE_PERCENT));
		compensation.setCurrency(rs.getString(DATA_CURRENCY));		
		compensation.setFutureDate(rs.getBoolean(DATA_IS_FUTURE_DATE));
		compensation.setLumpAmmount(rs.getDouble(DATA_LUMP_AMOUNT));
		compensation.setLump(rs.getBoolean(DATA_IS_LUMP));		
		compensation.setSalaryReasonCode(rs.getString(DATA_SLARY_REASON_CODE));
		compensation.setMaxSalary(rs.getString(DATA_MAX_SALARY));
		compensation.setMinSalary(rs.getString(DATA_MIN_SALARY));
		
		return compensation;		
	}
	

}
