package com.ge.corporate.hr.profile.employee.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="careerAspiration")
@XmlAccessorType(XmlAccessType.FIELD)
public class CareerAspiration implements Serializable{

	private static final long serialVersionUID = 1L;

	private Long sso;
	
	@XmlElement(name="goalShortTerm")
	private String goalShortTerm ;
	
	@XmlElement(name="goalLongTerm")
	private String goalLongTerm ;
	
	@XmlElement(name="optnTalentFlag")
	private String optnTalentFlag;
	
	@XmlElement(name="goalCombined")
	private String goalCombined;

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public String getGoalShortTerm() {
		return goalShortTerm;
	}

	public void setGoalShortTerm(String goalShortTerm) {
		this.goalShortTerm = goalShortTerm;
	}

	public String getGoalLongTerm() {
		return goalLongTerm;
	}

	public void setGoalLongTerm(String goalLongTerm) {
		this.goalLongTerm = goalLongTerm;
	}

	public String getOptnTalentFlag() {
		return optnTalentFlag;
	}

	public void setOptnTalentFlag(String optnTalentFlag) {
		this.optnTalentFlag = optnTalentFlag;
	}

	public String getGoalCombined() {
		return goalCombined;
	}

	public void setGoalCombined(String goalCombined) {
		this.goalCombined = goalCombined;
	}
	
	

}
