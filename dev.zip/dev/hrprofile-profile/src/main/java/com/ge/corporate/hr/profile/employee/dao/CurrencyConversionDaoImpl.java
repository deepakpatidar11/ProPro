/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;

import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;
import com.ge.corporate.hr.profile.employee.dao.mapper.CurrencyMapper;
import com.ge.corporate.hr.profile.employee.dto.CurrencyDto;
import com.ge.corporate.hr.profile.employee.model.Currency;
import com.ge.corporate.hr.profile.common.cache.MethodSignatureKeyGenerator;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;

public class CurrencyConversionDaoImpl extends AbstractBaseDaoSupport implements CurrencyConversionDao {
	
	@Cache(nodeName="/profile/employee/dao/currency", keyGeneratorClass = MethodSignatureKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	public Currency getCurrency(String currencyName, String currencyConverted) {
		Currency currency= null;
		
		String query = this.getSql("getCurrencyConversionRate");
		try{					
			currency = getJdbcTemplate().queryForObject(query, new Object[]{currencyName, currencyConverted}, new CurrencyMapper());
		}catch (EmptyResultDataAccessException eex) {			
			logger.error("Currency Not Found" + currencyName + " :" + currencyConverted);			
		}				
		return currency;
	}

	public void setCurrency(CurrencyDto currency) {
		String query = this.getSql("addCurrencyConversion");
		
		try{
			int result = getJdbcTemplate().update(query, new Object[]{
					currency.getFormerAmmount(), 
					currency.getConvertedCurrency(),currency.getConvertedAmmount(), 
					currency.getConvertedCurrency()
				 } );
		
			if(result < 1){
				logger.debug("No currencies were added");
			}
		}catch(DataAccessException de){
			logger.error("No currencies were added: "+de.getMessage());
		}
		
	}

	public void setCurrency(List<CurrencyDto> currencyList) {
		
		try{
			String query = getMultipleInsertionQuery(currencyList);
			Object[] params = getMultipleInsertionParams(currencyList);
			
			int result = getJdbcTemplate().update( query ,params );
		
			if(result < 1){
				logger.debug("No currencies were added");
			}
		}catch(DataAccessException de){
			logger.error("No currencies were added: "+de.getMessage());
		}
		
	}
	/**
	 * Generates Multiple Insert Query based on the list size
	 * @param currencyList
	 * @return
	 */
	private String getMultipleInsertionQuery(List<CurrencyDto> currencyList){
		String baseQuery 	= this.getSql("addCurrencyConversionList");
		String insertRowQuery 	= this.getSql("addCurrencyConversionListRows");
		
		StringBuilder insertRows = new StringBuilder(); 
		
		for(int cc = 0; cc < currencyList.size(); cc++){
			insertRows.append(insertRowQuery);
		}
		
		return  baseQuery.replace("[?]", insertRows.toString());
	}
	
	private Object[] getMultipleInsertionParams(List<CurrencyDto> currencyList){
		
		List<Object> insertionParams = new ArrayList<Object>();
		//(curr_ammount, curr_currency, curr_amount_converted, curr_currency_converted)
		for(CurrencyDto currency : currencyList){
			insertionParams.add(currency.getFormerAmmount());
			insertionParams.add(currency.getFormerCurrency());
			insertionParams.add(currency.getConvertedAmmount());
			insertionParams.add(currency.getConvertedCurrency());
		}
		
		return insertionParams.toArray();
	}
	
	
	public List<String> getAvaliableCurrencies(){
		
		String query = this.getSql("getAllAvailableCurrencies");
		List<String> currencyList = new ArrayList<String>();
		
		try{					
			currencyList = (List<String>) getJdbcTemplate().queryForList(query, String.class);
		}catch (EmptyResultDataAccessException eex) {			
			logger.error("No currenclies Found");			
		}				
		return currencyList;
	}
	
	public void clearConversionRatings() {
		
		try{
			String query = this.getSql("deleteCurrencyConversionRates");
			
			int result = getJdbcTemplate().update( query );
		
			if(result < 1){
				logger.debug("Currency Rates Cleared");
			}
		}catch(DataAccessException de){
			logger.error("Unable to clear currency rates"+de.getMessage());
		}
		
	}
	
	
	public void swapConversionRates(){
		
		String query = this.getSql("swapCurrencyConversionRates");
		
		try{
			int result = getJdbcTemplate().update(query );
		
			if(result < 1){
				logger.debug("Currency Table Values Enabled");
			}
		}catch(DataAccessException de){
			logger.error("Currency Table Values Swap failed");
		}
		
	}

}
