/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;

@XmlRootElement(name="personalInfo")
@XmlAccessorType(XmlAccessType.FIELD)
public class PersonalInfoDto extends AbstractBaseDtoSupport{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@XmlElement(name="sso")
	private Long sso;
	
	@XmlElement(name="fullName")
	private String fullName;

	@XmlElement(name="firtName")
	private String firstName;
	
	@XmlElement(name="lastName")
	private String lastName;
	
	@XmlElement(name="preferredName")
	private String preferredName;
	
	@XmlElement(name="title")
	private String title;
	
	@XmlElement(name="industrySegment")
	private String industrySegment;
	
	@XmlElement(name="bussinesSegment")
	private String bussinesSegment;
	
	@XmlElement(name="subBusiness")
	private String subBusiness;
	
	@XmlElement(name="function")
	private String function;
	
	@XmlElement(name="manager")
	private String manager;
	
	@XmlElement(name="hrManager")
	private String hrManager;
	
	@XmlElement(name="managerSso")
	private Long managerSso;
	
	@XmlElement(name="hrManagerSso")
	private Long hrManagerSso;
	
	@XmlElement(name="hrManagerEmail")
	private String hrManagerEmail;
	
	@XmlElement(name="band")
	private String band;
	
	@XmlElement(name="rating")
	private String rating;	
	
	@XmlElement(name="baseSalary")
	private Long baseSalary;
	
	@XmlElement(name="baseSalary")
	private String baseSalaryCurrency;
	
	@XmlElement(name="address1")
	private String address1;
	
	@XmlElement(name="address2")
	private String address2;
	
	@XmlElement(name="address3")
	private String address3;
	
	@XmlElement(name="city")
	private String city;
	
	@XmlElement(name="state")
	private String state;
	
	@XmlElement(name="zip")
	private String zip;
	
	@XmlElement(name="country")
	private String country;
	
	@XmlElement(name="region")
	private String region;
	
	@XmlElement(name="email")
	private String email;
	
	@XmlElement(name="phone")
	private String phone;
	
	@XmlElement(name="dcomm")
	private String dcomm;
	
	@XmlElement(name="cell")
	private String cell;
	
	@XmlElement(name="fax")
	private String fax;
	
	@XmlElement(name="mailstop")
	private String mailstop;
	
	@XmlElement(name="internalLocation")
	private String internalLocation;	
	
	@XmlElement(name="emergencyContactName")
	private String emergencyContactName;
	
	@XmlElement(name="emergencyContactRelationship")
	private String emergencyContactRelationship;
	
	@XmlElement(name="emergencyContactAddress")
	private String emergencyContactAddress;
	
	@XmlElement(name="emergencyContactCity")
	private String emergencyContactCity;
	
	@XmlElement(name="emergencyContactState")
	private String emergencyContactState;
	
	@XmlElement(name="emergencyContactZip")
	private String emergencyContactZip;
	
	@XmlElement(name="emergencyContactCountry")
	private String emergencyContactCountry;
	
	
	@XmlElement(name="emergencyContactPriPhone")
	private String emergencyContactPriPhone;
	
	@XmlElement(name="emergencyContactSecPhone")
	private String emergencyContactSecPhone;
	
	//own emergency contact
	@XmlElement(name="ownEmergencyContactName")
	private String ownEmergencyContactName;
		
	@XmlElement(name="ownEmergencyContactPriPhone")
	private String ownEmergencyContactPriPhone;
	
	@XmlElement(name="ownEmergencyContactSecPhone")
	private String ownEmergencyContactSecPhone;
	
	//Home address
	@XmlElement(name="homeAddrAddress")
	private String homeAddrAddress;
	
	@XmlElement(name="homeAddrCity")
	private String homeAddrCity;
	
	@XmlElement(name="homeAddrState")
	private String homeAddrState;
	
	@XmlElement(name="homeAddrZip")
	private String homeAddrZip;
	
	@XmlElement(name="homeAddrCountry")
	private String homeAddrCountry;
	
	@XmlElement(name="isAlstomEmployee")
	private boolean isAlstomEmployee;

	@XmlElement(name="assignmentStatus")
	private String assignmentStatus;
	
	@XmlElement(name="headcountValue")
	private String headcountValue;
	
	@XmlElement(name="professionalSummary")
	private String professionalSummary;
	
	@XmlElement(name="expertise")
	private String expertise;
	
	@XmlElement(name="payrollProcessorCode")
	private String payrollProcessorCode;
	
	@XmlElement(name="legalEntity")
	private String legalEntity;

	@XmlElement(name="hasEducation")
	private boolean hasEducation;

	@XmlElement(name="empType")
	private String empType;
	
	public String getMailstop() {
		return mailstop;
	}
	
	public void setMailstop(String mailstop) {
		this.mailstop = mailstop;
	}
	
	public String getInternalLocation() {
		return internalLocation;
	}
	
	public void setInternalLocation(String internalLocation) {
		this.internalLocation = internalLocation;
	}
	
	public boolean isAlstomEmployee() {
		return isAlstomEmployee;
	}
	
	public void setAlstomEmployee(boolean isAlstomEmployee) {
		this.isAlstomEmployee = isAlstomEmployee;
	}
	
	public String getHomeAddrAddress() {
		return homeAddrAddress;
	}

	public void setHomeAddrAddress(String homeAddrAddress) {
		this.homeAddrAddress = homeAddrAddress;
	}

	public String getHomeAddrCity() {
		return homeAddrCity;
	}

	public void setHomeAddrCity(String homeAddrCity) {
		this.homeAddrCity = homeAddrCity;
	}

	public String getHomeAddrState() {
		return homeAddrState;
	}

	public void setHomeAddrState(String homeAddrState) {
		this.homeAddrState = homeAddrState;
	}

	public String getHomeAddrZip() {
		return homeAddrZip;
	}

	public void setHomeAddrZip(String homeAddrZip) {
		this.homeAddrZip = homeAddrZip;
	}

	public String getHomeAddrCountry() {
		return homeAddrCountry;
	}

	public void setHomeAddrCountry(String homeAddrCountry) {
		this.homeAddrCountry = homeAddrCountry;
	}

	public long getId() {
		return (sso==null)?0:sso.longValue();
	}
			
	public void setSso(Long sso) {
		this.sso = sso;
	}	
	public Long getSso() {
		return sso;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getIndustrySegment() {
		return industrySegment;
	}
	public void setIndustrySegment(String industrySegment) {
		this.industrySegment = industrySegment;
	}
	public String getSubBusiness() {
		return subBusiness;
	}
	public void setSubBusiness(String subBusiness) {
		this.subBusiness = subBusiness;
	}
	public String getManager() {
		return manager;
	}
	public void setManager(String manager) {
		this.manager = manager;
	}
	public String getHrManager() {
		return hrManager;
	}
	public void setHrManager(String hrManager) {
		this.hrManager = hrManager;
	}
	public void setBussinesSegment(String bussinesSegment) {
		this.bussinesSegment = bussinesSegment;
	}
	public String getBussinesSegment() {
		return bussinesSegment;
	}
	public String getBand() {
		return band;
	}
	public void setBand(String band) {
		this.band = band;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public Long getBaseSalary() {
		return baseSalary;
	}
	public void setBaseSalary(Long baseSalary) {
		this.baseSalary = baseSalary;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getDcomm() {
		return dcomm;
	}
	public void setDcomm(String dcomm) {
		this.dcomm = dcomm;
	}
	public String getCell() {
		return cell;
	}
	public void setCell(String cell) {
		this.cell = cell;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getEmergencyContactName() {
		return emergencyContactName;
	}
	public void setEmergencyContactName(String emergencyContactName) {
		this.emergencyContactName = emergencyContactName;
	}
	public String getEmergencyContactAddress() {
		return emergencyContactAddress;
	}
	public void setEmergencyContactAddress(String emergencyContactAddress) {
		this.emergencyContactAddress = emergencyContactAddress;
	}
	public String getEmergencyContactPriPhone() {
		return emergencyContactPriPhone;
	}
	public void setEmergencyContactPriPhone(String emergencyContactPriPhone) {
		this.emergencyContactPriPhone = emergencyContactPriPhone;
	}
	public String getEmergencyContactSecPhone() {
		return emergencyContactSecPhone;
	}
	public void setEmergencyContactSecPhone(String emergencyContactSecPhone) {
		this.emergencyContactSecPhone = emergencyContactSecPhone;
	}
	public String getOwnEmergencyContactName() {
		return ownEmergencyContactName;
	}
	public void setOwnEmergencyContactName(String ownEmergencyContactName) {
		this.ownEmergencyContactName = ownEmergencyContactName;
	}
	public String getOwnEmergencyContactPriPhone() {
		return ownEmergencyContactPriPhone;
	}
	public void setOwnEmergencyContactPriPhone(String ownEmergencyContactPriPhone) {
		this.ownEmergencyContactPriPhone = ownEmergencyContactPriPhone;
	}
	public String getOwnEmergencyContactSecPhone() {
		return ownEmergencyContactSecPhone;
	}
	public void setOwnEmergencyContactSecPhone(String ownEmergencyContactSecPhone) {
		this.ownEmergencyContactSecPhone = ownEmergencyContactSecPhone;
	}
	public Long getManagerSso() {
		return managerSso;
	}
	public void setManagerSso(Long managerSso) {
		this.managerSso = managerSso;
	}
	public Long getHrManagerSso() {
		return hrManagerSso;
	}
	public void setHrManagerSso(Long hrManagerSso) {
		this.hrManagerSso = hrManagerSso;
	}	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setEmergencyContactState(String emergencyContactState) {
		this.emergencyContactState = emergencyContactState;
	}	
	public String getEmergencyContactState() {
		return emergencyContactState;
	}	
	public void setEmergencyContactZip(String emergencyContactZip) {
		this.emergencyContactZip = emergencyContactZip;
	}	
	public String getEmergencyContactZip() {
		return emergencyContactZip;
	}	
	public void setEmergencyContactCountry(String emergencyContactCoutry) {
		this.emergencyContactCountry = emergencyContactCoutry;
	}
	public String getEmergencyContactCountry() {
		return emergencyContactCountry;
	}	
	public void setEmergencyContactCity(String emergencyContactCity) {
		this.emergencyContactCity = emergencyContactCity;
	}
	public String getEmergencyContactCity() {
		return emergencyContactCity;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCity() {
		return city;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getState() {
		return state;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getZip() {
		return zip;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCountry() {
		return country;
	}

	public void setBaseSalaryCurrency(String baseSalaryCurrency) {
		this.baseSalaryCurrency = baseSalaryCurrency;
	}

	public String getBaseSalaryCurrency() {
		return baseSalaryCurrency;
	}
	
	public String getPreferredName() {
		return preferredName;
	}

	public void setPreferredName(String preferredName) {
		this.preferredName = preferredName;
	}
	
	public String getEmergencyContactRelationship() {
		return emergencyContactRelationship;
	}

	public void setEmergencyContactRelationship(String emergencyContactRelationship) {
		this.emergencyContactRelationship = emergencyContactRelationship;
	}
	
	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getAssignmentStatus() {
		return assignmentStatus;
	}

	public void setAssignmentStatus(String assignmentStatus) {
		this.assignmentStatus = assignmentStatus;
	}

	public String getHeadcountValue() {
		return headcountValue;
	}

	public void setHeadcountValue(String headcountValue) {
		this.headcountValue = headcountValue;
	}

	public String getProfessionalSummary() {
		return professionalSummary;
	}

	public void setProfessionalSummary(String professionalSummary) {
		this.professionalSummary = professionalSummary;
	}
	
	public String getExpertise() {
		return expertise;
	}

	public void setExpertise(String expertise) {
		this.expertise = expertise;
	} 
	
	public String getHrManagerEmail() {
		return hrManagerEmail;
	}

	public void setHrManagerEmail(String hrManagerEmail) {
		this.hrManagerEmail = hrManagerEmail;
	}

	public String getPayrollProcessorCode() {
		return payrollProcessorCode;
	}

	public void setPayrollProcessorCode(String payrollProcessorCode) {
		this.payrollProcessorCode = payrollProcessorCode;
	}

	public String getLegalEntity() {
		return legalEntity;
	}

	public void setLegalEntity(String legalEntity) {
		this.legalEntity = legalEntity;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public boolean getHasEducation() {
		return hasEducation;
	}

	public void setHasEducation(boolean hasEducation) {
		this.hasEducation = hasEducation;
	}
	public String getEmpType() {
		return empType;
	}
	public void setEmpType(String empType) {
		this.empType = empType;
	}
}
