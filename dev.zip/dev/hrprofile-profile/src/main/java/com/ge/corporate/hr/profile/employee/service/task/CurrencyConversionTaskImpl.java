/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.service.task;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ge.corporate.hr.profile.employee.dao.CurrencyConversionDao;
import com.ge.corporate.hr.profile.employee.dao.ScheduledDao;
import com.ge.corporate.hr.profile.employee.dto.CurrencyDto;
import com.ge.corporate.hr.profile.employee.service.CurrencyConversionService;
/**
 * 
 * @author hector.nevarez
 *
 */
public class CurrencyConversionTaskImpl implements CurrencyConversionTask{

	private static Log logger = LogFactory.getLog(CurrencyConversionTaskImpl.class);
	
	private static final String CURRENCY_CONVERSION_RATE_LOAD_TYPE = "CUCR";
	
	@Resource(name="currencyConverter")
	private CurrencyConversionService currencyConverter;
	@Resource(name="currencyDao")
	private CurrencyConversionDao currencyDao;
	@Resource(name="scheduledDao")
	private ScheduledDao scheduledDao;
	
	public void loadCurrencyConversionRates() {
		
		if (scheduledDao.validateScheduledStart(CURRENCY_CONVERSION_RATE_LOAD_TYPE)) {
			logger.debug("Currency Conversion Rates Load Started:"+ new Date(System.currentTimeMillis()) );
			
			
			
			
			//List<String> currencies = currencyDao.getAvaliableCurrencies();
			List<CurrencyDto> currencyList = new ArrayList<CurrencyDto>();
			
			/*
			for(String currencyName : currencies){
				CurrencyDto currency = currencyConverter.getCurrency(currencyName, DEFAULT_CURRENCY_RATE, DEFAULT_CURRENCY);
				if(currency != null && currency.getConvertedAmmount() != null){
					currencyList.add( currency );
				}
			}*/
			
			currencyList = currencyConverter.getCurrency();
			
			currencyDao.clearConversionRatings();
			currencyDao.setCurrency(currencyList);
			currencyDao.swapConversionRates();
			
			
			scheduledDao.removeSchedule(CURRENCY_CONVERSION_RATE_LOAD_TYPE);
			logger.debug("Currency Conversion Rates Load Ended:"+ new Date(System.currentTimeMillis()) );
		}else{
			logger.debug("Currency Conversion Rates Load Halted, The same process is runing different node" );
		}
	}
	
	
}
