/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;


public class SearchAdvancedDto extends AbstractBaseDtoSupport{
	
	private static final long serialVersionUID = -5065551171795908003L;
	
	public void copy(SearchAdvancedDto searchDto){
		if(searchDto.getSso() != null){
			this.setSso(new Long(searchDto.getSso()));
		}	
		if(searchDto.getFirstName() != null){		 
			this.setFirstName(new String(searchDto.getFirstName()));
		}
		if(searchDto.getLastName() != null){
			this.setLastName(new String(searchDto.getLastName()));
		}		
		if(searchDto.getBusiness() != null){
			this.setBusiness(new ArrayList<String>(searchDto.getBusiness()));
		}
		if(searchDto.getSubBusiness() != null){
			this.setSubBusiness(new ArrayList<String>(searchDto.getSubBusiness()));
		}
		if(searchDto.getBand() != null){
			this.setBand(new ArrayList<String>(searchDto.getBand()));
		}
		if(searchDto.getCountry() != null){
			this.setCountry(new ArrayList<String>(searchDto.getCountry()));
		}
		if(searchDto.getFunction() != null){
			this.setFunction(new ArrayList<String>(searchDto.getFunction()));
		}
		if(searchDto.getManagerSso() != null){
			this.setManagerSso(new Long(searchDto.getManagerSso()));
		}		
		if(searchDto.getRegion() != null){
			this.setRegion(new ArrayList<String>(searchDto.getRegion()));
		}
		if(searchDto.getJobFamily() != null){
			this.setJobFamily(new ArrayList<String>(searchDto.getJobFamily()));
		}		
		if(searchDto.getLeadershipProgram() != null){
			this.setLeadershipProgram(new ArrayList<String>(searchDto.getLeadershipProgram()));
		}
		if(searchDto.getLeadershipProgramType() != null){
			this.setLeadershipProgramType(new String(searchDto.getLeadershipProgramType()));
		}
		if(searchDto.getIfg() != null){
			this.setIfg(new String(searchDto.getIfg()));
		}
	}
	
	@XmlElement(name="sso")
	public Long sso;
	
	@XmlElement(name="lastName")
	private String lastName;
	
	@XmlElement(name="firstName")
	private String firstName;
	
	@XmlElement(name="managerSso")
	private Long managerSso;
	
	@XmlElement(name="business")
	private List<String> business;
	
	@XmlElement(name="subBusiness")
	private List<String> subBusiness;
	
	@XmlElement(name="band")
	private List<String> band;
	
	@XmlElement(name="function")
	private List<String> function;
	
	@XmlElement(name="region")
	private List<String> region;
	
	@XmlElement(name="country")
	private List<String> country;
	
	@XmlElement(name="jobFamily")
	private List<String> jobFamily;

	@XmlElement(name="leadershipProgram")
	private List<String> leadershipProgram;
	
	@XmlElement(name="leadershipProgramType")
	private String leadershipProgramType;
	
	@XmlElement(name="ifg")
	private String ifg;
	
	@XmlElement(name="organization")
	private String organization;

	@XmlElement(name="searchList")
	private List<SearchCompDto> searchList;

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}
		
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public List<String> getBusiness() {
		return business;
	}

	public void setBusiness(List<String> business) {
		this.business = business;
	}

	public List<String> getSubBusiness() {
		return subBusiness;
	}

	public void setSubBusiness(List<String> subBusiness) {
		this.subBusiness = subBusiness;
	}

	public List<String> getBand() {
		return band;
	}

	public Long getManagerSso() {
		return managerSso;
	}

	public void setManagerSso(Long managerSso) {
		this.managerSso = managerSso;
	}

	public void setBand(List<String> band) {
		this.band = band;
	}

	public List<String> getFunction() {
		return function;
	}

	public void setFunction(List<String> function) {
		this.function = function;
	}

	public List<String> getRegion() {
		return region;
	}

	public void setRegion(List<String> region) {
		this.region = region;
	}

	public List<String> getCountry() {
		return country;
	}

	public void setCountry(List<String> country) {
		this.country = country;
	}
	
	public List<String> getJobFamily() {
		return jobFamily;
	}

	public void setJobFamily(List<String> jobFamily) {
		this.jobFamily = jobFamily;
	}

	public List<String> getLeadershipProgram() {
		return leadershipProgram;
	}

	public void setLeadershipProgram(List<String> leadershipProgram) {
		this.leadershipProgram = leadershipProgram;
	}
	
	public String getLeadershipProgramType() {
		return leadershipProgramType;
	}

	public void setLeadershipProgramType(String leadershipProgramType) {
		this.leadershipProgramType = leadershipProgramType;
	}
	
	public List<SearchCompDto> getSearchList() {
		return searchList;
	}
	
	public String getIfg() {
		return ifg;
	}

	public void setIfg(String ifg) {
		this.ifg = ifg;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public void setSearchList(List<SearchCompDto> searchList) {
		this.searchList = searchList;
	}
	
	public Integer getSize(){
		Integer size = 0;
		if(searchList != null){
			size = 	searchList.size();		
		}
		return size;
	}
	
	public long getId() {
		return 0;
	}

}
