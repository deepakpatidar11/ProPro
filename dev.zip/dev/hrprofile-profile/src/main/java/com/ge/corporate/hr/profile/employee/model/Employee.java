/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="profile")
@XmlAccessorType(XmlAccessType.FIELD)
public class Employee extends AbstractBaseModelSupport {

	private static final long serialVersionUID = 4760712755094392751L;
	
	public Employee() {}	
	@XmlElement(name="sso")
	private Long sso;	
	// personal info
	@XmlElement(name="firstName")
	private String firstName;
	@XmlElement(name="lastName")
	private String lastName;
	@XmlElement(name="preferedName")
	private String preferedName;	
	@XmlElement(name="birthDate")
	private Date birthDate;
	@XmlElement(name="age")
	private Short age;
	@XmlElement(name="citizenShip")
	private String citizenShip;	
	@XmlElement(name="gender")
	private String gender;
	@XmlElement(name="usEeoCategory")
	private String usEeoCategory;
	@XmlElement(name="veteranStatus")
	private String veteranStatus;	
	@XmlElement(name="mobile")
	private String mobile;	
	@XmlElement(name="dcomm")
	private String dcomm;
	@XmlElement(name="phone")
	private String phone;
	@XmlElement(name="email")
	private String email;
	
	@XmlElement(name="mailstop")
	private String mailstop;
	@XmlElement(name="internalLocation")
	private String internalLocation;	
	
	@XmlElement(name="emergencyContact")	
	private EmergencyContact emergencyContact;
	
	// org info
	@XmlElement(name="title")
	private String title;
	
	@XmlElement(name="level")
	private int level;
	
	@XmlElement(name="ifgName")
	private String ifgName;
	//@XmlElement(name="org")
	//private String org;
	
	@XmlElement(name="payrollProcessorCode")
	private String payrollProcessorCode;
	
	@XmlElement(name="legalEntity")
	private String legalEntity;
	
		
	@XmlElement(name="managerSso")
	private Long managerSso;
	@XmlElement(name="managerName")
	private String managerName;
	@XmlElement(name="hrManagerName")
	private String hrManagerName;
	@XmlElement(name="hrManagerSso")
	private Long hrManagerSso;
	@XmlElement(name="localHrManager")
	private Long localHrManager;
	@XmlElement(name="dottedLineManager")
	private Long dottedLineManager;	
		
	@XmlElement(name="performance")
	private Performance performance;
		
	@XmlElement(name="currentEducation")	
	private Education education; // Current Education
	
	@XmlElement(name="education")	
	private List<Education> educationList = new ArrayList<Education>();
	
	@XmlElement(name="assignment")	
	private List<WorkAssignment> assignmentList = new ArrayList<WorkAssignment>();
	
	@XmlElement(name="training")
	private List<Training> trainingList = new ArrayList<Training>();
	
	@XmlElement(name="performanceAward")
	private List<LongTermPerformanceAward> LongTermPerfAwardList = new ArrayList<LongTermPerformanceAward>();
	
	@XmlElement(name="compensationList")
	private List<Compensation> compensationList = new ArrayList<Compensation>();
	
	@XmlElement(name="incentiveComp")
	private List<IncentiveCompensation> incentiveCompList = new ArrayList<IncentiveCompensation>();
	
	@XmlElement(name="lumpComp")
	private List<LumpCompensation> lumpCompList = new ArrayList<LumpCompensation>();
	
	@XmlElement(name="stockOption")
	private List<StockOption> stockOptionList = new ArrayList<StockOption>();
	
	@XmlElement(name="program")
	private List<Program> programList = new ArrayList<Program>();
	
	
	public Long getSso() {
		return sso;
	}	
	public void setSso(Long sso) {
		this.sso = sso;
	}	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPreferedName() {
		return preferedName;
	}
	public void setPreferedName(String preferedName) {
		this.preferedName = preferedName;
	}
	public Date getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}
	public Short getAge() {
		return age;
	}
	public void setAge(Short age) {
		this.age = age;
	}
	public String getCitizenShip() {
		return citizenShip;
	}
	public void setCitizenShip(String citizenShip) {
		this.citizenShip = citizenShip;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getUsEeoCategory() {
		return usEeoCategory;
	}
	public void setUsEeoCategory(String usEeoCategory) {
		this.usEeoCategory = usEeoCategory;
	}
	public String getVeteranStatus() {
		return veteranStatus;
	}
	public void setVeteranStatus(String veteranStatus) {
		this.veteranStatus = veteranStatus;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getDcomm() {
		return dcomm;
	}
	public void setDcomm(String dcomm) {
		this.dcomm = dcomm;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public EmergencyContact getEmergencyContact() {
		return emergencyContact;
	}
	public String getMailstop() {
		return mailstop;
	}
	public void setMailstop(String mailstop) {
		this.mailstop = mailstop;
	}
	public String getInternalLocation() {
		return internalLocation;
	}
	public void setInternalLocation(String internalLocation) {
		this.internalLocation = internalLocation;
	}
	public void setEmergencyContact(EmergencyContact emergencyContact) {
		this.emergencyContact = emergencyContact;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
//	public String getOrg() {
//		return org;
//	}
//	public void setOrg(String org) {
//		this.org = org;
//	}	
	public Long getManagerSso() {
		return managerSso;
	}
	public void setManagerSso(Long managerSso) {
		this.managerSso = managerSso;	
	}	
	public Long getHrManagerSso() {
		return hrManagerSso;
	}
	public void setHrManagerSso(Long hrManager) {
		this.hrManagerSso = hrManager;
	}
	public Long getLocalHrManager() {
		return localHrManager;
	}
	public void setLocalHrManager(Long localHrManager) {
		this.localHrManager = localHrManager;
	}
	public Long getDottedLineManager() {
		return dottedLineManager;
	}
	public void setDottedLineManager(Long dottedLineManager) {
		this.dottedLineManager = dottedLineManager;
	}
	public Performance getPerformance() {
		return performance;
	}
	public void setPerformance(Performance performance) {
		this.performance = performance;
	}
	public List<Education> getEducationList() {
		return educationList;
	}
	public void setEducationList(List<Education> educationList) {
		this.educationList = educationList;
	}
	public List<WorkAssignment> getAssignmentList() {
		return assignmentList;
	}
	public void setAssignmentList(List<WorkAssignment> assignmentList) {
		this.assignmentList = assignmentList;
	}
	public List<Training> getTrainingList() {
		return trainingList;
	}
	public void setTrainingList(List<Training> trainingList) {
		this.trainingList = trainingList;
	}
	public List<LongTermPerformanceAward> getLongTermPerfAwardList() {
		return LongTermPerfAwardList;
	}
	public void setLongTermPerfAwardList(
			List<LongTermPerformanceAward> LongTermPerfAwardList) {
		this.LongTermPerfAwardList = LongTermPerfAwardList;
	}
	public List<Compensation> getCompensationList() {
		return compensationList;
	}
	public void setCompensationList(List<Compensation> compensationList) {
		this.compensationList = compensationList;
	}
	public List<IncentiveCompensation> getIncentiveCompList() {
		return incentiveCompList;
	}
	public void setIncentiveCompList(List<IncentiveCompensation> incentiveCompList) {
		this.incentiveCompList = incentiveCompList;
	}
	public List<LumpCompensation> getLumpCompList() {
		return lumpCompList;
	}
	public void setLumpCompList(List<LumpCompensation> lumpCompList) {
		this.lumpCompList = lumpCompList;
	}
	public List<StockOption> getStockOptionList() {
		return stockOptionList;
	}
	public void setStockOptionList(List<StockOption> stockOptionList) {
		this.stockOptionList = stockOptionList;
	}
	public List<Program> getProgramList() {
		return programList;
	}
	public void setProgramList(List<Program> programList) {
		this.programList = programList;
	}
	public static Long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public void setEducation(Education education) {
		this.education = education;
	}
	public Education getEducation() {
		return education;
	}
	
	
	public void addEducation( Education education ) {
		this.educationList.add(education);
	}	
	public void addAssignment( WorkAssignment assignment ) {
		this.assignmentList.add(assignment);
	}
	public void addPerformanceAward( LongTermPerformanceAward performanceAward ) {
		this.LongTermPerfAwardList.add(performanceAward);
	}	
	public void addTraining( Training training ) {
		this.trainingList.add(training);
	}	
	public void addCompenmsation( Compensation compensation ) {
		this.compensationList.add(compensation);
	}	
	public void addIncentiveCompenmsation( IncentiveCompensation compensation ) {
		this.incentiveCompList.add(compensation);
	}	
	public void addLumpCompensation( LumpCompensation compensation ) {
		this.lumpCompList.add(compensation);
	}
	public void addStockOption( StockOption stockOption ) {
		this.stockOptionList.add(stockOption);
	}	
	public void addProgram( Program program ) {
		this.programList.add(program);
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setHrManagerName(String hrManagerName) {
		this.hrManagerName = hrManagerName;
	}
	public String getHrManagerName() {
		return hrManagerName;
	}
	public void setIfgName(String ifgName) {
		this.ifgName = ifgName;
	}
	public String getIfgName() {
		return ifgName;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public String getPayrollProcessorCode() {
		return payrollProcessorCode;
	}
	public void setPayrollProcessorCode(String payrollProcessorCode) {
		this.payrollProcessorCode = payrollProcessorCode;
	}
	public String getLegalEntity() {
		return legalEntity;
	}
	public void setLegalEntity(String legalEntity) {
		this.legalEntity = legalEntity;
	}
	
	
}