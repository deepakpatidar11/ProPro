package com.ge.corporate.hr.profile.employee.dto;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;

public class BandVisibilityDto extends AbstractBaseDtoSupport {

	private static final long serialVersionUID = 8726711381861455097L;
	
	private Boolean visible;
	
	public Boolean isVisible(){
		return visible;
	}
	
	public void setVisibility(Boolean visible){
		this.visible = visible;
	}
	
	public long getId() {
		return 0;
	}

}
