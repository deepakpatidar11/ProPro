package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.CareerAspiration;


public class CareerInterestMapper implements RowMapper<CareerAspiration>{
	
	public static final String DATA_SSO = "sso";
//	public static final String DATA_SHORT_TERM = "career_goal_shortterm";
//	public static final String DATA_LONG_TERM = "career_goal_longterm";
	public static final String DATA_GOAL_COMBINED = "career_goal_combined";
	public static final String DATA_TALENT_POOL = "optin_talentpool";
	
	@Override
	public CareerAspiration mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		
		CareerAspiration career = new CareerAspiration();
		career.setSso(rs.getLong(DATA_SSO));
//		career.setGoalShortTerm(rs.getString(DATA_SHORT_TERM));
//		career.setGoalLongTerm(rs.getString(DATA_LONG_TERM));
		career.setGoalCombined(rs.getString(DATA_GOAL_COMBINED));
		career.setOptnTalentFlag(rs.getString(DATA_TALENT_POOL));
		
		return career;
	}

	
	
	

}
