package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.IntiativesandProject;


public class IntiativesandProjectMapper implements RowMapper<IntiativesandProject> {
	
	public static final String DATA_SSO = "sso";
	public static final String DATA_TITLE ="name";
	public static final String  DATA_DESCRIPTION ="text";
	public static final String  DATA_DATEFROM ="datefrom";
	public static final String  DATA_DATETO ="dateto";
	
	
	public IntiativesandProject mapRow(ResultSet rs, int rowNum) throws SQLException {
		IntiativesandProject initiatives = new IntiativesandProject();
		initiatives.setSso(rs.getLong(DATA_SSO));
		initiatives.setTitle(rs.getString(DATA_TITLE));
		initiatives.setDescription(rs.getString(DATA_DESCRIPTION));
		initiatives.setFromDate(rs.getString(DATA_DATEFROM));
		initiatives.setToDate(rs.getString(DATA_DATETO));
		
		return initiatives;
	}
}