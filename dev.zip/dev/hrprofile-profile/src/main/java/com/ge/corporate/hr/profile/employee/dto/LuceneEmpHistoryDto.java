package com.ge.corporate.hr.profile.employee.dto;

import java.util.Date;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;

public class LuceneEmpHistoryDto extends AbstractBaseDtoSupport  {

	private long sso;
	private String businessCard;
	private String geBusiness;
	private String location;
	private String functionDes;
	private Date fromDate;
	private Date toDate;
	private String Manager;
	private String expDesc;

	public LuceneEmpHistoryDto() {
		super();
	}

	public LuceneEmpHistoryDto(long sso, String businessCard,
			String geBusiness, String location, String functionDes,
			Date fromDate, Date toDate, String manager, String expDesc) {
		super();
		this.sso = sso;
		this.businessCard = businessCard;
		this.geBusiness = geBusiness;
		this.location = location;
		this.functionDes = functionDes;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.expDesc = expDesc;
		Manager = manager;
	}

	public long getSso() {
		return sso;
	}

	public void setSso(long sso) {
		this.sso = sso;
	}

	public String getBusinessCard() {
		return businessCard;
	}

	public void setBusinessCard(String businessCard) {
		this.businessCard = businessCard;
	}

	public String getGeBusiness() {
		return geBusiness;
	}

	public void setGeBusiness(String geBusiness) {
		this.geBusiness = geBusiness;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getFunctionDes() {
		return functionDes;
	}

	public void setFunctionDes(String functionDes) {
		this.functionDes = functionDes;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public String getManager() {
		return Manager;
	}

	public void setManager(String manager) {
		Manager = manager;
	}

	public String getExpDesc() {
		return expDesc;
	}

	public void setExpDesc(String expDesc) {
		this.expDesc = expDesc;
	}

	@Override
	public long getId() {
		// TODO Auto-generated method stub
		return 0;
	}

}
