package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="languageProficicency")
@XmlAccessorType(XmlAccessType.FIELD)
public class LanguageProficiency {

	private static final long serialVersionUID = 1L;

	@XmlElement(name="sso")
	private Long sso;	
	
	@XmlElement(name="language")
	private String language;
	
	@XmlElement(name="level")
	private String level;
	
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String string) {
		this.language = string;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	
	
}
