/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.BonusSIT;
import com.ge.corporate.hr.profile.employee.model.Compensation;
import com.ge.corporate.hr.profile.employee.model.IncentiveCompensation;
import com.ge.corporate.hr.profile.employee.model.LongTermPerformanceAward;
import com.ge.corporate.hr.profile.employee.model.LumpCompensation;
import com.ge.corporate.hr.profile.employee.model.RestrictedStockOptionTotals;
import com.ge.corporate.hr.profile.employee.model.StockOption;
import com.ge.corporate.hr.profile.employee.model.StockOptionTotals;

/**
 * Compensation dao interface
 * @author enrique.romero
 *
 */
public interface CompensationDao {	
	/**
	 * Returns Compensation information by sso, this information belongs to "Compensation" Data Group
	 * @param sso Employee SSO
	 * @return Compensation model
	 */
	public Compensation getCurrentCompensationBySso(Long sso);
	
	/**
	 * Returns Compensation information by sso, this information belongs to "Compensation" Data Group
	 * @param sso Employee SSO
	 * @return Compensation model
	 */
	public BaseModelCollection<LumpCompensation> getLumpCompensationHistoryBySso(Long sso);

	/**
	 * Returns Compensation history data by sso 
	 * @param sso Employee SSO
	 * @return Compensation model
	 */
	public BaseModelCollection<Compensation> getCompensationHistoryBySso(Long sso);
	
	/**
	 * Returns Incentive compensation history data by sso 
	 * @param sso Employee SSO
	 * @return IncentiveList Model
	 */
	public BaseModelCollection<IncentiveCompensation> getIncentiveCompensationHistoryBySso(Long sso);
	
	/**
	 * Returns Stock Options list
	 * @param sso Employee SSO
	 * @return StockOption List model 
	 */
	public BaseModelCollection<StockOption> getStockOptionsBySso(Long sso);
	
	/**
	 * Returns Options Outstanding list
	 * @param sso Employee SSO
	 * @return StockOption List model 
	 */
	public BaseModelCollection<StockOption> getOptionsOutstandingBySso(Long sso);
	
	/**
	 * Returns restricted  Stock Options list
	 * @param sso Employee SSO
	 * @return StockOption List model 
	 */	
	public BaseModelCollection<StockOption> getRestrictedStockOptionsBySso(Long sso);
	
	/**
	 * Next Vesting Options list
	 * @param sso Employee SSO
	 * @return StockOption List model 
	 */
	public BaseModelCollection<StockOption> getNextVestingOptionsBySso(Long sso);
	
	/**
	 * Returns Long Term Performance Award
	 * @param sso Employee SSO
	 * @return LongTermPerformanceAward List model 
	 */	
	public BaseModelCollection<LongTermPerformanceAward> getLongTermPerformanceAwardsBySso(Long sso);
	
	/**
	 * return Total Current Compensation, this data is calculated
	 * @param sso Employee SSO
	 * @return Total Current Compensation
	 */
	public Long getCurrentCompensationTotalBySso(Long sso);
	
	/**
	 * return Stock Option totals by sso
	 * @param sso Employee SSO
	 * @return StockOptionTotal model
	 */
	public StockOptionTotals getStockOptionTotalBySso(Long sso);
	
	/**
	 * return Options Outstanding totals by sso
	 * @param sso Employee SSO
	 * @return StockOptionTotal model
	 */
	public StockOptionTotals getOptionOutsdngTotalBySso(Long sso);
	
	/**
	 * returns Restricted Stock Option totals by sso
	 * @param sso Employee SSO
	 * @return RestrictedStockOptionTotal model
	 */
	public RestrictedStockOptionTotals getRestrictedStockOptionTotalBySso(Long sso);
	
	/**
	 * returns Bonus SIT totals by sso
	 * @param sso Employee SSO
	 * @param startDate bonus Start Date
	 * @return BonusSIT List model
	 */
	public BaseModelCollection<BonusSIT> getBonusSITBySso(Long sso);
	
}
