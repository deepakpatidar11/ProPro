/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.service;

import java.io.Serializable;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ge.corporate.hr.profile.auth.model.DataGroup;
import com.ge.corporate.hr.profile.auth.service.ProfileAuthorityEvaluator;
import com.ge.corporate.hr.profile.auth.util.PersonAuthUtil;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.common.service.AbstractBaseServiceSupport;
import com.ge.corporate.hr.profile.common.util.ProfileStringUtil;
import com.ge.corporate.hr.profile.employee.dao.EmployeeDao;
import com.ge.corporate.hr.profile.employee.dao.LanguageDao;
import com.ge.corporate.hr.profile.employee.dao.SearchDao;
import com.ge.corporate.hr.profile.employee.dto.AutoCompleteDto;
import com.ge.corporate.hr.profile.employee.dto.EmployeeExpertiseDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneEducationDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneEmpHistoryDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneLeadershipDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneSearchCompDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneTrainingDto;
import com.ge.corporate.hr.profile.employee.dto.PersonalInfoDto;
import com.ge.corporate.hr.profile.employee.dto.SearchAdvancedDto;
import com.ge.corporate.hr.profile.employee.dto.SearchCompDto;
import com.ge.corporate.hr.profile.employee.dto.SearchCompListDto;
import com.ge.corporate.hr.profile.employee.dto.SearchLuceneDto;
import com.ge.corporate.hr.profile.employee.dto.StringCatalogDto;
import com.ge.corporate.hr.profile.employee.model.AffinityGroups;
import com.ge.corporate.hr.profile.employee.model.AutoCompleteRowModel;
import com.ge.corporate.hr.profile.employee.model.AutoCompleteViewModel;
import com.ge.corporate.hr.profile.employee.model.CustomerandSuppliers;
import com.ge.corporate.hr.profile.employee.model.EmployeeExpertise;
import com.ge.corporate.hr.profile.employee.model.Expertise;
import com.ge.corporate.hr.profile.employee.model.IntiativesandProject;
import com.ge.corporate.hr.profile.employee.model.LPBridgeAssignment;
import com.ge.corporate.hr.profile.employee.model.LanguageProficiency;
import com.ge.corporate.hr.profile.employee.model.Mentoring;
import com.ge.corporate.hr.profile.employee.model.MentoringInterest;
import com.ge.corporate.hr.profile.employee.model.ProfileUserMetrics;
import com.ge.corporate.hr.profile.employee.model.ShortProfile;
import com.ge.corporate.hr.profile.employee.model.ShortProfileList;
import com.ge.corporate.hr.profile.employee.model.WorkMobilityCountry;

public class SearchServiceImpl extends AbstractBaseServiceSupport implements
		SearchService, Serializable {
	private final Log logger = LogFactory
			.getLog(WorkAssignmentServiceImpl.class);

	@Resource(name = "employeeDao")
	private EmployeeDao employeeDao;

	@Resource(name = "searchDao")
	private SearchDao searchDao;

	@Resource(name = "advancedSearchPersistence")
	private List<ShortProfileList> persistedSearchResults;

	@Resource(name = "authorityEvaluator")
	private ProfileAuthorityEvaluator authEvaluator;
	
	@Resource(name = "searchService")
	private SearchService searchService;
	
	@Resource(name = "languageDao")
	private LanguageDao languageDao;

	private Map<String, String> aclListValueMap = getACLListMap();

	public PersonalInfoDto searchEmployee(String key) {
		return null;
	}

	public AutoCompleteDto searchEmployeeByParam(AutoCompleteDto autoCompletDto) {
		return searchIntEmployeeByParam(autoCompletDto, true);
	}

	public AutoCompleteDto searchEmployeeByParam(
			AutoCompleteDto autoCompletDto, boolean labelSsoAndName) {
		return searchIntEmployeeByParam(autoCompletDto, labelSsoAndName);
	}

	/**
	 * 
	 * @param autoCompletDto
	 * @param labelSsoAndName
	 * @return
	 */
	private AutoCompleteDto searchIntEmployeeByParam(
			AutoCompleteDto autoCompletDto, boolean labelSsoAndName) {
		BaseModelCollection<ShortProfile> profiles = null;
		List<ShortProfile> list = null;
		AutoCompleteDto autoCompResDto = new AutoCompleteDto();
		List<AutoCompleteRowModel> rows = new ArrayList<AutoCompleteRowModel>();

		if (ProfileStringUtil.isInteger(autoCompletDto.getQuery())) {
			// Returns the search ordering sso
			profiles = employeeDao
					.searchEmployeeByParamOrderBySso(autoCompletDto.getQuery());
			list = new ArrayList<ShortProfile>(profiles.getList());
		} else {
			profiles = employeeDao.searchEmployeeByParam(autoCompletDto
					.getQuery());
			list = new ArrayList<ShortProfile>(profiles.getList());
		}

		// TODO: This functionality should be part of AutoCompleteDTO
		// Populates List to DTO search
		for (ShortProfile p : list) {
			String label = "";
			if (labelSsoAndName) {
				label += p.getSso() + " ";
			}
			label += p.getLastName() + ", " + p.getFirstName() + " ("
					+ p.getIndustry() + ")";
			rows.add(new AutoCompleteRowModel(label, String.valueOf(p.getSso())));
		}

		if (rows.size() > 0) {
			autoCompResDto.setAutoComplete(new AutoCompleteViewModel(rows));
			logger.debug("Search function founded:" + rows.size() + " rows");
		} else {
			logger.debug("Search function did not find any match");
		}
		return autoCompResDto;
	}

	/**
	 * 
	 */
	public SearchCompListDto searchEmployeeListByParam(
			SearchCompListDto searchListDto) {
		persistedSearchResults.clear();

		List<SearchCompDto> searchCompListDto = new ArrayList<SearchCompDto>();
		BaseModelCollection<ShortProfileList> profiles = null;

		if (ProfileStringUtil.isInteger(searchListDto.getQuery())) {
			profiles = employeeDao.searchEmployeeListByParam(new Long(
					searchListDto.getQuery()));
		} else {
			profiles = employeeDao.searchEmployeeListByParam(searchListDto
					.getQuery());
		}
		persistedSearchResults.addAll(new ArrayList<ShortProfileList>(profiles
				.getList()));

		for (ShortProfileList p : persistedSearchResults) {

			SearchCompDto dto = new SearchCompDto();
			dto.setSso(p.getSso());
			dto.setEmpName(p.getEmpName());
			dto.setFunc(p.getFunction());
			dto.setEmpManagerName(p.getEmpManagerName());
			dto.setBusiness(p.getBusiness());
			dto.setSubBusiness(p.getSubBusiness());
			dto.setOrganization(p.getOrganization());
			dto.setIfg(p.getIfg());
			dto.setTitle(p.getTitle());
			dto.setEmpManagerSso(p.getEmpManagerSso());

			searchCompListDto.add(dto);
		}

		searchListDto.setSearchList(searchCompListDto);

		return searchListDto;
	}

	public StringCatalogDto getBusinessCatalog() {
		StringCatalogDto dto = new StringCatalogDto();
		dto.setCatalog(searchDao.getBusinessList());
		return dto;
	}

	public StringCatalogDto getSubBusinessCatalog(StringCatalogDto catalogDto) {
		StringCatalogDto dto = new StringCatalogDto();
		dto.setCatalog(searchDao.getSubBusinessList(catalogDto.getCrieria()));
		return dto;
	}

	public StringCatalogDto getBandCatalog() {
		StringCatalogDto dto = new StringCatalogDto();
		dto.setCatalog(searchDao.getBandList());
		return dto;
	}

	public StringCatalogDto getFunctionCatalog() {
		StringCatalogDto dto = new StringCatalogDto();
		dto.setCatalog(searchDao.getFunctionList());
		return dto;
	}

	public StringCatalogDto getJobFamilyCatalog(StringCatalogDto catalogDto) {
		StringCatalogDto dto = new StringCatalogDto();
		dto.setCatalog(searchDao.getJobFamilyList(catalogDto.getCrieria()));
		return dto;
	}

	public StringCatalogDto getRegionCatalog() {
		StringCatalogDto dto = new StringCatalogDto();
		dto.setCatalog(searchDao.getRegionList());
		return dto;
	}

	public StringCatalogDto getCountryCatalog() {
		StringCatalogDto dto = new StringCatalogDto();
		dto.setCatalog(searchDao.getCountryList());
		return dto;
	}
	
	public Map<String, String> getCountryCodeMap() {
		return searchDao.getCountryCodeMap();
	}

	public StringCatalogDto getCountryRegionCatalog(StringCatalogDto catalogDto) {
		StringCatalogDto dto = new StringCatalogDto();
		dto.setCatalog(searchDao.getCountryRegionList(catalogDto.getCrieria()));
		return dto;
	}

	public StringCatalogDto getLeadershipProgramCatalog() {
		StringCatalogDto dto = new StringCatalogDto();
		dto.setCatalog(searchDao.getLeadershipProgramList());
		return dto;
	}

	public StringCatalogDto getIfgCatalog() {
		StringCatalogDto dto = new StringCatalogDto();
		dto.setCatalog(searchDao.getIfgList());
		return dto;
	}

	public SearchAdvancedDto searchEmployeeAdvanced(
			SearchAdvancedDto searchListDto) {

		persistedSearchResults.clear();

		List<SearchCompDto> searchCompListDto = new ArrayList<SearchCompDto>();
		BaseModelCollection<ShortProfileList> profiles = null;

		profiles = searchDao.searchEmployeeAdvanced(
				PersonAuthUtil.getLoggedSSO(), searchListDto.getSso(),
				searchListDto.getLastName(), searchListDto.getFirstName(),
				searchListDto.getManagerSso(), searchListDto.getBusiness(),
				searchListDto.getSubBusiness(), searchListDto.getBand(),
				searchListDto.getFunction(), searchListDto.getRegion(),
				searchListDto.getCountry(), searchListDto.getJobFamily(),
				searchListDto.getLeadershipProgram(),
				searchListDto.getLeadershipProgramType());

		persistedSearchResults.addAll(new ArrayList<ShortProfileList>(profiles
				.getList()));

		for (ShortProfileList p : persistedSearchResults) {

			SearchCompDto dto = new SearchCompDto();
			dto.setSso(p.getSso());
			dto.setEmpName(p.getEmpName());
			dto.setFunc(p.getFunction());
			dto.setEmpManagerName(p.getEmpManagerName());
			dto.setBusiness(p.getBusiness());
			dto.setSubBusiness(p.getSubBusiness());
			dto.setOrganization(p.getOrganization());
			dto.setIfg(p.getIfg());
			dto.setTitle(p.getTitle());
			dto.setEmpManagerSso(p.getEmpManagerSso());
			searchCompListDto.add(dto);

		}

		searchListDto.setSearchList(searchCompListDto);

		return searchListDto;
	}

	public void cleanDto(SearchAdvancedDto searchListDto) {

		if (searchListDto != null) {
			if (searchListDto.getFirstName() != null) {
				searchListDto.setFirstName(ProfileStringUtil
						.replaceHexadecimalCharacters(searchListDto
								.getFirstName()));
			}

			if (searchListDto.getLastName() != null) {
				searchListDto.setLastName(ProfileStringUtil
						.replaceHexadecimalCharacters(searchListDto
								.getLastName()));
			}

			if (searchListDto.getBusiness() != null) {
				searchListDto.setBusiness(cleanArray(searchListDto
						.getBusiness()));
			}
			if (searchListDto.getSubBusiness() != null) {
				searchListDto.setSubBusiness(cleanArray(searchListDto
						.getSubBusiness()));
			}

			if (searchListDto.getFunction() != null) {
				searchListDto.setFunction(cleanArray(searchListDto
						.getFunction()));
			}
			if (searchListDto.getJobFamily() != null) {
				searchListDto.setJobFamily(cleanArray(searchListDto
						.getJobFamily()));
			}
			if (searchListDto.getLeadershipProgram() != null) {
				searchListDto.setLeadershipProgram(cleanArray(searchListDto
						.getLeadershipProgram()));
			}

			if (searchListDto.getLeadershipProgramType() != null) {
				searchListDto.setLeadershipProgramType(ProfileStringUtil
						.replaceHexadecimalCharacters(searchListDto
								.getLeadershipProgramType()));
			}

			if (searchListDto.getLeadershipProgramType() != null) {
				searchListDto.setLeadershipProgram(cleanArray(searchListDto
						.getLeadershipProgram()));
			}
			if (searchListDto.getRegion() != null) {
				searchListDto.setRegion(cleanArray(searchListDto.getRegion()));
			}
			if (searchListDto.getCountry() != null) {
				searchListDto
						.setCountry(cleanArray(searchListDto.getCountry()));
			}
			if (searchListDto.getBand() != null) {
				searchListDto.setBand(cleanArray(searchListDto.getBand()));
			}
		}
	}

	private List<String> cleanArray(List<String> array) {
		if (array != null && array.size() > 0) {
			List<String> newArray = new ArrayList<String>();
			for (String value : array) {
				newArray.add(ProfileStringUtil
						.replaceHexadecimalCharacters(value));
			}
			return newArray;
		}
		return null;
	}

	public List<LuceneSearchCompDto> loadEmployeeService() {
		return employeeDao.getEmployeeListDao();
	}

	@Override
	public List<Long> getAllSso() {
		return employeeDao.getAllSso();
	}

	@Override
	public Map<Long, List<LuceneEducationDto>> getEducationData() {
		// TODO Auto-generated method stub
		// int eduRecords = (int) (ssoList.size()*1.1);
		Map<Long, List<LuceneEducationDto>> eduMap = new HashMap<Long, List<LuceneEducationDto>>();
		List<LuceneEducationDto> eduList = employeeDao.getEducationData();
		for (LuceneEducationDto e : eduList) {
			if (eduMap.containsKey(e.getSso())) {
				List<LuceneEducationDto> edu = eduMap.get(e.getSso());
				edu.add(e);
				eduMap.put(e.getSso(), edu);
			} else {
				List<LuceneEducationDto> edu = new ArrayList<LuceneEducationDto>();
				edu.add(e);
				eduMap.put(e.getSso(), edu);

			}
		}
		return eduMap;
	}

	@Override
	public Map<Long, List<LuceneEmpHistoryDto>> getWorkHistoryData() {
		// TODO Auto-generated method stub
		// int eduRecords = (int) (ssoList.size()*1.1);
		Map<Long, List<LuceneEmpHistoryDto>> eduMap = new HashMap<Long, List<LuceneEmpHistoryDto>>();
		List<LuceneEmpHistoryDto> eduList = employeeDao.getWorkHistoryData();
		for (LuceneEmpHistoryDto e : eduList) {
			if (eduMap.containsKey(e.getSso())) {
				List<LuceneEmpHistoryDto> edu = eduMap.get(e.getSso());
				edu.add(e);
				eduMap.put(e.getSso(), edu);
			} else {
				List<LuceneEmpHistoryDto> edu = new ArrayList<LuceneEmpHistoryDto>();
				edu.add(e);
				eduMap.put(e.getSso(), edu);

			}
		}
		return eduMap;
	}

	@Override
	public Map<Long, List<LuceneTrainingDto>> getTrainingData() {
		// TODO Auto-generated method stub
		// int eduRecords = (int) (ssoList.size()*1.1);
		Map<Long, List<LuceneTrainingDto>> eduMap = new HashMap<Long, List<LuceneTrainingDto>>();
		List<LuceneTrainingDto> eduList = employeeDao.getTrainingData();
		for (LuceneTrainingDto e : eduList) {
			if (eduMap.containsKey(e.getSso())) {
				List<LuceneTrainingDto> edu = eduMap.get(e.getSso());
				edu.add(e);
				eduMap.put(e.getSso(), edu);
			} else {
				List<LuceneTrainingDto> edu = new ArrayList<LuceneTrainingDto>();
				edu.add(e);
				eduMap.put(e.getSso(), edu);

			}
		}
		return eduMap;
	}

	@Override
	public Map<Long, List<LuceneLeadershipDto>> getLeadershipData() {
		// TODO Auto-generated method stub
		// int eduRecords = (int) (ssoList.size()*1.1);
		Map<Long, List<LuceneLeadershipDto>> eduMap = new HashMap<Long, List<LuceneLeadershipDto>>();
		List<LuceneLeadershipDto> eduList = employeeDao.getLeadershipData();
		for (LuceneLeadershipDto e : eduList) {
			if (eduMap.containsKey(e.getSso())) {
				List<LuceneLeadershipDto> edu = eduMap.get(e.getSso());
				edu.add(e);
				eduMap.put(e.getSso(), edu);
			} else {
				List<LuceneLeadershipDto> edu = new ArrayList<LuceneLeadershipDto>();
				edu.add(e);
				eduMap.put(e.getSso(), edu);

			}
		}
		return eduMap;
	}

	@Override
	public List<String> getACLRoles(Long sso) {
		return searchDao.getWorkAssignmentRestrictedSearchLRoles(sso);
	}

	@Override
	public boolean hasACLRoles(Long sso) {
		return searchDao.getWorkAssignmentRestrictedSearchLRoles(sso).isEmpty() == true ? false : true;
	}
	
	@Override
	public boolean hasExportSearchAccess(Long sso){
		return searchDao.getRolesWithSearchExcelAccess(sso).isEmpty() == true ? false : true;
	}

	public String createTypeAheadQuery(String param) {
		boolean hasQuotes = false;
		if (param.startsWith("\"") && param.endsWith("\"")) {
			param = param.replaceAll("\"", "");
			hasQuotes = true;
		}
		StringBuilder query = new StringBuilder();
		param = param.replaceAll("\\*", " ");

		// if (query.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
		// escapeQuery = "\"" + query + "\"";
		// }
		// param = QueryParser.escape(param);
		param = escapeSpecialCharacters(param, true);
		String[] terms = param.split(" ");
		for (String t : terms) {
			query.append("+").append(t).append("* ");
		}
		// query.replace(0, 1, "");
		if (hasQuotes) {
			query.insert(0, "\\\"");
			query.append("\\\"");
		}
		return "defaultTypeahead:(" + query.toString() + ")";
	}

	public Map<String, String> createConnectionsQuery(Long userSSO, SearchLuceneDto searchDto, boolean facetConnect, Map<String, String> paramWeightage) {
		
	     Map<String, String> queryAndLabel = new HashMap<String, String>();
	     String query = "";
	     String seperator = "";
	     String resultLabel = "";
	     List<String> commaCheckedValue = null;
	     
	     if (searchDto != null && !facetConnect) {
	    	 	query = query + "(";
	            if (searchDto.getTitle() != null && !searchDto.getTitle().isEmpty()) {
	            	  if(paramWeightage != null && paramWeightage.get("title") != null && !paramWeightage.get("title").isEmpty()){
	            		  query = query + "AND ( title:(" + searchDto.getTitle() + ")^"+paramWeightage.get("title")
	            		  				+" OR empLocalTitle:(" + searchDto.getTitle() + ")^"+paramWeightage.get("title")+") ";
	            	  } else {
	            		  query = query + "AND ( title:(" + searchDto.getTitle() + ") OR empLocalTitle:(" + searchDto.getTitle() + ")) ";
	            	  }
	                  query = escapeSpecialCharacters(query, false);
	                  resultLabel = resultLabel + " + ( Title: \'"
	                                + searchDto.getTitle() + "\'";
	            }
	            
	            if (searchDto.getBusiness() != null) {
	                  commaCheckedValue = checkForQuestionMark(searchDto.getBusiness());
	                  seperator = "\" OR business:\"";
	                  if(paramWeightage != null && paramWeightage.get("business") != null && !paramWeightage.get("business").isEmpty()){
	                	  query = query + " OR ( business:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )^"+paramWeightage.get("business");
	                  } else {
	                	  query = query + " OR ( business:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )";
	                  }
	                  
	                  resultLabel = resultLabel + " | Business Segment: \'"
	                                + searchDto.getBusiness() + "\'";
	            }
	           
	            if (searchDto.getCountry() != null) {
	                  commaCheckedValue = checkForQuestionMark(searchDto.getCountry());
	                  seperator = "\" OR country:\"";
	                  if(paramWeightage != null && paramWeightage.get("country") != null && !paramWeightage.get("country").isEmpty()){
	                	  query = query + " OR ( country:\""
	                                + StringUtils.join(commaCheckedValue, seperator)
	                                + "\" )^"+paramWeightage.get("country");
	                  } else {
	                	  query = query + " OR ( country:\""
	                                + StringUtils.join(commaCheckedValue, seperator)
	                                + "\" )";
	                  }
	                  
	                  resultLabel = resultLabel + " | Country: \'"
	                                + searchDto.getCountry() + "\'";
	            }
	            if (searchDto.getJobFamily() != null) {
	                  commaCheckedValue = checkForQuestionMark(searchDto.getJobFamily());
	                  seperator = "\" OR jobFamily:\"";
	                  if(paramWeightage != null && paramWeightage.get("jobFamily") != null && !paramWeightage.get("jobFamily").isEmpty()){
	                	  query = query + " OR ( jobFamily:\"" + StringUtils.join(commaCheckedValue, seperator)
	                                	+ "\" )^" + paramWeightage.get("jobFamily");
	                  } else {
	                	  query = query + " OR ( jobFamily:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )";
	                  }
	                  resultLabel = resultLabel + " + Job Family: \'"
	                                + searchDto.getJobFamily() + "\'";
	            }
	            
	            query = query + ") ";
	            if (searchDto.getFunction() != null) {
	                 commaCheckedValue = checkForQuestionMark(searchDto.getFunction());
	                 seperator = "\" OR jobFunction:\"";
	               	 query = query + " AND ( jobFunction:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )";
	                 resultLabel = resultLabel + " + Function: \'" + searchDto.getFunction() + "\'";
		    	 }
	            
	            if (searchDto.getIfg() != null) {
	                  commaCheckedValue = checkForQuestionMark(searchDto.getIfg());
	                  seperator = "\" OR ifg:\"";
	                  
	                  String ifg = (searchDto.getIfg() != null && searchDto.getIfg().size() > 0) ? searchDto.getIfg().get(0) : null ;
	                  String ifgWeightage = "1";
	                  if(paramWeightage != null && paramWeightage.get("ifg") != null && !paramWeightage.get("ifg").isEmpty()){
	                	  ifgWeightage = paramWeightage.get("ifg");
	                  }
	                  if("Baker Hughes GE".equals(ifg)) {
	                	  query = query + " AND ((ifg:\"GE Oil & Gas\")^" + ifgWeightage +" OR (ifg:\"Baker Hughes GE\")^1)";  
	                  } else if("GE Oil & Gas".equals(ifg)) {
	                	  query = query + " AND ((ifg:\"GE Oil & Gas\")^1 OR (ifg:\"Baker Hughes GE\")^" +ifgWeightage+ ")";
	                  }
	                  
	                  /*query = query + " AND ( ifg:\""
	                                + StringUtils.join(commaCheckedValue, seperator)
	                                + "\" )";*/
	                  
	                  /*resultLabel = resultLabel + " ) + GE Business: \'"
	                                + searchDto.getIfg() + "\'";*/
	            }
	            
	            query = query + " AND";
	            
	            if (searchDto.getManagerDetails() != null
                        && !searchDto.getManagerDetails().isEmpty()) {
	                 query = query + " NOT ( acl_MGR:("
	                               + searchDto.getManagerDetails() + "))"
	                               + " AND NOT ( sso:("
	                               + searchDto.getManagerDetails() + "))";
	                 query = escapeSpecialCharacters(query, false);
//	                 resultLabel = resultLabel + " + Manager: \'"
//	                               + searchDto.getManagerDetails() + "\'";
	            }
	            
	            if (searchDto.getBand() != null) {
	            	commaCheckedValue = checkForQuestionMark(getBandValues(searchDto.getBand()));
	            	seperator = "\" OR band:\"";
	            	query = query + " AND ( band:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )";
//	            	resultLabel = resultLabel + " + Band: \'" + searchDto.getBand() + "\'";
	            }
	            
	            if(null != userSSO) {
	            	BaseModelCollection<Long> ssoList = getAllConnections(userSSO);
	            	if(null != ssoList && !ssoList.isEmpty()) {
	            		seperator = "\" OR sso:\"";
		            	query = query + " AND NOT ( sso:\"" + StringUtils.join(ssoList.getList(), seperator) + "\" )";
	            	}
	            }
	            
	            query = query + " AND ( connectionShared:\"N\")"; 
	            
//	            query = query + ")";
//	            query = query.replaceFirst("AND ", "");
	     } else if (searchDto != null && facetConnect) {
	    	 
	    	 if (searchDto.getTitle() != null && !searchDto.getTitle().isEmpty()) {
	    		 seperator = "\" OR title:\"";
	    		 query = query + "AND ( title:(" + searchDto.getTitle() + ") OR empLocalTitle:(" + searchDto.getTitle() + ")) ";
                 query = escapeSpecialCharacters(query, false);
	    	 }
	    	 
	    	 if (searchDto.getBusiness() != null) {
                 commaCheckedValue = checkForQuestionMark(searchDto.getBusiness());
                 seperator = "\" OR business:\"";
               	 query = query + " AND ( business:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )";
	    	 }
          
	    	 if (searchDto.getCountry() != null) {
                 commaCheckedValue = checkForQuestionMark(searchDto.getCountry());
                 seperator = "\" OR country:\"";
               	 query = query + " AND ( country:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )";
	    	 }
           
	    	 if (searchDto.getFunction() != null) {
                 commaCheckedValue = checkForQuestionMark(searchDto.getFunction());
                 seperator = "\" OR jobFunction:\"";
               	 query = query + " AND ( jobFunction:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )";
	    	 }
	    	 
	    	 if (searchDto.getJobFamily() != null) {
                 commaCheckedValue = checkForQuestionMark(searchDto.getJobFamily());
                 seperator = "\" OR jobFamily:\"";
                 query = query + " AND ( jobFamily:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )";
	    	 }
	    	 
	    	 /*if (searchDto.getCity() != null) {
	    		 commaCheckedValue = checkForQuestionMark(searchDto.getCity());
                 seperator = "\" OR empCity:\"";
                 query = query + " AND ( empCity:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )";
	    	 }*/
	    	 
	    	 if (searchDto.getIfg() != null) {
                 commaCheckedValue = checkForQuestionMark(searchDto.getIfg());
                 seperator = "\" OR ifg:\"";
                 query = query + " AND ( ifg:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )";
	    	 }
	     }
	     query = query.replaceFirst("AND ", "");
	     resultLabel = resultLabel.replaceAll("\\[", "").replaceAll("\\]", "");
	     resultLabel = resultLabel.replaceFirst("\\+ ", "");
	     queryAndLabel.put("query", query);
  	     queryAndLabel.put("label", resultLabel);
	     return queryAndLabel;
   }
	
    private List<String> getBandValues(List<String> bandList) {

    	if (bandList != null && bandList.size() == 1) {
    		String band = bandList.get(0);
    		if("LTB".equals(band)) {
    			bandList.add("LPB");
    		} else if("LPB".equals(band)) {
    			bandList.add("LTB");
    		} else if("EB".equals(band)) {
    			bandList.add("SEB");
    		} else if("SEB".equals(band)) {
    			bandList.add("EB");
    			bandList.add("VP");
    		} else if("VP".equals(band)) {
    			bandList.add("SEB");
    		}
    	}
    	
    	return bandList;
	}

    public Map<String, String> createMentoConnectionQuery(Long userSSO, SearchLuceneDto searchDto, boolean facetConnect, Map<String, String> paramWeightage) {
		
	     Map<String, String> queryAndLabel = new HashMap<String, String>();
	     String query = "";
	     String seperator = "";
	     List<String> commaCheckedValue = null;
	     
	     if (searchDto != null && !facetConnect) {
	    	 	query = query + "(";
	            
	    	 	if (searchDto.getIfg() != null) {
	                  commaCheckedValue = checkForQuestionMark(searchDto.getIfg());
	                  seperator = "\" OR ifg:\"";
	                  if(paramWeightage != null && paramWeightage.get("ifg") != null && !paramWeightage.get("ifg").isEmpty()){
	                	  query = query + " OR ( ifg:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )^"+paramWeightage.get("ifg");
	                  } else {
	                	  query = query + " OR ( ifg:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )";
	                  }
	            }
	    	 	
	            if (searchDto.getSubBusiness() != null) {
	                  commaCheckedValue = checkForQuestionMark(searchDto.getSubBusiness());
	                  seperator = "\" OR subBusiness:\"";
	                  if(paramWeightage != null && paramWeightage.get("subBusiness") != null && !paramWeightage.get("subBusiness").isEmpty()){
	                	  query = query + " OR ( subBusiness:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )^"+paramWeightage.get("subBusiness");
	                  } else {
	                	  query = query + " OR ( subBusiness:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )";
	                  }
	            }
	           
	            if (searchDto.getFunction() != null) {
	                  commaCheckedValue = checkForQuestionMark(searchDto.getFunction());
	                  seperator = "\" OR jobFunction:\"";
	                  if(paramWeightage != null && paramWeightage.get("jobFunction") != null && !paramWeightage.get("jobFunction").isEmpty()){
	                	  query = query + " OR ( jobFunction:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )^"+paramWeightage.get("jobFunction");
	                  } else {
	                	  query = query + " OR ( jobFunction:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )";
	                  }
	            }
	            
	            if (searchDto.getCountry() != null) {
	                  commaCheckedValue = checkForQuestionMark(searchDto.getCountry());
	                  seperator = "\" OR country:\"";
	                  if(paramWeightage != null && paramWeightage.get("country") != null && !paramWeightage.get("country").isEmpty()){
	                	  query = query + " OR ( country:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )^"+paramWeightage.get("country");
	                  } else {
	                	  query = query + " OR ( country:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )";
	                  }
	            }
	            
	            if (searchDto.getJobFamily() != null) {
	                  commaCheckedValue = checkForQuestionMark(searchDto.getJobFamily());
	                  seperator = "\" OR jobFamily:\"";
	                  if(paramWeightage != null && paramWeightage.get("jobFamily") != null && !paramWeightage.get("jobFamily").isEmpty()){
	                	  query = query + " OR ( jobFamily:\"" + StringUtils.join(commaCheckedValue, seperator)	+ "\" )^" + paramWeightage.get("jobFamily");
	                  } else {
	                	  query = query + " OR ( jobFamily:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )";
	                  }
	            }
	            
	            BaseModelCollection<String> userMenteeInterests = employeeDao.getEmpMenteeInterests(userSSO);
	            if(userMenteeInterests != null && !userMenteeInterests.isEmpty()) {
	            	seperator = "\" OR mentorAllInterest:\"";
	                query = query + " OR ( mentorAllInterest:\"" + StringUtils.join(userMenteeInterests.getList(), seperator) + "\" )";
	            }
	            
	            query = query + ") ";

	            if(searchDto.getMentoring() != null && !searchDto.getMentoring().isEmpty()){
					if("MENTOR".equalsIgnoreCase(searchDto.getMentoring())){
                   	 	query = query + "AND ( connectMentorAll:\"Y\") "; 
					}else if("MENTEE".equalsIgnoreCase(searchDto.getMentoring())){
                   	 query = query + "AND ( connectMenteeAll:\"Y\") ";        
					}else if("BOTH".equalsIgnoreCase(searchDto.getMentoring())){
                   	 query = query + "AND ( connectMentorAll:\"Y\"" + "OR  connectMenteeAll:\"Y\" ) ";        
					}
                   
				 }
	            
	            if(null != userSSO) {
//		            query = query + " AND NOT ( sso:\"" + userSSO + "\" )";
		            BaseModelCollection<Long> ssoList = getAllMentors(userSSO);
		            if(null != ssoList) {
		            	ssoList.addAll(getAllMentees(userSSO).getList());
		            	ssoList.add(userSSO);
		            	seperator = "\" OR sso:\"";
			           	query = query + " AND NOT ( sso:\"" + StringUtils.join(ssoList.getList(), seperator) + "\" )";
		            }
	            }
	            query = query.replaceFirst("OR ", "");
	     } else if (searchDto != null && facetConnect) {
	    	 
	    	 if (searchDto.getTitle() != null && !searchDto.getTitle().isEmpty()) {
	    		 seperator = "\" OR title:\"";
	    		 query = query + "AND ( title:(" + searchDto.getTitle() + ") OR empLocalTitle:(" + searchDto.getTitle() + ")) ";
                query = escapeSpecialCharacters(query, false);
	    	 }
	    	 
	    	 if (searchDto.getBusiness() != null) {
                commaCheckedValue = checkForQuestionMark(searchDto.getBusiness());
                seperator = "\" OR business:\"";
              	 query = query + " AND ( business:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )";
	    	 }
         
	    	 if (searchDto.getCountry() != null) {
                commaCheckedValue = checkForQuestionMark(searchDto.getCountry());
                seperator = "\" OR country:\"";
              	 query = query + " AND ( country:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )";
	    	 }
          
	    	 if (searchDto.getFunction() != null) {
                commaCheckedValue = checkForQuestionMark(searchDto.getFunction());
                seperator = "\" OR jobFunction:\"";
              	 query = query + " AND ( jobFunction:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )";
	    	 }
	    	 
	    	 if (searchDto.getJobFamily() != null) {
                commaCheckedValue = checkForQuestionMark(searchDto.getJobFamily());
                seperator = "\" OR jobFamily:\"";
                query = query + " AND ( jobFamily:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )";
	    	 }
	    	 
	    	/* if (searchDto.getCity() != null) {
	    		 commaCheckedValue = checkForQuestionMark(searchDto.getCity());
                seperator = "\" OR empCity:\"";
                query = query + " AND ( empCity:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )";
	    	 }*/
	    	 
	    	 if (searchDto.getIfg() != null) {
                commaCheckedValue = checkForQuestionMark(searchDto.getIfg());
                seperator = "\" OR ifg:\"";
                query = query + " AND ( ifg:\"" + StringUtils.join(commaCheckedValue, seperator) + "\" )";
	    	 }
	    	 query = query.replaceFirst("AND ", "");
	     }
	     queryAndLabel.put("query", query);
 	     queryAndLabel.put("label", "");
	     return queryAndLabel;
  }
    
    @Override
    public BaseModelCollection<Long> getAllMentors(Long sso) {
    	return employeeDao.getAllMentors(sso);
    }
    
    @Override
    public BaseModelCollection<Long> getAllMentees(Long sso) {
    	return employeeDao.getAllMentees(sso);
    }
    
	@Override
    public BaseModelCollection<Long> getAllConnections(Long sso) {
    	return searchDao.getAllConnections(sso);
    }
    
    @Override
    public BaseModelCollection<Expertise> getAllExpertise() {
    	return searchDao.getAllExpertise();
    }
    
    @Override
    public EmployeeExpertiseDto getExpertiseByParams(int offset, String status, String date, String expName, boolean isExcelDownload) {
    	return searchDao.getExpertiseByParams(offset, status, date, expName, isExcelDownload);
    }
    
    @Override
    public boolean updateExpertiseTaxo(List<Expertise> expertise) {
    	return searchDao.updateExpertiseTaxo(expertise);
    }
    
    @Override
    public BaseModelCollection<MentoringInterest> getMentoringInterest() {
    	return searchDao.getMentoringInterest();
    }
    
	public Map<String, String> createParentQuery(SearchLuceneDto searchDto,
            boolean clientSearch, boolean clientSearchAll) {
	     Map<String, String> queryAndLabel = new HashMap<String, String>();
	     String query = "";
	     String seperator = "";
	     //String seperator1 = "";
	     String resultLabel = "";
	     List<String> commaCheckedValue = null;
	     boolean hasRoleSA = false;
	     boolean isFuncHR = false;
	     Map<String, DataGroup> dataGroups = authEvaluator
					.getDataGroupsForContextAsMap(
							PersonAuthUtil.getPrincipal(),
							PersonAuthUtil.getAuthorities(), PersonAuthUtil.getLoggedSSO());
	     List<String> rolesList = authEvaluator.getAutorizedRoles(
	                  PersonAuthUtil.getPrincipal(), PersonAuthUtil.getAuthorities());
	     for (String role : rolesList) {
	            if (role.equalsIgnoreCase("ROLE_SA")) {
	                  hasRoleSA = true;
	            } else if (role.equalsIgnoreCase("FUNCTION_HR")) {
	                  isFuncHR = true;
	            }
	     }
	     if (searchDto != null) {
	    	 if(searchDto.getSearchByCategory()!= null && searchDto.getSearchByCategory().equalsIgnoreCase("N")){
	    		 if(searchDto.getSearchAllInput()!=null){
	    			 query = createSearchAllInputQuery(escapeSpecialCharacters(searchDto.getSearchAllInput(), false), hasRoleSA, isFuncHR, clientSearch, clientSearchAll);
		    		 
	    		 }
	    		 resultLabel = resultLabel + " + Combined Search : \'"
                         + searchDto.getSearchAllInput() + "\'";

	    	 }else{ 
	            if (searchDto.getSsoName() != null
	                         && !searchDto.getSsoName().isEmpty()) {
	                  // query = query + "AND ( sso:"+searchDto.getSsoName() +
	                  // " OR empName:" +searchDto.getSsoName() +") ";
	                  query = query + "AND ( ssoName:(" + searchDto.getSsoName()
	                                + ") OR empLastName:(" + searchDto.getSsoName()
	                                + ")^2) ";
	                  query = escapeSpecialCharacters(query, false);
	                  resultLabel = resultLabel + " + Name or SSO: \'"
	                                + searchDto.getSsoName() + "\'";
	            }
	            if (searchDto.getTitle() != null && !searchDto.getTitle().isEmpty()) {
	                  query = query + "AND ( title:(" + searchDto.getTitle() + ") OR empLocalTitle:(" + searchDto.getTitle() + ")) ";
	                  query = escapeSpecialCharacters(query, false);
	                  resultLabel = resultLabel + " + Title: \'"
	                                + searchDto.getTitle() + "\'";
	            }
	            if (searchDto.getEmailPhone() != null
	                         && !searchDto.getEmailPhone().isEmpty()) {
	                  String value = "";
	                  if (searchDto.getEmailPhone()
	                                .matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
	                         value = value + "AND ( emailPhone:\""
	                                       + searchDto.getEmailPhone() + "\")";
	                  } else {
	                         if (searchDto.getEmailPhone().startsWith("*") || searchDto.getEmailPhone().startsWith("+")) {
	                                value = value + "AND ( emailPhone:("
	                                              + searchDto.getEmailPhone().substring(1) + ")) ";
	
	                         } else {
	                                value = value + "AND ( emailPhone:("
	                                              + searchDto.getEmailPhone() + ")) ";
	                         }
	                  }
	                  resultLabel = resultLabel + " + Phone or Email: \'"
	                                + searchDto.getEmailPhone() + "\'";
	                  query = query + escapeSpecialCharacters(value, false);
	            }
	            if (searchDto.getIfg() != null) {
	                  commaCheckedValue = checkForQuestionMark(searchDto.getIfg());
	                  seperator = "\" OR ifg:\"";
	                  //seperator1= "\" OR empReportingIFG:\"";
	                  query = query + "AND ( ifg:\""
	                                + StringUtils.join(commaCheckedValue, seperator)
	                                + "\" ) ";
	                 /* query = query + "OR ( empReportingIFG:\""
                              + StringUtils.join(commaCheckedValue, seperator1)
                              + "\" )) ";*/
	                  resultLabel = resultLabel + " + GE Business: \'"
	                                + searchDto.getIfg() + "\'";
	            }
	            if (searchDto.getBusiness() != null) {
	                  commaCheckedValue = checkForQuestionMark(searchDto.getBusiness());
	                  seperator = "\" OR business:\"";
	                  //seperator1 = "\" OR empReportingBusiness:\"";
	                  query = query + "AND ( business:\""
	                                + StringUtils.join(commaCheckedValue, seperator)
	                                + "\" ) ";
	                  /*query = query + "OR ( empReportingBusiness:\""
                              + StringUtils.join(commaCheckedValue, seperator1)
                              + "\" )) ";*/
	                  resultLabel = resultLabel + " + Business Segment: \'"
	                                + searchDto.getBusiness() + "\'";
	            }
	            if (searchDto.getSubBusiness() != null) {
	                  commaCheckedValue = checkForQuestionMark(searchDto.getSubBusiness());
	                  seperator = "\" OR subBusiness:\"";
	                  query = query
	                                + "AND ( subBusiness:\""
	                                + StringUtils.join(commaCheckedValue,
	                                              seperator) + "\" ) ";
	                  resultLabel = resultLabel + " + Sub-Business: \'"
	                                + searchDto.getSubBusiness() + "\'";
	            }
	            if (searchDto.getReportingBusiness() != null) {
	                  commaCheckedValue = checkForQuestionMark(searchDto.getReportingBusiness());
	                  seperator = "\" OR empReportingBusiness:\"";
	                  query = query
	                                + "AND ( empReportingBusiness:\""
	                                + StringUtils.join(commaCheckedValue,
	                                              seperator) + "\" ) ";
	                  resultLabel = resultLabel + " + Reporting Business: \'"
	                                + searchDto.getReportingBusiness() + "\'";
	            }
	            if (searchDto.getReportingIFG() != null) {
	                  commaCheckedValue = checkForQuestionMark(searchDto.getReportingIFG());
	                  seperator = "\" OR empReportingIFG:\"";
	                  query = query
	                                + "AND ( empReportingIFG:\""
	                                + StringUtils.join(commaCheckedValue,
	                                              seperator) + "\" ) ";
	                  resultLabel = resultLabel + " + Reporting IFG: \'"
	                                + searchDto.getReportingIFG() + "\'";
	            }
	            if (searchDto.getManagerDetails() != null
	                         && !searchDto.getManagerDetails().isEmpty()) {
	                  query = query + "AND ( managerDetails:("
	                                + searchDto.getManagerDetails() + ")) ";
	                  query = escapeSpecialCharacters(query, false);
	                  resultLabel = resultLabel + " + Manager: \'"
	                                + searchDto.getManagerDetails() + "\'";
	            }
	            if (searchDto.getOrganization() != null
	                         && !searchDto.getOrganization().isEmpty()) {
	                  String[] orgList = searchDto.getOrganization().split(" ");
	                  String orgQuery = "";
	                  for (String org : orgList) {
	                         org = "+" + org + " ";
	                         orgQuery = orgQuery + org;
	                  }
	                  query = query + "AND ( organization:(" + orgQuery + ")) ";
	                  query = escapeSpecialCharacters(query, false);
	                  resultLabel = resultLabel + " + Organization: \'"
	                                + searchDto.getOrganization() + "\'";
	            }
	            if (searchDto.getLocation() != null
	                         && !searchDto.getLocation().isEmpty()) {
	                  query = query + "AND ( employeeLocation:("
	                                + searchDto.getLocation() + ")) ";
	                  query = escapeSpecialCharacters(query, false);
	                  resultLabel = resultLabel + " + Location: \'"
	                                + searchDto.getLocation() + "\'";
	            }
	            if (searchDto.getRegion() != null) {
	                  commaCheckedValue = checkForQuestionMark(searchDto.getRegion());
	                  seperator = "\" OR region:\"";
	                  query = query + "AND ( region:\""
	                                + StringUtils.join(commaCheckedValue, seperator)
	                                + "\" ) ";
	                  resultLabel = resultLabel + " + Region: \'"
	                                + searchDto.getRegion() + "\'";
	            }
	            if (searchDto.getCountry() != null) {
	                  commaCheckedValue = checkForQuestionMark(searchDto.getCountry());
	                  seperator = "\" OR country:\"";
	                  query = query + "AND ( country:\""
	                                + StringUtils.join(commaCheckedValue, seperator)
	                                + "\" ) ";
	                  resultLabel = resultLabel + " + Country: \'"
	                                + searchDto.getCountry() + "\'";
	            }
	            if (searchDto.getFunction() != null) {
	                  commaCheckedValue = checkForQuestionMark(searchDto.getFunction());
	                  seperator = "\" OR jobFunction:\"";
	                  query = query + "AND ( jobFunction:\""
	                                + StringUtils.join(commaCheckedValue, seperator)
	                                + "\" ) ";
	                  resultLabel = resultLabel + " + Function: \'"
	                                + searchDto.getFunction() + "\'";
	            }
	            if (searchDto.getJobFamily() != null) {
	                  commaCheckedValue = checkForQuestionMark(searchDto.getJobFamily());
	                  seperator = "\" OR jobFamily:\"";
	                  query = query + "AND ( jobFamily:\""
	                                + StringUtils.join(commaCheckedValue, seperator)
	                                + "\" ) ";
	                  resultLabel = resultLabel + " + Job Family: \'"
	                                + searchDto.getJobFamily() + "\'";
	            }
	            if (searchDto.getBand() != null) {
	                  if (clientSearch || hasRoleSA || isFuncHR) {
	                         commaCheckedValue = checkForQuestionMark(searchDto.getBand());
	                         seperator = "\" OR band:\"";
	                         query = query + "AND ( band:\""
	                                       + StringUtils.join(commaCheckedValue, seperator)
	                                       + "\" ) ";
	                         resultLabel = resultLabel + " + Band: \'"
	                                       + searchDto.getBand() + "\'";
	                  } else {
	                         resultLabel = "";
	                         resultLabel = "Band search cannot be performed using 'SearchAll' ";
	                         throw new RuntimeException(
	                                       "Band search cannot be performed using 'SearchAll' ");
	
	                  }
	            }
	            if (searchDto.getTalentPool() != null) {
	                  if (clientSearch || hasRoleSA || dataGroups.get("ResumeCareerOpportunities") != null) {
	                         commaCheckedValue = checkForQuestionMark(searchDto.getTalentPool());
	                         seperator = "\" OR talentPoolAll:\"";
	                         query = query + "AND ( talentPoolAll:\""
	                                       + StringUtils.join(commaCheckedValue, seperator)
	                                       + "\" ) ";
	                         resultLabel = resultLabel + " + Career Opportunties: \'"
	                                       + searchDto.getTalentPool() + "\'";
	                  } else {
	                         resultLabel = "";
	                         resultLabel = "Career Opportunties search cannot be performed using 'SearchAll' ";
	                         throw new RuntimeException(
	                                       "Career Opportunties search cannot be performed using 'SearchAll' ");
	
	                  }
	            }
	            if (searchDto.getEduTrng() != null
	                         && !searchDto.getEduTrng().equalsIgnoreCase("")) {
	            	resultLabel = resultLabel + " + Education or Training: \'"
	                                + searchDto.getEduTrng() + "\'";
	            }
	            if (searchDto.getWorkHistory() != null
	                         && !searchDto.getWorkHistory().equalsIgnoreCase("")) {
	            	resultLabel = resultLabel + " + Work History: \'"
	                                + searchDto.getWorkHistory() + "\'";
	            }
	            if (searchDto.getAffiliations() != null
                        && !searchDto.getAffiliations().equalsIgnoreCase("")) {
	            	resultLabel = resultLabel + " + External Affiliations: \'"
	                               + searchDto.getAffiliations() + "\'";
	            }
	            if (searchDto.getCareerInterests() != null
                        && !searchDto.getCareerInterests().equalsIgnoreCase("")) {
	            	resultLabel = resultLabel + " + Career Aspirations: \'"
	                               + searchDto.getCareerInterests() + "\'";
	            }
	            if (searchDto.getCustomerSuppliers() != null
                        && !searchDto.getCustomerSuppliers().equalsIgnoreCase("")) {
	            	resultLabel = resultLabel + " + Customers & Suppliers: \'"
	                               + searchDto.getCustomerSuppliers() + "\'";
	            }
	            if (searchDto.getInitiativesProjects() != null
                        && !searchDto.getInitiativesProjects().equalsIgnoreCase("")) {
	            	resultLabel = resultLabel + " + Initiatives & Projects: \'"
	                               + searchDto.getInitiativesProjects() + "\'";
	            }
	            if (searchDto.getInterests() != null
                        && !searchDto.getInterests().equalsIgnoreCase("")) {
	            	resultLabel = resultLabel + " + Interests: \'"
	                               + searchDto.getInterests() + "\'";
	            }
	            if (searchDto.getLanguageProficiency() != null
                        && !searchDto.getLanguageProficiency().isEmpty()) {
	            	resultLabel = resultLabel + " + Languages Known: \'"
	                               + searchDto.getLanguageProficiency() + "\'";
	            }
	            //Additional fields added!
	            
	            if (searchDto.getPrsnType() != null && !searchDto.getPrsnType().isEmpty()) {
	                  if(searchDto.getPrsnType().contains(",")){
	                	  String[] temp = searchDto.getPrsnType().split(",");
	                	  query = query + "AND ( personType:(" + temp[0] + ") OR personType:(" + temp[1] + ") ) ";
	                  }else{
	                	  query = query + "AND ( personType:(" + searchDto.getPrsnType() + ")) ";
	                  }
	                  query = escapeSpecialCharacters(query, false);
	                  resultLabel = resultLabel + " + Person Type: \'"
	                                + searchDto.getPrsnType() + "\'";
	            }
	            if (searchDto.getDirectoryIncl() != null && !searchDto.getDirectoryIncl().isEmpty()) {
	                  query = query + "AND ( directoryInclusion:(" + searchDto.getDirectoryIncl() + ")) ";
	                  query = escapeSpecialCharacters(query, false);
	                  resultLabel = resultLabel + " + Directory Inclusion: \'"
	                                + searchDto.getDirectoryIncl() + "\'";
	            }
	            if (searchDto.getTechDisciplineSTD() != null) {
	            	StringCatalogDto catalogDto = searchService.getTechnicalDiscipline();
	                  commaCheckedValue = checkForQuestionMark(searchDto.getTechDisciplineSTD());
	                  seperator = " OR techDisciplineSTD:";
	                  for(int i=0; i<commaCheckedValue.size(); i++){
	                	  for(int c=0; c<catalogDto.getCatalog().size(); c++){
	                		 if( commaCheckedValue.get(i).equalsIgnoreCase(catalogDto.getCatalog().get(c))){
	                			 commaCheckedValue.set(i, "~~" + commaCheckedValue.get(i) + "~~");
	                		 }
	                	  }
	                  }	                  
	                  query = query + "AND ( techDisciplineSTD:"
	                                + StringUtils.join(commaCheckedValue, seperator)
	                                + " ) ";
	                  query = query.replaceAll("~~", "\"");
	                  resultLabel = resultLabel + " + Technical Discipline: \'"
	                                + searchDto.getTechDisciplineSTD() + "\'";                
	                  
	            }
	            if (searchDto.getProfessionalSummary() != null && !searchDto.getProfessionalSummary().isEmpty()) {
	                  query = query + "AND (professionalSummaryShared:(" + searchDto.getProfessionalSummary() + ")) ";
	                  query = escapeSpecialCharacters(query, false);
	                  resultLabel = resultLabel + " + Professional Summary: \'"
	                                + searchDto.getProfessionalSummary() + "\'";
	            }
	            if (searchDto.getWorkMobility() != null
                        && !searchDto.getWorkMobility().isEmpty()) {
	            	resultLabel = resultLabel + " + Work Mobility";
	            	if(searchDto.getWorkMobilityType()!=null && searchDto.getWorkMobilityType().equalsIgnoreCase("INSIDE")){
	            		resultLabel = resultLabel + " within: \'";
	            	}else if(searchDto.getWorkMobilityType()!=null && searchDto.getWorkMobilityType().equalsIgnoreCase("OUTSIDE")){
	            		resultLabel = resultLabel + " outside: \'";
	            	}else if(searchDto.getWorkMobilityType()!=null && searchDto.getWorkMobilityType().equalsIgnoreCase("BOTH")){
	            		resultLabel = resultLabel + " : \'";
	            	}
	            	
	            	resultLabel = resultLabel + searchDto.getWorkMobility() + "\'";
	            }
	            if(searchDto.getMentoring()!=null && !searchDto.getMentoring().isEmpty()){
	            	resultLabel = resultLabel + " + Mentoring: ";
	            	if(searchDto.getMentoring()!=null && searchDto.getMentoring().equalsIgnoreCase("MENTOR")){
	            		resultLabel = resultLabel + " Search for a Mentor ";
	            	}else if(searchDto.getMentoring()!=null && searchDto.getMentoring().equalsIgnoreCase("MENTEE")){
	            		resultLabel = resultLabel + " Search for a Mentee ";
	            	}else if(searchDto.getMentoring()!=null && searchDto.getMentoring().equalsIgnoreCase("BOTH")){
	            		resultLabel = resultLabel + " Search for both";
	            	}
	            }
	            if (searchDto.getRotationNumber() != null && !searchDto.getRotationNumber().isEmpty()) {
	                  query = query + "AND (rotationNumber:(" + searchDto.getRotationNumber() + ")) ";
	                  query = escapeSpecialCharacters(query, false);
	                  resultLabel = resultLabel + " + Rotation Number: \'"
	                                + searchDto.getRotationNumber() + "\'";
	            }
	            if (searchDto.getAssignmentLeaderName()!= null && !searchDto.getAssignmentLeaderName().isEmpty()) {
	                  query = query + "AND (assignmentLeaderName:(" + searchDto.getAssignmentLeaderName() + ")) ";
	                  query = escapeSpecialCharacters(query, false);
	                  resultLabel = resultLabel + " + Assignment Leader Name: \'"
	                                + searchDto.getAssignmentLeaderName() + "\'";
	            }
	            if (searchDto.getAssignmentTitle() != null && !searchDto.getAssignmentTitle().isEmpty()) {
	                  query = query + "AND (assignmentTitle:(" + searchDto.getAssignmentTitle() + ")) ";
	                  query = escapeSpecialCharacters(query, false);
	                  resultLabel = resultLabel + " + Assignment Title: \'"
	                                + searchDto.getAssignmentTitle() + "\'";
	            }
	            if (searchDto.getAssignmentLeaderFor() != null) {
	                  commaCheckedValue = checkForQuestionMark(searchDto.getAssignmentLeaderFor());
	                  seperator = "\" OR assignmentLeaderFor:\"";
	                  query = query
	                                + "AND ( assignmentLeaderFor:\""
	                                + StringUtils.join(commaCheckedValue,
	                                              seperator) + "\" ) ";
	                  resultLabel = resultLabel + " + Assignment Leader For: \'"
	                                + searchDto.getAssignmentLeaderFor() + "\'";
	            }
	            if (searchDto.getAssignmentSubBusiness() != null) {
	                  commaCheckedValue = checkForQuestionMark(searchDto.getAssignmentSubBusiness());
	                  seperator = "\" OR assignmentSubBusiness:\"";
	                  query = query
	                                + "AND ( assignmentSubBusiness:\""
	                                + StringUtils.join(commaCheckedValue,
	                                              seperator) + "\" ) ";
	                  resultLabel = resultLabel + " + Assignment Sub-Business: \'"
	                                + searchDto.getAssignmentSubBusiness() + "\'";
	            }
	            if (searchDto.getEmpExpertise() != null
                        && !searchDto.getEmpExpertise().isEmpty()) {
	            	commaCheckedValue = checkForQuestionMark(searchDto.getEmpExpertise());
	            	seperator = "\" OR eeExpertiseAll:\"";
	            	query = query + "AND ( eeExpertiseAll:\"" + escapeSpecialCharacters(StringUtils.join(commaCheckedValue, seperator), false)//.toLowerCase()
                                     + "\" ) ";
	            	resultLabel = resultLabel + " + Expertise : \'"
                            + searchDto.getEmpExpertise() + "\'";

				}
	            if (searchDto.getMentoring() != null
                        && !searchDto.getMentoring().isEmpty()) {
					if(searchDto.getMentoring()!=null && searchDto.getMentoring().equalsIgnoreCase("MENTOR")){
                   	 query = query + "AND ( connectMentorAll:\"Y\") "; 
                   	
                   }else if(searchDto.getMentoring()!=null && searchDto.getMentoring().equalsIgnoreCase("MENTEE")){
                   	 query = query + "AND ( connectMenteeAll:\"Y\") ";        
                 
                   }else if(searchDto.getMentoring()!=null && searchDto.getMentoring().equalsIgnoreCase("BOTH")){
                   	 query = query + "AND ( connectMentorAll:\"Y\"" + "OR  connectMenteeAll:\"Y\" ) ";        
                   }
                   
				 }
	            if (!hasRoleSA) {
	                  if (clientSearch) {
	                         if(!query.equalsIgnoreCase("*") && !clientSearchAll){
							 if (searchDto.getEduTrng() != null
	                                       && !searchDto.getEduTrng().equalsIgnoreCase("")) {
									query = query + "AND ( educationTrainingAll:(" + escapeSpecialCharacters(searchDto.getEduTrng(),
					            			false) + ")) "; 

								}
							 if (searchDto.getWorkHistory() != null
                                     && !searchDto.getWorkHistory().equalsIgnoreCase("")) {
								query = query + "AND ( workHistoryAll:(" + escapeSpecialCharacters(searchDto.getWorkHistory(),
				            			false) + ")) "; 

							 }
							 if (searchDto.getCareerInterests() != null
                                     && !searchDto.getCareerInterests().equalsIgnoreCase("")) {
								query = query + "AND ( careerInterestsAll:(" + escapeSpecialCharacters(searchDto.getCareerInterests(),
				            			false) + ")) "; 

							 }
							 if (searchDto.getInitiativesProjects() != null
                                     && !searchDto.getInitiativesProjects().equalsIgnoreCase("")) {
								query = query + "AND ( projectsAll:(" + escapeSpecialCharacters(searchDto.getInitiativesProjects(),
				            			false) + ")) "; 

							 }
							 if (searchDto.getCustomerSuppliers() != null
                                     && !searchDto.getCustomerSuppliers().equalsIgnoreCase("")) {
								query = query + "AND ( customersSuppliersAll:(" + escapeSpecialCharacters(searchDto.getCustomerSuppliers(),
				            			false) + ")) "; 

							 }
							 if (searchDto.getLanguageProficiency() != null
                                     && !searchDto.getLanguageProficiency().isEmpty()) {
								 commaCheckedValue = checkForQuestionMark(searchDto.getLanguageProficiency());
								 
		                         seperator = "* OR languagesAll:";
		                         query = query + "AND ( languagesAll:" + escapeSpecialCharacters(StringUtils.join(commaCheckedValue, seperator), false)//.toLowerCase()
		                                       + "* ) ";

							 }
							 if (searchDto.getInterests() != null
                                     && !searchDto.getInterests().equalsIgnoreCase("")) {
								query = query + "AND ( interestsAll:(" + escapeSpecialCharacters(searchDto.getInterests(),
				            			false) + ")) "; 

							 }
							 if (searchDto.getAffiliations() != null
                                     && !searchDto.getAffiliations().equalsIgnoreCase("")) {
								query = query + "AND ( externalAffiliationsAll:(" + escapeSpecialCharacters(searchDto.getAffiliations(),
				            			false) + ")) "; 
							 }
							 if (searchDto.getWorkMobility() != null
                                     && !searchDto.getWorkMobility().isEmpty()) {
								 commaCheckedValue = checkForQuestionMark(searchDto.getWorkMobility());
		                        if(searchDto.getWorkMobilityType()!=null && searchDto.getWorkMobilityType().equalsIgnoreCase("INSIDE")){
		                        	 seperator = "\" OR employeeLocation:\"";                
		                        	 query = query + "AND ( relocateWithinAll:\"Y\") "; 
		                        	 query = query + "AND ( employeeLocation:\"" + StringUtils.join(commaCheckedValue, seperator).toLowerCase()
			                                       + "\" ) ";
		                        }else if(searchDto.getWorkMobilityType()!=null && searchDto.getWorkMobilityType().equalsIgnoreCase("OUTSIDE")){
		                        	 seperator = "\" OR mobilityCountry:\"";         
		                        	 query = query + "AND ( relocateOutsideAll:\"Y\") ";        
			                         query = query + "AND ( mobilityCountry:\"" + StringUtils.join(commaCheckedValue, seperator).toLowerCase()
			                                       + "\" ) ";
		                        }else if(searchDto.getWorkMobilityType()!=null && searchDto.getWorkMobilityType().equalsIgnoreCase("BOTH")){
		                        	 seperator = "\" OR employeeLocation:\"";                
		                        	 query = query + "AND ( relocateWithinAll:\"Y\""; 
		                        	 query = query + "AND ( employeeLocation:\"" + StringUtils.join(commaCheckedValue, seperator).toLowerCase()
			                                       + "\" )) ";
		                        	 seperator = "\" OR mobilityCountry:\"";         
		                        	 query = query + "OR ( relocateOutsideAll:\"Y\"";        
			                         query = query + "AND ( mobilityCountry:\"" + StringUtils.join(commaCheckedValue, seperator).toLowerCase()
			                                       + "\" )) ";
		                        }
		                        
							 }
							 /*if (searchDto.getMentoring() != null
                                     && !searchDto.getMentoring().isEmpty()) {
								if(searchDto.getMentoring()!=null && searchDto.getMentoring().equalsIgnoreCase("MENTOR")){
		                        	 query = query + "AND ( mentorAll:\"Y\") "; 
		                        	
		                        }else if(searchDto.getMentoring()!=null && searchDto.getMentoring().equalsIgnoreCase("MENTEE")){
		                        	 query = query + "AND ( menteeAll:\"Y\") ";        
			                  
		                        }else if(searchDto.getMentoring()!=null && searchDto.getMentoring().equalsIgnoreCase("BOTH")){
		                        	 query = query + "AND ( mentorAll:\"Y\"" + "OR  menteeAll:\"Y\" ) ";        
		                        }
		                        
							 }*/
	                         if (query.equalsIgnoreCase("")) {	
	                                query = getQueryByClients(
	                                              getACLRoles(PersonAuthUtil.getLoggedSSO()),
	                                              query, PersonAuthUtil.getLoggedSSO().toString());
	                                query.replaceFirst(" AND ", "");
	                         } else {
	                                query = getQueryByClients(
	                                              getACLRoles(PersonAuthUtil.getLoggedSSO()),
	                                              query, PersonAuthUtil.getLoggedSSO().toString());
	                         }
	                  }
	                  } else {
	                         if (searchDto.getEduTrng() != null
	                                       && !searchDto.getEduTrng().equalsIgnoreCase("")) {
	                                //query = query + "AND ( educationShared:\"Y\" ) ";
									query = query + "AND (educationTrainingShared:(" + escapeSpecialCharacters(searchDto.getEduTrng(),
					            			false) + ")) "; 

	                         }
	                         if (searchDto.getWorkHistory() != null
	                                       && !searchDto.getWorkHistory().equalsIgnoreCase("")) {
	                                //query = query + "AND ( empHistoryShared:\"Y\" ) ";
	                        	 query = query + "AND (workHistoryShared:(" + escapeSpecialCharacters(searchDto.getWorkHistory(),
					            			false) + ")) "; 
	                         }
	                         if (searchDto.getCareerInterests() != null
                                     && !searchDto.getCareerInterests().equalsIgnoreCase("")) {
								query = query + "AND (careerInterestsShared:(" + escapeSpecialCharacters(searchDto.getCareerInterests(),
				            			false) + ")) "; 

							 }
							 if (searchDto.getInitiativesProjects() != null
                                     && !searchDto.getInitiativesProjects().equalsIgnoreCase("")) {
								query = query + "AND ( projectsShared:(" + escapeSpecialCharacters(searchDto.getInitiativesProjects(),
				            			false) + ")) "; 

							 }
							 if (searchDto.getCustomerSuppliers() != null
                                     && !searchDto.getCustomerSuppliers().equalsIgnoreCase("")) {
								query = query + "AND ( customersSuppliersShared:(" + escapeSpecialCharacters(searchDto.getCustomerSuppliers(),
				            			false) + ")) "; 

							 }
							 if (searchDto.getLanguageProficiency() != null
                                     && !searchDto.getLanguageProficiency().isEmpty()) {
								 commaCheckedValue = checkForQuestionMark(searchDto.getLanguageProficiency());
		                         seperator = "* OR languagesShared:";
		                         query = query + "AND ( languagesShared:" + escapeSpecialCharacters(StringUtils.join(commaCheckedValue, seperator), false)//.toLowerCase()
		                                       + "* ) ";

							 }
							 if (searchDto.getInterests() != null
                                     && !searchDto.getInterests().equalsIgnoreCase("")) {
								query = query + "AND ( interestsShared:(" + escapeSpecialCharacters(searchDto.getInterests(),
				            			false) + ")) "; 

							 }
							 if (searchDto.getAffiliations() != null
                                     && !searchDto.getAffiliations().equalsIgnoreCase("")) {
								query = query + "AND ( externalAffiliationsShared:(" + escapeSpecialCharacters(searchDto.getAffiliations(),
				            			false) + ")) "; 
							 }
							 if (searchDto.getWorkMobility() != null
                                     && !searchDto.getWorkMobility().isEmpty()) {
								 commaCheckedValue = checkForQuestionMark(searchDto.getWorkMobility());
		                        if(searchDto.getWorkMobilityType()!=null && searchDto.getWorkMobilityType().equalsIgnoreCase("INSIDE")){
		                        	 seperator = "\" OR employeeLocation:\"";                
		                        	 query = query + "AND ( relocateWithinAllShared:\"Y\") "; 
		                        	 query = query + "AND ( employeeLocation:\"" + StringUtils.join(commaCheckedValue, seperator).toLowerCase()
			                                       + "\" ) ";
		                        }else if(searchDto.getWorkMobilityType()!=null && searchDto.getWorkMobilityType().equalsIgnoreCase("OUTSIDE")){
		                        	 seperator = "\" OR mobilityCountry:\"";         
		                        	 query = query + "AND ( relocateOutsideAllShared:\"Y\") ";        
			                         query = query + "AND ( mobilityCountry:\"" + StringUtils.join(commaCheckedValue, seperator).toLowerCase()
			                                       + "\" ) ";
		                        }else if(searchDto.getWorkMobilityType()!=null && searchDto.getWorkMobilityType().equalsIgnoreCase("BOTH")){
		                        	 seperator = "\" OR employeeLocation:\"";                
		                        	 query = query + "AND ( relocateWithinShared:\"Y\""; 
		                        	 query = query + "AND ( employeeLocation:\"" + StringUtils.join(commaCheckedValue, seperator).toLowerCase()
			                                       + "\" )) ";
		                        	 seperator = "\" OR mobilityCountry:\"";         
		                        	 query = query + "OR ( relocateOutsideShared:\"Y\"";        
			                         query = query + "AND ( mobilityCountry:\"" + StringUtils.join(commaCheckedValue, seperator).toLowerCase()
			                                       + "\" )) ";
		                        }
		                        
							 }
							 /*if (searchDto.getMentoring() != null
                                     && !searchDto.getMentoring().isEmpty()) {
								if(searchDto.getMentoring()!=null && searchDto.getMentoring().equalsIgnoreCase("MENTOR")){
		                        	 query = query + "AND ( mentorShared:\"Y\") "; 
		                        	
		                        }else if(searchDto.getMentoring()!=null && searchDto.getMentoring().equalsIgnoreCase("MENTEE")){
		                        	 query = query + "AND ( menteeShared:\"Y\") ";        
			                  
		                        }else if(searchDto.getMentoring()!=null && searchDto.getMentoring().equalsIgnoreCase("BOTH")){
		                        	 query = query + "AND ( mentorShared:\"Y\"" + "OR  menteeShared:\"Y\" ) ";        
		                        }
		                        
							 }*/
	                  }
	            } else {
					  if (searchDto.getEduTrng() != null
	                                       && !searchDto.getEduTrng().equalsIgnoreCase("")) {
									query = query + "AND ( educationTrainingAll:(" + escapeSpecialCharacters(searchDto.getEduTrng(),
					            			false) + "))"; 

	                  }
					  if (searchDto.getWorkHistory() != null
                              && !searchDto.getWorkHistory().equalsIgnoreCase("")) {
						query = query + "AND ( workHistoryAll:(" + escapeSpecialCharacters(searchDto.getWorkHistory(),
		            			false) + "))"; 

					  }
					  if (searchDto.getCareerInterests() != null
                              && !searchDto.getCareerInterests().equalsIgnoreCase("")) {
							query = query + "AND ( careerInterestsAll:(" + escapeSpecialCharacters(searchDto.getCareerInterests(),
			            			false) + ")) "; 

						 }
						 if (searchDto.getInitiativesProjects() != null
                              && !searchDto.getInitiativesProjects().equalsIgnoreCase("")) {
							query = query + "AND ( projectsAll:(" + escapeSpecialCharacters(searchDto.getInitiativesProjects(),
			            			false) + ")) "; 

						 }
						 if (searchDto.getCustomerSuppliers() != null
                              && !searchDto.getCustomerSuppliers().equalsIgnoreCase("")) {
							query = query + "AND ( customersSuppliersAll:(" + escapeSpecialCharacters(searchDto.getCustomerSuppliers(),
			            			false) + ")) "; 

						 }
						 if (searchDto.getLanguageProficiency() != null
                              && !searchDto.getLanguageProficiency().isEmpty()) {
							 commaCheckedValue = checkForQuestionMark(searchDto.getLanguageProficiency());
	                         seperator = "* OR languagesAll:";
	                         query = query + "AND ( languagesAll:" + escapeSpecialCharacters(StringUtils.join(commaCheckedValue, seperator), false)//.toLowerCase()
	                                       + "* ) ";

						 }
						 if (searchDto.getInterests() != null
                              && !searchDto.getInterests().equalsIgnoreCase("")) {
							query = query + "AND ( interestsAll:(" + escapeSpecialCharacters(searchDto.getInterests(),
			            			false) + ")) "; 

						 }
						 if (searchDto.getAffiliations() != null
                              && !searchDto.getAffiliations().equalsIgnoreCase("")) {
							query = query + "AND ( externalAffiliationsAll:(" + escapeSpecialCharacters(searchDto.getAffiliations(),
			            			false) + ")) "; 
						 }
						 if (searchDto.getWorkMobility() != null
                                 && !searchDto.getWorkMobility().isEmpty()) {
							 commaCheckedValue = checkForQuestionMark(searchDto.getWorkMobility());
	                        if(searchDto.getWorkMobilityType()!=null && searchDto.getWorkMobilityType().equalsIgnoreCase("INSIDE")){
	                        	 seperator = "\" OR employeeLocation:\"";                
	                        	 query = query + "AND ( relocateWithinAll:\"Y\") "; 
	                        	 query = query + "AND ( employeeLocation:\"" + StringUtils.join(commaCheckedValue, seperator).toLowerCase()
		                                       + "\" ) ";
	                        }else if(searchDto.getWorkMobilityType()!=null && searchDto.getWorkMobilityType().equalsIgnoreCase("OUTSIDE")){
	                        	 seperator = "\" OR mobilityCountry:\"";         
	                        	 query = query + "AND ( relocateOutsideAll:\"Y\") ";        
		                         query = query + "AND ( mobilityCountry:\"" + StringUtils.join(commaCheckedValue, seperator).toLowerCase()
		                                       + "\" ) ";
	                        }else if(searchDto.getWorkMobilityType()!=null && searchDto.getWorkMobilityType().equalsIgnoreCase("BOTH")){
	                        	 seperator = "\" OR employeeLocation:\"";                
	                        	 query = query + "AND ( relocateWithinAll:\"Y\""; 
	                        	 query = query + "AND ( employeeLocation:\"" + StringUtils.join(commaCheckedValue, seperator).toLowerCase()
		                                       + "\" )) ";
	                        	 seperator = "\" OR mobilityCountry:\"";         
	                        	 query = query + "OR ( relocateOutsideAll:\"Y\"";        
		                         query = query + "AND ( mobilityCountry:\"" + StringUtils.join(commaCheckedValue, seperator).toLowerCase()
		                                       + "\" )) ";
	                        }
	                        
						 }
						 
						 /*if (searchDto.getMentoring() != null
                                 && !searchDto.getMentoring().isEmpty()) {
							if(searchDto.getMentoring()!=null && searchDto.getMentoring().equalsIgnoreCase("MENTOR")){
	                        	 query = query + "AND ( mentorAll:\"Y\") "; 
	                        	
	                        }else if(searchDto.getMentoring()!=null && searchDto.getMentoring().equalsIgnoreCase("MENTEE")){
	                        	 query = query + "AND ( menteeAll:\"Y\") ";        
		                  
	                        }else if(searchDto.getMentoring()!=null && searchDto.getMentoring().equalsIgnoreCase("BOTH")){
	                        	 query = query + "AND ( mentorAll:\"Y\"" + "OR  menteeAll:\"Y\" ) ";        
	                        }
	                        
						 }*/
					  
					  if (clientSearch) {
	                         if (query.equalsIgnoreCase("")) {query = "*";}
	                  }
	            }
	            if (searchDto.getLeadershipProgram() != null) {
	                  if(query.equalsIgnoreCase("")){
	                         query = "*";
	                  }
	                  resultLabel = resultLabel + " + Leadership Program: \'"
	                                + searchDto.getLeadershipProgram() + "\'";
	            }
	            query = query.replaceFirst("AND ", "");
	      }
	     }
	     resultLabel = resultLabel.replaceAll("\\[", "").replaceAll("\\]", "");
	     resultLabel = resultLabel.replaceFirst("\\+ ", "");
	     queryAndLabel.put("query", query);
   	     queryAndLabel.put("label", resultLabel);
	     return queryAndLabel;
    }


	private String createSearchAllInputQuery(String param, boolean hasRoleSA, boolean isFuncHR, boolean clientSearch, boolean clientSearchAll) {
		String query = "";
        if (!hasRoleSA) {
            if (clientSearch) {
                   if(!query.equalsIgnoreCase("*") && !clientSearchAll){
					 String[] fields = { "combinedAllData", "educationTrainingAll", "workHistoryAll",
								"careerInterestsAll", "projectsAll", "customersSuppliersAll",
								"languagesAll", "interestsAll", "externalAffiliationsAll" };
					 
					query = parseSearchAllQuery(fields, param);
					
                   if (query.equalsIgnoreCase("")) {	
                          query = getQueryByClients(
                                        getACLRoles(PersonAuthUtil.getLoggedSSO()),
                                        query, PersonAuthUtil.getLoggedSSO().toString());
                          query.replaceFirst(" AND ", "");
                   } else {
                          query = getQueryByClients(
                                        getACLRoles(PersonAuthUtil.getLoggedSSO()),
                                        query, PersonAuthUtil.getLoggedSSO().toString());
                   }
            }
            } else { 
            	String[] fields = { "combinedSharedData", "educationTrainingShared", "workHistoryShared",
						"careerInterestsShared", "projectsShared", "customersSuppliersShared",
						"languagesShared", "interestsShared", "externalAffiliationsShared" };   	
            	query = parseSearchAllQuery(fields, param);
            }
      } else {
    	  String[] fields = { "combinedAllData", "educationTrainingAll", "workHistoryAll",
  				"careerInterestsAll", "projectsAll", "customersSuppliersAll",
  				"languagesAll", "interestsAll", "externalAffiliationsAll" };
    	  query = parseSearchAllQuery(fields, param);
			  if (clientSearch) {
                   if (query.equalsIgnoreCase("")) {query = "*";}
			  }
      }
		return query;
        
	}

	private String parseSearchAllQuery(String[] fields, String param) {
		String query = "";
		if(param.startsWith("\"") && param.endsWith("\"")){
			query = query + " AND ( ";
			for (String f : fields) {
				query = query + f + ":" + param  + " ";
			}
			query = query + " )";
		
		}else{
			String[] terms = param.split(" ");
			for (String t : terms) {
				query = query + " AND ( ";
				for (String f : fields) {
					query = query + f + ":" + t  + " ";
				}
				query = query + " )";
			}
		}
		
		query = query.replaceFirst("AND ", "");
		return query;
	}

	public String createLeadershipQuery(SearchLuceneDto searchDto) {
        // String lpQuery= "lpq=";
        String lpQuery = "";
        if (searchDto != null) {
	        if(searchDto.getLeadershipProgram() != null){
		        List<String> commaCheck = new ArrayList<String>();
		        commaCheck = checkForQuestionMark(searchDto.getLeadershipProgram());
		        String seperator = '"' + " OR prgName:\"";
		        if (searchDto != null) {
		               if (searchDto.getLeadershipProgram() != null) {
		                     lpQuery = lpQuery
		                                   + "(prgName:\""
		                                   + StringUtils.join(commaCheck,
		                                                 seperator) + "\" )";
		                     if (searchDto.getLeadershipProgramType() != null
		                                   && !searchDto.getLeadershipProgramType()
		                                                 .equalsIgnoreCase("ALL")) {
		                            lpQuery = lpQuery + "AND (prgStatus:\""
		                                          + searchDto.getLeadershipProgramType() + "\" ) ";
		                     }
		               }
		               // lpQuery = lpQuery.replaceFirst("AND ", "");
		        }
	        }
        }
        return lpQuery;
	}
	
	public String getResultsLabel(int total, String string) {
		String label = "";
		NumberFormat myFormat = NumberFormat.getInstance();
		myFormat.setGroupingUsed(true);
		label = myFormat.format(total) + " Results for " + string;
		return label;
	}

	private String escapeSpecialCharacters(String s, boolean escapeAll) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (escapeAll) {
				// These characters are part of the query syntax and must be
				// escaped
				if (c == '\\' || c == '+' || c == '-' || c == '!' || c == '('
						|| c == ')' || c == ':' || c == '^' || c == '['
						|| c == ']' || c == '\"' || c == '{' || c == '}'
						|| c == '~' || c == '*' || c == '?' || c == '|'
						|| c == '&' || c == '/') {
					sb.append('\\');
				}
			} else {
				if (c == '\\' || c == '-' || c == '/') {
					sb.append('\\');
				}
			}

			sb.append(c);
		}
		return sb.toString();
	}

	private String getQueryByClients(List<String> roleList, String query,
			String smUser) {
		boolean flag = true;

		if (roleList != null && roleList.size() > 0) {
			for (String str : roleList) {
				// flag added to diff the first iteration
				if (flag) {
					if(aclListValueMap.get(str)!=null){
					query = query + " AND " + "( " + aclListValueMap.get(str)
							+ ":(" + smUser + ")";
					flag = false;
					}
				} else {
					if(aclListValueMap.get(str)!=null){
					query = query + " OR " + aclListValueMap.get(str) + ":("
							+ smUser + ")";
					}
				}
			}
			if(!flag){query = query + " )";}
		} else {
			query = query + " AND " + "( " + "acl_SUPV:(" + smUser + ")"
					+ " OR " + "acl_MGR:(" + smUser + ")" + " OR "
					+ " OR " + "acl_ORG_MGR:(" + smUser + ")" + " OR "
					+ " OR " + "acl_ORG_HRM:(" + smUser + ")" + " OR "
					+ "acl_HRM:(" + smUser + ")" + " OR " + "acl_HRM_SPL:("
					+ smUser + ")" + " OR " + "acl_SHRM:(" + smUser + ")"

					+ " OR " + "acl_SHRM_F:(" + smUser + ")" + " OR "
					+ "acl_SHRM_R:(" + smUser + ")" + " OR " + "acl_SHRM_GL:("
					+ smUser + ")"

					+ " OR " + "acl_MATRIX_HRM:(" + smUser + ")" + " OR "
					+ "acl_O_S_MANAGER:(" + smUser + ")" + " OR "
					+ "acl_O_S_MANAGER_CP:(" + smUser + ")"

					+ " OR " + "acl_O_S_MANAGER_F:(" + smUser + ")" + " OR "
					+ "acl_O_S_MANAGER_GL:(" + smUser + ")" + " OR "
					+ "acl_O_S_MANAGER_R:(" + smUser + ")"
					
					+ "acl_O_TD_MANAGER:(" + smUser + ")" + " OR "
					+ "acl_O_TD_MANAGER_CP:(" + smUser + ")"

					+ " OR " + "acl_O_TD_MANAGER_F:(" + smUser + ")" + " OR "
					+ "acl_O_TD_MANAGER_GL:(" + smUser + ")" + " OR "
					+ "acl_O_TD_MANAGER_R:(" + smUser + ")"  + " OR "

					+ "acl_O_TD_NO_COMP:(" + smUser + ")"  + " OR "
					+ "acl_ADMIN_STAFF:(" + smUser + ")"  + " OR "
					+ "acl_STAFF_HS_LTD_ACCESS:(" + smUser + ")"  + " OR "
					+ "acl_STAFF_HS_STAFFING_SPL:(" + smUser + ")"  + " OR "
					+ "acl_STAFF_HS_US_LEAD_RCTR:(" + smUser + ")"  + " OR "
					+ "acl_STAFF_REQ_FLDR_OWNR:(" + smUser + ")"  + " OR "	
					
					+ "acl_HRM_VIEW:(" + smUser + ")" + " OR "
					+ "acl_HR_BP:(" + smUser + ")" + " )";
		}
		return query;
	}

	private Map<String, String> getACLListMap() {

		Map<String, String> funcDataMap = new HashMap<String, String>();
		
		funcDataMap.put("SUPV", "acl_SUPV");
		funcDataMap.put("MGR", "acl_MGR");

		funcDataMap.put("ORG_MGR", "acl_ORG_MGR");
		funcDataMap.put("ORG_HRM", "acl_ORG_HRM");
		funcDataMap.put("HRM", "acl_HRM");
		funcDataMap.put("HRM_SPL", "acl_HRM_SPL");
		funcDataMap.put("SHRM", "acl_SHRM");

		funcDataMap.put("SHRM_F", "acl_SHRM_F");
		funcDataMap.put("SHRM_R", "acl_SHRM_R");
		funcDataMap.put("SHRM_GL", "acl_SHRM_GL");

		funcDataMap.put("MATRIX_HRM", "acl_MATRIX_HRM");
		funcDataMap.put("O_S_MANAGER", "acl_O_S_MANAGER");
		funcDataMap.put("O_S_MANAGER_CP", "acl_O_S_MANAGER_CP");

		funcDataMap.put("O_S_MANAGER_F", "acl_O_S_MANAGER_F");
		funcDataMap.put("O_S_MANAGER_GL", "acl_O_S_MANAGER_GL");
		funcDataMap.put("O_S_MANAGER_R", "acl_O_S_MANAGER_R");
		
		funcDataMap.put("O_TD_MANAGER", "acl_O_TD_MANAGER");
		funcDataMap.put("O_TD_MANAGER_CP", "acl_O_TD_MANAGER_CP");

		funcDataMap.put("O_TD_MANAGER_F", "acl_O_TD_MANAGER_F");
		funcDataMap.put("O_TD_MANAGER_GL", "acl_O_TD_MANAGER_GL");
		funcDataMap.put("O_TD_MANAGER_R", "acl_O_TD_MANAGER_R");

		funcDataMap.put("HRM_VIEW", "acl_HRM_VIEW");
		funcDataMap.put("HR_BP", "acl_HR_BP");
		
		funcDataMap.put("O_TD_NO_COMP", "acl_O_TD_NO_COMP");
		funcDataMap.put("ADMIN_STAFF", "acl_ADMIN_STAFF");
		funcDataMap.put("STAFF_HS_LTD_ACCESS", "acl_STAFF_HS_LTD_ACCESS");
		funcDataMap.put("STAFF_HS_STAFFING_SPL", "acl_STAFF_HS_STAFFING_SPL");
		funcDataMap.put("STAFF_HS_US_LEAD_RCTR", "acl_STAFF_HS_US_LEAD_RCTR");
		funcDataMap.put("STAFF_REQ_FLDR_OWNR", "acl_STAFF_REQ_FLDR_OWNR");

		return funcDataMap;
	}
	
	private List<String> checkForQuestionMark(List<String> inputList) {
        String sanitizedInput = "";
        List<String> sanitizedList = new ArrayList<String>();
        for(int i=0;i<inputList.size();i++){
               sanitizedInput = inputList.get(i);
               if(sanitizedInput.contains("?")){
                     sanitizedInput = sanitizedInput.replaceAll("\\?", ",");
               }
               sanitizedList.add(sanitizedInput);
        }
        return sanitizedList;
	}

	@Override
	public StringCatalogDto getTechnicalDiscipline() {
		StringCatalogDto dto = new StringCatalogDto();
		dto.setCatalog(searchDao.getDisciplineList());
		return dto;
	}

	@Override
	public StringCatalogDto getReportingIfgCatalog() {
		StringCatalogDto dto = new StringCatalogDto();
		dto.setCatalog(searchDao.getReportingIfgCatalog());
		return dto;
	}

	@Override
	public StringCatalogDto getReportingBusinessCatalog() {
		StringCatalogDto dto = new StringCatalogDto();
		dto.setCatalog(searchDao.getReportingBusinessCatalog());
		return dto;
	}

	@Override
	public StringCatalogDto getLanguageList() {
		StringCatalogDto dto = new StringCatalogDto();
		BaseModelCollection<String> list = new BaseModelCollection<String>();
		list.setList(languageDao.getLanguageList());
		dto.setCatalog(list);
		return dto;
	}

	@Override
	public Map<Long, List<IntiativesandProject>> getInitiativeProjectData() {
		// TODO Auto-generated method stub
		// int eduRecords = (int) (ssoList.size()*1.1);
		Map<Long, List<IntiativesandProject>> projMap = new HashMap<Long, List<IntiativesandProject>>();
		List<IntiativesandProject> eduList = employeeDao.getInitiativeProjectData();
		for (IntiativesandProject e : eduList) {
			if (projMap.containsKey(e.getSso())) {
				List<IntiativesandProject> proj = projMap.get(e.getSso());
				proj.add(e);
				projMap.put(e.getSso(), proj);
			} else {
				List<IntiativesandProject> proj = new ArrayList<IntiativesandProject>();
				proj.add(e);
				projMap.put(e.getSso(), proj);

			}
		}
		return projMap;
	}

	@Override
	public Map<Long, List<CustomerandSuppliers>> getCustomersAndSuppliersData() {
		Map<Long, List<CustomerandSuppliers>> projMap = new HashMap<Long, List<CustomerandSuppliers>>();
		List<CustomerandSuppliers> csList = employeeDao.getCustomersAndSuppliersData();
		for (CustomerandSuppliers e : csList) {
			if (projMap.containsKey(e.getSso())) {				
				List<CustomerandSuppliers> proj = projMap.get(e.getSso());
				proj.add(e);
				projMap.put(e.getSso(), proj);				
			} else {
				List<CustomerandSuppliers> proj = new ArrayList<CustomerandSuppliers>();
				proj.add(e);
				projMap.put(e.getSso(), proj);

			}
		}
		return projMap;
	}

	@Override
	public Map<Long, List<LanguageProficiency>> getLanguagesData() {
		Map<Long, List<LanguageProficiency>> projMap = new HashMap<Long, List<LanguageProficiency>>();
		List<LanguageProficiency> csList = employeeDao.getLanguagesData();
		for (LanguageProficiency e : csList) {
			if (projMap.containsKey(e.getSso())) {				
				List<LanguageProficiency> proj = projMap.get(e.getSso());
				proj.add(e);
				projMap.put(e.getSso(), proj);				
			} else {
				List<LanguageProficiency> proj = new ArrayList<LanguageProficiency>();
				proj.add(e);
				projMap.put(e.getSso(), proj);

			}
		}
		return projMap;
	}

	@Override
	public Map<Long, List<AffinityGroups>> getExternalAffiliationsData() {
		Map<Long, List<AffinityGroups>> projMap = new HashMap<Long, List<AffinityGroups>>();
		List<AffinityGroups> csList = employeeDao.getExternalAffiliationsData();
		for (AffinityGroups e : csList) {
			if (projMap.containsKey(e.getSso())) {				
				List<AffinityGroups> proj = projMap.get(e.getSso());
				proj.add(e);
				projMap.put(e.getSso(), proj);				
			} else {
				List<AffinityGroups> proj = new ArrayList<AffinityGroups>();
				proj.add(e);
				projMap.put(e.getSso(), proj);

			}
		}
		return projMap;
	}
	
	@Override
	public Map<Long, List<WorkMobilityCountry>> getWorkMobilityData() {
		Map<Long, List<WorkMobilityCountry>> wmMap = new HashMap<Long, List<WorkMobilityCountry>>();
		List<WorkMobilityCountry> wmList = employeeDao.getWorkMobilityData();
		for (WorkMobilityCountry wm : wmList) {
			if (wmMap.containsKey(wm.getSso())) {				
				List<WorkMobilityCountry> mobility = wmMap.get(wm.getSso());
				mobility.add(wm);
				wmMap.put(wm.getSso(), mobility);				
			} else {
				List<WorkMobilityCountry> mobility = new ArrayList<WorkMobilityCountry>();
				mobility.add(wm);
				wmMap.put(wm.getSso(), mobility);

			}
		}
		return wmMap;
	}

	@Override
	public StringCatalogDto getAssignmentLeaderFor() {
		StringCatalogDto dto = new StringCatalogDto();
		dto.setCatalog(searchDao.getAssignmentLeaderFor());
		return dto;
	}

	@Override
	public StringCatalogDto getAssignmentSubBusiness() {
		StringCatalogDto dto = new StringCatalogDto();
		dto.setCatalog(searchDao.getAssignmentSubBusiness());
		return dto;
	}

	@Override
	public Map<Long, List<LPBridgeAssignment>> getLPBridgeData() {
		Map<Long, List<LPBridgeAssignment>> wmMap = new HashMap<Long, List<LPBridgeAssignment>>();
		List<LPBridgeAssignment> wmList = employeeDao.getLPBridgeData();
		for (LPBridgeAssignment wm : wmList) {
			if (wmMap.containsKey(wm.getSso())) {				
				List<LPBridgeAssignment> mobility = wmMap.get(wm.getSso());
				mobility.add(wm);
				wmMap.put(wm.getSso(), mobility);				
			} else {
				List<LPBridgeAssignment> mobility = new ArrayList<LPBridgeAssignment>();
				mobility.add(wm);
				wmMap.put(wm.getSso(), mobility);

			}
		}
		return wmMap;
	}
	
	@Override
	public Map<Long, List<EmployeeExpertise>> getEmpExpertiseData() {
		Map<Long, List<EmployeeExpertise>> expMap = new HashMap<Long, List<EmployeeExpertise>>();
		List<EmployeeExpertise> expList = employeeDao.getEmpExpertiseData();
		for (EmployeeExpertise ee : expList) {
			if (expMap.containsKey(ee.getSso())) {				
				List<EmployeeExpertise> expertises = expMap.get(ee.getSso());
				expertises.add(ee);
			} else {
				List<EmployeeExpertise> expertises = new ArrayList<>();
				expertises.add(ee);
				expMap.put(ee.getSso(), expertises);

			}
		}
		return expMap;
	}
	
	@Override
	public Map<Long, List<Mentoring>> getEmpMentoringInterestData() {
		Map<Long, List<Mentoring>> interestMap = new HashMap<>();
		List<Mentoring> list = employeeDao.getEmpMentoringInterestData();
		for (Mentoring ee : list) {
			if (interestMap.containsKey(ee.getSso())) {				
				List<Mentoring> interest = interestMap.get(ee.getSso());
				interest.add(ee);
			} else {
				List<Mentoring> interest = new ArrayList<>();
				interest.add(ee);
				interestMap.put(ee.getSso(), interest);

			}
		}
		return interestMap;
	}

	@Override
	public void insertSearchMetrics(PersonalInfoDto personInfo, SearchLuceneDto searchDto, boolean hasClientSearch, String userAgent) {

		Map<String, Map<String, String>> categoryMap = new HashMap<>();
		Map<String, String> labelValueMap = new HashMap<>();
		String seperator = "|";
		
		if("N".equalsIgnoreCase(searchDto.getSearchByCategory())) {
			if(searchDto.getSearchAllInput() != null && !searchDto.getSearchAllInput().isEmpty()) {
				labelValueMap.put("Search All Label", checkLength(searchDto.getSearchAllInput()));
				categoryMap.put("Search All", labelValueMap);
			}
		} else {
			boolean matched = false;
			
			if(searchDto.getSsoName() != null && !searchDto.getSsoName().isEmpty()) {
				labelValueMap.put("Name or SSO", checkLength(searchDto.getSsoName()));
				matched = true;
			}
			if(searchDto.getTitle() != null && !searchDto.getTitle().isEmpty()) {
				labelValueMap.put("Title", checkLength(searchDto.getTitle()));
				matched = true;
			}
			if(searchDto.getEmailPhone() != null && !searchDto.getEmailPhone().isEmpty()) {
				labelValueMap.put("Phone or Email", checkLength(searchDto.getEmailPhone()));
				matched = true;
			}
			if(searchDto.getManagerDetails() != null && !searchDto.getManagerDetails().isEmpty()) {
				labelValueMap.put("Manager", checkLength(searchDto.getManagerDetails()));
				matched = true;
			}
			if(matched) {
				categoryMap.put("Basic Information", labelValueMap);
				labelValueMap = new HashMap<>();
				matched = false;
			}
			
			if(searchDto.getFunction() != null) {
				labelValueMap.put("Function", checkLength(StringUtils.join(searchDto.getFunction(), seperator)));
				matched = true;
			}
			if(searchDto.getJobFamily() != null) {
				labelValueMap.put("Job Family", checkLength(StringUtils.join(searchDto.getJobFamily(), seperator)));
				matched = true;
			}
			if(searchDto.getTechDisciplineSTD() != null) {
				labelValueMap.put("Technical Discipline", checkLength(StringUtils.join(searchDto.getTechDisciplineSTD(), seperator)));
				matched = true;
			}
			if(searchDto.getBand() != null) {
				labelValueMap.put("Band", checkLength(StringUtils.join(searchDto.getBand(), seperator)));
				matched = true;
			}
			if(matched) {
				categoryMap.put("Job Information", labelValueMap);
				labelValueMap = new HashMap<>();
				matched = false;
			}
			
			if(searchDto.getIfg() != null) {
				labelValueMap.put("GE Business", checkLength(StringUtils.join(searchDto.getIfg(), seperator)));
				matched = true;
			}
			if(searchDto.getBusiness() != null) {
				labelValueMap.put("Business Segment", checkLength(StringUtils.join(searchDto.getBusiness(), seperator)));
				matched = true;
			}
			if(searchDto.getSubBusiness() != null) {
				labelValueMap.put("Sub-Business", checkLength(StringUtils.join(searchDto.getSubBusiness(), seperator)));
				matched = true;
			}
			if(searchDto.getOrganization() != null && !searchDto.getOrganization().isEmpty()) {
				labelValueMap.put("Organization", checkLength(searchDto.getOrganization()));
				matched = true;
			}
			if(searchDto.getReportingIFG() != null) {
				labelValueMap.put("Reporting IFG", checkLength(StringUtils.join(searchDto.getReportingIFG(), seperator)));
				matched = true;
			}
			if(searchDto.getReportingBusiness() != null) {
				labelValueMap.put("Reporting Business", checkLength(StringUtils.join(searchDto.getReportingBusiness(), seperator)));
				matched = true;
			}
			if(matched) {
				categoryMap.put("Organization", labelValueMap);
				labelValueMap = new HashMap<>();
				matched = false;
			}
			
			if(searchDto.getLocation() != null && !searchDto.getLocation().isEmpty()) {
				labelValueMap.put("Work Location",checkLength(searchDto.getLocation()));
				matched = true;
			}
			if(searchDto.getRegion() != null) {
				labelValueMap.put("Region", checkLength(StringUtils.join(searchDto.getRegion(), seperator)));
				matched = true;
			}
			if(searchDto.getCountry() != null) {
				labelValueMap.put("Country", checkLength(StringUtils.join(searchDto.getCountry(), seperator)));
				matched = true;
			}
			if(matched) {
				categoryMap.put("Location", labelValueMap);
				labelValueMap = new HashMap<>();
				matched = false;
			}
			
			if(searchDto.getProfessionalSummary() != null && !searchDto.getProfessionalSummary().isEmpty()) {
				labelValueMap.put("Professional Summary", checkLength(searchDto.getProfessionalSummary()));
				matched = true;
			}
			if(searchDto.getEmpExpertise() != null && !searchDto.getEmpExpertise().isEmpty()) {
				labelValueMap.put("Expertise", checkLength(StringUtils.join(searchDto.getEmpExpertise(), seperator)));
				matched = true;
			}
			if(searchDto.getWorkHistory() != null && !searchDto.getWorkHistory().isEmpty()) {
				labelValueMap.put("Employment History", checkLength(searchDto.getWorkHistory()));
				matched = true;
			}
			if(searchDto.getCareerInterests() != null && !searchDto.getCareerInterests().isEmpty()) {
				labelValueMap.put("Career Aspirations", checkLength(searchDto.getCareerInterests()));
				matched = true;
			}
			if(searchDto.getInitiativesProjects() != null && !searchDto.getInitiativesProjects().isEmpty()) {
				labelValueMap.put("Initiatives & Projects", checkLength(searchDto.getInitiativesProjects()));
				matched = true;
			}
			if(searchDto.getCustomerSuppliers() != null && !searchDto.getCustomerSuppliers().isEmpty()) {
				labelValueMap.put("Customers & Suppliers", checkLength(searchDto.getCustomerSuppliers()));
				matched = true;
			}
			if(searchDto.getTalentPool() != null) {
				labelValueMap.put("Career Opportunities", checkLength(StringUtils.join(searchDto.getTalentPool(), seperator)));
				matched = true;
			}
			if(searchDto.getWorkMobility() != null && !searchDto.getWorkMobility().isEmpty()) {
				labelValueMap.put("Mobility Country", checkLength(StringUtils.join(searchDto.getWorkMobility(), seperator)+"-"+searchDto.getWorkMobilityType()));
				matched = true;
			}
			if(matched) {
				categoryMap.put("Work & Career", labelValueMap);
				labelValueMap = new HashMap<>();
				matched = false;
			}
			
			if(searchDto.getEduTrng() != null && !searchDto.getEduTrng().isEmpty()) {
				labelValueMap.put("Education or Training", checkLength(searchDto.getEduTrng()));
				matched = true;
			}
			if(searchDto.getLanguageProficiency() != null) {
				labelValueMap.put("Languages Known", checkLength(StringUtils.join(searchDto.getLanguageProficiency(), seperator)));
				matched = true;
			}
			if(searchDto.getLeadershipProgram() != null) {
				labelValueMap.put("Leadership Program", checkLength(StringUtils.join(searchDto.getLeadershipProgram(), seperator)+"-"+searchDto.getLeadershipProgramType()));
				matched = true;
			}
			if(searchDto.getRotationNumber() != null && !searchDto.getRotationNumber().isEmpty()) {
				labelValueMap.put("Rotation Number", checkLength(searchDto.getRotationNumber()));
				matched = true;
			}
			if(searchDto.getAssignmentTitle() != null && !searchDto.getAssignmentTitle().isEmpty()) {
				labelValueMap.put("Assignment Title", checkLength(searchDto.getAssignmentTitle()));
				matched = true;
			}
			if(searchDto.getAssignmentLeaderName() != null && !searchDto.getAssignmentLeaderName().isEmpty()) {
				labelValueMap.put("Assignment Leader Name", checkLength(searchDto.getAssignmentLeaderName()));
				matched = true;
			}
			if(searchDto.getAssignmentSubBusiness() != null) {
				labelValueMap.put("Assignment Sub-business", checkLength(StringUtils.join(searchDto.getAssignmentSubBusiness(), seperator)));
				matched = true;
			}
			if(searchDto.getAssignmentLeaderFor() != null) {
				labelValueMap.put("Assignment Leader For", checkLength(StringUtils.join(searchDto.getAssignmentLeaderFor(), seperator)));
				matched = true;
			}
			if(matched) {
				categoryMap.put("Education & Training", labelValueMap);
				labelValueMap = new HashMap<>();
				matched = false;
			}
			
			if(searchDto.getInterests() != null && !searchDto.getInterests().isEmpty()) {
				labelValueMap.put("Interests", checkLength(searchDto.getInterests()));
				matched = true;
			}
			if(searchDto.getAffiliations() != null && !searchDto.getAffiliations().isEmpty()) {
				labelValueMap.put("External Affiliations", checkLength(searchDto.getAffiliations()));
				matched = true;
			}
			if(searchDto.getMentoring() != null && !searchDto.getMentoring().isEmpty()) {
				labelValueMap.put("Mentoring", checkLength(searchDto.getMentoring()));
				matched = true;
			}
			if(matched) {
				categoryMap.put("Interests & Affiliations", labelValueMap);
				matched = false;
			}
		}
		
		ProfileUserMetrics metrics = new ProfileUserMetrics();
		if(null != personInfo) {
			metrics.setSso(personInfo.getSso());
			metrics.setBusiness(personInfo.getIndustrySegment());
			metrics.setFunction(personInfo.getFunction());
			metrics.setRegion(personInfo.getRegion());
		}
		ProfileUserMetrics.setUserAgentDetails(metrics, userAgent);
		if(hasClientSearch) {
			metrics.setClientSearch("Y");
		} else {
			metrics.setClientSearch("N");
		}
		
		searchDao.addSearchMetrics(metrics, categoryMap);		
	}
	private String checkLength(String values) {
		if(values != null && values.length() > 200) {
			values = values.substring(0,200);
		}
		return values;
	}
}