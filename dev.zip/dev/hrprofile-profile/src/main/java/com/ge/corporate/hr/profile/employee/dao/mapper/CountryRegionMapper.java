package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.dto.CountryRegionDto;


public class CountryRegionMapper implements RowMapper<CountryRegionDto>  {
	
	public static final String DATA_SSO = "sso";
	public static final String DATA_GEOTYPE = "geo_type";
	public static final String DATA_COUNTRY_REGION = "country_region";
	

	@Override
	public CountryRegionDto mapRow(ResultSet rs, int rowNum) throws SQLException {
		CountryRegionDto countryRegion = new CountryRegionDto ();
		countryRegion.setSso(rs.getLong(DATA_SSO));
		countryRegion.setGeoType(rs.getString(DATA_GEOTYPE));
		countryRegion.setCountryRegion(rs.getString(DATA_COUNTRY_REGION));
		
		return countryRegion;
	}
	
}
