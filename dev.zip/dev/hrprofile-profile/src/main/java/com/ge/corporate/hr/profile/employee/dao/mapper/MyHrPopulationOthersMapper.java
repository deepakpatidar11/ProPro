/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.Locale;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.MyHrPopulation;

/**
 * Direct Reports mapper
 * @author enrique.romero
 *
 */
public class MyHrPopulationOthersMapper implements RowMapper<MyHrPopulation>{
	
	public static final String DATA_SSO = "sso";
	public static final String DATA_FULL_NAME = "full_name";
	public static final String DATA_POSITION_TITLE = "title";
	public static final String DATA_SUB_BUSINESS = "sub_business";
	public static final String DATA_ORGANIZATION = "organization";
	public static final String DATA_FUNCTION = "ffunction"; 
	public static final String DATA_JOB_TYPE = "job_type"; 
	public static final String DATA_BAND = "band";
	public static final String DATA_GENDER = "gender";
	public static final String DATA_REGION = "region";
	public static final String DATA_COUNTRY = "country";
	public static final String DATA_MANAGER_SSO = "manager_sso";
	public static final String DATA_MANAGER_NAME = "manager_name";
	public static final String DATA_HRMANAGER_SSO = "hrm_sso";
	public static final String DATA_HRMANAGER_NAME = "hrm_name";
	public static final String DATA_ADJ_SERVICE_DATE = "adjservicedate";
	public static final String DATA_RATING = "rating";
	public static final String DATA_HEADCOUNT_VALUE = "headcount_value";
	public static final String DATA_DIVERSITY = "diversity";
	public static final String DATA_ORG_START_DATE = "org_start_date";
	public static final String DATA_TERMINATION_DATE = "terminationdate";

	private Locale locale = new Locale("en-US");

	private String format = "";
	
	public MyHrPopulationOthersMapper(Locale locale_, String format_) {
		if(locale!=null){
			locale=locale_;
		}
		format=format_;
	}

	public MyHrPopulation mapRow(ResultSet rs, int rowNum) throws SQLException {
		MyHrPopulation myHrPopulation = new MyHrPopulation();
		
		DecimalFormat df = new DecimalFormat("0.0");
		
		myHrPopulation.setSso(rs.getLong(DATA_SSO));
		myHrPopulation.setFull_name(rs.getString(DATA_FULL_NAME));
		myHrPopulation.setTitle(rs.getString(DATA_POSITION_TITLE));
		myHrPopulation.setSub_business(rs.getString(DATA_SUB_BUSINESS));
		myHrPopulation.setOrganization(rs.getString(DATA_ORGANIZATION));
		myHrPopulation.setFfunction(rs.getString(DATA_FUNCTION));
		myHrPopulation.setJob_type(rs.getString(DATA_JOB_TYPE));
		myHrPopulation.setBand(rs.getString(DATA_BAND));
		myHrPopulation.setRating(rs.getString(DATA_RATING));
		myHrPopulation.setGender(rs.getString(DATA_GENDER));
		myHrPopulation.setRegion(rs.getString(DATA_REGION));
		myHrPopulation.setCountry(rs.getString(DATA_COUNTRY));
		myHrPopulation.setManager_sso(rs.getLong(DATA_MANAGER_SSO));
		myHrPopulation.setManager_name(rs.getString(DATA_MANAGER_NAME));
		myHrPopulation.setHrm_sso(rs.getLong(DATA_HRMANAGER_SSO));
		myHrPopulation.setHrm_name(rs.getString(DATA_HRMANAGER_NAME));
		myHrPopulation.setAdjservicedate(rs.getDate(DATA_ADJ_SERVICE_DATE));
		myHrPopulation.setHeadcount_value(rs.getString(DATA_HEADCOUNT_VALUE));
		myHrPopulation.setHeadcount_value(rs.getString(DATA_HEADCOUNT_VALUE)==null?rs.getString(DATA_HEADCOUNT_VALUE):df.format(Float.parseFloat(rs.getString(DATA_HEADCOUNT_VALUE))));
		myHrPopulation.setDiversity(rs.getString(DATA_DIVERSITY));
		myHrPopulation.setOrg_start_date(rs.getDate(DATA_ORG_START_DATE));
		myHrPopulation.setTerminationdate(rs.getDate(DATA_TERMINATION_DATE));
				
		return myHrPopulation;		
	}	
}
