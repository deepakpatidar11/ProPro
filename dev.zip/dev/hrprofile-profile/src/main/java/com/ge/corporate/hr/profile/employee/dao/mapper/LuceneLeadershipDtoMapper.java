package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.dto.LuceneLeadershipDto;

public class LuceneLeadershipDtoMapper implements RowMapper<LuceneLeadershipDto> {

	public static final String DATA_NAME = "prg_name";
	public static final String DATA_LONG_NAME = "prg_long_name";
	public static final String DATA_STATUS = "prg_status";
	public static final String DATA_SSO = "sso";
	
	@Override
	public LuceneLeadershipDto mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		LuceneLeadershipDto ldr = new LuceneLeadershipDto();
		ldr.setPrgLongName(rs.getString(DATA_LONG_NAME));
		ldr.setPrgName(rs.getString(DATA_NAME));
		ldr.setPrgStatus(rs.getString(DATA_STATUS));
		ldr.setSso(rs.getLong(DATA_SSO));
		return ldr;
	}
}
