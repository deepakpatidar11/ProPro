package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.LanguageProficiency;

public class LanguageProficicencyMapper implements RowMapper<LanguageProficiency> {
	
	public static final String DATA_SSO = "sso";
	public static final String DATA_LANGUAGE = "emp_language";
	public static final String DATA_LEVEL = "emp_level";
	
	
	public LanguageProficiency mapRow(ResultSet rs, int rowNum) throws SQLException {
		LanguageProficiency languageproficicency = new LanguageProficiency();
		languageproficicency.setSso(rs.getLong(DATA_SSO));
		languageproficicency.setLanguage(rs.getString(DATA_LANGUAGE));
		languageproficicency.setLevel(rs.getString(DATA_LEVEL));
		
		return languageproficicency;
	}
}
