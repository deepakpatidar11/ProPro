package com.ge.corporate.hr.profile.employee.dto;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.EducationCountry;
import com.ge.corporate.hr.profile.employee.model.EducationUniversity;

public class EducationCatalogs extends AbstractBaseDtoSupport {

	private BaseModelCollection<EducationCountry> countryList;

	private BaseModelCollection<EducationUniversity> universityList;

	private BaseModelCollection<String> degreeList;

	private BaseModelCollection<String> majorList;

	private BaseModelCollection<EducationCountry> statusList;

	public BaseModelCollection<EducationCountry> getCountryList() {
		return countryList;
	}

	public void setCountryList(BaseModelCollection<EducationCountry> countryList) {
		this.countryList = countryList;
	}

	public BaseModelCollection<EducationUniversity> getUniversityList() {
		return universityList;
	}

	public void setUniversityList(BaseModelCollection<EducationUniversity> universityList) {
		this.universityList = universityList;
	}

	public BaseModelCollection<String> getDegreeList() {
		return degreeList;
	}

	public void setDegreeList(BaseModelCollection<String> degreeList) {
		this.degreeList = degreeList;
	}

	public BaseModelCollection<String> getMajorList() {
		return majorList;
	}

	public void setMajorList(BaseModelCollection<String> majorList) {
		this.majorList = majorList;
	}

	public BaseModelCollection<EducationCountry> getStatusList() {
		return statusList;
	}

	public void setStatusList(BaseModelCollection<EducationCountry> statusList) {
		this.statusList = statusList;
	}

	@Override
	public long getId() {
		// TODO Auto-generated method stub
		return 0;
	}

}
