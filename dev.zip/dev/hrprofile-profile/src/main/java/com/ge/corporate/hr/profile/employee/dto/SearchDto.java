/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;

public class SearchDto  extends AbstractBaseDtoSupport{

	private static final long serialVersionUID = -6246023705366590869L;
	
	private Long currentSso;
	private String query;

	public void setQuery(String searchText) {
		this.query = searchText;
	}

	public String getQuery() {
		return query;
	}

	public void setCurrentSso(Long currentSso) {
		this.currentSso = currentSso;
	}

	public Long getCurrentSso() {
		return currentSso;
	}

	public long getId() {
		return 0;
	}
	
}
