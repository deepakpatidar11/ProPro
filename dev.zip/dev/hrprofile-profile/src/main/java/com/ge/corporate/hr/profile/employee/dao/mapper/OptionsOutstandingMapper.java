/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import com.ge.corporate.hr.profile.employee.model.StockOption;
/**
 * Stock option mapper
 * @author enrique.romero
 *
 */
public class OptionsOutstandingMapper implements RowMapper<StockOption>{
	
	
	public static final String DATA_EXERCISED = "so_shares_exercised";
	public static final String DATA_TOTAL = "so_total";
	public static final String DATA_SHARE_VESTED = "so_shares_vested";
	public static final String DATA_SHARE_UNVESTED = "so_shares_unvested";
	
	

	public StockOption mapRow(ResultSet rs, int rowNum) throws SQLException {		
		StockOption stockOpt = new StockOption();
		
		stockOpt.setExercised(rs.getInt(DATA_EXERCISED));
		stockOpt.setTotal(rs.getInt(DATA_TOTAL));
		stockOpt.setSharedVested(rs.getInt(DATA_SHARE_VESTED));
		stockOpt.setSharedUnvested(rs.getInt(DATA_SHARE_UNVESTED));
		
		return stockOpt;		
	}
}
