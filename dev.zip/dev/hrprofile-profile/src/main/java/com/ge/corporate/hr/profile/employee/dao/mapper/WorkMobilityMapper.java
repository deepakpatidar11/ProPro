package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.WorkMobility;

public class WorkMobilityMapper implements RowMapper<WorkMobility> {
	public static final String DATA_SSO = "sso";
	public static final String DATA_MOBILITY_RELOCATEWITHIN = "mobility_relocatewithin";
	public static final String DATA_RELOCATE_OUTSIDE = "relocate_outside";
		
	@Override
	public WorkMobility mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		WorkMobility workMobility = new WorkMobility();
		workMobility.setSso(rs.getLong(DATA_SSO));
		workMobility.setRelocateWithin(rs.getString(DATA_MOBILITY_RELOCATEWITHIN));
		workMobility.setRelocateOutside(rs.getString(DATA_RELOCATE_OUTSIDE));
		return workMobility;
	}

}
