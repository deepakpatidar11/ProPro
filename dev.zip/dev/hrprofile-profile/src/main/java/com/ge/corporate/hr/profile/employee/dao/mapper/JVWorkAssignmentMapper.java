package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.JVEmployee;

public class JVWorkAssignmentMapper implements RowMapper<JVEmployee>{

	public static final String DATA_SSO = "prsn_sso_id";
	public static final String DATA_PERSON_TYPE = "emp_person_type";
	public static final String DATA_TITLE = "emp_title";
	public static final String DATA_IFG = "emp_ifg";
	public static final String DATA_BS = "emp_bs";
	public static final String DATA_SB = "emp_sb";
	public static final String DATA_JOB_FN = "emp_job_fn";
	public static final String DATA_SPONSOR_SSO = "emp_sponsor_sso";
	public static final String DATA_SPONSOR_NAME = "emp_sponsor_name";
	/*public static final String DATA_SPONSOR_FIRSTNAME = "emp_sponsor_firstname";
	public static final String DATA_SPONSOR_LASTNAME = "emp_sponsor_lastname";*/
	
	public JVEmployee mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		
		JVEmployee employee = new JVEmployee();
		employee.setSso(rs.getLong(DATA_SSO));
		employee.setBusinessSegment(rs.getString(DATA_BS));		
		if(rs.getString(DATA_IFG)!=null && rs.getString(DATA_IFG).equalsIgnoreCase("Granite")){
			employee.setIfgName("FieldCore");
		}else{
			employee.setIfgName(rs.getString(DATA_IFG));
		}
		employee.setJobFunction(rs.getString(DATA_JOB_FN));
		employee.setPersonType(rs.getString(DATA_PERSON_TYPE));
		employee.setSubBusiness(rs.getString(DATA_SB));
		employee.setTitle(rs.getString(DATA_TITLE));
		employee.setSponsorName(rs.getString(DATA_SPONSOR_NAME));
		employee.setSponsorSSO(rs.getLong(DATA_SPONSOR_SSO));
		if(employee.getSponsorName()!=null && !employee.getSponsorName().equalsIgnoreCase("") && employee.getSponsorName().contains(",")){
			String[] firstName = employee.getSponsorName().split(",");
			employee.setSponsorLastName(firstName[0]);
			if(firstName[1].contains("(")){
				String[] preferredName = firstName[1].split("\\(");
				employee.setSponsorFirstName(preferredName[1].substring(0, preferredName[1].length()-1));
			}else{
				employee.setSponsorFirstName(firstName[1]);
			}
		}else{
			employee.setSponsorLastName(rs.getString(DATA_SPONSOR_NAME));
			employee.setSponsorFirstName(rs.getString(DATA_SPONSOR_NAME));
		}
		return employee;
	}

}
