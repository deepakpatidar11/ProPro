/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ge.corporate.hr.profile.auth.util.PersonAuthUtil;
import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.common.service.AbstractBaseServiceSupport;
import com.ge.corporate.hr.profile.employee.dao.EmergencyContactDao;
import com.ge.corporate.hr.profile.employee.dao.EmployeeDao;
import com.ge.corporate.hr.profile.employee.dao.WorkAssignmentDao;
import com.ge.corporate.hr.profile.employee.dto.ContingAssignmentDto;
import com.ge.corporate.hr.profile.employee.dto.ContingWorkMgmntDto;
import com.ge.corporate.hr.profile.employee.dto.JVAssignmentDto;
import com.ge.corporate.hr.profile.employee.dto.PersonalInfoDto;
import com.ge.corporate.hr.profile.employee.model.ContingentEmployee;
import com.ge.corporate.hr.profile.employee.model.ContingentManagement;
import com.ge.corporate.hr.profile.employee.model.EmergencyContact;
import com.ge.corporate.hr.profile.employee.model.Employee;
import com.ge.corporate.hr.profile.employee.model.EmployeeAssignment;
import com.ge.corporate.hr.profile.employee.model.EmployeeExpertise;
import com.ge.corporate.hr.profile.employee.model.HomeAddress;
import com.ge.corporate.hr.profile.employee.model.JVEmployee;
import com.ge.corporate.hr.profile.employee.model.ProfileCompleteness;
import com.ge.corporate.hr.profile.employee.model.ProfileUserMetrics;
import com.ge.corporate.hr.profile.employee.model.UserInfo;
import com.ge.corporate.hr.profile.employee.model.WorkAssignment;
import com.ge.corporate.hr.profile.employee.model.WorkAssignmentRestricted;
import com.ge.corporate.hr.profile.employee.service.cache.ServiceKeyGenerator;
import com.ge.corporate.hr.profile.employee.ws.dto.AssignmentDto;
import com.ge.corporate.hr.profile.employee.ws.dto.EmployeeBasicInfoDto;
import com.ge.corporate.hr.profile.employee.ws.dto.EmployeeDto;

public class EmployeeProfileServiceImpl extends AbstractBaseServiceSupport implements EmployeeProfileService {
	private static Log logger = LogFactory.getLog(EmployeeProfileServiceImpl.class);	
	private static final int LIMIT = 1000; 
	@Resource(name = "workAssignmentDao")
	private WorkAssignmentDao assignmentDao;
	@Resource(name = "employeeDao")
	private EmployeeDao employeeDao;
	@Resource(name = "emergencyContactDao")
	private EmergencyContactDao emergencyContactDao;
	
	
	@Cache(
			nodeName="/profile/employee/service/employeeProfileService",
			keyGeneratorClass=ServiceKeyGenerator.class,
			cacheName=InfinispanCacheFactory.EMPSERVICECACHE	
		)
	public PersonalInfoDto getPersonalInfo(PersonalInfoDto personalInfo) {
		PersonalInfoDto infoDto = new PersonalInfoDto();		
		//Set information depending on security data groups they belongs to	
		setPersonalIdentificationDGData(personalInfo.getSso(), infoDto);
		setWorkAssignmentDGData( infoDto);
		//setEmergencyContactInfoDGData( infoDto);	
		//setHomeAddressInfoDGData(infoDto);
		setExpertiseAsString(infoDto);	
		/*below lines added for Connection tab*/
		WorkAssignmentRestricted corpBand = assignmentDao.getCurrentCorpBandBySso(personalInfo.getSso());
		if(null != corpBand)  {
			infoDto.setBand(corpBand.getBand());
		}
		
		return infoDto;
	}
	
	

	public void setExpertiseAsString(PersonalInfoDto infoDto) {
		String expertise = "";
		BaseModelCollection<EmployeeExpertise> expListbySso= getExpertiseListBySSO(infoDto.getSso());
		int i=1;
		for(EmployeeExpertise exp : expListbySso.getList()) {
			if("Y".equals(exp.getExpertise().getApprovedFlag()) && i++ != expListbySso.getList().size()) {
				expertise = expertise + exp.getExpertise().getName() + ",";
			}
			else
				expertise = expertise + exp.getExpertise().getName();				
		}
		if(!expertise.isEmpty()) {
			infoDto.setExpertise(expertise);
		}		
	}

	public PersonalInfoDto getContingentPersonalInfo(
			PersonalInfoDto personalInfo)
	{
		PersonalInfoDto infoDto = new PersonalInfoDto();	
		
		//Set information depending on security data groups they belongs to		
		setContgntPersonalIdentificationDGData(personalInfo.getSso(), infoDto);

		return infoDto;
		
	}
	
	
	public void setContgntPersonalIdentificationDGData(Long sso, PersonalInfoDto infoDto) {
		
		ContingentEmployee employee = employeeDao.getContEmployeeBySso(sso);		
		if(employee != null){			
			//Mapping Model to DTO				
			infoDto.setSso(sso);
			infoDto.setFirstName(employee.getFirstName());
			infoDto.setLastName(employee.getLastName());
			infoDto.setFullName(employee.getFullName());
			infoDto.setPreferredName(employee.getKnownAs());
			infoDto.setAddress1(employee.getAddress());
			infoDto.setCity(employee.getCity());
			infoDto.setState(employee.getState());
			infoDto.setCountry(employee.getCountry());
			infoDto.setZip(employee.getZip());
			infoDto.setEmail(employee.getEmail());
			infoDto.setPhone(employee.getPhone());
			infoDto.setDcomm(employee.getDcomm());
			infoDto.setFax(employee.getFax());
			infoDto.setCell(employee.getMobile());
			infoDto.setMailstop(employee.getMailstop());
			infoDto.setInternalLocation(employee.getInternalLocation());
	
		}		
		else{
			logger.debug("employee is null");
		}
		
	}

	public ContingAssignmentDto getContingentWorkAssgnmtInfo(Long sso,
			ContingAssignmentDto assignmentDto)
	{
		//Set information depending on security data groups they belongs to		
		setContingentWorkAssignment(sso,assignmentDto);
		return assignmentDto;
		
	}
	
	private void setContingentWorkAssignment(Long sso,
			ContingAssignmentDto assignmentDto) {
		// TODO Auto-generated method stub
		ContingentEmployee employee = employeeDao.getContWorkAssgnmtbySso(sso);
		if(employee != null){			
			//Mapping Model to DTO				
			assignmentDto.setBusinessSegmentName(employee.getBusinessSegment());
			assignmentDto.setDepartment(employee.getDepartment());
			assignmentDto.setIndustrySegment(employee.getIfgName());
			assignmentDto.setJobFamily(employee.getJobFamily());
			assignmentDto.setJobFucntion(employee.getJobFunction());
			assignmentDto.setPersonType(employee.getPersonType());
			assignmentDto.setSubBusinessName(employee.getSubBusiness());
			assignmentDto.setTitle(employee.getTitle());
			assignmentDto.setSponsorName(employee.getSponsorName());
			assignmentDto.setSponsorFirstName(employee.getSponsorFirstName());
			assignmentDto.setSponsorLastName(employee.getSponsorLastName());
			assignmentDto.setSponsorSso(employee.getSponsorSSO());
			assignmentDto.setSsoStartDate(employee.getSsoStartDate());
			assignmentDto.setSsoEndDate(employee.getSsoEndDate());

		}		
		else{
			logger.debug("Employee assignment is null");
		}
		
	}
	
	public ContingWorkMgmntDto getContingentWorkMgmntInfo(Long sso,
			ContingWorkMgmntDto contingWorkMgmntDto) {
		//Set information depending on security data groups they belongs to		
		setContingentWorkMgmnt(sso,contingWorkMgmntDto);
		return contingWorkMgmntDto;
	}

	private void setContingentWorkMgmnt(Long sso,
			ContingWorkMgmntDto contingWorkMgmntDto) {
		// TODO Auto-generated method stub
		ContingentManagement contingentManagement = employeeDao.getContManagement(sso);
		if(contingentManagement != null){			
			//Mapping Model to DTO				
			contingWorkMgmntDto.setActlResources(contingentManagement.getActlResources());
			contingWorkMgmntDto.setApprvdResources(contingentManagement.getApprvdResources());
			contingWorkMgmntDto.setSupplier(contingentManagement.getSupplier());
			contingWorkMgmntDto.setWorkerType(contingentManagement.getWorkerType());
			contingWorkMgmntDto.setWorkReqEndDate(contingentManagement.getWorkReqEndDate());
			contingWorkMgmntDto.setWorkReqId(contingentManagement.getWorkReqId());
			contingWorkMgmntDto.setWorkReqName(contingentManagement.getWorkReqName());
			contingWorkMgmntDto.setWorkReqStatus(contingentManagement.getWorkReqStatus());
			contingWorkMgmntDto.setWorkReqStartDate(contingentManagement.getWorkReqStartDate());

		}		
		else{
			logger.debug("Contingent Management data is null");
		}
		
	}
	/**
	 * Returns of Basic Employee Information by Sso List
	 * @param ssoList
	 * @return
	 */
	public List<EmployeeBasicInfoDto> getEmployeeBasicInfoList(List<Long> ssoList){
		
		BaseModelCollection<Employee> employeeBaseModel = null;		
		List<Employee> employeeList = null ;
		List<EmployeeBasicInfoDto> employeeBasicListRet = new ArrayList<EmployeeBasicInfoDto>();
		int size = ssoList.size();		
		int times = size/LIMIT;
		
		for(int i =0 ; i <= times; i++){
			
			if((i*LIMIT)<size){
				
				List<Long> subList = ssoList.subList((i*LIMIT), ((i+1)*LIMIT >= size)?size:(i+1)*LIMIT);
				
				employeeBaseModel = employeeDao.getBasicEmployeeListBySsoList(subList);			
				//Map Employee Model to EmployeeBasicInfoDto 
				if(employeeBaseModel != null){
					employeeList = (List<Employee>)employeeBaseModel.getList();
					if(employeeList!=null && employeeList.size()>0){
						List<EmployeeBasicInfoDto> employeeBasicList = new ArrayList<EmployeeBasicInfoDto>(); 
						for(Employee emp:employeeList){
							EmployeeBasicInfoDto empBasic = new EmployeeBasicInfoDto();
							empBasic.setSso(emp.getSso());			
							empBasic.setFirstName(emp.getFirstName());
							empBasic.setLastName(emp.getLastName());
							empBasic.setPreferredName(emp.getPreferedName());
							empBasic.setIfgName(emp.getIfgName());
							
							employeeBasicList.add(empBasic);
						}
						employeeBasicListRet.addAll(employeeBasicList);
						//return employeeBasicList;				
					}
				}
			}
		}
		
		if(employeeBasicListRet.size()>0)
			return employeeBasicListRet;
		
		return null;
		
	}	
	
	public List<EmployeeDto> getEmployeeInfoList(List<Long> ssoList){		
		 
		BaseModelCollection<EmployeeAssignment> employeeBaseModel = null;		
		List<EmployeeAssignment> employeeList = null ; 
		employeeBaseModel = employeeDao.getEmployeeListBySsoList(ssoList);
		
		//Map EmployeeAssignment Model to EmployeeWSDto 
		if(employeeBaseModel != null){
			employeeList = (List<EmployeeAssignment>)employeeBaseModel.getList();
			if(employeeList!=null && employeeList.size()>0){
				List<EmployeeDto> employeeAssgmntList = new ArrayList<EmployeeDto>(); 
				for(EmployeeAssignment emp:employeeList){
					
					EmployeeDto empAssignment = new EmployeeDto();
					EmployeeBasicInfoDto basicInf = new EmployeeBasicInfoDto();
					AssignmentDto assgnmt = new AssignmentDto();
					empAssignment.setBasicInfo(basicInf);
					empAssignment.setAssignment(assgnmt);
					
					empAssignment.getBasicInfo().setSso(emp.getEmployee().getSso());			
					empAssignment.getBasicInfo().setFirstName(emp.getEmployee().getFirstName());					
					empAssignment.getBasicInfo().setLastName(emp.getEmployee().getLastName());
					empAssignment.getBasicInfo().setPreferredName(emp.getEmployee().getPreferedName());
					empAssignment.getBasicInfo().setIfgName(emp.getEmployee().getIfgName());
					empAssignment.getAssignment().setAddress(emp.getWorkAssignment().getAddress1());
					empAssignment.getAssignment().setCity(emp.getWorkAssignment().getAddress1());
					empAssignment.getAssignment().setState(emp.getWorkAssignment().getState());
					empAssignment.getAssignment().setZip(emp.getWorkAssignment().getZip());
					empAssignment.getAssignment().setCountry(emp.getWorkAssignment().getCountry());
					empAssignment.getAssignment().setEmail(emp.getWorkAssignment().getEmail());
					empAssignment.getAssignment().setPhone(emp.getWorkAssignment().getPhone());
					empAssignment.getAssignment().setDcomm(emp.getWorkAssignment().getDcomm());
					empAssignment.getAssignment().setCell(emp.getWorkAssignment().getMobile());					
					empAssignment.getAssignment().setTitle(emp.getWorkAssignment().getPositionTitle());
					empAssignment.getAssignment().setIndustrySegmentId(emp.getWorkAssignment().getIfgId());
					empAssignment.getAssignment().setBusinessSegmentId(emp.getWorkAssignment().getBusinessSegmentId());					
					empAssignment.getAssignment().setSubBusinessId(emp.getWorkAssignment().getSubBusinessId());					
					empAssignment.getAssignment().setOrganizationId(emp.getWorkAssignment().getOrgId());
					empAssignment.getAssignment().setEmployeeType(emp.getWorkAssignment().getEmployeeType());
					empAssignment.getAssignment().setJobFucntion(emp.getWorkAssignment().getJobFunction());
					empAssignment.getAssignment().setJobFamily(emp.getWorkAssignment().getJobFamily());
					empAssignment.getAssignment().setManagerSso(emp.getWorkAssignment().getManager());
					empAssignment.getAssignment().setManager(emp.getWorkAssignment().getManagerName());
					empAssignment.getAssignment().setHrManagerSso(emp.getWorkAssignment().getHrManager());
					empAssignment.getAssignment().setHrManager(emp.getWorkAssignment().getHrManagerName());
					empAssignment.getAssignment().setLocalHrManagerSso(emp.getWorkAssignment().getLocalHrManager());
					empAssignment.getAssignment().setLocalHrManager(emp.getWorkAssignment().getLocalHrManagerName());							
					
					employeeAssgmntList.add(empAssignment);
				}	
				
				return employeeAssgmntList;
			}
		}
		return null;
	}
	
	public void setPersonalIdentificationDGData(Long sso, PersonalInfoDto infoDto) {
		Employee employee = employeeDao.getEmployeeBySso(sso);		
		if(employee != null){			
			//Mapping Model to DTO				
			infoDto.setSso(sso);
			infoDto.setFirstName(employee.getFirstName());
			infoDto.setLastName(employee.getLastName());
		}		
		else{
			logger.debug("employee is null");
		}	
	}
	
	public void setEmergencyContactInfoDGData(PersonalInfoDto infoDto) {
		EmergencyContact contact = emergencyContactDao.getEmergencyContactBySso(infoDto.getSso());				
		if(contact != null){
			//Mapping Model to DTO					
			//ToDo Implement Dozer Mapping			
			infoDto.setEmergencyContactName(contact.getFullName());
			infoDto.setEmergencyContactRelationship(contact.getRelationship());		
			infoDto.setEmergencyContactAddress(contact.getAddress1());
			infoDto.setEmergencyContactCity(contact.getCity());			
			infoDto.setEmergencyContactState(contact.getState());
			infoDto.setEmergencyContactZip(contact.getZip());
			infoDto.setEmergencyContactCountry(contact.getCountry());						
			infoDto.setEmergencyContactPriPhone(contact.getPrimaryPhone());
			infoDto.setEmergencyContactSecPhone(contact.getSecondaryPhone());
			
			infoDto.setOwnEmergencyContactPriPhone(contact.getOwnPrimaryPhone());
			infoDto.setOwnEmergencyContactSecPhone(contact.getOwnSecondaryPhone());
			
		}else{
			logger.debug("contact is null");
		}
	}
	
	
	public void setHomeAddressInfoDGData(PersonalInfoDto infoDto) {
		HomeAddress homeAddress = employeeDao.getHomeAdressBySso(infoDto.getSso());				
		if(homeAddress != null){
			//Mapping Model to DTO					
			//ToDo Implement Dozer Mapping		
			
			infoDto.setHomeAddrAddress(homeAddress.getAddress1());
			infoDto.setHomeAddrCity(homeAddress.getCity());			
			infoDto.setHomeAddrCountry(homeAddress.getCountry());
			infoDto.setHomeAddrState(homeAddress.getState());
			infoDto.setHomeAddrZip(homeAddress.getZip());			
		}else{
			logger.debug("home adress is null");
		}
	}
	
		
	public void setWorkAssignmentDGData(PersonalInfoDto infoDto){
		WorkAssignment assignment = null;
		
		if(infoDto.isAlstomEmployee()){
			assignment = assignmentDao.getCurrentWorkAssignmentAlstomBySso(infoDto.getSso());		
		}else{
			assignment = assignmentDao.getCurrentWorkAssignmentBySso(infoDto.getSso());	
		}
		//this line must be analyzed , we are not sure where get email, phone, dcomm and cell this information could be get from assiignment too
		Employee employee = employeeDao.getEmployeeBySso(infoDto.getSso());		
		if(assignment != null){
			
			//Mapping Model to DTO					
			//ToDo Implement Dozer Mapping			
			infoDto.setTitle(assignment.getPositionTitle());
			infoDto.setIndustrySegment(assignment.getIfg());
			infoDto.setBussinesSegment(assignment.getBusinessSegment());
			infoDto.setSubBusiness(assignment.getSubBusiness());
			infoDto.setFunction(assignment.getJobFunction());
			infoDto.setManager(assignment.getManagerName());
			infoDto.setManagerSso(assignment.getManager());
			infoDto.setHrManager(assignment.getHrManagerName());
			infoDto.setHrManagerSso(assignment.getHrManager());
			infoDto.setHrManagerEmail(assignment.getHrManagerEmail());
			infoDto.setAddress1(assignment.getAddress1());
			infoDto.setAddress2(assignment.getAddress2());
			infoDto.setAddress3(assignment.getAddress3());
			infoDto.setCity(assignment.getCity());
			infoDto.setState(assignment.getState());
			infoDto.setCountry(assignment.getCountry());
			infoDto.setRegion(assignment.getRegion());
			infoDto.setZip(assignment.getZip());
			//this code must be analyzed , we are not sure where get email, phone, dcomm and cell this information could be get from assiignment too
			infoDto.setEmail(employee.getEmail());
			infoDto.setPhone(employee.getPhone());
			infoDto.setDcomm(employee.getDcomm());
			infoDto.setCell(employee.getMobile());
			infoDto.setPreferredName(employee.getPreferedName());
			infoDto.setMailstop(employee.getMailstop());
			infoDto.setInternalLocation(employee.getInternalLocation());
			infoDto.setHeadcountValue(assignment.getHeadcountValue());
			infoDto.setAssignmentStatus(assignment.getAssignmentStatus());
			infoDto.setPayrollProcessorCode(employee.getPayrollProcessorCode());
			infoDto.setLegalEntity(employee.getLegalEntity());
			//below field is set to retrieve it for metrics purpose
			infoDto.setEmpType(assignment.getEmployeeType());
			
			
		}else{
			logger.debug("assigment is null");
		}			
	}
	
	@Override
	public void captureLoginMetrics(String page, Long ssoViewed, Boolean isCW, List<String> rolesForContext,
			HttpSession session, String userAgent) {

		ProfileUserMetrics metrics = new ProfileUserMetrics();
		PersonalInfoDto personalInfo;

		if (session.getAttribute("IS_LGN") == null) {
			session.setAttribute("IS_LGN", true);
			metrics.setLoginType("LOGIN");
		} else {
			metrics.setLoginType(page);
		}

		try {
			if (isCW) {
				ContingAssignmentDto contingAssignment = new ContingAssignmentDto();
				contingAssignment = getContingentWorkAssgnmtInfo(PersonAuthUtil.getLoggedSSO(), contingAssignment);
				metrics.setBusiness(contingAssignment.getIndustrySegment());
				metrics.setFunction(contingAssignment.getJobFucntion());
				// metrics.setRegion(contingAssignment.getRegion());
				if (PersonAuthUtil.getLoggedSSO().equals(ssoViewed)) {
					metrics.setViewType("CW");
				} else {
					metrics.setViewType("CW_OTHER");
				}
			} else {
				personalInfo = new PersonalInfoDto();
				personalInfo.setSso(PersonAuthUtil.getLoggedSSO());
				personalInfo = getPersonalInfo(personalInfo);
				metrics.setBusiness(personalInfo.getIndustrySegment());
				metrics.setFunction(personalInfo.getFunction());
				metrics.setRegion(personalInfo.getRegion());
				if (PersonAuthUtil.getLoggedSSO().equals(ssoViewed)) {
					if (null != personalInfo.getEmpType()) {
						metrics.setViewType(personalInfo.getEmpType().toUpperCase());
					}
				} else if (null != personalInfo.getEmpType()) {
					metrics.setViewType(personalInfo.getEmpType().toUpperCase() + "_OTHER");
				}
			}

			metrics.setPageVisited(page);
			metrics.setSso(PersonAuthUtil.getLoggedSSO());
			metrics.setViewedSso(ssoViewed);
			metrics.setRolesForContext(StringUtils.join(rolesForContext, "|"));
			ProfileUserMetrics.setUserAgentDetails(metrics, userAgent);

			employeeDao.insertLoginMetrics(metrics);
		} catch (Exception e) {
			logger.debug("insertLoginMetrics - "+e.getMessage());
		}
	}
	
	@Override
	public boolean addConnection(Long sso, Long connectSSO, int connectionType) {
		return employeeDao.addConnection(sso, connectSSO, connectionType);
	}
	
	@Override
	public boolean deleteConnection(Long sso, Long connectSSO, int connectionType) {
		return employeeDao.deleteConnection(sso, connectSSO, connectionType);
	}
	
	@Override
    public BaseModelCollection<EmployeeExpertise> getExpertiseListBySSO(Long sso) {
    	return employeeDao.getExpertiseListBySSO(sso);
    }
	
	@Override
	public Map<String, List<Integer>> getEmpMentoringInterestBySSO(Long sso) {
		return employeeDao.getEmpMentoringInterest(sso);
	}
	
	@Override
	public BaseModelCollection<EmployeeExpertise> updateEmpExperties(Long sso, List<EmployeeExpertise> expertises) {
		return employeeDao.updateEmpExpertise(sso, expertises);
	}
	
	public UserInfo getLoggedUserInfo(Long sso){
		return employeeDao.loggedUserInfo(sso);
	}
	
	public boolean isValidSSO (Long sso){
	
		return employeeDao.isValidSSO(sso);
	}
	
	public boolean showInfoPopupStatusBySSOService(Long sso){
		return employeeDao.showInfoPopupStatusBySSODao(sso);
	}
	
	public boolean showWhatsNewPopupBySSOService(Long sso){
		return employeeDao.showWhatsNewPopupBySSODao(sso);
	}
	
	public void infoPopupInsertBySSOService(Long sso, String flag){
		employeeDao.infoPopupInsertBySSODao(sso, flag);
	}
	
	public void whatsnewInsertBySSOService(Long sso, String flag){
		employeeDao.whatsnewInsertBySSODao(sso, flag);
	}

	@Override
	public void insertExpertisePopupBySSOService(Long sso, String flag) {
		employeeDao.insertExpertiseEmptyPopupBySSO(sso, flag);
	}
	
	@Override
	public boolean showExpertiseEmptyPopupBySSOService(Long sso) {
		return employeeDao.showExpertiseEmptyPopupBySSO(sso);
	}
	/*public void sensitiveDataPopupService(Long sso, String flag){
		employeeDao.sensitiveDataPopupDao(sso,flag);
	}
	
	public void sensitiveDataPopupDeleteRolesService(Long sso){
		employeeDao.sensitiveDataPopupDeleteRolesDao(sso);
	}
	
	public boolean isValidSensitiveDataPopupService(Long sso){
		return employeeDao.isValidSensitiveDataPopupDao(sso);
	}*/
	public void setAssignmentDao(WorkAssignmentDao assignmentDao) {
		this.assignmentDao = assignmentDao;
	}

	public WorkAssignmentDao getAssignmentDao() {
		return assignmentDao;
	}
	
	public void setEmployeeDao(EmployeeDao employeeDao) {
		this.employeeDao = employeeDao;
	}

	public EmployeeDao getEmployeeDao() {
		return employeeDao;
	}

	public void setEmergencyContactDao(EmergencyContactDao emergencyContactDao) {
		this.emergencyContactDao = emergencyContactDao;
	}

	public EmergencyContactDao getEmergencyContactDao() {
		return emergencyContactDao;
	}

	public ProfileCompleteness getProfileCompleteness(Long sso, Boolean expertiseFlag) {
		return employeeDao.getProfileCompleteness(sso, expertiseFlag);
	}
	
	public ProfileCompleteness getProfileBreakdown(Long sso) {
		return employeeDao.getProfileBreakdown(sso);
	}
	
	public String escapeSpecialCharacters(String s) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			// These characters are part of the query syntax and must be
			// escaped
			/*if (c == '\\' || c == '+' || c == '-' || c == '!' || c == '('
					|| c == ')' || c == ':' || c == '^' || c == '['
					|| c == ']' || c == '\"' || c == '{' || c == '}'
					|| c == '~' || c == '*' || c == '?' || c == '|'
					|| c == '&' || c == '/' ) {
					sb.append('\\');
				sb.append(c);
			}*/

	        if(c == '<') {
	            sb.append("&lt;");
	        } else if(c == '>') {
	            sb.append("&gt;");
	        } else if(c == '\'') {
	            sb.append("&#39;"); 
	        } else if(c == '"') {
	            sb.append("&quot;");                        
	        } else {
	            sb.append(c);
	        }
		}
		return sb.toString();
	}



	@Override
	public PersonalInfoDto getJVPersonalInfo(PersonalInfoDto personalInfo) {
		PersonalInfoDto infoDto = new PersonalInfoDto();	
		
		//Set information depending on security data groups they belongs to		
		setJVPersonalIdentificationDGData(personalInfo.getSso(), infoDto);

		return infoDto;
		
	}
	
public void setJVPersonalIdentificationDGData(Long sso, PersonalInfoDto infoDto) {
		
		JVEmployee employee = employeeDao.getJVEmployeeBySso(sso);		
		if(employee != null){			
			//Mapping Model to DTO				
			infoDto.setSso(sso);
			infoDto.setFirstName(employee.getFirstName());
			infoDto.setLastName(employee.getLastName());
			infoDto.setFullName(employee.getFullName());
			infoDto.setAddress1(employee.getAddress());
			infoDto.setCity(employee.getCity());
			infoDto.setState(employee.getState());
			infoDto.setCountry(employee.getCountry());
			infoDto.setZip(employee.getZip());
			infoDto.setEmail(employee.getEmail());
			infoDto.setPhone(employee.getPhone());
			infoDto.setCell(employee.getMobile());
		}		
		else{
			logger.debug("employee is null");
		}
		
	}

	@Override
	public JVAssignmentDto getJVAssgnmtInfo(Long sso, JVAssignmentDto assignmentDto) {
		setJVWorkAssignment(sso,assignmentDto);
		return assignmentDto;
	}



	private void setJVWorkAssignment(Long sso, JVAssignmentDto assignmentDto) {
		// TODO Auto-generated method stub
		JVEmployee employee = employeeDao.getJVWorkAssgnmtbySso(sso);
		if(employee != null){			
			//Mapping Model to DTO				
			assignmentDto.setBusinessSegmentName(employee.getBusinessSegment());
			assignmentDto.setIndustrySegment(employee.getIfgName());
			assignmentDto.setJobFucntion(employee.getJobFunction());
			assignmentDto.setPersonType(employee.getPersonType());
			assignmentDto.setSubBusinessName(employee.getSubBusiness());
			assignmentDto.setTitle(employee.getTitle());
			assignmentDto.setSponsorName(employee.getSponsorName());
			assignmentDto.setSponsorFirstName(employee.getSponsorFirstName());
			assignmentDto.setSponsorLastName(employee.getSponsorLastName());
			assignmentDto.setSponsorSso(employee.getSponsorSSO());
		}		
		else{
			logger.debug("Employee assignment is null");
		}
		
	}
}
