/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="stockOptionTotals")
@XmlAccessorType(XmlAccessType.FIELD)
public class StockOptionTotals extends AbstractBaseModelSupport{

	private static final long serialVersionUID = 5099578513065376768L;
	
	@XmlElement(name="numShares")
	private Integer numShares;
	@XmlAttribute(name="exercided")
	private Long exercided;	
	@XmlAttribute(name="total")
	private Long total;	
	@XmlElement(name="sharedVested;")
	private Integer sharedVested;
	@XmlElement(name="sharedUnvested;")
	private Integer sharedUnvested;
		
	public Integer getNumShares() {
		return numShares;
	}
	public void setNumShares(Integer numShares) {
		this.numShares = numShares;
	}
	public Long getExercided() {
		return exercided;
	}
	public void setExercided(Long exercided) {
		this.exercided = exercided;
	}
	public Long getTotal() {
		return total;
	}
	public void setTotal(Long total) {
		this.total = total;
	}
	public Integer getSharedVested() {
		return sharedVested;
	}
	public void setSharedVested(Integer sharedVested) {
		this.sharedVested = sharedVested;
	}
	public Integer getSharedUnvested() {
		return sharedUnvested;
	}
	public void setSharedUnvested(Integer sharedUnvested) {
		this.sharedUnvested = sharedUnvested;
	}
	
}
