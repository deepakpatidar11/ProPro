package com.ge.corporate.hr.profile.employee.service;

import java.util.List;

import com.ge.corporate.hr.profile.employee.dto.InterestAffiliationDto;
import com.ge.corporate.hr.profile.employee.model.AffinityGroups;
import com.ge.corporate.hr.profile.employee.model.Mentoring;
import com.ge.corporate.hr.profile.employee.model.OnlineNetwork;

public interface InterestAffiliationService {
	
	public InterestAffiliationDto getInterestAffiliations(Long sso, boolean showProfInterests, boolean showExtGroupAffiliations, boolean showOnlineNetworks);

	public boolean saveProfessionalInterests(Long sso, String interests);
	public boolean saveMentoringData(Long sso, Mentoring mentoring);
	
	public boolean saveOnlineNetworks(Long sso,
			List<OnlineNetwork> list);

	public boolean saveExternalAffiliations(Long sso,
			List<AffinityGroups> externalAffiliationsList);

	public Mentoring getMentoringData(Long sso, boolean connectFlag);
}
