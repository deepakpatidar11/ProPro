/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.employee.model.AutoCompleteViewModel;



public class AutoCompleteDto extends AbstractBaseDtoSupport{

	/**
	 *Default serial ID 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Query String	
	 */
	private String query;
	
	private int counter;
	/**
	 * Education Model
	 */
	AutoCompleteViewModel autoComplete;
	
		
	public AutoCompleteViewModel getAutoComplete() {
		return autoComplete;
	}

	public void setAutoComplete(AutoCompleteViewModel autoComplete) {
		this.autoComplete = autoComplete;
	}

	public long getId() {
		return 0;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public String getQuery() {
		return query;
	}
	
	public int getCounter() {
		return counter;
	}

	public void setCounter(int counter) {
		this.counter = counter;
	}
	
		
}
