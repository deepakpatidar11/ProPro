/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.ShortProfile;

public class ShortProfileMapper implements RowMapper<ShortProfile>{
	
	public static final String DATA_SSO = "sso";
	public static final String DATA_FIRST_NAME = "emps_first_name";
	public static final String DATA_LAST_NAME = "emps_last_name";
	public static final String DATA_IFG = "emps_ifg";
	
	public ShortProfile mapRow(ResultSet rs, int rowNum) throws SQLException {		
		ShortProfile employee = new ShortProfile();
		
		employee.setSso(rs.getLong(DATA_SSO));		
		employee.setFirstName(rs.getString(DATA_FIRST_NAME));
		employee.setLastName(rs.getString(DATA_LAST_NAME));
		employee.setIndustry(rs.getString(DATA_IFG));
		return employee;		
	}
	
}
