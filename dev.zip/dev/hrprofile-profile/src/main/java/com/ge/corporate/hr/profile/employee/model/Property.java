/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;


public class Property extends AbstractBaseModelSupport{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 120570252065628774L;

	private Long id;	
	
	private String key;
	
	private String value;
	
	public void setId(Long id) {
		this.id = id;
	}	
	public Long getId() {
		return id;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}	
	
	
	
}
