package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.LeadershipProgramAssignment;

public class LeadershipProgramAssignmentMapper implements RowMapper<LeadershipProgramAssignment> {

	public static final String DATA_LEADER_NAME = "leader_full_name";
	public static final String DATA_PROGRAM_SHORT_NAME = "programshortname";
	public static final String DATA_LEADER_SSO = "leadersso";
	public static final String DATA_ROTATION_TITLE = "rotationtitle";
	public static final String DATA_ROTATION_NUMBER = "rotationnumber";
	public static final String DATA_ROTATION_SUBBUSINESS = "rotationsubbusinessname";
	public static final String DATA_ROTATION_SUBFUNCTION = "subfunction";

	@Override
	public LeadershipProgramAssignment mapRow(ResultSet rs, int rowNum)
			throws SQLException {

		LeadershipProgramAssignment lpAssignment = new LeadershipProgramAssignment();
		lpAssignment.setLeaderFullName(rs.getString(DATA_LEADER_NAME));
		lpAssignment.setLeaderSso(rs.getLong(DATA_LEADER_SSO));
		lpAssignment.setProgramShortName(rs.getString(DATA_PROGRAM_SHORT_NAME));
		lpAssignment.setRotationNumber(rs.getShort(DATA_ROTATION_NUMBER));
		lpAssignment.setRotationSubbusiness(rs.getString(DATA_ROTATION_SUBBUSINESS));
		lpAssignment.setRotationTitle(rs.getString(DATA_ROTATION_TITLE));
		lpAssignment.setSubFunction(rs.getString(DATA_ROTATION_SUBFUNCTION));
		return lpAssignment;
	}
}
