/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.serializer;
import java.io.IOException;
import java.util.Date;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;

/**
 * Custom Serializer for Dto's or model that are returned as JSON to views
 * @author enrique.romero
 *
 */
public class CustomRestrictedSerializer extends JsonSerializer<Object> {
	
	
	@Override    
    public void serialize(Object value, JsonGenerator gen, 
                          SerializerProvider arg2)
        throws IOException, JsonProcessingException {    	

    	//If value is null serializer must returns -r-, this means that this property is restricted
    	if(((Date)value).equals(new Date(0))){
    		gen.writeString("");
    	}else{
    		gen.writeString(value.toString());    		
    	}            
    }	
}
