package com.ge.corporate.hr.profile.employee.model;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dto.CountryRegionDto;

@XmlRootElement(name = "workMobility")
@XmlAccessorType(XmlAccessType.FIELD)
public class WorkMobility {

	private Long sso;
	
	@XmlElement(name = "relocateWithin")
	private String relocateWithin;

	@XmlElement(name = "relocateOutside")
	private String relocateOutside;

	private List<String> countryRegionList;

	@XmlElement(name="selectedCountryList")
	private List<String> selectedCountryList;

	@XmlElement(name="countryList")
	private BaseModelCollection<String> countryList;

	public BaseModelCollection<String> getCountryList() {
		return countryList;
	}

	public void setCountryList(BaseModelCollection<String> countryList) {
		this.countryList = countryList;
	}

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public String getRelocateWithin() {
		return relocateWithin;
	}

	public void setRelocateWithin(String relocateWithin) {
		this.relocateWithin = relocateWithin;
	}

	public String getRelocateOutside() {
		return relocateOutside;
	}

	public void setRelocateOutside(String relocateOutside) {
		this.relocateOutside = relocateOutside;
	}

	public List<String> getCountryRegionList() {
		return countryRegionList;
	}

	public void setCountryRegionList(List<String> countryRegionList) {
		this.countryRegionList = countryRegionList;
	}

	public List<String> getSelectedCountryList() {
		return selectedCountryList;
	}

	public void setSelectedCountryList(List<String> selectedCountryList) {
		this.selectedCountryList = selectedCountryList;
	}

}
