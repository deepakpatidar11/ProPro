/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.Program;

/**
 * Education Mapper
 * @author enrique.romero
 *
 */
public class ProgramNoYearMapper implements RowMapper<Program>{
	
	public static final String DATA_ID = "prg_id";
	public static final String DATA_NAME = "prg_name";	
	public static final String DATA_GRAD_YEAR = "eprg_graduation_year";
	public static final String DATA_STATUS = "prg_status";
	
	public Program mapRow(ResultSet rs, int rowNum) throws SQLException {
		Program program = new Program();
		
		program.setName(rs.getString(DATA_NAME));		
		program.setStatus(rs.getString(DATA_STATUS));		
		
		return program;
	}

}
