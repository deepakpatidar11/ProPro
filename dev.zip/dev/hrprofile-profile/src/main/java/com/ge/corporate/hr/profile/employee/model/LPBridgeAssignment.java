package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "lpBridgeAssignment")
@XmlAccessorType(XmlAccessType.FIELD)
public class LPBridgeAssignment {

	@XmlElement(name = "sso")
	private long sso;

	@XmlElement(name = "rotationNumber")
	private String rotationNumber;

	@XmlElement(name = "assignmentTitle")
	private String assignmentTitle;

	@XmlElement(name = "assignmentLeaderName")
	private String assignmentLeaderName;

	@XmlElement(name = "assignmentSubBusiness")
	private String assignmentSubBusiness;

	@XmlElement(name = "assignmentLeaderFor")
	private String assignmentLeaderFor;


	public long getSso() {
		return sso;
	}

	public void setSso(long sso) {
		this.sso = sso;
	}

	public String getRotationNumber() {
		return rotationNumber;
	}

	public void setRotationNumber(String rotationNumber) {
		this.rotationNumber = rotationNumber;
	}

	public String getAssignmentTitle() {
		return assignmentTitle;
	}

	public void setAssignmentTitle(String assignmentTitle) {
		this.assignmentTitle = assignmentTitle;
	}

	public String getAssignmentLeaderName() {
		return assignmentLeaderName;
	}

	public void setAssignmentLeaderName(String assignmentLeaderName) {
		this.assignmentLeaderName = assignmentLeaderName;
	}

	public String getAssignmentSubBusiness() {
		return assignmentSubBusiness;
	}

	public void setAssignmentSubBusiness(String assignmentSubBusiness) {
		this.assignmentSubBusiness = assignmentSubBusiness;
	}

	public String getAssignmentLeaderFor() {
		return assignmentLeaderFor;
	}

	public void setAssignmentLeaderFor(String assignmentLeaderFor) {
		this.assignmentLeaderFor = assignmentLeaderFor;
	}

	
}
