package com.ge.corporate.hr.profile.employee.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class OrgChartDto {
	@XmlElement(name = "sso")
	private Long sso;

	@XmlElement(name = "firstName")
	private String firstName;

	@XmlElement(name = "lastName")
	private String lastName;

	@XmlElement(name = "title")
	private String title;

	@XmlElement(name = "ifg")
	private String ifg;

	@XmlElement(name = "business")
	private String business;
	
	@XmlElement(name = "city")
	private String city;
	
	@XmlElement(name = "state")
	private String state;
	
	@XmlElement(name = "country")
	private String country;

	@XmlElement(name = "isContingentWorker")
	private String isContingentWorker;
	
	@XmlElement(name = "isLongTermSuspend")
	private String isLongTermSuspend;

	private List<OrgChartDirectReportsDto> directReportList;

	private List<OrgChartDirectReportsDto> contingentList;
	
	private List<OrgChartDirectReportsDto> peerList;

	private DirectReportsDto manager;

	private DirectReportsDto oneOverOneManager;

	private DirectReportsDto orgHeirarchy1;

	private DirectReportsDto orgHeirarchy2;
	
	private int totalDirectReports;
	
	private int totalNodes;
	
	private int totalPeers;

	public OrgChartDto(Long sso, String firstName, String lastName,
			String title, List<OrgChartDirectReportsDto> directReportList,
			List<OrgChartDirectReportsDto> contingentList,
			DirectReportsDto manager, DirectReportsDto oneOverOneManager,
			String ifg, String business, String city, String state, String country, DirectReportsDto orgHeirarchy2,
			DirectReportsDto orgHeirarchy1) {
		super();
		this.sso = sso;
		this.firstName = firstName;
		this.lastName = lastName;
		this.title = title;
		this.directReportList = directReportList;
		this.manager = manager;
		this.oneOverOneManager = oneOverOneManager;
		this.ifg = ifg;
		this.business = business;
		this.contingentList = contingentList;
		this.orgHeirarchy2 = orgHeirarchy2;
		this.orgHeirarchy1 = orgHeirarchy1;
		this.city = city;
		this.state = state;
		this.country = country;
	}

	public OrgChartDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getIsContingentWorker() {
		return isContingentWorker;
	}

	public void setIsContingentWorker(String isContingentWorker) {
		this.isContingentWorker = isContingentWorker;
	}

	public int getTotalDirectReports() {
		return totalDirectReports;
	}

	public void setTotalDirectReports(int totalDirectReports) {
		this.totalDirectReports = totalDirectReports;
	}

	public int getTotalNodes() {
		return totalNodes;
	}

	public void setTotalNodes(int totalNodes) {
		this.totalNodes = totalNodes;
	}

	public DirectReportsDto getOrgHeirarchy1() {
		return orgHeirarchy1;
	}

	public void setOrgHeirarchy1(DirectReportsDto orgHeirarchy1) {
		this.orgHeirarchy1 = orgHeirarchy1;
	}

	public DirectReportsDto getOrgHeirarchy2() {
		return orgHeirarchy2;
	}

	public void setOrgHeirarchy2(DirectReportsDto orgHeirarchy2) {
		this.orgHeirarchy2 = orgHeirarchy2;
	}

	public String getIfg() {
		return ifg;
	}

	public void setIfg(String ifg) {
		this.ifg = ifg;
	}

	public String getBusiness() {
		return business;
	}

	public void setBusiness(String business) {
		this.business = business;
	}

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<OrgChartDirectReportsDto> getDirectReportList() {
		return directReportList;
	}

	public void setDirectReportList(
			List<OrgChartDirectReportsDto> directReportList) {
		this.directReportList = directReportList;
	}

	public DirectReportsDto getManager() {
		return manager;
	}

	public void setManager(DirectReportsDto manager) {
		this.manager = manager;
	}

	public List<OrgChartDirectReportsDto> getContingentList() {
		return contingentList;
	}

	public DirectReportsDto getOneOverOneManager() {
		return oneOverOneManager;
	}

	public void setOneOverOneManager(DirectReportsDto oneOverOneManager) {
		this.oneOverOneManager = oneOverOneManager;
	}

	public void setContingentList(List<OrgChartDirectReportsDto> contingentList) {
		this.contingentList = contingentList;
	}

	public List<OrgChartDirectReportsDto> getPeerList() {
		return peerList;
	}

	public void setPeerList(List<OrgChartDirectReportsDto> peerList) {
		this.peerList = peerList;
	}

	public int getTotalPeers() {
		return totalPeers;
	}

	public void setTotalPeers(int totalPeers) {
		this.totalPeers = totalPeers;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getIsLongTermSuspend() {
		return isLongTermSuspend;
	}

	public void setIsLongTermSuspend(String isLongTermSuspend) {
		this.isLongTermSuspend = isLongTermSuspend;
	}



}
