package com.ge.corporate.hr.profile.employee.dto;

import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.auth.model.DataGroup;
import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;
import com.ge.corporate.hr.profile.employee.model.OptinSharing;


@XmlRootElement(name="printPDF")
@XmlAccessorType(XmlAccessType.FIELD)
public class PrintPDFDto extends AbstractBaseModelSupport{

	private static final long serialVersionUID = 1L;

	@XmlElement(name="sso")
	private Long sso;
	
	private PersonalInfoDto personalInfoDto;
	
	private AssignmentDto assignmentDto;
	
	private AssignmentHistoryDto assignmentHistoryDto;
	
	private EmployeeHistoryDto employeeHistoryDto;

	private EducationTrainingDto educationDto;
	
	private InterestAffiliationDto interestAffilationDto;
	private ContactsDemographicsDto contactDemographics;

	private CompensationDto compensationDto;
      
    private PerformanceDto performanceDto;

	private Map<String,DataGroup> dataGroupAcess;
	
	private OptinSharing optinSharingAccess;
	
	private List<String> columns;
	
	private String stk_opt_outstanding_total;
	private String stk_opt_vested_total;
	private String stk_opt_unvested_total;
	private String rsu_grant_hist_total;
	private float nameHeaderFont;
	private float headerFont;
	private float subHeaderFont;
	private float bodyFont;

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public PersonalInfoDto getPersonalInfoDto() {
		return personalInfoDto;
	}

	public void setPersonalInfoDto(PersonalInfoDto personalInfoDto) {
		this.personalInfoDto = personalInfoDto;
	}

	public AssignmentDto getAssignmentDto() {
		return assignmentDto;
	}

	public void setAssignmentDto(AssignmentDto assignmentDto) {
		this.assignmentDto = assignmentDto;
	}

	public AssignmentHistoryDto getAssignmentHistoryDto() {
		return assignmentHistoryDto;
	}

	public void setAssignmentHistoryDto(AssignmentHistoryDto assignmentHistoryDto) {
		this.assignmentHistoryDto = assignmentHistoryDto;
	}
	
	public EmployeeHistoryDto getEmployeeHistoryDto() {
		return employeeHistoryDto;
	}

	public void setEmployeeHistoryDto(EmployeeHistoryDto employeeHistoryDto) {
		this.employeeHistoryDto = employeeHistoryDto;
	}
	
	public EducationTrainingDto getEducationTrainingDto() {
		return educationDto;
	}

	public void setEducationTrainingDto(EducationTrainingDto educationDto) {
		this.educationDto = educationDto;
	}

	public CompensationDto getCompensationDto() {
		return compensationDto;
	}

	public void setCompensationDto(CompensationDto compensationDto) {
		this.compensationDto = compensationDto;
	}

	public PerformanceDto getPerformanceDto() {
		return performanceDto;
	}

	public void setPerformanceDto(PerformanceDto performanceDto) {
		this.performanceDto = performanceDto;
	}
	
	public ContactsDemographicsDto getContactDemographics() {
		return contactDemographics;
	}

	public void setContactDemographics(ContactsDemographicsDto contactDemographics) {
		this.contactDemographics = contactDemographics;
	}
	
	public Map<String, DataGroup> getDataGroupAcess() {
		return dataGroupAcess;
	}

	public void setDataGroupAcess(Map<String, DataGroup> dataGroupAcess) {
		this.dataGroupAcess = dataGroupAcess;
	}
	
	public OptinSharing getOptinSharingAccess() {
		return optinSharingAccess;
	}

	public void setOptinSharingAccess(OptinSharing optinSharingAccess) {
		this.optinSharingAccess = optinSharingAccess;
	}

	public List<String> getColumns() {
		return columns;
	}

	public void setColumns(List<String> columns) {
		this.columns = columns;
	}
	public EducationTrainingDto getEducationDto() {
		return educationDto;
	}

	public void setEducationDto(EducationTrainingDto educationDto) {
		this.educationDto = educationDto;
	}

	public String getStk_opt_outstanding_total() {
		return stk_opt_outstanding_total;
	}

	public void setStk_opt_outstanding_total(String stk_opt_outstanding_total) {
		this.stk_opt_outstanding_total = stk_opt_outstanding_total;
	}

	public String getStk_opt_vested_total() {
		return stk_opt_vested_total;
	}

	public void setStk_opt_vested_total(String stk_opt_vested_total) {
		this.stk_opt_vested_total = stk_opt_vested_total;
	}

	public String getStk_opt_unvested_total() {
		return stk_opt_unvested_total;
	}

	public void setStk_opt_unvested_total(String stk_opt_unvested_total) {
		this.stk_opt_unvested_total = stk_opt_unvested_total;
	}

	public String getRsu_grant_hist_total() {
		return rsu_grant_hist_total;
	}

	public void setRsu_grant_hist_total(String rsu_grant_hist_total) {
		this.rsu_grant_hist_total = rsu_grant_hist_total;
	}

	public InterestAffiliationDto getInterestAffilationDto() {
		return interestAffilationDto;
	}

	public void setInterestAffilationDto(
			InterestAffiliationDto interestAffilationDto) {
		this.interestAffilationDto = interestAffilationDto;
	}

	public float getNameHeaderFont() {
		return nameHeaderFont;
	}

	public void setNameHeaderFont(float nameHeaderFont) {
		this.nameHeaderFont = nameHeaderFont;
	}

	public float getHeaderFont() {
		return headerFont;
	}

	public void setHeaderFont(float headerFont) {
		this.headerFont = headerFont;
	}

	public float getSubHeaderFont() {
		return subHeaderFont;
	}

	public void setSubHeaderFont(float subHeaderFont) {
		this.subHeaderFont = subHeaderFont;
	}

	public float getBodyFont() {
		return bodyFont;
	}

	public void setBodyFont(float bodyFont) {
		this.bodyFont = bodyFont;
	}
	
}
