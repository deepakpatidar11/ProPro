package com.ge.corporate.hr.profile.employee.dto;

public class ProfessionalSummaryDto {
	
	
	private Long sso;
	private String professionalSummary;
//	private String goalCombined;
//	private String goalShortterm;
//	private String goalLongterm;
//	private String optiontalentpool;
//	private String relocateWithin;
//	private String relocateOutside;
//	private String dataCreated;
//	private String dataUpdated;
//	private String employeeInterest;
	
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	public String getProfessionalSummary() {
		return professionalSummary;
	}
	public void setProfessionalSummary(String professionalSummary) {
		this.professionalSummary = professionalSummary;
	}
	
	
//	public String getGoalCombined() {
//		return goalCombined;
//	}
//	public void setGoalCombined(String goalCombined) {
//		this.goalCombined = goalCombined;
//	}
//	public String getGoalShortterm() {
//		return goalShortterm;
//	}
//	public void setGoalShortterm(String goalShortterm) {
//		this.goalShortterm = goalShortterm;
//	}
//	public String getGoalLongterm() {
//		return goalLongterm;
//	}
//	public void setGoalLongterm(String goalLongterm) {
//		this.goalLongterm = goalLongterm;
//	}
//	public String getOptiontalentpool() {
//		return optiontalentpool;
//	}
//	public void setOptiontalentpool(String optiontalentpool) {
//		this.optiontalentpool = optiontalentpool;
//	}
//	public String getRelocateWithin() {
//		return relocateWithin;
//	}
//	public void setRelocateWithin(String relocateWithin) {
//		this.relocateWithin = relocateWithin;
//	}
//	public String getRelocateOutside() {
//		return relocateOutside;
//	}
//	public void setRelocateOutside(String relocateOutside) {
//		this.relocateOutside = relocateOutside;
//	}
//	public String getDataCreated() {
//		return dataCreated;
//	}
//	public void setDataCreated(String dataCreated) {
//		this.dataCreated = dataCreated;
//	}
//	public String getDataUpdated() {
//		return dataUpdated;
//	}
//	public void setDataUpdated(String dataUpdated) {
//		this.dataUpdated = dataUpdated;
//	}
//	public String getEmployeeInterest() {
//		return employeeInterest;
//	}
//	public void setEmployeeInterest(String employeeInterest) {
//		this.employeeInterest = employeeInterest;
//	}

}
