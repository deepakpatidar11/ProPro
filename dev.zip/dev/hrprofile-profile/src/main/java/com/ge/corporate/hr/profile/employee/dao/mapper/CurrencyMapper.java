/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.Currency;

public class CurrencyMapper implements RowMapper<Currency>{
	
	private static final String CURRENCY = "curr_currency";
	private static final String AMMOUNT = "curr_ammount";
	private static final String CURRENCY_CONVERTED = "curr_currency_converted";
	private static final String AMMOUNT_CONVERTED = "curr_ammount_converted";
	
	public Currency mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		Currency currency = new Currency();
		
		currency.setCurrency(rs.getString(CURRENCY));
		currency.setAmmount(rs.getDouble(AMMOUNT));
		currency.setCurrencyConverted(rs.getString(CURRENCY_CONVERTED));
		currency.setAmmountConverted(rs.getDouble(AMMOUNT_CONVERTED));
				
		return currency;
	}

}
