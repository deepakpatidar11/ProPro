/*******************************************************************************
 * Copyright � 2018 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 02/13/2018
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.employee.model.EmployeeExpertise;
import com.ge.corporate.hr.profile.employee.model.Expertise;


@XmlRootElement(name="employeeExpertisesDto")
@XmlAccessorType(XmlAccessType.FIELD)
public class EmployeeExpertiseDto extends AbstractBaseDtoSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6013182796152502514L;
	
	@XmlElement(name = "employeeExpertises")
	private List<EmployeeExpertise> employeeExpertises;
	
	@XmlElement(name = "expertise")
	private List<Expertise> expertise;
	
	@XmlElement(name = "totalCount")
	private int totalCount;

	public EmployeeExpertiseDto() {
	}

	public List<EmployeeExpertise> getEmployeeExpertises() {
		return employeeExpertises;
	}
	
	public void setEmployeeExpertises(List<EmployeeExpertise> employeeExpertises) {
		this.employeeExpertises = employeeExpertises;
	}

	public List<Expertise> getExpertise() {
		return expertise;
	}
	
	public void setExpertise(List<Expertise> expertise) {
		this.expertise = expertise;
	}
	
	public int getTotalCount() {
		return totalCount;
	}
	
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	@Override
	public long getId() {
		return 0;
	}
	
}
