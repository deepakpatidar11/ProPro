package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name="onlineNetwork")
@XmlAccessorType(XmlAccessType.FIELD)
public class OnlineNetwork {

	@XmlElement(name="sso")
	private Long sso;
	
	@XmlElement(name="name")
	private String name;
	
	@XmlElement(name="address")
	private String address;


	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
}
