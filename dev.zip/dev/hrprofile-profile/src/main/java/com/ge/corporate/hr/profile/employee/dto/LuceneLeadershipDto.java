package com.ge.corporate.hr.profile.employee.dto;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;

public class LuceneLeadershipDto extends AbstractBaseDtoSupport {

	private long sso;
	private String prgName;
	private String prgLongName;
	private String prgStatus;

	public long getSso() {
		return sso;
	}

	public void setSso(long sso) {
		this.sso = sso;
	}

	public LuceneLeadershipDto(long sso, String prgName, String prgLongName,
			String prgStatus) {
		super();
		this.sso = sso;
		this.prgName = prgName;
		this.prgLongName = prgLongName;
		this.prgStatus = prgStatus;
	}

	public LuceneLeadershipDto() {
		super();
	}

	public String getPrgName() {
		return prgName;
	}

	public void setPrgName(String prgName) {
		this.prgName = prgName;
	}

	public String getPrgLongName() {
		return prgLongName;
	}

	public void setPrgLongName(String prgLongName) {
		this.prgLongName = prgLongName;
	}

	public String getPrgStatus() {
		return prgStatus;
	}

	public void setPrgStatus(String prgStatus) {
		this.prgStatus = prgStatus;
	}

	@Override
	public long getId() {
		// TODO Auto-generated method stub
		return 0;
	}

}
