/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

//jaxb
@XmlRootElement(name="restrictedStockOptionTotals")
@XmlAccessorType(XmlAccessType.FIELD)
public class RestrictedStockOptionTotals extends AbstractBaseModelSupport{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5094585084114835512L;
	
	@XmlElement(name="sso")
	private Long sso;
	@XmlAttribute(name="id")
	private Long id;
	
	@XmlElement(name="numGranted")
	private Integer numGranted;
	
	@XmlElement(name="unvested")
	private Integer unvested;
	
	public void setId(Long id) {
		this.id = id;
	}	
	public Long getId() {
		return	 id;
	}	
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}	
	public void setUnvested(Integer unvested) {
		this.unvested = unvested;
	}
	public Integer getUnvested() {
		return unvested;
	}
	public void setNumGranted(Integer numGranted) {
		this.numGranted = numGranted;
	}
	public Integer getNumGranted() {
		return numGranted;
	}
	
}
