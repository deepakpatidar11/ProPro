/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;

@XmlRootElement(name="training")
@XmlAccessorType(XmlAccessType.FIELD)

public class ProgramHeader extends AbstractBaseModelSupport{
	
	private static final long serialVersionUID = 5969382423167807102L;

	
	@XmlAttribute(name="id")
	private Long id;
	
	@XmlElement(name="uiDisplayHeading")
	private String uiDisplayHeading;
	
	@XmlElement(name="ProgramList")
	private BaseModelCollection<Program> ProgramList;

	@XmlElement(name="shared")
	private boolean shared;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUiDisplayHeading() {
		return uiDisplayHeading;
	}

	public void setUiDisplayHeading(String uiDisplayHeading) {
		this.uiDisplayHeading = uiDisplayHeading;
	}

	public BaseModelCollection<Program> getProgramList() {
		return ProgramList;
	}

	public void setProgramList(BaseModelCollection<Program> programList) {
		ProgramList = programList;
	}
	
	public boolean isShared() {
		return shared;
	}

	public void setShared(boolean shared) {
		this.shared = shared;
	}

	
}
