/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
/**
 * 
 */
package com.ge.corporate.hr.profile.employee.dao;

import java.util.List;
import java.util.Map;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dto.EmployeeExpertiseDto;
import com.ge.corporate.hr.profile.employee.model.Expertise;
import com.ge.corporate.hr.profile.employee.model.MentoringInterest;
import com.ge.corporate.hr.profile.employee.model.ProfileUserMetrics;
import com.ge.corporate.hr.profile.employee.model.ShortProfileList;

public interface SearchDao {
	
	/**
	 * 
	 * @param type
	 * @return
	 */
	public BaseModelCollection<String> getBusinessList();
	
	public BaseModelCollection<String> getSubBusinessList(String bussines);
	
	public BaseModelCollection<String> getBandList();
	
	public BaseModelCollection<String> getFunctionList();
	
	public BaseModelCollection<String> getRegionList();
	
	public Map<String, String> getCountryCodeMap();
	
	public BaseModelCollection<String> getCountryList();
	
	public BaseModelCollection<String> getCountryRegionList(String region);
	
	public BaseModelCollection<String> getJobFamilyList(String function);
	
	public BaseModelCollection<String> getLeadershipProgramList();
	
	public BaseModelCollection<String> getIfgList();
	
	public List<String> getRolesWithClientSearchAccess();
	
	public List<String> getWorkAssignmentRestrictedSearchLRoles(Long sso);
	
	public List<String> getRolesWithSearchExcelAccess(Long sso);
	
	/**
	 * Get list of employees matching criteria
	 * 	
	 * @param sso
	 * @param lastName
	 * @param firstName
	 * @param business
	 * @param subBusiness
	 * @param band
	 * @param function
	 * @param region
	 * @param country
	 * @return
	 */
	public BaseModelCollection<ShortProfileList> searchEmployeeAdvanced(Long LoggedSso,
			Long sso, String lastName, String firstName, Long managerSso, List<String> business,
			List<String> subBusiness, List<String> band, List<String> function, 
			List<String> region, List<String> country, List<String> jobFamily, List<String> leadershipProgram, String leadershipProgramType);

	public BaseModelCollection<String> getDisciplineList();
	
	public BaseModelCollection<String> getReportingIfgCatalog();
	
	public BaseModelCollection<String> getReportingBusinessCatalog();

	public BaseModelCollection<String> getAssignmentLeaderFor();

	public BaseModelCollection<String> getAssignmentSubBusiness();

	public BaseModelCollection<Long> getAllConnections(Long sso);

	public BaseModelCollection<Expertise> getAllExpertise();
	
	public EmployeeExpertiseDto getExpertiseByParams(int offset, String status, String date, String expName, boolean isExcelDownload);
	
	public boolean updateExpertiseTaxo(List<Expertise> expertise);
	
	public BaseModelCollection<MentoringInterest> getMentoringInterest();
	
	public void addSearchMetrics(ProfileUserMetrics metrics, Map<String, Map<String, String>> categoryMap);

}
