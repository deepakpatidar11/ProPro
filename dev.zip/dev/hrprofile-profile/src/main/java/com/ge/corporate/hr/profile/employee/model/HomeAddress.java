/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

//jaxb
@XmlRootElement(name="emergencyContact")
@XmlAccessorType(XmlAccessType.FIELD)
public class HomeAddress extends AbstractBaseModelSupport{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4926107505218470071L;
	
	@XmlElement(name="sso")
	private Long sso;
	
	//Home address
	@XmlElement(name="address1")
	private String address1;
	
	@XmlElement(name="address2")
	private String address2;
	
	@XmlElement(name="address3")
	private String address3;
	
	@XmlElement(name="city")
	private String city;
	
	@XmlElement(name="state")
	private String state;
	
	@XmlElement(name="zip")
	private String zip;
	
	@XmlElement(name="country")
	private String country;
	
	@XmlElement(name="personalEmail")
	private String personalEmail;

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	
	public String getPersonalEmail() {
		return personalEmail;
	}

	public void setPersonalEmail(String personalEmail) {
		this.personalEmail = personalEmail;
	}

	public long getId() {
		return (sso==null)?0:sso.longValue();
	}
			
	public void setSso(Long sso) {
		this.sso = sso;
	}	
	public Long getSso() {
		return sso;
	}
	
}
