/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;
@XmlRootElement(name = "employmentHistory")
@XmlAccessorType(XmlAccessType.FIELD)
public class EmployeeHistory extends AbstractBaseModelSupport {
		
	private static final long serialVersionUID = -7194589138135889739L;

	@XmlElement(name="sso")
	private long sso;
	@XmlElement(name="businessCard")
	private String businessCard;
	@XmlElement(name="corporateBand")
	private String corporateBand;
	@XmlElement(name="businessBand")
	private String businessBand;
	@XmlElement(name="geBusiness")
	private String geBusiness;
	@XmlElement(name="location")
	private String location;
	@XmlElement(name="jobFunction")
	private String jobFunction;
	@XmlElement(name="fromDate")
	private String fromDate;
	@XmlElement(name="toDate")
	private String toDate;
	@XmlElement(name="manager")
	private String manager;
	@XmlElement(name="insertDate")
	private String insertDate;
	@XmlElement(name="updateDate")
	private String updateDate;
	@XmlElement(name="description")
	private String description;
	@XmlElement(name="currentFlag")
	private String currentFlag;
	@XmlElement(name="alertFlag")
	private String alertFlag;
	
	public long getSso() {
		return sso;
	}
	public void setSso(long sso) {
		this.sso = sso;
	}
	public String getBusinessCard() {
		return businessCard;
	}
	public void setBusinessCard(String businessCard) {
		this.businessCard = businessCard;
	}
	public String getCorporateBand() {
		return corporateBand;
	}
	public void setCorporateBand(String corporateBand) {
		this.corporateBand = corporateBand;
	}
	public String getBusinessBand() {
		return businessBand;
	}
	public void setBusinessBand(String businessBand) {
		this.businessBand = businessBand;
	}
	public String getGeBusiness() {
		return geBusiness;
	}
	public void setGeBusiness(String geBusiness) {
		this.geBusiness = geBusiness;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getJobFunction() {
		return jobFunction;
	}
	public void setJobFunction(String jobFunction) {
		this.jobFunction = jobFunction;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(String insertDate) {
		this.insertDate = insertDate;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	public String getManager() {
		return manager;
	}
	public void setManager(String manager) {
		this.manager = manager;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCurrentFlag() {
		return currentFlag;
	}
	public void setCurrentFlag(String currentFlag) {
		this.currentFlag = currentFlag;
	}
	public String getAlertFlag() {
		return alertFlag;
	}
	public void setAlertFlag(String alertFlag) {
		this.alertFlag = alertFlag;
	}
}
