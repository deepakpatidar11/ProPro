/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.Program;
/**
 * Program Dao interface
 * @author enrique.romero
 *
 */
public interface ProgramDao {
	/**
	 * 
	 * @param sso Employee sso
	 * @return Program model
	 */
	public BaseModelCollection<Program> getProgramListBySso(Long sso);
	public BaseModelCollection<Program> getProgramListAllBySso(Long sso);
	public BaseModelCollection<Program> getProgramListOptinBySso(Long sso);

}
