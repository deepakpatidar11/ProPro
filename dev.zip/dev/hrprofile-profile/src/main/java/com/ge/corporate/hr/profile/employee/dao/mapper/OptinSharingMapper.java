package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.OptinSharing;

public class OptinSharingMapper implements RowMapper<OptinSharing> {
	
	public static final String DATA_SSO = "sso";
	public static final String DATA_EMP_HISTORY = "emp_history";
	public static final String DATA_EDUCATION = "education";
	public static final String DATA_TRAINING = "training";
	
	public static final String DATA_LANG_PROF = "language_proficiency"; 
	public static final String DATA_PROF_SUMM = "professional_summary"; 
	public static final String DATA_WORK_MOB = "work_mobility";
	public static final String DATA_CURR_JOB = "current_job"; 
	public static final String DATA_CAREER_ASPIRATION = "career_aspirations";
	public static final String DATA_INIT_PROJECT = "initiatives_projects";
	public static final String DATA_CUST_SUPP = "customers_suppliers"; 
	public static final String DATA_ONLINE_NETW = "online_networks"; 
	public static final String DATA_PROF_PER_INTEREST = "prof_personal_interests";
	public static final String DATA_EXT_GRP_AFF = "external_group_affiliations";
	public static final String DATA_MENTORING ="mentoring";
	public static final String DATA_CONNECTIONS ="connections";
	
	public static final String DATA_LAST_UPDATED = "last_updated_date";
	
	public OptinSharing mapRow(ResultSet rs, int rowNum) throws SQLException {		
		OptinSharing optinSharing = new OptinSharing();
		optinSharing.setSso(rs.getLong(DATA_SSO));
		optinSharing.setEmp_history(rs.getString(DATA_EMP_HISTORY));
		optinSharing.setEducation(rs.getString(DATA_EDUCATION));
		optinSharing.setTraining(rs.getString(DATA_TRAINING));
		
		optinSharing.setLanguage_proficiency(rs.getString(DATA_LANG_PROF));
		optinSharing.setProfessional_summary(rs.getString(DATA_PROF_SUMM));
		optinSharing.setWork_mobility(rs.getString(DATA_WORK_MOB));
		optinSharing.setCurrent_job(rs.getString(DATA_CURR_JOB));
		optinSharing.setCareer_aspirations(rs.getString(DATA_CAREER_ASPIRATION));
		optinSharing.setInitiatives_projects(rs.getString(DATA_INIT_PROJECT));
		optinSharing.setCustomers_suppliers(rs.getString(DATA_CUST_SUPP));
		optinSharing.setOnline_networks(rs.getString(DATA_ONLINE_NETW));
		optinSharing.setProf_personal_interests(rs.getString(DATA_PROF_PER_INTEREST));
		optinSharing.setExternal_group_affiliations(rs.getString(DATA_EXT_GRP_AFF));	
		optinSharing.setMentoring(rs.getString(DATA_MENTORING));
		optinSharing.setConnections(rs.getString(DATA_CONNECTIONS));
		return optinSharing;
	}
	
}
