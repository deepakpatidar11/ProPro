/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.ProgramHeader;
import com.ge.corporate.hr.profile.employee.model.TrainingHeader;

public class TrainingDto extends AbstractBaseDtoSupport{

	/**
	 *Default serial ID 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 *Employee SSO
	 */
	private Long sso;
	
	private boolean shared;

	/**
	 * Training Model List
	 */
	private BaseModelCollection<TrainingHeader> trainingHederList;
	
	/**
	 * Program Model List
	 */
	private ProgramHeader leadershipProgramList;
	

	public Long getSso() {
		return sso;
	}
	
	public void setSso(Long sso) {
		this.sso = sso;
	}
	
	
	public boolean getShared() {
		return shared;
	}

	public void setShared(boolean shared) {
		this.shared = shared;
	}
	
	public long getId() {
		return sso != null ? sso.longValue() : 0;
	}

	public void setTrainingHederList(BaseModelCollection<TrainingHeader> trainingHederList) {
		this.trainingHederList = trainingHederList;
	}

	public BaseModelCollection<TrainingHeader> getTrainingHederList() {
		return trainingHederList;
	}
	
	public ProgramHeader getLeadershipProgramList() {
		return leadershipProgramList;
	}

	public void setLeadershipProgramList(
			ProgramHeader leadershipProgramList) {
		this.leadershipProgramList = leadershipProgramList;
	}
	
}
