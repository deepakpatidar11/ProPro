/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.LongTermPerformanceAward;
/**
 * Long Term Performance Award Mapper
 * @author enrique.romero
 *
 */
public class LongTermPerformanceAwardMapper implements RowMapper<LongTermPerformanceAward>{
	
	public static final String DATA_PROGRAM_YEAR = "ltpa_program_year";
	public static final String DATA_DATE = "ltpa_date";
	public static final String DATA_CATEGORY = "ltpa_category";
	
	public LongTermPerformanceAward mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		LongTermPerformanceAward ltPerfAward = new LongTermPerformanceAward();
		
		ltPerfAward.setProgramYear(rs.getShort(DATA_PROGRAM_YEAR));	
		ltPerfAward.setDate(rs.getDate(DATA_DATE));
		ltPerfAward.setCategory(rs.getString(DATA_CATEGORY));
		
		return ltPerfAward;		
	}
	

}
