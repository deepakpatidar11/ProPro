package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="hrPopulationFlexiGridColModel")
@XmlAccessorType(XmlAccessType.FIELD)
public class HrPopulationFlexiGridColModel extends AbstractBaseModelSupport{
	
	private static final long serialVersionUID = 46981221793287345L;
	
	@XmlElement(name="id")
	private int id; //SSO Id
	
	@XmlElement(name="cell")
	private MyHrPopulation cell;
		
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public MyHrPopulation getCell() {
		return cell;
	}

	public void setCell(MyHrPopulation cell) {
		this.cell = cell;
	}

}

