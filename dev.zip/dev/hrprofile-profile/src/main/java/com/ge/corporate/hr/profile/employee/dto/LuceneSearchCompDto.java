/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.employee.model.IntiativesandProject;

public class LuceneSearchCompDto extends AbstractBaseDtoSupport {

	private static final long serialVersionUID = -103632232234856348L;

	public LuceneSearchCompDto(Long sso, String empName, String empAsciiName,
			String empPreferredName, String title, String empEmail,
			String empWorkPhone, String empMobile, String empAddr1,
			String empAddr2, String empAddr3, String empState,
			String empZip, String empCountry, String empStateName,
			String empCountryLabel, String empManagerName,
			String empManagerAsciiName, Long empManagerSso,
			String mgrPreferredName, String mgrTitle, String mgrEmail,
			String mgrPhone, String mgrMobile, String ohMgrSso,
			String ohMgrSso1, String ohMgrSso2, String ohMgrSso3,
			String ohMgrLastName, String ohMgrLastName1, String ohMgrLastName2,
			String ohMgrLastName3, String ohMgrFirstName,
			String ohMgrFirstName1, String ohMgrFirstName2,
			String ohMgrFirstName3, String ifg, String business,
			String subBusiness, String organization, String func,
			String jobFamily, String region, String country, String band,
			ACLBean acl, String empLastName, String empFirstName,
			String empHistorySharedFlag, String trainingSharedFlag,
			String empReportingBusiness, String empReportingIFG,
			String empLocalLangName, String prsnType, String techDisciplineKW,
			String techDisciplineSTD, String directoryIncl,
			String empLocalLangTitle, String workHistoryField, String projects,
			String interests, String careerInterests,
			String professionalSummary, String initiativeProjectSharedFlag,
			String careerSharedFlag, String talentPool,
			String customerSuppliersSharedFlag, String languagesSharedFlag,
			String externalAffiliationsSharedFlag, String interestsSharedFlag, 
			String customersSuppliers,
			String languages, String externalAffiliations,String relocateWithin, String relocateOutside,String mobilityCountries, String mentoringSharedFlag, String mentorInfo, String menteeInfo, String mentoringDesc,
			String rotationNumber, String assignmentTitle, String assignmentLeaderName, String assignmentSubBusiness, String assignmentLeaderFor,
			String careerOpportunity) {
		super();
		this.sso = sso;
		this.empName = empName;
		this.empAsciiName = empAsciiName;
		this.empPreferredName = empPreferredName;
		this.title = title;
		this.empEmail = empEmail;
		this.empWorkPhone = empWorkPhone;
		this.empMobile = empMobile;
		this.empAddr1 = empAddr1;
		this.empAddr2 = empAddr2;
		this.empAddr3 = empAddr3;
		//this.empCity = empCity;
		this.empState = empState;
		this.empStateName = empStateName;
		this.empZip = empZip;
		this.empCountry = empCountry;
		this.empCountryLabel = empCountryLabel;
		this.empManagerName = empManagerName;
		this.empManagerAsciiName = empManagerAsciiName;
		this.empManagerSso = empManagerSso;
		this.mgrPreferredName = mgrPreferredName;
		this.mgrTitle = mgrTitle;
		this.mgrEmail = mgrEmail;
		this.mgrPhone = mgrPhone;
		this.mgrMobile = mgrMobile;
		this.ohMgrSso = ohMgrSso;
		this.ohMgrSso1 = ohMgrSso1;
		this.ohMgrSso2 = ohMgrSso2;
		this.ohMgrSso3 = ohMgrSso3;
		this.ohMgrLastName = ohMgrLastName;
		this.ohMgrLastName1 = ohMgrLastName1;
		this.ohMgrLastName2 = ohMgrLastName2;
		this.ohMgrLastName3 = ohMgrLastName3;
		this.ohMgrFirstName = ohMgrFirstName;
		this.ohMgrFirstName1 = ohMgrFirstName1;
		this.ohMgrFirstName2 = ohMgrFirstName2;
		this.ohMgrFirstName3 = ohMgrFirstName3;
		this.ifg = ifg;
		this.business = business;
		this.subBusiness = subBusiness;
		this.organization = organization;
		this.func = func;
		this.jobFamily = jobFamily;
		this.region = region;
		this.country = country;
		this.band = band;
		this.acl = acl;
		this.empLastName = empLastName;
		this.empFirstName = empFirstName;
		this.empHistorySharedFlag = empHistorySharedFlag;
		this.trainingSharedFlag = trainingSharedFlag;
		this.empReportingBusiness = empReportingBusiness;
		this.empReportingIFG = empReportingIFG;
		this.empLocalLangName = empLocalLangName;
		this.prsnType = prsnType;
		this.techDisciplineKW = techDisciplineKW;
		this.techDisciplineSTD = techDisciplineSTD;
		this.directoryIncl = directoryIncl;
		this.empLocalLangTitle = empLocalLangTitle;
		this.workHistoryField = workHistoryField;
		this.projects = projects;
		this.interests = interests;
		this.careerInterests = careerInterests;
		this.professionalSummary = professionalSummary;
		this.initiativeProjectSharedFlag = initiativeProjectSharedFlag;
		this.careerSharedFlag = careerSharedFlag;
		this.talentPool = talentPool;
		this.customerSuppliersSharedFlag = customerSuppliersSharedFlag;
		this.languagesSharedFlag = languagesSharedFlag;
		this.externalAffiliationsSharedFlag = externalAffiliationsSharedFlag;
		this.customersSuppliers = customersSuppliers;
		this.languages = languages;
		this.externalAffiliations = externalAffiliations;
		this.interestsSharedFlag = interestsSharedFlag;
		//this.workMobilityShared = workMobilityShared;
		this.relocateOutside = relocateOutside;
		this.relocateWithin = relocateWithin;
		this.mobilityCountries = mobilityCountries;
		this.mentoringSharedFlag = mentoringSharedFlag;
		this.mentorInfo = mentorInfo;
		this.menteeInfo = menteeInfo;
		this.mentoringDesc = mentoringDesc;
		this.rotationNumber = rotationNumber;
		this.assignmentTitle = assignmentTitle;
		this.assignmentLeaderName = assignmentLeaderName;
		this.assignmentSubBusiness = assignmentSubBusiness;
		this.assignmentLeaderFor = assignmentLeaderFor;
		this.careerOpportunity = careerOpportunity;
	}

	public LuceneSearchCompDto(Long sso, String empName, String empAsciiName,
			String empPreferredName, String title, String empEmail,
			String empWorkPhone, String empMobile, String empAddr1,
			String empAddr2, String empAddr3, String empState,
			String empStateName, String empZip, String empCountry,
			String empCountryLabel, String empManagerName,
			String empManagerAsciiName, Long empManagerSso,
			String mgrPreferredName, String mgrTitle, String mgrEmail,
			String mgrPhone, String mgrMobile, String ohMgrSso,
			String ohMgrSso1, String ohMgrSso2, String ohMgrSso3,
			String ohMgrLastName, String ohMgrLastName1, String ohMgrLastName2,
			String ohMgrLastName3, String ohMgrFirstName,
			String ohMgrFirstName1, String ohMgrFirstName2,
			String ohMgrFirstName3, String ifg, String business,
			String subBusiness, String organization, String func,
			String jobFamily, String region, String country, /* String band, */
			String empLastName, String empFirstName,
			String empHistorySharedFlag, String trainingSharedFlag,
			String empReportingBusiness, String empReportingIFG,
			String empLocalLangName, String prsnType, String techDisciplineKW,
			String techDisciplineSTD, String directoryIncl,
			String empLocalLangTitle, String workHistoryField, String projects,
			String interests, String careerInterests,
			String professionalSummary, String initiativeProjectSharedFlag,
			String careerSharedFlag, String talentPool,
			String customerSuppliersSharedFlag, String languagesSharedFlag,
			String externalAffiliationsSharedFlag, String interestsSharedFlag,
			String customersSuppliers, String languages,
			String externalAffiliations, 
			String relocateWithin, String relocateOutside, String mobilityCountries, String mentoringSharedFlag, String mentorInfo, String menteeInfo, String mentoringDesc,
			String connectMentoringDesc, String empExpertise,
			String menteeAllInterest, String mentorAllInterest, String rotationNumber, String assignmentTitle, String assignmentLeaderName, String assignmentSubBusiness, String assignmentLeaderFor,
			String careerOpportunity) {
		super();
		this.sso = sso;
		this.empName = empName;
		this.empAsciiName = empAsciiName;
		this.empPreferredName = empPreferredName;
		this.title = title;
		this.empEmail = empEmail;
		this.empWorkPhone = empWorkPhone;
		this.empMobile = empMobile;
		this.empAddr1 = empAddr1;
		this.empAddr2 = empAddr2;
		this.empAddr3 = empAddr3;
		//this.empCity = empCity;
		this.empState = empState;
		this.empStateName = empStateName;
		this.empZip = empZip;
		this.empCountry = empCountry;
		this.empCountryLabel = empCountryLabel;
		this.empManagerName = empManagerName;
		this.empManagerAsciiName = empManagerAsciiName;
		this.empManagerSso = empManagerSso;
		this.mgrPreferredName = mgrPreferredName;
		this.mgrTitle = mgrTitle;
		this.mgrEmail = mgrEmail;
		this.mgrPhone = mgrPhone;
		this.mgrMobile = mgrMobile;
		this.ohMgrSso = ohMgrSso;
		this.ohMgrSso1 = ohMgrSso1;
		this.ohMgrSso2 = ohMgrSso2;
		this.ohMgrSso3 = ohMgrSso3;
		this.ohMgrLastName = ohMgrLastName;
		this.ohMgrLastName1 = ohMgrLastName1;
		this.ohMgrLastName2 = ohMgrLastName2;
		this.ohMgrLastName3 = ohMgrLastName3;
		this.ohMgrFirstName = ohMgrFirstName;
		this.ohMgrFirstName1 = ohMgrFirstName1;
		this.ohMgrFirstName2 = ohMgrFirstName2;
		this.ohMgrFirstName3 = ohMgrFirstName3;
		this.ifg = ifg;
		this.business = business;
		this.subBusiness = subBusiness;
		this.organization = organization;
		this.func = func;
		this.jobFamily = jobFamily;
		this.region = region;
		this.country = country;
		/* this.band = band; */
		this.empLastName = empLastName;
		this.empFirstName = empFirstName;
		this.empHistorySharedFlag = empHistorySharedFlag;
		this.trainingSharedFlag = trainingSharedFlag;
		this.empReportingBusiness = empReportingBusiness;
		this.empReportingIFG = empReportingIFG;
		this.empLocalLangName = empLocalLangName;
		this.prsnType = prsnType;
		this.techDisciplineKW = techDisciplineKW;
		this.techDisciplineSTD = techDisciplineSTD;
		this.directoryIncl = directoryIncl;
		this.empLocalLangTitle = empLocalLangTitle;
		this.workHistoryField = workHistoryField;
		this.projects = projects;
		this.interests = interests;
		this.careerInterests = careerInterests;
		this.professionalSummary = professionalSummary;
		this.initiativeProjectSharedFlag = initiativeProjectSharedFlag;
		this.careerSharedFlag = careerSharedFlag;
		this.talentPool = talentPool;
		this.customerSuppliersSharedFlag = customerSuppliersSharedFlag;
		this.languagesSharedFlag = languagesSharedFlag;
		this.externalAffiliationsSharedFlag = externalAffiliationsSharedFlag;
		this.customersSuppliers = customersSuppliers;
		this.languages = languages;
		this.externalAffiliations = externalAffiliations;
		this.interestsSharedFlag = interestsSharedFlag;
		//this.workMobilityShared = workMobilityShared;
		this.relocateOutside = relocateOutside;
		this.relocateWithin = relocateWithin;
		this.mobilityCountries = mobilityCountries;
		this.mentoringSharedFlag = mentoringSharedFlag;
		this.mentorInfo = mentorInfo;
		this.menteeInfo = menteeInfo;
		this.mentoringDesc = mentoringDesc;
		this.connectMentoDesc = connectMentoringDesc;
		this.empExpertise = empExpertise;
		this.mentorInterest = mentorAllInterest;
		this.menteeInterest = menteeAllInterest;
		this.rotationNumber = rotationNumber;
		this.assignmentTitle = assignmentTitle;
		this.assignmentLeaderName = assignmentLeaderName;
		this.assignmentSubBusiness = assignmentSubBusiness;
		this.assignmentLeaderFor = assignmentLeaderFor;
		this.careerOpportunity = careerOpportunity;
	}

	public LuceneSearchCompDto() {
		// TODO Auto-generated constructor stub
	}

	@XmlElement(name = "sso")
	private Long sso;

	@XmlElement(name = "empName")
	private String empName;

	@XmlElement(name = "empAsciiName")
	private String empAsciiName;

	@XmlElement(name = "empPreferredName")
	private String empPreferredName;

	@XmlElement(name = "title")
	private String title;

	@XmlElement(name = "empEmail")
	private String empEmail;

	@XmlElement(name = "empWorkPhone")
	private String empWorkPhone;

	@XmlElement(name = "empMobile")
	private String empMobile;

	@XmlElement(name = "empAddr1")
	private String empAddr1;

	@XmlElement(name = "empAddr2")
	private String empAddr2;

	@XmlElement(name = "empAddr3")
	private String empAddr3;

	//@XmlElement(name = "empCity")
	//private String empCity;

	@XmlElement(name = "empState")
	private String empState;

	@XmlElement(name = "empStateName")
	private String empStateName;

	@XmlElement(name = "empZip")
	private String empZip;

	@XmlElement(name = "empCountry")
	private String empCountry;

	@XmlElement(name = "empCountryLabel")
	private String empCountryLabel;

	@XmlElement(name = "empReportingBusiness")
	private String empReportingBusiness;

	@XmlElement(name = "empReportingIFG")
	private String empReportingIFG;

	@XmlElement(name = "empLocalLangName")
	private String empLocalLangName;
	
	@XmlElement(name = "empExpertise")
	private String empExpertise;
	
	@XmlElement(name = "mentorInterest")
	private String mentorInterest;
	
	@XmlElement(name = "menteeInterest")
	private String menteeInterest;

	@XmlElement(name = "empManagerName")
	private String empManagerName;

	@XmlElement(name = "empManagerAsciiName")
	private String empManagerAsciiName;

	@XmlElement(name = "empManagerSso")
	private Long empManagerSso;

	@XmlElement(name = "mgrPreferredName")
	private String mgrPreferredName;

	@XmlElement(name = "mgrTitle")
	private String mgrTitle;

	@XmlElement(name = "mgrEmail")
	private String mgrEmail;

	@XmlElement(name = "mgrPhone")
	private String mgrPhone;

	@XmlElement(name = "mgrMobile")
	private String mgrMobile;

	@XmlElement(name = "ohMgrSso")
	private String ohMgrSso;

	@XmlElement(name = "ohMgrSso1")
	private String ohMgrSso1;

	@XmlElement(name = "ohMgrSso2")
	private String ohMgrSso2;

	@XmlElement(name = "ohMgrSso3")
	private String ohMgrSso3;

	@XmlElement(name = "ohMgrLastName")
	private String ohMgrLastName;

	@XmlElement(name = "ohMgrLastName1")
	private String ohMgrLastName1;

	@XmlElement(name = "ohMgrLastName2")
	private String ohMgrLastName2;

	@XmlElement(name = "ohMgrLastName3")
	private String ohMgrLastName3;

	@XmlElement(name = "ohMgrFirstName")
	private String ohMgrFirstName;

	@XmlElement(name = "ohMgrFirstName1")
	private String ohMgrFirstName1;

	@XmlElement(name = "ohMgrFirstName2")
	private String ohMgrFirstName2;

	@XmlElement(name = "ohMgrFirstName3")
	private String ohMgrFirstName3;

	@XmlElement(name = "ifg")
	private String ifg;

	@XmlElement(name = "business")
	private String business;

	@XmlElement(name = "subBusiness")
	private String subBusiness;

	@XmlElement(name = "organization")
	private String organization;

	@XmlElement(name = "func")
	private String func;

	@XmlElement(name = "jobFamily")
	private String jobFamily;

	@XmlElement(name = "region")
	private String region;

	@XmlElement(name = "country")
	private String country;

	@XmlElement(name = "band")
	private String band;

	private ACLBean acl;

	@XmlElement(name = "empLastName")
	private String empLastName;

	@XmlElement(name = "empFirstName")
	private String empFirstName;

	@XmlElement(name = "sortBy")
	private String sortBy;

	@XmlElement(name = "prsnType")
	private String prsnType;

	@XmlElement(name = "techDisciplineKW")
	private String techDisciplineKW;

	@XmlElement(name = "techDisciplineSTD")
	private String techDisciplineSTD;

	@XmlElement(name = "directoryIncl")
	private String directoryIncl;

	@XmlElement(name = "empLocalLangTitle")
	private String empLocalLangTitle;

	@XmlElement(name = "empHistorySharedFlag")
	private String empHistorySharedFlag;

	@XmlElement(name = "educationSharedFlag")
	private String educationSharedFlag;

	@XmlElement(name = "trainingSharedFlag")
	private String trainingSharedFlag;

	@XmlElement(name = "initiativeProjectSharedFlag")
	private String initiativeProjectSharedFlag;

	@XmlElement(name = "interestsSharedFlag")
	private String interestsSharedFlag;

	@XmlElement(name = "careerSharedFlag")
	private String careerSharedFlag;

	@XmlElement(name = "customerSuppliersSharedFlag")
	private String customerSuppliersSharedFlag;

	@XmlElement(name = "languagesSharedFlag")
	private String languagesSharedFlag;

	@XmlElement(name = "externalAffiliationsSharedFlag")
	private String externalAffiliationsSharedFlag;

	@XmlElement(name = "workHistoryField")
	private String workHistoryField;

	@XmlElement(name = "projects")
	private String projects;

	@XmlElement(name = "interests")
	private String interests;

	@XmlElement(name = "professionalSummary")
	private String professionalSummary;

	@XmlElement(name = "careerInterests")
	private String careerInterests;

	@XmlElement(name = "talentPool")
	private String talentPool;

	@XmlElement(name = "customersSuppliers")
	private String customersSuppliers;

	@XmlElement(name = "languages")
	private String languages;

	@XmlElement(name = "workMobilityShared")
	private String workMobilityShared;

	@XmlElement(name = "relocateWithin")
	private String relocateWithin;

	@XmlElement(name = "relocateOutside")
	private String relocateOutside;

	@XmlElement(name = "externalAffiliations")
	private String externalAffiliations;

	@XmlElement(name = "mobilityCountries")
	private String mobilityCountries;

	@XmlElement(name = "connectionSharedFlag")
	private String connectionSharedFlag;
	
	@XmlElement(name = "mentoringSharedFlag")
	private String mentoringSharedFlag;

	@XmlElement(name = "mentorInfo")
	private String mentorInfo;

	@XmlElement(name = "menteeInfo")
	private String menteeInfo;

	@XmlElement(name = "mentoringDesc")
	private String mentoringDesc;
	
	@XmlElement(name = "connectMentorInfo")
	private String connectMentorInfo;

	@XmlElement(name = "connectMenteeInfo")
	private String connectMenteeInfo;

	@XmlElement(name = "connectMentoDesc")
	private String connectMentoDesc;
	
	@XmlElement(name = "rotationNumber")
	private String rotationNumber;

	@XmlElement(name = "assignmentTitle")
	private String assignmentTitle;

	@XmlElement(name = "assignmentLeaderName")
	private String assignmentLeaderName;

	@XmlElement(name = "assignmentSubBusiness")
	private String assignmentSubBusiness;

	@XmlElement(name = "assignmentLeaderFor")
	private String assignmentLeaderFor;

	@XmlElement(name = "careerOpportunity")
	private String careerOpportunity;
	
	@XmlElement(name = "highlights")
	private Map<String, String> highlights;

	private List<LuceneEducationDto> education;

	private List<LuceneEmpHistoryDto> workHistory;

	private List<LuceneTrainingDto> training;

	private List<LuceneLeadershipDto> leadershipProgram;

	private List<IntiativesandProject> initiativesProject;

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpAsciiName() {
		return empAsciiName;
	}

	public void setEmpAsciiName(String empAsciiName) {
		this.empAsciiName = empAsciiName;
	}

	public String getEmpPreferredName() {
		return empPreferredName;
	}

	public void setEmpPreferredName(String empPreferredName) {
		this.empPreferredName = empPreferredName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getEmpEmail() {
		return empEmail;
	}

	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}

	public String getEmpWorkPhone() {
		return empWorkPhone;
	}

	public void setEmpWorkPhone(String empWorkPhone) {
		this.empWorkPhone = empWorkPhone;
	}

	public String getEmpMobile() {
		return empMobile;
	}

	public void setEmpMobile(String empMobile) {
		this.empMobile = empMobile;
	}

	public String getEmpAddr1() {
		return empAddr1;
	}

	public void setEmpAddr1(String empAddr1) {
		this.empAddr1 = empAddr1;
	}

	public String getEmpAddr2() {
		return empAddr2;
	}

	public void setEmpAddr2(String empAddr2) {
		this.empAddr2 = empAddr2;
	}

	public String getEmpAddr3() {
		return empAddr3;
	}

	public void setEmpAddr3(String empAddr3) {
		this.empAddr3 = empAddr3;
	}

	/*public String getEmpCity() {
		return empCity;
	}

	public void setEmpCity(String empCity) {
		this.empCity = empCity;
	}*/

	public String getEmpState() {
		return empState;
	}

	public void setEmpState(String empState) {
		this.empState = empState;
	}

	public String getEmpStateName() {
		return empStateName;
	}

	public void setEmpStateName(String empStateName) {
		this.empStateName = empStateName;
	}

	public String getEmpZip() {
		return empZip;
	}

	public void setEmpZip(String empZip) {
		this.empZip = empZip;
	}

	public String getEmpCountry() {
		return empCountry;
	}

	public void setEmpCountry(String empCountry) {
		this.empCountry = empCountry;
	}

	public String getEmpCountryLabel() {
		return empCountryLabel;
	}

	public void setEmpCountryLabel(String empCountryLabel) {
		this.empCountryLabel = empCountryLabel;
	}

	public String getEmpReportingBusiness() {
		return empReportingBusiness;
	}

	public void setEmpReportingBusiness(String empReportingBusiness) {
		this.empReportingBusiness = empReportingBusiness;
	}

	public String getEmpReportingIFG() {
		return empReportingIFG;
	}

	public void setEmpReportingIFG(String empReportingIFG) {
		this.empReportingIFG = empReportingIFG;
	}

	public String getEmpLocalLangName() {
		return empLocalLangName;
	}

	public void setEmpLocalLangName(String empLocalLangName) {
		this.empLocalLangName = empLocalLangName;
	}

	public String getEmpExpertise() {
		return empExpertise;
	}
	
	public void setEmpExpertise(String empExpertise) {
		this.empExpertise = empExpertise;
	}
	
	public String getMentorInterest() {
		return mentorInterest;
	}
	
	public void setMentorInterest(String mentorInterest) {
		this.mentorInterest = mentorInterest;
	}
	
	public String getMenteeInterest() {
		return menteeInterest;
	}
	
	public void setMenteeInterest(String menteeInterest) {
		this.menteeInterest = menteeInterest;
	}
	
	public String getEmpManagerName() {
		return empManagerName;
	}

	public void setEmpManagerName(String empManagerName) {
		this.empManagerName = empManagerName;
	}

	public String getEmpManagerAsciiName() {
		return empManagerAsciiName;
	}

	public void setEmpManagerAsciiName(String empManagerAsciiName) {
		this.empManagerAsciiName = empManagerAsciiName;
	}

	public Long getEmpManagerSso() {
		return empManagerSso;
	}

	public void setEmpManagerSso(Long empManagerSso) {
		this.empManagerSso = empManagerSso;
	}

	public String getMgrPreferredName() {
		return mgrPreferredName;
	}

	public void setMgrPreferredName(String mgrPreferredName) {
		this.mgrPreferredName = mgrPreferredName;
	}

	public String getMgrTitle() {
		return mgrTitle;
	}

	public void setMgrTitle(String mgrTitle) {
		this.mgrTitle = mgrTitle;
	}

	public String getMgrEmail() {
		return mgrEmail;
	}

	public void setMgrEmail(String mgrEmail) {
		this.mgrEmail = mgrEmail;
	}

	public String getMgrPhone() {
		return mgrPhone;
	}

	public void setMgrPhone(String mgrPhone) {
		this.mgrPhone = mgrPhone;
	}

	public String getMgrMobile() {
		return mgrMobile;
	}

	public void setMgrMobile(String mgrMobile) {
		this.mgrMobile = mgrMobile;
	}

	public String getOhMgrSso() {
		return ohMgrSso;
	}

	public void setOhMgrSso(String ohMgrSso) {
		this.ohMgrSso = ohMgrSso;
	}

	public String getOhMgrSso1() {
		return ohMgrSso1;
	}

	public void setOhMgrSso1(String ohMgrSso1) {
		this.ohMgrSso1 = ohMgrSso1;
	}

	public String getOhMgrSso2() {
		return ohMgrSso2;
	}

	public void setOhMgrSso2(String ohMgrSso2) {
		this.ohMgrSso2 = ohMgrSso2;
	}

	public String getOhMgrSso3() {
		return ohMgrSso3;
	}

	public void setOhMgrSso3(String ohMgrSso3) {
		this.ohMgrSso3 = ohMgrSso3;
	}

	public String getOhMgrLastName() {
		return ohMgrLastName;
	}

	public void setOhMgrLastName(String ohMgrLastName) {
		this.ohMgrLastName = ohMgrLastName;
	}

	public String getOhMgrLastName1() {
		return ohMgrLastName1;
	}

	public void setOhMgrLastName1(String ohMgrLastName1) {
		this.ohMgrLastName1 = ohMgrLastName1;
	}

	public String getOhMgrLastName2() {
		return ohMgrLastName2;
	}

	public void setOhMgrLastName2(String ohMgrLastName2) {
		this.ohMgrLastName2 = ohMgrLastName2;
	}

	public String getOhMgrLastName3() {
		return ohMgrLastName3;
	}

	public void setOhMgrLastName3(String ohMgrLastName3) {
		this.ohMgrLastName3 = ohMgrLastName3;
	}

	public String getOhMgrFirstName() {
		return ohMgrFirstName;
	}

	public void setOhMgrFirstName(String ohMgrFirstName) {
		this.ohMgrFirstName = ohMgrFirstName;
	}

	public String getOhMgrFirstName1() {
		return ohMgrFirstName1;
	}

	public void setOhMgrFirstName1(String ohMgrFirstName1) {
		this.ohMgrFirstName1 = ohMgrFirstName1;
	}

	public String getOhMgrFirstName2() {
		return ohMgrFirstName2;
	}

	public void setOhMgrFirstName2(String ohMgrFirstName2) {
		this.ohMgrFirstName2 = ohMgrFirstName2;
	}

	public String getOhMgrFirstName3() {
		return ohMgrFirstName3;
	}

	public void setOhMgrFirstName3(String ohMgrFirstName3) {
		this.ohMgrFirstName3 = ohMgrFirstName3;
	}

	public String getIfg() {
		return ifg;
	}

	public void setIfg(String ifg) {
		this.ifg = ifg;
	}

	public String getBusiness() {
		return business;
	}

	public void setBusiness(String business) {
		this.business = business;
	}

	public String getSubBusiness() {
		return subBusiness;
	}

	public void setSubBusiness(String subBusiness) {
		this.subBusiness = subBusiness;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getFunc() {
		return func;
	}

	public void setFunc(String func) {
		this.func = func;
	}

	public String getJobFamily() {
		return jobFamily;
	}

	public void setJobFamily(String jobFamily) {
		this.jobFamily = jobFamily;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getBand() {
		return band;
	}

	public void setBand(String band) {
		this.band = band;
	}

	public ACLBean getAcl() {
		return acl;
	}

	public void setAcl(ACLBean acl) {
		this.acl = acl;
	}

	public String getEmpLastName() {
		return empLastName;
	}

	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}

	public String getEmpFirstName() {
		return empFirstName;
	}

	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}

	public String getEmpHistorySharedFlag() {
		return empHistorySharedFlag;
	}

	public void setEmpHistorySharedFlag(String empHistorySharedFlag) {
		this.empHistorySharedFlag = empHistorySharedFlag;
	}

	public String getEducationSharedFlag() {
		return educationSharedFlag;
	}

	public void setEducationSharedFlag(String educationSharedFlag) {
		this.educationSharedFlag = educationSharedFlag;
	}

	public String getSortBy() {
		return sortBy;
	}

	public String getTrainingSharedFlag() {
		return trainingSharedFlag;
	}

	public void setTrainingSharedFlag(String trainingSharedFlag) {
		this.trainingSharedFlag = trainingSharedFlag;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	public String getPrsnType() {
		return prsnType;
	}

	public void setPrsnType(String prsnType) {
		this.prsnType = prsnType;
	}

	public String getTechDisciplineKW() {
		return techDisciplineKW;
	}

	public void setTechDisciplineKW(String techDisciplineKW) {
		this.techDisciplineKW = techDisciplineKW;
	}

	public String getTechDisciplineSTD() {
		return techDisciplineSTD;
	}

	public void setTechDisciplineSTD(String techDisciplineSTD) {
		this.techDisciplineSTD = techDisciplineSTD;
	}

	public String getDirectoryIncl() {
		return directoryIncl;
	}

	public void setDirectoryIncl(String directoryIncl) {
		this.directoryIncl = directoryIncl;
	}

	public String getEmpLocalLangTitle() {
		return empLocalLangTitle;
	}

	public void setEmpLocalLangTitle(String empLocalLangTitle) {
		this.empLocalLangTitle = empLocalLangTitle;
	}

	public String getWorkHistoryField() {
		return workHistoryField;
	}

	public void setWorkHistoryField(String workHistoryField) {
		this.workHistoryField = workHistoryField;
	}

	public String getProjects() {
		return projects;
	}

	public void setProjects(String projects) {
		this.projects = projects;
	}

	public String getInitiativeProjectSharedFlag() {
		return initiativeProjectSharedFlag;
	}

	public void setInitiativeProjectSharedFlag(
			String initiativeProjectSharedFlag) {
		this.initiativeProjectSharedFlag = initiativeProjectSharedFlag;
	}

	public String getInterests() {
		return interests;
	}

	public void setInterests(String interests) {
		this.interests = interests;
	}

	public String getInterestsSharedFlag() {
		return interestsSharedFlag;
	}

	public void setInterestsSharedFlag(String interestsSharedFlag) {
		this.interestsSharedFlag = interestsSharedFlag;
	}

	public String getProfessionalSummary() {
		return professionalSummary;
	}

	public void setProfessionalSummary(String professionalSummary) {
		this.professionalSummary = professionalSummary;
	}

	public String getCareerInterests() {
		return careerInterests;
	}

	public void setCareerInterests(String careerInterests) {
		this.careerInterests = careerInterests;
	}

	public String getCareerSharedFlag() {
		return careerSharedFlag;
	}

	public void setCareerSharedFlag(String careerSharedFlag) {
		this.careerSharedFlag = careerSharedFlag;
	}

	public String getTalentPool() {
		return talentPool;
	}

	public void setTalentPool(String talentPool) {
		this.talentPool = talentPool;
	}

	public String getCustomerSuppliersSharedFlag() {
		return customerSuppliersSharedFlag;
	}

	public void setCustomerSuppliersSharedFlag(
			String customerSuppliersSharedFlag) {
		this.customerSuppliersSharedFlag = customerSuppliersSharedFlag;
	}

	public String getLanguagesSharedFlag() {
		return languagesSharedFlag;
	}

	public void setLanguagesSharedFlag(String languagesSharedFlag) {
		this.languagesSharedFlag = languagesSharedFlag;
	}

	public String getExternalAffiliationsSharedFlag() {
		return externalAffiliationsSharedFlag;
	}

	public void setExternalAffiliationsSharedFlag(
			String externalAffiliationsSharedFlag) {
		this.externalAffiliationsSharedFlag = externalAffiliationsSharedFlag;
	}

	public String getCustomersSuppliers() {
		return customersSuppliers;
	}

	public void setCustomersSuppliers(String customersSuppliers) {
		this.customersSuppliers = customersSuppliers;
	}

	public String getLanguages() {
		return languages;
	}

	public void setLanguages(String languages) {
		this.languages = languages;
	}

	public String getExternalAffiliations() {
		return externalAffiliations;
	}

	public void setExternalAffiliations(String externalAffiliations) {
		this.externalAffiliations = externalAffiliations;
	}

	public String getCareerOpportunity() {
		return careerOpportunity;
	}

	public void setCareerOpportunity(String careerOpportunity) {
		this.careerOpportunity = careerOpportunity;
	}

	public Map<String, String> getHighlights() {
		return highlights;
	}

	public void setHighlights(Map<String, String> highlights) {
		this.highlights = highlights;
	}

	public List<LuceneEducationDto> getEducation() {
		return education;
	}

	public void setEducation(List<LuceneEducationDto> education) {
		this.education = education;
	}

	public List<LuceneEmpHistoryDto> getWorkHistory() {
		return workHistory;
	}

	public void setWorkHistory(List<LuceneEmpHistoryDto> workHistory) {
		this.workHistory = workHistory;
	}

	public List<LuceneTrainingDto> getTraining() {
		return training;
	}

	public void setTraining(List<LuceneTrainingDto> training) {
		this.training = training;
	}

	public List<LuceneLeadershipDto> getLeadershipProgram() {
		return leadershipProgram;
	}

	public void setLeadershipProgram(List<LuceneLeadershipDto> leadershipProgram) {
		this.leadershipProgram = leadershipProgram;
	}

	public List<IntiativesandProject> getInitiativesProject() {
		return initiativesProject;
	}

	public void setInitiativesProject(
			List<IntiativesandProject> initiativesProject) {
		this.initiativesProject = initiativesProject;
	}

	public String getWorkMobilityShared() {
		return workMobilityShared;
	}

	public void setWorkMobilityShared(String workMobilityShared) {
		this.workMobilityShared = workMobilityShared;
	}

	public String getRelocateWithin() {
		return relocateWithin;
	}

	public void setRelocateWithin(String relocateWithin) {
		this.relocateWithin = relocateWithin;
	}

	public String getRelocateOutside() {
		return relocateOutside;
	}

	public void setRelocateOutside(String relocateOutside) {
		this.relocateOutside = relocateOutside;
	}

	public String getMobilityCountries() {
		return mobilityCountries;
	}

	public void setMobilityCountries(String mobilityCountries) {
		this.mobilityCountries = mobilityCountries;
	}

	public String getConnectionSharedFlag() {
		return connectionSharedFlag;
	}
	
	public void setConnectionSharedFlag(String connectionSharedFlag) {
		this.connectionSharedFlag = connectionSharedFlag;
	}
	
	public String getMentoringSharedFlag() {
		return mentoringSharedFlag;
	}

	public void setMentoringSharedFlag(String mentoringSharedFlag) {
		this.mentoringSharedFlag = mentoringSharedFlag;
	}

	public String getMentorInfo() {
		return mentorInfo;
	}

	public void setMentorInfo(String mentorInfo) {
		this.mentorInfo = mentorInfo;
	}

	public String getMenteeInfo() {
		return menteeInfo;
	}

	public void setMenteeInfo(String menteeInfo) {
		this.menteeInfo = menteeInfo;
	}

	public String getConnectMenteeInfo() {
		return connectMenteeInfo;
	}
	
	public void setConnectMenteeInfo(String connectMenteeInfo) {
		this.connectMenteeInfo = connectMenteeInfo;
	}
	
	public String getConnectMentorInfo() {
		return connectMentorInfo;
	}
	
	public void setConnectMentorInfo(String connectMentorInfo) {
		this.connectMentorInfo = connectMentorInfo;
	}
	
	public String getConnectMentoDesc() {
		return connectMentoDesc;
	}
	
	public void setConnectMentoDesc(String connectMentoDesc) {
		this.connectMentoDesc = connectMentoDesc;
	}
	
	public String getRotationNumber() {
		return rotationNumber;
	}

	public void setRotationNumber(String rotationNumber) {
		this.rotationNumber = rotationNumber;
	}

	public String getAssignmentTitle() {
		return assignmentTitle;
	}

	public void setAssignmentTitle(String assignmentTitle) {
		this.assignmentTitle = assignmentTitle;
	}

	public String getAssignmentLeaderName() {
		return assignmentLeaderName;
	}

	public void setAssignmentLeaderName(String assignmentLeaderName) {
		this.assignmentLeaderName = assignmentLeaderName;
	}

	public String getAssignmentSubBusiness() {
		return assignmentSubBusiness;
	}

	public void setAssignmentSubBusiness(String assignmentSubBusiness) {
		this.assignmentSubBusiness = assignmentSubBusiness;
	}

	public String getAssignmentLeaderFor() {
		return assignmentLeaderFor;
	}

	public void setAssignmentLeaderFor(String assignmentLeaderFor) {
		this.assignmentLeaderFor = assignmentLeaderFor;
	}

	public String getMentoringDesc() {
		return mentoringDesc;
	}

	public void setMentoringDesc(String mentoringDesc) {
		this.mentoringDesc = mentoringDesc;
	}

	@Override
	public long getId() {
		// TODO Auto-generated method stub
		return 0;
	}

}
