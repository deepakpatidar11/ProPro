/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.MyCWPopulation;

/**
 * Direct Reports mapper
 * @author enrique.romero
 *
 */
public class MyCWPopulationMapper implements RowMapper<MyCWPopulation>{
	
	public static final String DATA_SSO = "sso";
	public static final String DATA_FULL_NAME = "full_name";
	public static final String DATA_WR_NO = "wr_no";
	public static final String DATA_PERSON_TYPE = "persontype";
	public static final String DATA_SUB_PERSON_TYPE = "subpersontype";
	public static final String DATA_COMPANY = "company";
	public static final String DATA_JOB_TITLE = "jobtitle";
	public static final String DATA_JOB_FUNCTION = "jobfunction";
	public static final String DATA_EFF_START_DATE = "effectivestartdate";     
	public static final String DATA_EFF_END_DATE = "effectiveenddate";      
	public static final String DATA_WR_STATUS = "wr_status"; 
	public static final String DATA_SUPERVISOR_SSO = "supervisorid";      
	public static final String DATA_SUPERVISOR_NAME = "supervisorname";
	public static final String DATA_HRM_SSO = "emp_hr_manager";
	public static final String DATA_HRM_NAME = "emp_hrm_name";
	public static final String DATA_INDUSTRY_GROUP = "industrygroup"; 
	public static final String DATA_BUSSINESS_SEGMENT = "businesssegment";
	public static final String DATA_BUSSINESS_UNIT= "businessunit";
	public static final String DATA_COUNTRY = "country";
	public static final String DATA_CITY= "city";
	public static final String DATA_GIVEN_NAME = "given_name";
	public static final String DATA_SURNAME = "surname";


	public MyCWPopulation mapRow(ResultSet rs, int rowNum) throws SQLException {
		MyCWPopulation myCWPopulation = new MyCWPopulation();

		myCWPopulation.setSso(rs.getLong(DATA_SSO));		
		myCWPopulation.setFull_name(rs.getString(DATA_FULL_NAME));
		myCWPopulation.setWr_no(rs.getLong(DATA_WR_NO));
		myCWPopulation.setPersontype(rs.getString(DATA_PERSON_TYPE));
		myCWPopulation.setSubpersontype(rs.getString(DATA_SUB_PERSON_TYPE));
		myCWPopulation.setCompany(rs.getString(DATA_COMPANY));
		myCWPopulation.setJobtitle(rs.getString(DATA_JOB_TITLE));
		myCWPopulation.setJobfunction(rs.getString(DATA_JOB_FUNCTION));
		myCWPopulation.setEffectivestartdate(rs.getDate(DATA_EFF_START_DATE));
		myCWPopulation.setEffectiveenddate(rs.getDate(DATA_EFF_END_DATE));
		myCWPopulation.setWr_status(rs.getString(DATA_WR_STATUS));
		myCWPopulation.setSupervisorid(rs.getLong(DATA_SUPERVISOR_SSO));
		myCWPopulation.setSupervisorname(rs.getString(DATA_SUPERVISOR_NAME));
		myCWPopulation.setEmp_hr_manager(rs.getLong(DATA_HRM_SSO));
		myCWPopulation.setEmp_hrm_name(rs.getString(DATA_HRM_NAME));
		myCWPopulation.setIndustrygroup(rs.getString(DATA_INDUSTRY_GROUP));
		myCWPopulation.setBusinesssegment(rs.getString(DATA_BUSSINESS_SEGMENT));		
		myCWPopulation.setBusinessunit(rs.getString(DATA_BUSSINESS_UNIT));
		myCWPopulation.setCountry(rs.getString(DATA_COUNTRY));
		myCWPopulation.setCity(rs.getString(DATA_CITY));
		myCWPopulation.setGiven_name(rs.getString(DATA_GIVEN_NAME));		
		myCWPopulation.setSurname(rs.getString(DATA_SURNAME));		
				
		return myCWPopulation;		
	}	
}
