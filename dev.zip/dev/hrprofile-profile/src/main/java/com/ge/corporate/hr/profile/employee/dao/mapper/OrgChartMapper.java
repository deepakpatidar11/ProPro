package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.dto.OrgChartDirectReportsDto;

public class OrgChartMapper implements RowMapper<OrgChartDirectReportsDto> {

	public static final String DATA_SSO = "sso";
	public static final String DATA_ORG_LEVEL = "org_level";
	public static final String DATA_FIRST_NAME = "emp_first_name";
	public static final String DATA_LAST_NAME = "emp_last_name";
	public static final String DATA_POSITION_TITLE = "emp_title";
	public static final String DATA_MANAGER_SSO = "emp_manager";
	private static final String DATA_IFG = "ifg";
	private static final String DATA_BUSINESS = "business";

	@Override
	public OrgChartDirectReportsDto mapRow(ResultSet rs, int rowNum) throws SQLException {

		OrgChartDirectReportsDto orgChart = new OrgChartDirectReportsDto();

		try {
			//orgChart.setDirectReports(null);
			orgChart.setFirstName(rs.getString(DATA_FIRST_NAME));
			orgChart.setLastName(rs.getString(DATA_LAST_NAME));
			orgChart.setManagerSso(rs.getLong(DATA_MANAGER_SSO));
			orgChart.setOrgLevel(rs.getInt(DATA_ORG_LEVEL));
			orgChart.setSso(rs.getLong(DATA_SSO));
			orgChart.setTitle(rs.getString(DATA_POSITION_TITLE));
			orgChart.setIfg(rs.getString(DATA_IFG));
			orgChart.setBusiness(rs.getString(DATA_BUSINESS));
			if(orgChart.getSso().toString().startsWith("5")){
				orgChart.setIsContingentWorker("Y");
			}else{
				orgChart.setIsContingentWorker("N");
			}
		} catch (SQLException e) {
			throw new SQLException("Org Chart data not loaded");
		}

		return orgChart;
	}

}
