/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.PriorPerformanceGV;

/**
 * Performance mapper
 * @author enrique.romero
 *
 */
public class PriorPerformanceGVMapper implements RowMapper<PriorPerformanceGV>{
	
	public static final String DATA_GV_NAME = "gv_name";
	public static final String DATA_GV_RATING = "gv_rating";
	public static final String DATA_GV_YEAR = "perf_year";
	
	public PriorPerformanceGV mapRow(ResultSet rs, int rowNum) throws SQLException {		
		PriorPerformanceGV priorPerformanceGV = new PriorPerformanceGV();		
		priorPerformanceGV.setName(rs.getString(DATA_GV_NAME));
		priorPerformanceGV.setRating(rs.getString(DATA_GV_RATING));
		priorPerformanceGV.setYear(rs.getInt(DATA_GV_YEAR));
		return priorPerformanceGV;		
	}
	
}
