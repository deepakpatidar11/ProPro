/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.MyHrPopulation;

/**
 * Direct Reports mapper
 * @author enrique.romero
 *
 */
public class MyHrPopulationMapper implements RowMapper<MyHrPopulation>{
	
	public static final String DATA_SSO = "sso";
	public static final String DATA_FIRST_NAME = "first_name";
	public static final String DATA_LAST_NAME = "last_name"; 
	public static final String DATA_FULL_NAME = "full_name";
	public static final String DATA_POSITION_TITLE = "title";
	public static final String DATA_BUSINESS = "business";
	public static final String DATA_SUB_BUSINESS = "sub_business";
	public static final String DATA_ORGANIZATION = "organization";
	public static final String DATA_FUNCTION = "ffunction"; 
	public static final String DATA_JOB_FAMILY = "job_family";
	public static final String DATA_JOB_TYPE = "job_type"; 
	public static final String DATA_BAND = "band";
	public static final String DATA_GENDER = "gender";
	public static final String DATA_US_EEO = "useeo";
	public static final String DATA_REGION = "region";
	public static final String DATA_COUNTRY = "country";
	public static final String DATA_CITY = "city";
	public static final String DATA_MANAGER = "manager_sso";
	public static final String DATA_MANAGER_NAME = "manager_name";
	public static final String DATA_HRMANAGER = "hrm_sso";
	public static final String DATA_HRMANAGER_NAME = "hrm_name";
	public static final String DATA_ADJ_SERVICE_DATE = "adjservicedate";
	public static final String DATA_ORG_START_DATE = "org_start_date";
	public static final String DATA_CURRENCY = "currency";
	public static final String DATA_LEGAL_ENTITY = "legal_entity";
	public static final String DATA_HEADCOUNT_COST_CENTER = "headcount_costcenter";
	public static final String DATA_RATING = "rating";
	public static final String DATA_SALARY = "salary";
	public static final String DATA_HEADCOUNT_VALUE = "headcount_value";
	public static final String DATA_ASSIGNMENT_STATUS= "assignment_status";
	public static final String DATA_ASSIGNMENT_CATEGORY = "assignment_category";
	public static final String DATA_MARKET_TYPE = "market_type";
	public static final String DATA_DIVERSITY = "diversity";
	
	private Locale locale = new Locale("en-US");
	private String format = "";
	private boolean isNoCompRole = false;
	
	public MyHrPopulationMapper(Locale locale_, String format_, boolean isNoCompRole_) {
		if(locale!=null){
			locale=locale_;
		}
		format=format_;
		isNoCompRole=isNoCompRole_;
	}
	
	public MyHrPopulationMapper(Locale locale_, String format_) {
		if(locale!=null){
			locale=locale_;
		}
		format=format_;
	}

	public MyHrPopulation mapRow(ResultSet rs, int rowNum) throws SQLException {
		MyHrPopulation myHrPopulation = new MyHrPopulation();
		
		NumberFormat nf = NumberFormat.getInstance(locale);
		nf.setMinimumFractionDigits(2);     
		nf.setMaximumFractionDigits(2);
		nf.setGroupingUsed(true);
	
		DecimalFormat df = new DecimalFormat("0.0");
		
		myHrPopulation.setSso(rs.getLong(DATA_SSO));		
		myHrPopulation.setFirst_name(rs.getString(DATA_FIRST_NAME));
		myHrPopulation.setLast_name(rs.getString(DATA_LAST_NAME));
		myHrPopulation.setFull_name(rs.getString(DATA_FULL_NAME));
		myHrPopulation.setTitle(rs.getString(DATA_POSITION_TITLE));
		myHrPopulation.setBusiness(rs.getString(DATA_BUSINESS));
		myHrPopulation.setSub_business(rs.getString(DATA_SUB_BUSINESS));
		myHrPopulation.setOrganization(rs.getString(DATA_ORGANIZATION));
		myHrPopulation.setFfunction(rs.getString(DATA_FUNCTION));
		myHrPopulation.setJob_family(rs.getString(DATA_JOB_FAMILY));
		myHrPopulation.setJob_type(rs.getString(DATA_JOB_TYPE));
		myHrPopulation.setBand(rs.getString(DATA_BAND));
		myHrPopulation.setGender(rs.getString(DATA_GENDER));
		myHrPopulation.setUseeo(rs.getString(DATA_US_EEO));
		myHrPopulation.setRegion(rs.getString(DATA_REGION));
		myHrPopulation.setCountry(rs.getString(DATA_COUNTRY));
		myHrPopulation.setCity(rs.getString(DATA_CITY));
		myHrPopulation.setManager_sso(rs.getLong(DATA_MANAGER));
		myHrPopulation.setManager_name(rs.getString(DATA_MANAGER_NAME));
		myHrPopulation.setHrm_sso(rs.getLong(DATA_HRMANAGER));
		myHrPopulation.setHrm_name(rs.getString(DATA_HRMANAGER_NAME));
		myHrPopulation.setAdjservicedate(rs.getDate(DATA_ADJ_SERVICE_DATE));
		myHrPopulation.setOrg_start_date(rs.getDate(DATA_ORG_START_DATE));
		if(!isNoCompRole){
			myHrPopulation.setCurrency(rs.getString(DATA_CURRENCY));
		}
		myHrPopulation.setLegal_entity(rs.getString(DATA_LEGAL_ENTITY));
		myHrPopulation.setHeadcount_costcenter(rs.getString(DATA_HEADCOUNT_COST_CENTER));
		myHrPopulation.setRating(rs.getString(DATA_RATING));
		if(format.equalsIgnoreCase("JSON")){
			if(!isNoCompRole){
				myHrPopulation.setSalary(rs.getString(DATA_SALARY)==null?rs.getString(DATA_SALARY):nf.format(Double.parseDouble(rs.getString(DATA_SALARY))));		
			}
			myHrPopulation.setHeadcount_value(rs.getString(DATA_HEADCOUNT_VALUE)==null?rs.getString(DATA_HEADCOUNT_VALUE):df.format(Float.parseFloat(rs.getString(DATA_HEADCOUNT_VALUE))));			
		}else{
			if(!isNoCompRole){
				myHrPopulation.setSalary(rs.getString(DATA_SALARY));		
			}
			myHrPopulation.setHeadcount_value(rs.getString(DATA_HEADCOUNT_VALUE));			
		}
		myHrPopulation.setAssignment_status(rs.getString(DATA_ASSIGNMENT_STATUS));
		myHrPopulation.setAssignment_category(rs.getString(DATA_ASSIGNMENT_CATEGORY));
		myHrPopulation.setHeadcount_value(rs.getString(DATA_HEADCOUNT_VALUE)==null?rs.getString(DATA_HEADCOUNT_VALUE):df.format(Float.parseFloat(rs.getString(DATA_HEADCOUNT_VALUE))));
		myHrPopulation.setMarket_type(rs.getString(DATA_MARKET_TYPE));
		myHrPopulation.setDiversity(rs.getString(DATA_DIVERSITY));
				
		return myHrPopulation;		
	}	
}
