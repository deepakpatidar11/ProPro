package com.ge.corporate.hr.profile.employee.service;


import com.ge.corporate.hr.profile.employee.dto.OneHrCompensationDto;

public interface OneHrCompensationService {
	
	public OneHrCompensationDto getOneHrCompensation(OneHrCompensationDto oneHrCompensationDto);

}
