/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
	
	private final static double AVERAGE_MILLIS_PER_MONTH = 365.24 * 24 * 60 * 60 * 1000 / 12;  
	   
	public static double monthsBetween(Date d1, Date d2) {  
	    return (d1.getTime() - d2.getTime()) / AVERAGE_MILLIS_PER_MONTH;   
	} 
	
	public static int getYear(Date date) {  
		SimpleDateFormat simpleDateformat=new SimpleDateFormat("yyyy");
		return Integer.parseInt(simpleDateformat.format(date));	       
	} 
	
	
}
