/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.ShortProfileList;


public class ShortProfileListMapper implements RowMapper<ShortProfileList>{

	public static final String DATA_SSO = "sso";
	public static final String DATA_LAST_NAME = "emps_last_name";
	public static final String DATA_FISRT_NAME = "emps_first_name";
	public static final String DATA_NAME = "emps_full_name";
	public static final String DATA_FUNCTION = "emps_function";
	public static final String DATA_MANAGER_NAME = "emps_manager_name";
	public static final String DATA_BUSINESS = "emps_business_name";
	public static final String DATA_SUB_BUSINESS = "emps_subbusiness_name";
	public static final String DATA_ORGANIZATION = "emps_org_name";
	public static final String DATA_IFG = "emps_ifg";
	public static final String DATA_TITLE = "emps_title_name";
	public static final String DATA_MANAGER_SSO = "emps_manager_sso";
	
	
	public ShortProfileList mapRow(ResultSet rs, int rowNum) throws SQLException {		
		ShortProfileList employee = new ShortProfileList();
		
		employee.setSso(rs.getLong(DATA_SSO));
		employee.setFirstName(rs.getString(DATA_FISRT_NAME));
		employee.setLastName(rs.getString(DATA_LAST_NAME));
		employee.setEmpName(rs.getString(DATA_NAME));
		employee.setFunction(rs.getString(DATA_FUNCTION));
		employee.setEmpManagerName(rs.getString(DATA_MANAGER_NAME));
		employee.setBusiness(rs.getString(DATA_BUSINESS));
		employee.setSubBusiness(rs.getString(DATA_SUB_BUSINESS));
		employee.setOrganization(rs.getString(DATA_ORGANIZATION));
		employee.setIfg(rs.getString(DATA_IFG));
		employee.setTitle(rs.getString(DATA_TITLE));
		employee.setEmpManagerSso(rs.getLong(DATA_MANAGER_SSO));
		return employee;		
		
	}
	
}
