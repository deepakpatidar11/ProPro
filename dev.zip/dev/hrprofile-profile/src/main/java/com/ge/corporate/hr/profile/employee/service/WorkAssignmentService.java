/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.service;

import com.ge.corporate.hr.profile.employee.dto.AssignmentDto;
import com.ge.corporate.hr.profile.employee.dto.AssignmentHistoryDto;
import com.ge.corporate.hr.profile.employee.dto.MyClientsDto;
import com.ge.corporate.hr.profile.employee.dto.MyReportsDto;
import com.ge.corporate.hr.profile.employee.dto.ProfessionalSummaryDto;
import com.ge.corporate.hr.profile.employee.model.LeadershipProgramAssignment;



public interface WorkAssignmentService {	
	public AssignmentDto getCurrentInformation(AssignmentDto assignmentDto);
	public AssignmentDto getConnectParams(AssignmentDto assignmentDto);
	public AssignmentHistoryDto getJobHistoryInformation(AssignmentHistoryDto assignmentDto);
	public MyClientsDto getMyClients(MyClientsDto myClientsDtoPar);
	public String getFullName(Long sso);
	public MyReportsDto getMyReport(MyReportsDto myReportsDto);	
	
	public boolean setProfessionalSummary(Long sso, String text);
	public String getProfessionalSummary(Long sso);
	public LeadershipProgramAssignment getLeadershipAssignment(Long sso);
		
}
