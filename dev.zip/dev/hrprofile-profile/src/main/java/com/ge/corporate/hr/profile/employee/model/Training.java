/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;
import com.ge.corporate.hr.profile.employee.serializer.PerfYearSerializer;

@XmlRootElement(name="training")
@XmlAccessorType(XmlAccessType.FIELD)
public class Training extends AbstractBaseModelSupport{

	private static final long serialVersionUID = 5969382423167807102L;

	@XmlElement(name="sso")
	private Long sso;
	@XmlAttribute(name="id")
	private Long id;
	
	@XmlElement(name="trainingTitle")
	private String trainingTitle;
	
	@XmlElement(name="completionDate")
	private Date completionDate;	
	
	@XmlElement(name="type")
	private String type;
	
	@XmlElement(name="screenUnder")
	private String screenUnder;	
	
	@XmlElement(name="displayHeading")
	private String displayHeading;
	
	@XmlElement(name="columNum")
	private Short columNum;
	
	@XmlElement(name="hasScreenUnder")
	private Boolean hasScreenUnder;
	
	
	public Training() {}
	
	public Training(String trainingName, Date completionDate) {
		super();
		this.setTrainingTitle(trainingName);
		this.setCompletionDate(completionDate);
	}
	
	public void setId(Long id) {
		this.id = id;
	}	
	public Long getId() {
		return id;
	}	
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getScreenUnder() {
		return screenUnder;
	}

	public void setScreenUnder(String screenUnder) {
		this.screenUnder = screenUnder;
	}

	public String getDisplayHeading() {
		return displayHeading;
	}

	public void setDisplayHeading(String displayHeading) {
		this.displayHeading = displayHeading;
	}

	public Short getColumNum() {
		return columNum;
	}

	public void setColumNum(Short couluNum) {
		this.columNum = couluNum;
	}
	
	public void setTrainingTitle(String trainingTitle) {
		this.trainingTitle = trainingTitle;
	}

	public String getTrainingTitle() {
		return trainingTitle;
	}

	public void setCompletionDate(Date completionDate) {
		this.completionDate = completionDate;
	}
	@JsonSerialize(using = PerfYearSerializer.class)
	public Date getCompletionDate() {
		return completionDate;
	}

	public void setHasScreenUnder(Boolean hasScreenUnder) {
		this.hasScreenUnder = hasScreenUnder;
	}

	public Boolean getHasScreenUnder() {
		return hasScreenUnder;
	}	
}
