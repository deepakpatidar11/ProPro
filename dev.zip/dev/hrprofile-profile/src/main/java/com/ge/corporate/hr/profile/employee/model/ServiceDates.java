/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;
import com.ge.corporate.hr.profile.employee.serializer.CustomDateSerializer;

@XmlRootElement(name="serviceDates")
@XmlAccessorType(XmlAccessType.FIELD)
public class ServiceDates extends AbstractBaseModelSupport{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7689225302484758395L;
	
	@XmlElement(name="sso")
	private Long sso; //
	@XmlElement(name="dateFirstHired")
	private Date dateFirstHired;
	@XmlElement(name="acquiredServiceDate")
	private Date acquiredServiceDate;
	@XmlElement(name="adjustedServiceDate")
	private Date adjustedServiceDate;
	@XmlElement(name="adjustedServiceDate")
	private Short monthsInBusiness;
	@XmlElement(name="geServiceYears")
	private Short geServiceYears;
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getDateFirstHired() {
		return dateFirstHired;
	}
	public void setDateFirstHired(Date dateFirstHired) {
		this.dateFirstHired = dateFirstHired;
	}
	
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getAcquiredServiceDate() {
		return acquiredServiceDate;
	}
	public void setAcquiredServiceDate(Date acquiredServiceDate) {
		this.acquiredServiceDate = acquiredServiceDate;
	}
	
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getAdjustedServiceDate() {
		return adjustedServiceDate;
	}
	public void setAdjustedServiceDate(Date adjustedServiceDate) {
		this.adjustedServiceDate = adjustedServiceDate;
	}
	
	public Short getMonthsInBusiness() {
		return monthsInBusiness;
	}
	public void setMonthsInBusiness(Short monthInBusiness) {
		this.monthsInBusiness = monthInBusiness;
	}
	
	public Short getGeServiceYears() {
		return geServiceYears;
	}
	public void setGeServiceYears(Short geServiceYears) {
		this.geServiceYears = geServiceYears;
	}
	
}
