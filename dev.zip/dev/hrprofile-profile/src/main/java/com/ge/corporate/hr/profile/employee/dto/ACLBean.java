package com.ge.corporate.hr.profile.employee.dto;

public class ACLBean {

	private String sso;         
	private String SUPV;
	private String MGR;
	private String ORG_MGR;
	private String ORG_HRM;
	private String HRM_SPL;
	private String SHRM;
	private String SHRM_F;
	private String SHRM_R;
	private String SHRM_GL;
	private String MATRIX_HRM;
	private String O_S_MANAGER;
	private String O_S_MANAGER_CP;
	private String O_S_MANAGER_F;
	private String O_S_MANAGER_GL;
	private String O_S_MANAGER_R;
	private String O_TD_MANAGER;
	private String O_TD_MANAGER_CP;
	private String O_TD_MANAGER_F;
	private String O_TD_MANAGER_GL;
	private String O_TD_MANAGER_R;
	private String HRM_VIEW;
	private String HR_BP;
	private String HRM;
	private String O_TD_NO_COMP;
	private String ADMIN_STAFF;
	private String STAFF_HS_STAFFING_SPL;
	private String STAFF_REQ_FLDR_OWNR;
	private String STAFF_HS_LTD_ACCESS;
	private String STAFF_HS_US_LEAD_RCTR;
	private String MGR_1O1; 
	private String LP_GLOBAL_PROGRAM_MGR; 
	private String LP_PROGRAM_MGR;
	private String LP_OPERATIONS;
	
	public String getSso() {
		return sso;
	}
	public void setSso(String sso) {
		this.sso = sso;
	}
	public String getORG_MGR() {
		return ORG_MGR;
	}
	public void setORG_MGR(String oRG_MGR) {
		ORG_MGR = oRG_MGR;
	}
	public String getORG_HRM() {
		return ORG_HRM;
	}
	public void setORG_HRM(String oRG_HRM) {
		ORG_HRM = oRG_HRM;
	}
	public String getHRM_SPL() {
		return HRM_SPL;
	}
	public void setHRM_SPL(String hRM_SPL) {
		HRM_SPL = hRM_SPL;
	}
	public String getSHRM() {
		return SHRM;
	}
	public void setSHRM(String sHRM) {
		SHRM = sHRM;
	}
	public String getSHRM_F() {
		return SHRM_F;
	}
	public void setSHRM_F(String sHRM_F) {
		SHRM_F = sHRM_F;
	}
	public String getSHRM_R() {
		return SHRM_R;
	}
	public void setSHRM_R(String sHRM_R) {
		SHRM_R = sHRM_R;
	}
	public String getSHRM_GL() {
		return SHRM_GL;
	}
	public void setSHRM_GL(String sHRM_GL) {
		SHRM_GL = sHRM_GL;
	}
	public String getMATRIX_HRM() {
		return MATRIX_HRM;
	}
	public void setMATRIX_HRM(String mATRIX_HRM) {
		MATRIX_HRM = mATRIX_HRM;
	}
	public String getO_S_MANAGER() {
		return O_S_MANAGER;
	}
	public void setO_S_MANAGER(String o_S_MANAGER) {
		O_S_MANAGER = o_S_MANAGER;
	}
	public String getO_S_MANAGER_CP() {
		return O_S_MANAGER_CP;
	}
	public void setO_S_MANAGER_CP(String o_S_MANAGER_CP) {
		O_S_MANAGER_CP = o_S_MANAGER_CP;
	}
	public String getO_S_MANAGER_F() {
		return O_S_MANAGER_F;
	}
	public void setO_S_MANAGER_F(String o_S_MANAGER_F) {
		O_S_MANAGER_F = o_S_MANAGER_F;
	}
	public String getO_S_MANAGER_GL() {
		return O_S_MANAGER_GL;
	}
	public void setO_S_MANAGER_GL(String o_S_MANAGER_GL) {
		O_S_MANAGER_GL = o_S_MANAGER_GL;
	}
	public String getO_S_MANAGER_R() {
		return O_S_MANAGER_R;
	}
	public void setO_S_MANAGER_R(String o_S_MANAGER_R) {
		O_S_MANAGER_R = o_S_MANAGER_R;
	}
	public String getO_TD_MANAGER() {
		return O_TD_MANAGER;
	}
	public void setO_TD_MANAGER(String o_TD_MANAGER) {
		O_TD_MANAGER = o_TD_MANAGER;
	}
	public String getO_TD_MANAGER_CP() {
		return O_TD_MANAGER_CP;
	}
	public void setO_TD_MANAGER_CP(String o_TD_MANAGER_CP) {
		O_TD_MANAGER_CP = o_TD_MANAGER_CP;
	}
	public String getO_TD_MANAGER_F() {
		return O_TD_MANAGER_F;
	}
	public void setO_TD_MANAGER_F(String o_TD_MANAGER_F) {
		O_TD_MANAGER_F = o_TD_MANAGER_F;
	}
	public String getO_TD_MANAGER_GL() {
		return O_TD_MANAGER_GL;
	}
	public void setO_TD_MANAGER_GL(String o_TD_MANAGER_GL) {
		O_TD_MANAGER_GL = o_TD_MANAGER_GL;
	}
	public String getO_TD_MANAGER_R() {
		return O_TD_MANAGER_R;
	}
	public void setO_TD_MANAGER_R(String o_TD_MANAGER_R) {
		O_TD_MANAGER_R = o_TD_MANAGER_R;
	}
	public String getHRM_VIEW() {
		return HRM_VIEW;
	}
	public void setHRM_VIEW(String hRM_VIEW) {
		HRM_VIEW = hRM_VIEW;
	}
	public String getHR_BP() {
		return HR_BP;
	}
	public void setHR_BP(String hR_BP) {
		HR_BP = hR_BP;
	}
	public String getHRM() {
		return HRM;
	}
	public void setHRM(String hRM) {
		HRM = hRM;
	}
	public String getSUPV() {
		return SUPV;
	}
	public void setSUPV(String sUPV) {
		SUPV = sUPV;
	}
	public String getMGR() {
		return MGR;
	}
	public void setMGR(String mGR) {
		MGR = mGR;
	}
	public String getO_TD_NO_COMP() {
		return O_TD_NO_COMP;
	}
	public void setO_TD_NO_COMP(String o_TD_NO_COMP) {
		O_TD_NO_COMP = o_TD_NO_COMP;
	}
	public String getADMIN_STAFF() {
		return ADMIN_STAFF;
	}
	public void setADMIN_STAFF(String aDMIN_STAFF) {
		ADMIN_STAFF = aDMIN_STAFF;
	}
	public String getSTAFF_HS_STAFFING_SPL() {
		return STAFF_HS_STAFFING_SPL;
	}
	public void setSTAFF_HS_STAFFING_SPL(String sTAFF_HS_STAFFING_SPL) {
		STAFF_HS_STAFFING_SPL = sTAFF_HS_STAFFING_SPL;
	}
	public String getSTAFF_REQ_FLDR_OWNR() {
		return STAFF_REQ_FLDR_OWNR;
	}
	public void setSTAFF_REQ_FLDR_OWNR(String sTAFF_REQ_FLDR_OWNR) {
		STAFF_REQ_FLDR_OWNR = sTAFF_REQ_FLDR_OWNR;
	}
	public String getSTAFF_HS_LTD_ACCESS() {
		return STAFF_HS_LTD_ACCESS;
	}
	public void setSTAFF_HS_LTD_ACCESS(String sTAFF_HS_LTD_ACCESS) {
		STAFF_HS_LTD_ACCESS = sTAFF_HS_LTD_ACCESS;
	}
	public String getSTAFF_HS_US_LEAD_RCTR() {
		return STAFF_HS_US_LEAD_RCTR;
	}
	public void setSTAFF_HS_US_LEAD_RCTR(String sTAFF_HS_US_LEAD_RCTR) {
		STAFF_HS_US_LEAD_RCTR = sTAFF_HS_US_LEAD_RCTR;
	}
	public String getMGR_1O1() {
		return MGR_1O1;
	}
	public void setMGR_1O1(String mGR_1O1) {
		MGR_1O1 = mGR_1O1;
	}
	public String getLP_GLOBAL_PROGRAM_MGR() {
		return LP_GLOBAL_PROGRAM_MGR;
	}
	public void setLP_GLOBAL_PROGRAM_MGR(String lP_GLOBAL_PROGRAM_MGR) {
		LP_GLOBAL_PROGRAM_MGR = lP_GLOBAL_PROGRAM_MGR;
	}
	public String getLP_PROGRAM_MGR() {
		return LP_PROGRAM_MGR;
	}
	public void setLP_PROGRAM_MGR(String lP_PROGRAM_MGR) {
		LP_PROGRAM_MGR = lP_PROGRAM_MGR;
	}
	public String getLP_OPERATIONS() {
		return LP_OPERATIONS;
	}
	public void setLP_OPERATIONS(String lP_OPERATIONS) {
		LP_OPERATIONS = lP_OPERATIONS;
	}
	public ACLBean(String sso, String sUPV, String mGR, String oRG_MGR, String hRM, String oRG_HRM, String hRM_SPL,
			String sHRM, String sHRM_F, String sHRM_R, String sHRM_GL,
			String mATRIX_HRM, String o_S_MANAGER, String o_S_MANAGER_CP,
			String o_S_MANAGER_F, String o_S_MANAGER_GL, String o_S_MANAGER_R,
			String o_TD_MANAGER, String o_TD_MANAGER_CP,
			String o_TD_MANAGER_F, String o_TD_MANAGER_GL, String o_TD_MANAGER_R,
			String hRM_VIEW, String hR_BP,
			String o_TD_NO_COMP, String aDMIN_STAFF, String sTAFF_HS_STAFFING_SPL, 
			String sTAFF_REQ_FLDR_OWNR, String sTAFF_HS_LTD_ACCESS, String sTAFF_HS_US_LEAD_RCTR, String MGR_1O1, String LP_GLOBAL_PROGRAM_MGR, String LP_PROGRAM_MGR, String LP_OPERATIONS) {
		super();
		this.sso = sso;
		SUPV = sUPV;
		MGR = mGR;
		ORG_MGR = oRG_MGR;
		HRM = hRM;
		ORG_HRM = oRG_HRM;
		HRM_SPL = hRM_SPL;
		SHRM = sHRM;
		SHRM_F = sHRM_F;
		SHRM_R = sHRM_R;
		SHRM_GL = sHRM_GL;
		MATRIX_HRM = mATRIX_HRM;
		O_S_MANAGER = o_S_MANAGER;
		O_S_MANAGER_CP = o_S_MANAGER_CP;
		O_S_MANAGER_F = o_S_MANAGER_F;
		O_S_MANAGER_GL = o_S_MANAGER_GL;
		O_S_MANAGER_R = o_S_MANAGER_R;
		O_TD_MANAGER = o_TD_MANAGER;
		O_TD_MANAGER_CP = o_TD_MANAGER_CP;
		O_TD_MANAGER_F = o_TD_MANAGER_F;
		O_TD_MANAGER_GL = o_TD_MANAGER_GL;
		O_TD_MANAGER_R = o_TD_MANAGER_R;
		HRM_VIEW = hRM_VIEW;
		HR_BP = hR_BP;		
		O_TD_NO_COMP = o_TD_NO_COMP;
		ADMIN_STAFF = aDMIN_STAFF;
		STAFF_HS_STAFFING_SPL = sTAFF_HS_STAFFING_SPL;
		STAFF_REQ_FLDR_OWNR = sTAFF_REQ_FLDR_OWNR;
		STAFF_HS_LTD_ACCESS = sTAFF_HS_LTD_ACCESS;
		STAFF_HS_US_LEAD_RCTR = sTAFF_HS_US_LEAD_RCTR;
		MGR_1O1 = MGR_1O1;
		LP_GLOBAL_PROGRAM_MGR = LP_GLOBAL_PROGRAM_MGR;
		LP_PROGRAM_MGR = LP_PROGRAM_MGR;
		LP_OPERATIONS = LP_OPERATIONS;
	}
	public ACLBean() {
		super();
	}
	
}
