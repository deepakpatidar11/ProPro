package com.ge.corporate.hr.profile.employee.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class OrgChartPdfDto {
	
		@XmlElement(name = "svg")
		private String svg;
		
		@XmlElement(name = "html")
		private String html;

		@XmlElement(name = "width")
		private float width;

		@XmlElement(name = "height")
		private float height;

		@XmlElement(name = "svgheight")
		private float svgheight;

		@XmlElement(name = "svgwidth")
		private float svgwidth;

		@XmlElement(name = "path")
		private List<String> path;

		
		public String getSvg() {
			return svg;
		}

		public void setSvg(String svg) {
			this.svg = svg;
		}
		
		public String getHtml() {
			return html;
		}

		public void setHtml(String html) {
			this.html = html;
		}

		public float getWidth() {
			return width;
		}

		public void setWidth(float width) {
			this.width = width;
		}

		public float getHeight() {
			return height;
		}

		public void setHeight(float height) {
			this.height = height;
		}

		public float getSvgheight() {
			return svgheight;
		}

		public void setSvgheight(float svgheight) {
			this.svgheight = svgheight;
		}

		public float getSvgwidth() {
			return svgwidth;
		}

		public void setSvgwidth(float svgwidth) {
			this.svgwidth = svgwidth;
		}

		public List<String> getPath() {
			return path;
		}

		public void setPath(List<String> path) {
			this.path = path;
		}

		
	
}
