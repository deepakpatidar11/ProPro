/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.security.access.prepost.PreAuthorize;

import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;
import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dao.mapper.CASMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.CertificationMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.SixSigmaMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.TrainingMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.TrainingNoYearMapper;
import com.ge.corporate.hr.profile.employee.model.CAS;
import com.ge.corporate.hr.profile.employee.model.Certification;
import com.ge.corporate.hr.profile.employee.model.SixSigma;
import com.ge.corporate.hr.profile.employee.model.Training;
import com.ge.corporate.hr.profile.employee.service.cache.DaoKeyGenerator;
/**
 * Education Dao Implementation
 * @author enrique.romero
 */
public class TrainingDaoImpl extends AbstractBaseDaoSupport  implements TrainingDao{
	
	//@Cache(nodeName="/profile/employee/dao/training", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	//@PreAuthorize("hasPermission(#sso, 'ResumeTrainingView', read)")
	public BaseModelCollection<Training> getEmployeeTrainingBySso(Long sso) {
		BaseModelCollection<Training> trainingList = new BaseModelCollection<Training>();
		String query = this.getSql("getEmployeeTrainingBySso");		
		try{
			trainingList.setList( getJdbcTemplate().query(query, new Object[]{sso.intValue(),sso.intValue()}, new TrainingMapper()));
			logger.debug("Training data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Training data Not found");
		}
		return trainingList;
	}
	
	public BaseModelCollection<Training> getEmployeeTrainingAllBySso(Long sso) {
		BaseModelCollection<Training> trainingList = new BaseModelCollection<Training>();
		String query = this.getSql("getEmployeeTrainingBySso");		
		try{
			trainingList.setList( getJdbcTemplate().query(query, new Object[]{sso.intValue(),sso.intValue()}, new TrainingNoYearMapper()));
			logger.debug("Training data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Training data Not found");
		}
		return trainingList;
	}
	
	public BaseModelCollection<Training> getEmployeeTrainingOptinBySso(Long sso) {
		BaseModelCollection<Training> trainingList = new BaseModelCollection<Training>();
		String query = this.getSql("getEmployeeTrainingOptinBySso");		
		try{
			trainingList.setList( getJdbcTemplate().query(query, new Object[]{sso.intValue(),sso.intValue(),sso.intValue()}, new TrainingNoYearMapper()));
			logger.debug("Training data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Training data Not found");
		}
		return trainingList;
	}

	@Override
	public BaseModelCollection<SixSigma> getSixSigmaBySso(Long sso) {
		BaseModelCollection<SixSigma> sixSigmaList = new BaseModelCollection<SixSigma>();
		String query = this.getSql("getSixSigmaBySso");		
		try{
			sixSigmaList.setList(getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new SixSigmaMapper()));
			logger.debug("Six Sigma data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Six Sigma data was not found");
		}catch (Exception ex) {
			logger.debug("Six Sigma data was not found" );
		}
		
		return sixSigmaList;
	}

	@Override
	public BaseModelCollection<CAS> getCASDataBySso(Long sso) {
		BaseModelCollection<CAS> casList = new BaseModelCollection<CAS>();
		String query = this.getSql("getCASBySso");		
		try{
			casList.setList(getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new CASMapper()));
			logger.debug("CAS data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("CAS data was not found");
		}catch (Exception ex) {
			logger.debug("CAS data was not found" );
		}
		
		return casList;
	}

}
