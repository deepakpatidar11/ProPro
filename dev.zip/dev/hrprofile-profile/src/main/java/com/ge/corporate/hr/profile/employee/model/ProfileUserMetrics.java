package com.ge.corporate.hr.profile.employee.model;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

public class ProfileUserMetrics extends AbstractBaseModelSupport {

	private static final long serialVersionUID = 157546633102722461L;
	
	private Long sso;
	private Long viewedSso;
	private String viewType;
	private String pageVisited;
	private String tabClicked;
	private String rolesForContext;
	private String business;
	private String function;
	private String region;
	private String employeeType;
	private String loginType;
	private String operatingSystem;
	private String browser;
	private String device;
	private String clientSearch;
	
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	public Long getViewedSso() {
		return viewedSso;
	}
	public void setViewedSso(Long viewedSso) {
		this.viewedSso = viewedSso;
	}
	public String getPageVisited() {
		return pageVisited;
	}
	public void setPageVisited(String pageVisited) {
		this.pageVisited = pageVisited;
	}
	public String getTabClicked() {
		return tabClicked;
	}
	public void setTabClicked(String tabClicked) {
		this.tabClicked = tabClicked;
	}
	public String getRolesForContext() {
		return rolesForContext;
	}
	public void setRolesForContext(String rolesForContext) {
		this.rolesForContext = rolesForContext;
	}
	public String getBusiness() {
		return business;
	}
	public void setBusiness(String business) {
		this.business = business;
	}
	public String getFunction() {
		return function;
	}
	public void setFunction(String function) {
		this.function = function;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getEmployeeType() {
		return employeeType;
	}
	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}
	public String getOperatingSystem() {
		return operatingSystem;
	}
	public void setOperatingSystem(String operatingSystem) {
		this.operatingSystem = operatingSystem;
	}
	public String getBrowser() {
		return browser;
	}
	public void setBrowser(String browser) {
		this.browser = browser;
	}
	public String getDevice() {
		return device;
	}
	public void setDevice(String device) {
		this.device = device;
	}
	public String getClientSearch() {
		return clientSearch;
	}
	public void setClientSearch(String clientSearch) {
		this.clientSearch = clientSearch;
	}
	public String getLoginType() {
		return loginType;
	}
	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}
	public String getViewType() {
		return viewType;
	}
	public void setViewType(String viewType) {
		this.viewType = viewType;
	}
	
	public static ProfileUserMetrics setUserAgentDetails(ProfileUserMetrics metrics, String userAgent) {
		String browser = "";
		String os = "";
		String deviceType = "";
		
		if(userAgent.contains("msie") || userAgent.contains("trident/")){
			browser = "msie";		
	    } else if(userAgent.contains("firefox")){
	    	browser = "firefox";
	    } else if(userAgent.contains("chrome")){
	    	browser = "chrome";
	    } else if(userAgent.contains("safari")){
	    	browser = "safari";
	    }
		
		if(userAgent.contains("windows")) {
			os = "windows";
		} else if(userAgent.contains("macintosh") || userAgent.contains("mac")) {
			os = "macintosh";
		}
		
		if(userAgent.contains("mobile")) {
			deviceType = "mobile";
		} else {
			deviceType = "computer";
		}
		
		metrics.setBrowser(browser);
		metrics.setOperatingSystem(os);
		metrics.setDevice(deviceType);
		
		return metrics;
	}
}
