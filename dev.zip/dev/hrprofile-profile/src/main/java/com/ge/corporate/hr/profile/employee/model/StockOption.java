/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;
import com.ge.corporate.hr.profile.employee.serializer.CustomDateSerializer;

@XmlRootElement(name="stockOption")
@XmlAccessorType(XmlAccessType.FIELD)
public class StockOption extends AbstractBaseModelSupport{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5094585084114835512L;
	
	@XmlElement(name="sso")
	private Long sso;
	@XmlAttribute(name="id")
	private Long id;
	@XmlElement(name="dateGranted")
	private Date dateGranted;
	@XmlElement(name="price")
	private Double price;
	@XmlElement(name="numShares")
	private Integer numShares;
	@XmlElement(name="exercised")
	private Integer exercised;
	@XmlElement(name="total")
	private Integer total;
	@XmlElement(name="sharedVested")
	private Integer sharedVested;	
	@XmlElement(name="nextVestingDate")
	private Date nextVestingDate;	
	@XmlElement(name="nextVestingAmount")
	private Double nextVestingAmount;	
	@XmlElement(name="sharedUnvested")
	private Integer sharedUnvested;
	
	
	public void setId(Long id) {
		this.id = id;
	}	
	public Long getId() {
		return id;
	}	
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getDateGranted() {
		return dateGranted;
	}
	public void setDateGranted(Date dateGranted) {
		this.dateGranted = dateGranted;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Integer getNumShares() {
		return numShares;
	}
	public void setNumShares(Integer numShares) {
		this.numShares = numShares;
	}
	public Integer getSharedVested() {
		return sharedVested;
	}
	public void setSharedVested(Integer sharedVested) {
		this.sharedVested = sharedVested;
	}
	public void setNextVestingDate(Date nextVestingDate) {
		this.nextVestingDate = nextVestingDate;
	}
	
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getNextVestingDate() {
		return nextVestingDate;
	}
	public void setNextVestingAmount(Double nextVestingAmount) {
		this.nextVestingAmount = nextVestingAmount;
	}
	public Double getNextVestingAmount() {
		return nextVestingAmount;
	}	
	public void setSharedUnvested(Integer sharedUnvested) {
		this.sharedUnvested = sharedUnvested;
	}
	public Integer getSharedUnvested() {
		return sharedUnvested;
	}
	public void setExercised(Integer exercised) {
		this.exercised = exercised;
	}
	public Integer getExercised() {
		return exercised;
	}
	public void setTotal(Integer total) {
		this.total = total;
	}
	public Integer getTotal() {
		return total;
	}
	
	
}
