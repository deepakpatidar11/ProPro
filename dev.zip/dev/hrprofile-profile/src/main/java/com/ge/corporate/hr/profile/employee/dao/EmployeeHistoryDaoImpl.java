/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.security.access.prepost.PreAuthorize;

import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dao.mapper.CareerInterestMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.CustomerandSuppilersMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.CountryRegionMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.EmployeeHistoryMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.IntiativesandProjectMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.LanguageProficicencyMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.WorkMobilityMapper;
import com.ge.corporate.hr.profile.employee.dto.CountryRegionDto;
import com.ge.corporate.hr.profile.employee.dto.EmployeeHistoryDto;
import com.ge.corporate.hr.profile.employee.model.CareerAspiration;
import com.ge.corporate.hr.profile.employee.model.CustomerandSuppliers;
import com.ge.corporate.hr.profile.employee.model.EmployeeHistory;
import com.ge.corporate.hr.profile.employee.model.IntiativesandProject;
import com.ge.corporate.hr.profile.employee.model.LanguageProficiency;
import com.ge.corporate.hr.profile.employee.model.WorkAssignmentRestricted;
import com.ge.corporate.hr.profile.employee.model.WorkMobility;
import com.ge.corporate.hr.profile.employee.service.EmployeeProfileService;
import com.ge.corporate.hr.profile.employee.service.cache.DaoKeyGenerator;

public class EmployeeHistoryDaoImpl extends AbstractBaseDaoSupport implements EmployeeHistoryDao {
	@Resource(name = "employeeProfileService")
	private EmployeeProfileService personalInfoService;
	//@Cache(nodeName="/profile/employee/dao/employeehistory", keyGeneratorClass = DaoKeyGenerator.class, cacheName="profile-employee-dao")
	//@PreAuthorize("hasPermission(#sso, 'ResumeWorkHistoryView', read)")
	public BaseModelCollection<EmployeeHistory> getEmployeeHistoryBySso(Long sso) {
		
		final BaseModelCollection<EmployeeHistory> employeeHistory = new BaseModelCollection<EmployeeHistory>();
		String query = this.getSql("getEmployeeHistoryBySSO");
		
		try{
			employeeHistory.getList().addAll(getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new EmployeeHistoryMapper()));
		}catch(EmptyResultDataAccessException eex) {
			logger.debug("Employee History Not found");
		}
		
		return employeeHistory;
	}
	
	public BaseModelCollection<EmployeeHistory> getEmployeeHistoryForRoleSelf(Long sso) {
		
		final BaseModelCollection<EmployeeHistory> employeeHistory = new BaseModelCollection<EmployeeHistory>();
		String query = this.getSql("getEmployeeHistoryBySSO");
		
		try{
			employeeHistory.getList().addAll(getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new EmployeeHistoryMapper()));
		}catch(EmptyResultDataAccessException eex) {
			logger.debug("Employee History Not found");
		}
		
		return employeeHistory;
	}
	
	public BaseModelCollection<EmployeeHistory> getEmployeeHistoryAllBySso(Long sso, boolean isSelf, boolean hasDataGroup) {
		
		final BaseModelCollection<EmployeeHistory> employeeHistory = new BaseModelCollection<EmployeeHistory>();
		String query = this.getSql("getEmployeeHistoryBySSO");
		
		try{
			employeeHistory.getList().addAll(getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new EmployeeHistoryMapper(isSelf,hasDataGroup)));
			
		}catch(EmptyResultDataAccessException eex) {
			logger.debug("Employee History Not found");
		}
		
		return employeeHistory;
	}
	
	public BaseModelCollection<EmployeeHistory> getEmployeeHistoryOptinBySso(Long sso, boolean isSelf, boolean hasDataGroup) {
		
		final BaseModelCollection<EmployeeHistory> employeeHistory = new BaseModelCollection<EmployeeHistory>();
		String query = this.getSql("getEmployeeHistoryOptinBySSO");
		
		try{
			employeeHistory.getList().addAll(getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new EmployeeHistoryMapper(isSelf,hasDataGroup)));
		}catch(EmptyResultDataAccessException eex) {
			logger.debug("Employee History Not found");
		}
		
		return employeeHistory;
	}
	
	//@PreAuthorize("hasPermission(#sso, 'ResumeInitiativesProjectsView', read)")
	public BaseModelCollection<IntiativesandProject> getIntiativesAndProject(
			Long sso) {
		BaseModelCollection<IntiativesandProject> employeehis=new BaseModelCollection<IntiativesandProject>();
		String query = this.getSql("intiativesandproject");
		try{
        employeehis.setList(getJdbcTemplate().query(query,new Object[]{sso},new IntiativesandProjectMapper()));
		}catch(EmptyResultDataAccessException eex) {
			logger.debug("Employee History Not found");
		}
		
		return employeehis;
	}

	@PreAuthorize("hasPermission(#sso, 'ResumeInitiativesProjectsEdit', read)")
	public void updateIntiativesAndProject(Long sso,
			EmployeeHistoryDto employeeHistory) {
		String addquery = this.getSql("addIntiativesAndProject");
		String deletequery = this.getSql("deleteIntiativesAndProject");
		String deleteallquery = this.getSql("deleteAllIntiativesAndProject");
		try{
			if(employeeHistory.getNewIntiativesandProject().size()>0)
			{
				getJdbcTemplate().update(deleteallquery, new Object[]{employeeHistory.getSso()});
				for(IntiativesandProject inti:employeeHistory.getNewIntiativesandProject())
				{
					
						Date toDate=null;
				
					if(inti.getToDate()!=""){
					 toDate=java.sql.Date.valueOf(inti.getToDate()+"-01");}
					
					Date fromDate=java.sql.Date.valueOf(inti.getFromDate()+"-01");
				int row=getJdbcTemplate().update(addquery, new Object[]{employeeHistory.getSso(), personalInfoService.escapeSpecialCharacters(inti.getTitle()),personalInfoService.escapeSpecialCharacters(inti.getDescription()),fromDate,toDate});
				}
			}
				if(employeeHistory.getDeleteIntiativesandProject().size()>0)
				{
					for(IntiativesandProject inti:employeeHistory.getDeleteIntiativesandProject())
					{
						
					int row=getJdbcTemplate().update(deletequery, new Object[]{employeeHistory.getSso(),inti.getTitle()});
				}
				}
		}catch(EmptyResultDataAccessException eex) {
			logger.debug("Employee History Not found");
		}
		
		
	}
	
	//@PreAuthorize("hasPermission(#sso, 'ResumeCareerAspirationView', read)")
	public CareerAspiration getCareerAspiration(Long sso) {
		
		
		CareerAspiration careerInterest = new CareerAspiration();
		String query = this.getSql("getCareerAspiration");
		try{					
			careerInterest = getJdbcTemplate().queryForObject(query, new Object[]{sso}, new CareerInterestMapper());
			logger.debug("Career Aspiration data was loaded susscesfully");	
		
		}catch (EmptyResultDataAccessException eex) {		
			
			logger.debug("Career Aspiration Not Found");			
		
		}				
	
		return careerInterest;
	}
	
	@PreAuthorize("hasPermission(#sso, 'ResumeCareerAspirationEdit', read)")
	public boolean setCareerAspiration(Long sso, String goalCombined) {
		try{	
			getJdbcTemplate().update(this.getSql("setCareerAspiration"),new Object[]{sso,goalCombined});
			logger.debug("Career Aspiration data updated sucessfully");
		}catch(Exception e){
			logger.debug("Career Aspiration data update failed");
			return false;
		}	
		return true ;
	}
	
	//@PreAuthorize("hasPermission(#sso, 'ResumeCustomerSuppliersView', read)")
	public BaseModelCollection<CustomerandSuppliers> getCustomerAndSuppiler(Long sso) {
		// TODO Auto-generated method stub
		BaseModelCollection<CustomerandSuppliers> employeehis=new BaseModelCollection<CustomerandSuppliers>();
		String query = this.getSql("customerAndSuppliers");
		try{
        employeehis.setList(getJdbcTemplate().query(query,new Object[]{sso},new CustomerandSuppilersMapper()));
		}catch(EmptyResultDataAccessException eex) {
			logger.debug("Employee History Not found");
		}
		
		return employeehis;
	}

	@PreAuthorize("hasPermission(#sso, 'ResumeCustomerSuppliersEdit', read)")
	public void updateCustomerSuppliers(Long sso, EmployeeHistoryDto employeeHistory) {
		String addquery = this.getSql("addcustomerAndSuppliers");
		String deletequery = this.getSql("deletecustomerAndSuppliers");
		String deleteallquery = this.getSql("deleteAllcustomerAndSuppliers");
		try{
			if(employeeHistory.getNewcustomerSupplier().size()>0)
			{
				
				
				
				int r=getJdbcTemplate().update(deleteallquery, new Object[]{employeeHistory.getSso()});
				Date toDate=null;
				
				
				for(CustomerandSuppliers cust:employeeHistory.getNewcustomerSupplier())
				{
					if(cust.getToDate()!=""){
						 toDate=java.sql.Date.valueOf(cust.getToDate()+"-01");}
					
					Date fromDate=java.sql.Date.valueOf(cust.getFromDate()+"-01");
				int row=getJdbcTemplate().update(addquery, new Object[]{employeeHistory.getSso(),personalInfoService.escapeSpecialCharacters(cust.getTitle()),personalInfoService.escapeSpecialCharacters(cust.getLocation()),personalInfoService.escapeSpecialCharacters(cust.getDescription()),fromDate,toDate});
			
			}
			}
				if(employeeHistory.getDeleteCustomerSupplier().size()>0)
				{
					for(CustomerandSuppliers cust:employeeHistory.getDeleteCustomerSupplier())
					{
						
					
					int row=getJdbcTemplate().update(deletequery, new Object[]{employeeHistory.getSso(),cust.getTitle()});
					System.out.println("row"+row);
				}
				}
		}catch(EmptyResultDataAccessException eex) {
			logger.debug("Employee History Not found");
		}
		
	}

	@PreAuthorize("hasPermission(#sso, 'ResumeWorkHistoryEdit', read)")
	public boolean saveEmploymentHistory(Long sso, List<EmployeeHistory> empHistory) {
	String addQuery = this.getSql("addEmpHistoryBySso");
	String deleteQuery = this.getSql("deleteEmpHistoryBySso");
	try{
		getJdbcTemplate().update(deleteQuery, new Object[]{sso});
		for(EmployeeHistory emh : empHistory){
			getJdbcTemplate().update(addQuery, new Object[]{sso, personalInfoService.escapeSpecialCharacters(emh.getBusinessCard()), emh.getCorporateBand(), personalInfoService.escapeSpecialCharacters(emh.getGeBusiness()), personalInfoService.escapeSpecialCharacters(emh.getLocation()), personalInfoService.escapeSpecialCharacters(emh.getJobFunction()), personalInfoService.escapeSpecialCharacters(emh.getManager()), personalInfoService.escapeSpecialCharacters(emh.getDescription()), emh.getFromDate(), emh.getToDate()});
		}
		logger.debug("Employment History data updated sucessfully");
	}catch (EmptyResultDataAccessException eex) {
		logger.debug("Employment History data could not be updated");
		return false;
	}catch(Exception e){
		logger.debug("Employment History data could not be updated");
		return false;
	}
	return true;
	}

	@PreAuthorize("hasPermission(#sso, 'ResumeWorkHistoryEdit', read)")
	public boolean saveCurrentJob(Long sso, EmployeeHistory currentJob) {
		// TODO Auto-generated method stub
		String updateQuery = "";
		try{
			if(currentJob.getDescription()!=null || currentJob.getFromDate()!= null){
				if(currentJob.getFromDate()!= null){
					updateQuery = this.getSql("updateCurrentJobEditFlag");
					getJdbcTemplate().update(updateQuery, new Object[]{personalInfoService.escapeSpecialCharacters(currentJob.getDescription()), currentJob.getFromDate(), sso});
				}else{
					updateQuery = this.getSql("updateCurrentJob");
					getJdbcTemplate().update(updateQuery, new Object[]{personalInfoService.escapeSpecialCharacters(currentJob.getDescription()), sso});
				}
			}
			logger.debug("Current Job data updated sucessfully");
			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Current Job data could not be updated");
			return false;
		}catch(Exception e){
			logger.debug("Current Job data could not be updated");
			return false;
		}	
		return true;
	}
	
	//@PreAuthorize("hasPermission(#sso, 'ResumeWorkMobilityView', read)")
	public WorkMobility getWorkMobility(Long sso) {
		WorkMobility workMobility = new WorkMobility();
		try{					
			workMobility = getJdbcTemplate().queryForObject(this.getSql("getWorkMobility"), new Object[]{sso}, new WorkMobilityMapper());
			logger.debug("Work Mobility data was loaded susscesfully");	
		
		}catch (EmptyResultDataAccessException eex) {		
			logger.debug("Work Mobility Not Found");				
		}
		return workMobility;
	}

	//@PreAuthorize("hasPermission(#sso, 'ResumeWorkMobilityView', read)")
	public List<String> getSelectedCountries(Long sso) {
		List<String> selectedCountryList = new ArrayList<String>();
		try{		
			selectedCountryList = getJdbcTemplate().queryForList(this.getSql("getRelocationSelectedCountries"), new Object[]{sso}, String.class);
			logger.debug("Work Mobility data was loaded susscesfully");	
		
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Work Mobility Not Found");		
		}		
		return selectedCountryList;
	}

	@PreAuthorize("hasPermission(#sso, 'ResumeWorkMobilityEdit', read)")
	public boolean setWorkMobility(Long sso, WorkMobility workMobility) {
		boolean success = true;
		String geoType = "";
		try{							
			getJdbcTemplate().update(this.getSql("setWorkMobility"), sso, workMobility.getRelocateWithin(), workMobility.getRelocateOutside());
			getJdbcTemplate().update(this.getSql("deleteRelocationSelectedCountries"),new Object[]{sso});
			if(workMobility.getSelectedCountryList()!=null && !workMobility.getSelectedCountryList().isEmpty() && workMobility.getRelocateOutside().equalsIgnoreCase("Y")){
				for(String country : workMobility.getSelectedCountryList()){			
					geoType="Country";
					getJdbcTemplate().update(this.getSql("setRelocationSelectedCountries"),new Object[]{sso,geoType,country});
				}
			}
			logger.debug("Relocation Countries data updated sucessfully");	
		}
		catch (Exception e) {
			success = false;
			logger.debug("Work Mobility data  not saved for: "+sso);
			logger.debug("Work Relocation Countries data  not saved for: "+sso);
		}
		return success;	
	}
	
	public boolean updateEmpistoryAlertFlagBySSO(Long sso) {
		boolean success = true;
		try{							
			getJdbcTemplate().update(this.getSql("updateEmpistoryAlertFlagBySSO"), sso);
			
			logger.debug("Work History Alert Flag updated successfully");
		}
		catch (Exception e) {
			success = false;
			logger.debug("Work History Alert Flag update failed: "+sso);
		}
		return success;	
	}

	@Override
	public boolean setCareerOpportunity(Long sso, String careerOppFlag) {
			try{	
				getJdbcTemplate().update(this.getSql("setCareerOpportunity"),new Object[]{sso,careerOppFlag});
				logger.debug("Career Opportunity data updated sucessfully");
			}catch(Exception e){
				logger.debug("Career Opportunity data update failed");
				return false;
			}	
			return true ;
		}

	//@PreAuthorize("hasPermission(#sso, 'ResumeCareerAspirationView', read)")
	public String getCareerOpportunity(Long sso) {
		String query = this.getSql("getCareerOpportunity");
		String careerOpportunity ="";
		try{
			careerOpportunity = getJdbcTemplate().queryForObject(query, new Object[]{sso},String.class);
			logger.debug("Logged User Prof. summary  data was loaded susscesfully");			
			}catch (EmptyResultDataAccessException eex) {
				careerOpportunity="";
			logger.debug("Prof. summary data not found for "+sso);
		}
		return careerOpportunity;
	}
}
