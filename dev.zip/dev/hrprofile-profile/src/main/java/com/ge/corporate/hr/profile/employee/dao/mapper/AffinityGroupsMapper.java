package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.AffinityGroups;

public class AffinityGroupsMapper implements RowMapper<AffinityGroups> {

	public static final String DATA_SSO = "sso";
	public static final String DATA_GROUP_TYPE= "group_type";
	public static final String DATA_GROUP_NAME= "group_name";
	public static final String DATA_POSITION= "position";
	public static final String DATE_JOINED= "date_joined";

	@Override
	public AffinityGroups mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		AffinityGroups externalGroup = new AffinityGroups();
		externalGroup.setSso(rs.getLong(DATA_SSO));
		externalGroup.setPosition(rs.getString(DATA_POSITION));
		externalGroup.setGroupType(rs.getString(DATA_GROUP_TYPE));
		externalGroup.setGroupName(rs.getString(DATA_GROUP_NAME));
		externalGroup.setDateJoined(rs.getShort(DATE_JOINED));
		
		return externalGroup;
	}
	


}
