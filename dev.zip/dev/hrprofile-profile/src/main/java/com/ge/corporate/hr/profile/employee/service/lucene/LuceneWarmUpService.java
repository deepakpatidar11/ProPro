package com.ge.corporate.hr.profile.employee.service.lucene;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.core.KeywordAnalyzer;
import org.apache.lucene.analysis.miscellaneous.PerFieldAnalyzerWrapper;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.facet.taxonomy.directory.DirectoryTaxonomyWriter;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.LockObtainFailedException;
import org.apache.lucene.util.Version;
import org.springframework.mail.MailException;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dao.PropertyDao;
import com.ge.corporate.hr.profile.employee.dto.LanguageProficiencyDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneEducationDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneEmpHistoryDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneLeadershipDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneSearchCompDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneTrainingDto;
import com.ge.corporate.hr.profile.employee.dto.WarmupStatus;
import com.ge.corporate.hr.profile.employee.model.AffinityGroups;
import com.ge.corporate.hr.profile.employee.model.CustomerandSuppliers;
import com.ge.corporate.hr.profile.employee.model.EmployeeExpertise;
import com.ge.corporate.hr.profile.employee.model.Expertise;
import com.ge.corporate.hr.profile.employee.model.IntiativesandProject;
import com.ge.corporate.hr.profile.employee.model.LPBridgeAssignment;
import com.ge.corporate.hr.profile.employee.model.LanguageProficiency;
import com.ge.corporate.hr.profile.employee.model.Mentoring;
import com.ge.corporate.hr.profile.employee.model.WorkMobility;
import com.ge.corporate.hr.profile.employee.model.WorkMobilityCountry;
import com.ge.corporate.hr.profile.employee.service.SearchService;

@Service("luceneWarmUpService")
public class LuceneWarmUpService {

	// customized as per requirement

	private static Logger LOG = Logger.getLogger(LuceneWarmUpService.class);

	@Resource(name = "searchService")
	private SearchService searchService;

	@Resource(name = "searchIndexService")
	private SearchLuceneService searchIndexService;
	
	@Resource(name="mailSender")	
	private MailSender mailSender;
	
	@Resource(name="templateMessageLuceneIndex")
    private SimpleMailMessage templateMessage;
	
	@Resource(name = "propertyDao")
	private PropertyDao propertyDao;

	private String mailTo;

	private Version ver = Version.LUCENE_5_1_0;
	private Directory onlineDirectory = null;
	private Directory offlineDirectory = null;
	private Directory workingDirectory = null;
	private Directory onlineTaxoDirectory = null;
	private Directory offlineTaxoDirectory = null;
	private Directory workingTaxoDirectory = null;
	private Directory onlineExpDirectory = null;
	private Directory offlineExpDirectory = null;
	private Directory workingExpDirectory = null;
	
	private Analyzer analyzer = null;
	private File onlineFile = null;
	private File offlineFile = null;
	private File onlineTaxoFile = null;
	private File offlineTaxoFile = null;
	private File onlineExpFile = null;

	private IndexWriter writer;
	private IndexWriter copyWriter;
	private DirectoryTaxonomyWriter taxo;
	private DirectoryTaxonomyWriter copyTaxo;

	private long commitInterval;
	private ThreadPoolTaskExecutor taskExecutor;

	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	public long getCommitInterval() {
		return commitInterval;
	}

	public void setCommitInterval(long commitInterval) {
		this.commitInterval = commitInterval;
	}

	private Map<String, WarmupStatus> status = new LinkedHashMap<String, WarmupStatus>();
	private Map<String, Analyzer> analyzerPerField = new HashMap<String, Analyzer>();

	public LuceneWarmUpService() {
		try {
			this.onlineFile = new File(System.getProperty("geware.dir.shared")
					+ "/" + "HRP_Index_File" + "/" + "onlineFile");
			this.offlineFile = new File(System.getProperty("geware.dir.shared")
					+ "/" + "HRP_Index_File" + "/" + "offlineFile");
			this.onlineExpFile = new File(System.getProperty("geware.dir.shared")
					+ "/" + "HRP_Index_File" + "/" + "onlineExpFile");
			LOG.info("AbsolutePath:" + onlineFile.getAbsolutePath());
			LOG.info("AbsolutePath:" + offlineFile.getAbsolutePath());

			this.onlineTaxoFile = new File(
					System.getProperty("geware.dir.shared") + "/"
							+ "HRP_Index_File" + "/" + "onlineTaxoFile");
			this.offlineTaxoFile = new File(
					System.getProperty("geware.dir.shared") + "/"
							+ "HRP_Index_File" + "/" + "offlineTaxoFile");
			LOG.info("Taxo - AbsolutePath:" + onlineFile.getAbsolutePath());
			LOG.info("Taxo - AbsolutePath:" + offlineFile.getAbsolutePath());

			this.onlineDirectory = FSDirectory.open(Paths.get(System
					.getProperty("geware.dir.shared")
					+ "/"
					+ "HRP_Index_File"
					+ "/" + "onlineFile"));
			this.offlineDirectory = FSDirectory.open(Paths.get(System
					.getProperty("geware.dir.shared")
					+ "/"
					+ "HRP_Index_File"
					+ "/" + "offlineFile"));
			this.onlineTaxoDirectory = FSDirectory.open(Paths.get(System
					.getProperty("geware.dir.shared")
					+ "/"
					+ "HRP_Index_File"
					+ "/" + "onlineTaxoFile"));
			this.offlineTaxoDirectory = FSDirectory.open(Paths.get(System
					.getProperty("geware.dir.shared")
					+ "/"
					+ "HRP_Index_File"
					+ "/" + "offlineTaxoFile"));
			this.onlineExpDirectory = FSDirectory.open(Paths.get(System
					.getProperty("geware.dir.shared")
					+ "/"
					+ "HRP_Index_File"
					+ "/" + "onlineExpFile"));
			this.offlineExpDirectory = FSDirectory.open(Paths.get(System
					.getProperty("geware.dir.shared")
					+ "/"
					+ "HRP_Index_File"
					+ "/" + "offlineExpFile"));
			analyzerPerField.put("ifg", new KeywordAnalyzer());
			analyzerPerField.put("business", new KeywordAnalyzer());
			analyzerPerField.put("subBusiness", new KeywordAnalyzer());
			analyzerPerField.put("jobFunction", new KeywordAnalyzer());
			analyzerPerField.put("jobFamily", new KeywordAnalyzer());
			analyzerPerField.put("region", new KeywordAnalyzer());
			analyzerPerField.put("country", new KeywordAnalyzer());
			analyzerPerField.put("band", new KeywordAnalyzer());
			analyzerPerField.put("subBusiness", new KeywordAnalyzer());
			this.analyzer = new PerFieldAnalyzerWrapper(new StandardAnalyzer(),
					analyzerPerField);
			// this.analyzer = new StandardAnalyzer(this.ver);

			if (this.onlineFile.exists()
					&& DirectoryReader.indexExists(onlineDirectory)) {
				LOG.info("Online index exists - building Offline directory");
				this.workingDirectory = offlineDirectory;
				this.workingTaxoDirectory = offlineTaxoDirectory;
			} else {
				LOG.info("Online index does not exist - building Online directory");
				this.workingDirectory = onlineDirectory;
				this.workingTaxoDirectory = onlineTaxoDirectory;
			}

			if (this.onlineExpFile.exists()
					&& DirectoryReader.indexExists(onlineExpDirectory)) {
				LOG.info("Online expertise index exists - building Offline directory");
				this.workingExpDirectory = offlineExpDirectory;
			} else {
				LOG.info("Online expertise index does not exist - building Online directory");
				this.workingExpDirectory = onlineExpDirectory;
			}
		} catch (CorruptIndexException e) {
			throw new RuntimeException(e);
		} catch (LockObtainFailedException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public IndexWriterConfig getWriterConfig() {
		IndexWriterConfig writerConfig = new IndexWriterConfig(this.analyzer);
		writerConfig.setOpenMode(OpenMode.CREATE);
		writerConfig.setRAMBufferSizeMB(Double.parseDouble(propertyDao.getByKey("search.ram.buffer")));
		return writerConfig;
	}

	public WarmupStatus startLuceneWarmupJob() {
		WarmupStatus s = new WarmupStatus();
		String hostname = "";
		try {	
			hostname = InetAddress.getLocalHost().getHostName();
			sendNotificationMail("Host: "+ InetAddress.getLocalHost().getHostName() +"\n"+
					 "Status: Starting Lucene Index");
			writer = new IndexWriter(this.workingDirectory, getWriterConfig());
			taxo = new DirectoryTaxonomyWriter(this.workingTaxoDirectory, OpenMode.CREATE);
			status.put(s.getId(), s);
			LOG.info("Lucene Index warmup job StartTime: " + s.getStartTime());

			SearchIndexTask siw = new SearchIndexTask(s, writer, taxo,
					null, null, null, null, null, null,null,null,null,null,null,null,null);
			SearchIndexCopyTask sic = new SearchIndexCopyTask(s, writer, taxo,
					commitInterval);

			taskExecutor.execute(siw);
			taskExecutor.execute(sic);			
		} catch (CorruptIndexException e) {
			sendNotificationMail("Host: "+ hostname +"\n"+
					 "Status: Lucene Index Failed due to Corrupt Index.");
			LOG.info("CorruptIndexException:" + e.getMessage());
			throw new RuntimeException(e);
		} catch (LockObtainFailedException e) {
			sendNotificationMail("Host: "+ hostname +"\n"+
					 "Status: Lucene Index Failed: Can't start Lucene warmup - Other warmup job is writing indexes.");
			LOG.warn(String
					.format("Can't start Lucene warmup for id:%s - Other warmup job is writing indexes",
							s.getId()));
			s.setRunning(false);
		} catch (IOException e) {
			sendNotificationMail("Host: "+ hostname +"\n"+
					 "Status: Lucene Index Failed due to IO Exception");
			throw new RuntimeException(e);
		}
		return s;
	}

	public WarmupStatus startLuceneExpertiseJob() {
		WarmupStatus s = new WarmupStatus();
		String hostname = "";
		try {	
			hostname = InetAddress.getLocalHost().getHostName();
			sendNotificationMail("Host: "+ InetAddress.getLocalHost().getHostName() +"\n"+
					 				"Status: Starting Expertise Index");
			writer = new IndexWriter(this.workingExpDirectory, getWriterConfig());
			status.put(s.getId(), s);
			LOG.info("Expertise Index job StartTime: " + s.getStartTime());

			ExpertiseIndexTask eit = new ExpertiseIndexTask(s, writer);
			ExpertiseIndexCopyTask eic = new ExpertiseIndexCopyTask(s, writer, commitInterval);
			
			taskExecutor.execute(eit);
			taskExecutor.execute(eic);
			
		} catch (CorruptIndexException e) {
			sendNotificationMail("Host: "+ hostname +"\nStatus: Expertise Index Failed due to Corrupt Index.");
			LOG.info("ExpertiseCorruptIndexException:" + e.getMessage());
			throw new RuntimeException(e);
		} catch (LockObtainFailedException e) {
			sendNotificationMail("Host: "+ hostname +"\n"+
					 "Status: Expertise Index Failed: Can't start Expertise index job - Other job is writing indexes.");
			LOG.warn(String
					.format("Can't start Expertise index job for id:%s - Other job is writing indexes",	s.getId()));
			s.setRunning(false);
		} catch (IOException e) {
			sendNotificationMail("Host: "+ hostname +"\nStatus: Expertise Index Failed due to IO Exception");
			throw new RuntimeException(e);
		}
		return s;
	}
	
	public Collection<WarmupStatus> getSearchIndexWarmupJobs() {
		return this.status.values();
	}

	public WarmupStatus getSearchIndexWarmupStatus(String id) {
		return status.get(id);
	}

	public void stopSearchIndexWarmupJob(String id) {
		WarmupStatus s = this.status.get(id);
		if (s != null && s.isRunning()) {
			s.setRunning(false);
			onDestroy();
		}
	}

	@PreDestroy
	protected void onDestroy() {
		LOG.info("calling destroy - to close writers (Lucene Search)");
		try {
			if (IndexWriter.isLocked(workingDirectory) && writer != null) {
				writer.close();
			}
			if (IndexWriter.isLocked(onlineDirectory) && copyWriter != null) {
				copyWriter.close();
			}
			if (IndexWriter.isLocked(onlineDirectory)
					&& copyWriter != null
					|| (IndexWriter.isLocked(onlineTaxoDirectory) && copyWriter != null)) {
				copyWriter.close();
			}
		} catch (CorruptIndexException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public List<String> getDirDetails() {
		List<String> rval = new ArrayList<String>();
		long onlineFileSize = 0;
		long offlineFileSize = 0;
		long onlineTaxoFileSize = 0;
		long offlineTaxoFileSize = 0;
		long getMB = 1024 * 1024;

		try {
			rval.add("Online Directory Files:");
			for (String file : onlineDirectory.listAll()) {
				rval.add(file);
				onlineFileSize += onlineDirectory.fileLength(file);
			}
			rval.add("Total Size in MB:" + onlineFileSize / getMB);
			rval.add("Offline Directory Files:");
			for (String file : offlineDirectory.listAll()) {
				rval.add(file);
				offlineFileSize += offlineDirectory.fileLength(file);
			}
			rval.add("Total Size in MB:" + offlineFileSize / getMB);

			rval.add("OnlineTaxo Directory Files:");
			for (String file : onlineTaxoDirectory.listAll()) {
				rval.add(file);
				onlineTaxoFileSize += onlineTaxoDirectory.fileLength(file);
			}
			rval.add("Total Size in MB:" + onlineTaxoFileSize / getMB);
			rval.add("OfflineTaxo Directory Files:");
			for (String file : offlineTaxoDirectory.listAll()) {
				rval.add(file);
				offlineTaxoFileSize += offlineTaxoDirectory.fileLength(file);
			}
			rval.add("Total Size in MB:" + offlineTaxoFileSize / getMB);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return rval;
	}

	class SearchIndexTask extends Thread {

		private WarmupStatus warmupStatus;
		private IndexWriter writer;
		private DirectoryTaxonomyWriter taxo;
		private List<LuceneEducationDto> eduList;
		private List<LuceneLeadershipDto> prgList;
		private List<LuceneTrainingDto> trngList;
		private List<LuceneEmpHistoryDto> emhList;
		private List<LuceneSearchCompDto> empList;
		private List<IntiativesandProject> projectList;
		private List<CustomerandSuppliers> csList;
		private List<LanguageProficiency> lpList;
		private List<AffinityGroups> eaList;
		private List<WorkMobilityCountry> wmList;
		private List<LPBridgeAssignment> lpBridgeList;
		private List<EmployeeExpertise> expertiseList;
		private List<Mentoring> interestList;

		public SearchIndexTask(WarmupStatus warmupStatus,
				IndexWriter writer, DirectoryTaxonomyWriter taxo,
				List<LuceneSearchCompDto> empList,
				List<LuceneEducationDto> eduList,
				List<LuceneLeadershipDto> prgList,
				List<LuceneTrainingDto> trngList,
				List<LuceneEmpHistoryDto> emhList,
				List<IntiativesandProject> projectList,
				List<CustomerandSuppliers> csList,
				List<LanguageProficiency> lpList,
				List<AffinityGroups> eaList, List<WorkMobilityCountry> wmList, List<LPBridgeAssignment> lpBridgeList,
				List<EmployeeExpertise> expertiseList, List<Mentoring> interestList) {
			super();
			this.warmupStatus = warmupStatus;
			this.warmupStatus.incrementRequestCount();
			this.writer = writer;
			this.taxo = taxo;
			this.eduList = eduList;
			this.emhList = emhList;
			this.prgList = prgList;
			this.trngList = trngList;
			this.empList = empList;
			this.projectList = projectList;
			this.csList = csList;
			this.lpList = lpList;
			this.eaList = eaList;	
			this.wmList = wmList;
			this.lpBridgeList = lpBridgeList;
			this.expertiseList = expertiseList;
			this.interestList = interestList;
		}

		public void run() {
			if (warmupStatus.isRunning()) {
				Map<Long, List<LuceneEducationDto>> eduMap = null;
				Map<Long, List<LuceneLeadershipDto>> prgMap = null;
				Map<Long, List<LuceneTrainingDto>> trngMap = null;
				Map<Long, List<LuceneEmpHistoryDto>> emhMap = null;
				Map<Long, List<IntiativesandProject>> projectMap = null;
				Map<Long, List<CustomerandSuppliers>> csMap = null;
				Map<Long, List<LanguageProficiency>> lpMap = null;
				Map<Long, List<AffinityGroups>> eaMap = null;
				Map<Long, List<WorkMobilityCountry>> wmMap = null;
				Map<Long, List<LPBridgeAssignment>> lpBridgeMap = null;
				Map<Long, List<EmployeeExpertise>> expertiseMap = null;
				Map<Long, List<Mentoring>> interestMap = null;
				List<LuceneSearchCompDto> empList = null;
				List<Long> ssoList = new ArrayList<Long>();
				try {
						ssoList = searchService.getAllSso();
						LOG.info("Employee Count:" + ssoList.size());
						empList = searchService.loadEmployeeService();
						eduMap = searchService.getEducationData();
						emhMap = searchService.getWorkHistoryData();
						trngMap = searchService.getTrainingData();
						prgMap = searchService.getLeadershipData();
						projectMap =searchService.getInitiativeProjectData();
						csMap = searchService.getCustomersAndSuppliersData();
						lpMap = searchService.getLanguagesData();
						eaMap = searchService.getExternalAffiliationsData();
						wmMap = searchService.getWorkMobilityData();
						lpBridgeMap = searchService.getLPBridgeData();
						expertiseMap = searchService.getEmpExpertiseData();
						interestMap = searchService.getEmpMentoringInterestData();
						if (empList != null && !empList.isEmpty()) {
							for (LuceneSearchCompDto searchDto : empList) {
								prgList = prgMap.get(searchDto.getSso());
								eduList = eduMap.get(searchDto.getSso());
								emhList = emhMap.get(searchDto.getSso());
								trngList = trngMap.get(searchDto.getSso());
								projectList = projectMap.get(searchDto.getSso());
								csList = csMap.get(searchDto.getSso());
								lpList = lpMap.get(searchDto.getSso());
								eaList = eaMap.get(searchDto.getSso());
								wmList = wmMap.get(searchDto.getSso());
								lpBridgeList = lpBridgeMap.get(searchDto.getSso());
								expertiseList = expertiseMap.get(searchDto.getSso());
								interestList = interestMap.get(searchDto.getSso());
								searchIndexService.index(searchDto, prgList, emhList, eduList, trngList, projectList,
										csList, lpList, eaList, wmList, lpBridgeList, expertiseList, interestList,
										writer, taxo);	
								prgMap.get(prgList);
								eduMap.get(eduList);
								emhMap.get(emhList);
								trngMap.get(trngList);
								projectMap.get(projectList);
								csMap.get(csList);
								lpMap.get(lpList);
								eaMap.get(eaList);
								wmMap.get(wmList);
								this.warmupStatus.incrementSuccessCount();
								// }
							}
						}
						sendNotificationMail("Host: "+ InetAddress.getLocalHost().getHostName() +"\n"+
								 "Status: Bulk Index for Employee Data Completed"+"\n"+
								 "Total Employees Indexed: " + ssoList.size());
						LOG.info("Bulk Index for employee data successful!");
						warmupStatus.setAllSsoIndexed(true);
				} catch (Throwable t) {
					this.warmupStatus.incrementFailureCount();
					warmupStatus.addToFailedBulkList("Advanced Search");
					LOG.info("Failure in loading BulkIndex");
					LOG.warn(t.getMessage(), t);
					warmupStatus.setRunning(false);
				}
			}
		}		
	}

	class SearchIndexCopyTask extends Thread {

		private IndexWriter writer;
		private long sleepMilliseconds;
		private WarmupStatus status;
		private DirectoryTaxonomyWriter taxo;

		public SearchIndexCopyTask(WarmupStatus status, IndexWriter writer,
				DirectoryTaxonomyWriter taxo, long sleepMilliseconds) {
			super();
			this.status = status;
			this.writer = writer;
			this.taxo = taxo;
			this.sleepMilliseconds = sleepMilliseconds;
		}

		@Override
		public void run() {
			try {
				while (status.isRunning()) {
					writer.commit();
					if (taskExecutor.getThreadPoolExecutor().getQueue().size() == 0
							&& taskExecutor.getThreadPoolExecutor()
									.getActiveCount() == 1
							&& taskExecutor.getThreadPoolExecutor()
									.getCompletedTaskCount() >= 1) {

						LOG.info("Total Employee records Indexed :"
								+ writer.numDocs());
						status.setIndexedRecords(writer.numDocs());

						taxo.close();
						writer.close();
						if (status.isAllSsoIndexed()) {
							if (workingDirectory.equals(offlineDirectory)) {
								copyWriter = new IndexWriter(onlineDirectory,
										getWriterConfig());
								Date startTime = new Date();
								copyWriter.addIndexes(offlineDirectory);
								LOG.info("Total records copied to online :"
										+ copyWriter.numDocs());
								status.setCopiedRecords(copyWriter.numDocs());
								copyWriter.commit();
								copyWriter.close();

								copyWriter = new IndexWriter(
										onlineTaxoDirectory, getWriterConfig());
								copyWriter.addIndexes(offlineTaxoDirectory);
								LOG.info("Total records copied to onlineTaxoDir :"
										+ copyWriter.numDocs());
								copyWriter.commit();
								copyWriter.close();

								Date currentTime = new Date();
								LOG.info("Lucene Index copy runtime in seconds :"
										+ (currentTime.getTime() - startTime
												.getTime()) / 1000L);
								
								sendNotificationMail("Host: "+ InetAddress.getLocalHost().getHostName() +"\n"+
										 "Status: Index copied to online directory"+"\n"+
										 "Total Records Copied: " + status.getCopiedRecords());
								
							} else if (workingDirectory.equals(onlineDirectory)) {
								// Skip copy as building onlineExEmp
								workingDirectory = offlineDirectory;
								workingTaxoDirectory = offlineTaxoDirectory;
							}
						} else {
							LOG.warn("Index not copied as AllSsoIndexed:"
									+ status.isAllSsoIndexed());
						}
						status.setRunning(false);
					} else {
						Thread.sleep(sleepMilliseconds);
					}
				}
			} catch (CorruptIndexException e) {
				throw new RuntimeException(e);
			} catch (IOException e) {
				throw new RuntimeException(e);
			} catch (InterruptedException e) {
				throw new RuntimeException(e);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
	}
	
	class ExpertiseIndexTask extends Thread {

		private WarmupStatus warmupStatus;
		private IndexWriter writer;

		public ExpertiseIndexTask(WarmupStatus warmupStatus, IndexWriter writer) {
			super();
			this.warmupStatus = warmupStatus;
			this.warmupStatus.incrementRequestCount();
			this.writer = writer;
		}

		public void run() {
			if (warmupStatus.isRunning()) {
				try {
						BaseModelCollection<Expertise> expertiseList;
						expertiseList = searchService.getAllExpertise();
						LOG.info("Expertise Count:" + expertiseList.size());
						if (expertiseList != null && !expertiseList.isEmpty()) {
							for (Expertise expertise : expertiseList.getList()) {
								searchIndexService.indexExpertise(expertise, writer);	
								this.warmupStatus.incrementSuccessCount();
							}
						}
						sendNotificationMail("Host: "+ InetAddress.getLocalHost().getHostName() +"\n"+
								 "Status: Index for Expertise Data Completed"+"\n"+
								 "Total Expertise Indexed: " + expertiseList.size());
						LOG.info("Index for Expertise data successful!");
						warmupStatus.setAllExpertiseIndexed(true);
				} catch (Throwable t) {
					this.warmupStatus.incrementFailureCount();
					LOG.info("Failure in loading Expertise Index");
					LOG.warn(t.getMessage(), t);
					warmupStatus.setRunning(false);
				}
			}
		}		
	}
	
	class ExpertiseIndexCopyTask extends Thread {

		private IndexWriter writer;
		private long sleepMilliseconds;
		private WarmupStatus status;

		public ExpertiseIndexCopyTask(WarmupStatus status, IndexWriter writer, long sleepMilliseconds) {
			super();
			this.status = status;
			this.writer = writer;
			this.sleepMilliseconds = sleepMilliseconds;
		}

		@Override
		public void run() {
			try {
				while (status.isRunning()) {
					writer.commit();
					if (taskExecutor.getThreadPoolExecutor().getQueue().size() == 0
							&& taskExecutor.getThreadPoolExecutor()
									.getActiveCount() == 1
							&& taskExecutor.getThreadPoolExecutor()
									.getCompletedTaskCount() >= 1) {

						LOG.info("Total Expertise records Indexed :"+ writer.numDocs());
						status.setIndexedRecords(writer.numDocs());

						writer.close();
						
						if (status.isAllExpertiseIndexed()) {
							if (workingExpDirectory.equals(offlineExpDirectory)) {
								copyWriter = new IndexWriter(onlineExpDirectory, getWriterConfig());
								
								Date startTime = new Date();
								copyWriter.addIndexes(offlineExpDirectory);
								
								LOG.info("Total Expertise records copied to online :"	+ copyWriter.numDocs());
								
								status.setCopiedRecords(copyWriter.numDocs());
								
								copyWriter.commit();
								copyWriter.close();

								Date currentTime = new Date();
								LOG.info("Expertise Index copy runtime in seconds :"
										+ (currentTime.getTime() - startTime.getTime()) / 1000L);
								
								sendNotificationMail("Host: "+ InetAddress.getLocalHost().getHostName() +"\n"+
										 "Status: Expertise Index copied to online directory"+"\n"+
										 "Total Records Copied: " + status.getCopiedRecords());
								
							} else if (workingExpDirectory.equals(onlineExpDirectory)) {
								workingExpDirectory = offlineExpDirectory;
							}
						} else {
							LOG.warn("Expertise Index not copied as AllExpertiseIndexed:"
									+ status.isAllExpertiseIndexed());
						}
						status.setRunning(false);
					} else {
						Thread.sleep(sleepMilliseconds);
					}
				}
			} catch (CorruptIndexException e) {
				throw new RuntimeException(e);
			} catch (IOException e) {
				throw new RuntimeException(e);
			} catch (InterruptedException e) {
				throw new RuntimeException(e);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
	}
	
	public void sendNotificationMail(String acctionMsg){	
		SimpleMailMessage msg = new SimpleMailMessage(this.templateMessage);			
        msg.setTo(mailTo);
        msg.setText(acctionMsg);	            
        try{
            this.mailSender.send(msg);
        }
        catch(MailException ex) {
            System.err.println(ex.getMessage());            
        }
	}
	
	public MailSender getMailSender() {
		return mailSender;
	}

	public void setMailSender(MailSender mailSender) {
		this.mailSender = mailSender;
	}

	public SimpleMailMessage getTemplateMessage() {
		return templateMessage;
	}

	public void setTemplateMessage(SimpleMailMessage templateMessage) {
		this.templateMessage = templateMessage;
	}
	
	public String getMailTo() {
		return mailTo;
	}

	public void setMailTo(String mailTo) {
		this.mailTo = mailTo;
	}
}
