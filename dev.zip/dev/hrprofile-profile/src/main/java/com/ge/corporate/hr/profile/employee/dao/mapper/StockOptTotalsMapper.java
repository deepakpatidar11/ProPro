/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import com.ge.corporate.hr.profile.employee.model.StockOptionTotals;
/**
 * Compensation mapper
 * @author enrique.romero
 *
 */
public class StockOptTotalsMapper implements RowMapper<StockOptionTotals>{
	
	public static final String DATA_NUM_SHARES = "so_num_shares";
	public static final String DATA_EXERCISED = "so_shares_exercised";
	public static final String DATA_TOTAL = "so_total";
	public static final String DATA_SHARES_VESTED = "so_shares_vested";
	public static final String DATA_SHARES_UNVESTED = "so_shares_unvested";
	
	public StockOptionTotals mapRow(ResultSet rs, int rowNum) throws SQLException {		
		StockOptionTotals totals = new StockOptionTotals();		
		totals.setNumShares(rs.getInt(DATA_NUM_SHARES));
		return totals;		
	}
}
