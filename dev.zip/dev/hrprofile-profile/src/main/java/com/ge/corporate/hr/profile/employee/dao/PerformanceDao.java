/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.Performance;
/**
 * Performance DAO Interface
 * @author enrique.romero
 *
 */
public interface PerformanceDao {
	/**
	 * Returns Performance information by sso, this information  belongs to "Performance" Data Group
	 * @param sso Employee SSO
	 * @return Performance model
	 */
	public BaseModelCollection<Performance> getPerformanceBySso(Long sso);
	
	
}
