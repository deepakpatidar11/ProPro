package com.ge.corporate.hr.profile.employee.model;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

public class ContingentManagement extends AbstractBaseModelSupport implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6034095663446178283L;

	@XmlElement(name="workReqId")
	private Long workReqId;
	
	@XmlElement(name="workRedStartDate")
	private Date workReqStartDate;
	
	@XmlElement(name="workReqEndDate")
	private Date workReqEndDate;
	
	@XmlElement(name="workReqName")
	private String workReqName;
	
	@XmlElement(name="workReqStatus")
	private String workReqStatus;

	@XmlElement(name="supplier")
	private String supplier;
	
	@XmlElement(name="workerType")
	private String workerType;
	
	@XmlElement(name="apprvdResources")
	private String apprvdResources;
	
	@XmlElement(name="actlResources")
	private String actlResources;
	
	@XmlElement(name="sso")
	private String sso;
	

	public Long getWorkReqId() {
		return workReqId;
	}

	public void setWorkReqId(Long workReqId) {
		this.workReqId = workReqId;
	}

	public Date getWorkReqStartDate() {
		return workReqStartDate;
	}

	public void setWorkReqStartDate(Date workReqStartDate) {
		this.workReqStartDate = workReqStartDate;
	}

	public Date getWorkReqEndDate() {
		return workReqEndDate;
	}

	public void setWorkReqEndDate(Date workReqEndDate) {
		this.workReqEndDate = workReqEndDate;
	}

	public String getWorkReqName() {
		return workReqName;
	}

	public void setWorkReqName(String workReqName) {
		this.workReqName = workReqName;
	}
	
	public String getWorkReqStatus() {
		return workReqStatus;
	}

	public void setWorkReqStatus(String workReqStatus) {
		this.workReqStatus = workReqStatus;
	}
	
	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public String getWorkerType() {
		return workerType;
	}

	public void setWorkerType(String workerType) {
		this.workerType = workerType;
	}

	public String getApprvdResources() {
		return apprvdResources;
	}

	public void setApprvdResources(String apprvdResources) {
		this.apprvdResources = apprvdResources;
	}

	public String getActlResources() {
		return actlResources;
	}

	public void setActlResources(String actlResources) {
		this.actlResources = actlResources;
	}

	public String getSso() {
		return sso;
	}

	public void setSso(String sso) {
		this.sso = sso;
	}


}
