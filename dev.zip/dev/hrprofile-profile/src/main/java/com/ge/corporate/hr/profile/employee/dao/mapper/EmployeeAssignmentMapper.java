/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.Employee;
import com.ge.corporate.hr.profile.employee.model.EmployeeAssignment;
import com.ge.corporate.hr.profile.employee.model.WorkAssignment;

/**
 * Currenrt Work Assignment mapper
 * @author enrique.romero
 *
 */
public class EmployeeAssignmentMapper implements RowMapper<EmployeeAssignment> {
	
	public static final String DATA_SSO = "SSO";
	public static final String DATA_FIRST_NAME = "EMP_FIRST_NAME";
	public static final String DATA_LAST_NAME = "EMP_LAST_NAME";
	public static final String DATA_PREFERRED_NAME = "EMP_PREFERRED_NAME";
	public static final String DATA_POSITION_TITLE = "WA_POSITION_TITLE";
	public static final String DATA_IFG = "WA_IFG_NAME";
	public static final String DATA_IFG_ID = "WA_IFG_ID";
	public static final String DATA_BUSINESS_SEG = "WA_BUSINESS_SEGMENT_NAME";
	public static final String DATA_BUSINESS_SEG_ID = "WA_BUSINESS_SEGMENT_ID";
	public static final String DATA_SUB_BUSINESS = "WA_SUB_BUSINESS_NAME";
	public static final String DATA_SUB_BUSINESS_ID = "WA_SUB_BUSINESS_ID";
	public static final String DATA_ORGANIZATION = "WA_ORG_NAME";
	public static final String DATA_ORGANIZATION_ID = "WA_ORG_ID";
	public static final String DATA_MANAGER = "WA_MANAGER";
	public static final String DATA_MANAGER_NAME = "WA_MANAGER_NAME";
	public static final String DATA_HR_MANAGER = "WA_HR_MANAGER";
	public static final String DATA_HR_MANAGER_NAME = "WA_HR_MANAGER_NAME";	
	public static final String DATA_LOCAL_HR_MANAGER = "WA_LOCAL_HR_MANAGER";
	public static final String DATA_LOCAL_HR_MANAGER_NAME = "WA_LOCAL_HR_MANAGER_NAME";
	public static final String DATA_EMPLOYEE_TYPE = "WA_EMPLOYEE_TYPE";
	public static final String DATA_JOB_FUNCTION = "AFUNC_LABEL";	
	public static final String DATA_JOB_FAMILY = "WA_JOB_FAMILY";			
	public static final String DATA_ADRESS1 = "WA_ADDRESS1";
	public static final String DATA_CITY = "WA_CITY";
	public static final String DATA_STATE = "WA_STATE";
	public static final String DATA_ZIP = "WA_ZIP";
	public static final String DATA_COUNTRY = "WA_COUNTRY";
	
	public static final String DATA_EMAIL = "EMP_EMAIL";
	public static final String DATA_PHONE = "EMP_WORK_PHONE";
	public static final String DATA_DCOMM = "EMP_DCOMM";
	public static final String DATA_MOBILE = "EMP_MOBILE";
	public static final String DATA_START_DATE = "WA_START_DATE";
	public static final String DATA_END_DATE = "WA_END_DATE";
	
	
	public EmployeeAssignment mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		EmployeeAssignment employee = new EmployeeAssignment();
		//Create and assign internal Elements. 
		Employee emp = new Employee(); 
		employee.setEmployee(emp);
		WorkAssignment wa = new WorkAssignment();
		employee.setWorkAssignment(wa);
		
		//Set Employee Fields
		employee.getEmployee().setSso(rs.getLong(DATA_SSO));
		employee.getEmployee().setFirstName(rs.getString(DATA_FIRST_NAME));
		employee.getEmployee().setLastName(rs.getString(DATA_LAST_NAME));
		employee.getEmployee().setPreferedName(rs.getString(DATA_PREFERRED_NAME));		
		employee.getEmployee().setIfgName(rs.getString(DATA_IFG));
		
		//Set Assignment Fields
		employee.getWorkAssignment().setPositionTitle(rs.getString(DATA_POSITION_TITLE));
		employee.getWorkAssignment().setIfg(rs.getString(DATA_IFG));
		employee.getWorkAssignment().setIfgId(rs.getLong(DATA_IFG_ID));
		employee.getWorkAssignment().setBusinessSegment(rs.getString(DATA_BUSINESS_SEG));
		employee.getWorkAssignment().setBusinessSegmentId(rs.getLong(DATA_BUSINESS_SEG_ID));
		employee.getWorkAssignment().setSubBusiness(rs.getString(DATA_SUB_BUSINESS));	
		employee.getWorkAssignment().setSubBusinessId(rs.getLong(DATA_SUB_BUSINESS_ID));
		employee.getWorkAssignment().setOrg(rs.getString(DATA_ORGANIZATION));
		employee.getWorkAssignment().setOrgId(rs.getLong(DATA_ORGANIZATION_ID));
		employee.getWorkAssignment().setManager(rs.getLong(DATA_MANAGER));
		employee.getWorkAssignment().setManagerName(rs.getString(DATA_MANAGER_NAME));
		employee.getWorkAssignment().setHrManager(rs.getLong(DATA_HR_MANAGER));
		employee.getWorkAssignment().setHrManagerName(rs.getString(DATA_HR_MANAGER_NAME));		
		employee.getWorkAssignment().setLocalHrManager(rs.getLong(DATA_LOCAL_HR_MANAGER));
		employee.getWorkAssignment().setLocalHrManagerName(rs.getString(DATA_LOCAL_HR_MANAGER_NAME));
		employee.getWorkAssignment().setEmployeeType(rs.getString(DATA_EMPLOYEE_TYPE));
		employee.getWorkAssignment().setJobFunction(rs.getString(DATA_JOB_FUNCTION));
		employee.getWorkAssignment().setJobFamily(rs.getString(DATA_JOB_FAMILY));
		employee.getWorkAssignment().setAddress1(rs.getString(DATA_ADRESS1));
		employee.getWorkAssignment().setCity(rs.getString(DATA_CITY));
		employee.getWorkAssignment().setState(rs.getString(DATA_STATE));
		employee.getWorkAssignment().setZip(rs.getString(DATA_ZIP));
		employee.getWorkAssignment().setCountry(rs.getString(DATA_COUNTRY));
		employee.getWorkAssignment().setEmail(rs.getString(DATA_EMAIL));
		employee.getWorkAssignment().setPhone(rs.getString(DATA_PHONE));
		employee.getWorkAssignment().setDcomm(rs.getString(DATA_DCOMM));
		employee.getWorkAssignment().setMobile(rs.getString(DATA_MOBILE));
		
		
		
		return employee;		
	}
}
