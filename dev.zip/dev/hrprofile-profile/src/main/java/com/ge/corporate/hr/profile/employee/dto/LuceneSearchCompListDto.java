/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

import org.apache.lucene.facet.FacetResult;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;


public class LuceneSearchCompListDto extends AbstractBaseDtoSupport{
	
	private static final long serialVersionUID = 3954425810252008717L;

	@XmlElement(name="sortBy")
	private String sortBy;
	
	@XmlElement(name="resultLabel")
	private String resultLabel;
	
	@XmlElement(name="total")
	private int total;
	
	@XmlElement(name="type")
	private String type;

	@XmlElement(name="searchQuery")
	private String searchQuery;
	
	@XmlElement(name="whQuery")
	private String whQuery;
	
	@XmlElement(name="edutrngQuery")
	private String edutrngQuery;
	
	@XmlElement(name="prgQuery")
	private String prgQuery;
	
	private boolean isFuncHR;
	
	@XmlElement(name="luceneSearchList")
	private List<LuceneSearchCompDto> searchList;
	
	@XmlElement(name="facetList")
	private List<FacetResult> facetList;

	public String getResultLabel() {
		return resultLabel;
	}

	public List<FacetResult> getFacetList() {
		return facetList;
	}

	public void setFacetList(List<FacetResult> facetList) {
		this.facetList = facetList;
	}

	public void setResultLabel(String resultLabel) {
		this.resultLabel = resultLabel;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public String getSearchQuery() {
		return searchQuery;
	}

	public String getSortBy() {
		return sortBy;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	public void setSearchQuery(String searchQuery) {
		this.searchQuery = searchQuery;
	}

	public String getWhQuery() {
		return whQuery;
	}

	public void setWhQuery(String whQuery) {
		this.whQuery = whQuery;
	}

	public String getEdutrngQuery() {
		return edutrngQuery;
	}

	public void setEdutrngQuery(String edutrngQuery) {
		this.edutrngQuery = edutrngQuery;
	}

	public String getPrgQuery() {
		return prgQuery;
	}

	public void setPrgQuery(String prgQuery) {
		this.prgQuery = prgQuery;
	}

	public List<LuceneSearchCompDto> getSearchList() {
		return searchList;
	}

	public void setSearchList(List<LuceneSearchCompDto> searchList) {
		this.searchList = searchList;
	}

	public Integer getSize(){
		Integer size = 0;
		if(searchList != null){
			size = 	searchList.size();		
		}
		return size;
	}
	
	public long getId() {
		return 0;
	}

	public boolean isFuncHR() {
		return isFuncHR;
	}

	public void setFuncHR(boolean isFuncHR) {
		this.isFuncHR = isFuncHR;
	}

}
