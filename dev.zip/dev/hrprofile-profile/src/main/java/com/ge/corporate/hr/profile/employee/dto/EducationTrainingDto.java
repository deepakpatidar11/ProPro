/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.CAS;
import com.ge.corporate.hr.profile.employee.model.Certification;
import com.ge.corporate.hr.profile.employee.model.Education;
import com.ge.corporate.hr.profile.employee.model.LanguageProficiency;
import com.ge.corporate.hr.profile.employee.model.Program;
import com.ge.corporate.hr.profile.employee.model.SixSigma;
import com.ge.corporate.hr.profile.employee.model.TrainingHeader;

@XmlRootElement(name="educationTraining")
@XmlAccessorType(XmlAccessType.FIELD)
public class EducationTrainingDto extends AbstractBaseDtoSupport{
	
	private static final long serialVersionUID = -3600530242896336312L;
	
	@XmlElement(name = "sso")
	private Long sso;
	
	private BaseModelCollection<Education> educationList;
	
	@XmlElement(name = "education")
	private List<Education> educationDetailsList;
	
	@XmlElement(name = "languageProficiencyList")
	private BaseModelCollection<LanguageProficiency> languageProficiencyList;
	
	@XmlElement(name = "languageList")
	private List<String> languageList;

	private BaseModelCollection<TrainingHeader> trainingHederList;
	
	private BaseModelCollection<Program> programList;

	@XmlElement(name = "certification")
	private List<Certification> certificationList;
	
	private BaseModelCollection<Certification> certifications;

	@XmlElement(name = "sixSigma")
	private BaseModelCollection<SixSigma> sixSigmaList;

	@XmlElement(name = "CAS")
	private BaseModelCollection<CAS> CASList;

	@XmlElement(name = "optinTrainingList")
	private List<String> optinTrainingList;
	
	@XmlElement(name = "isSelf")
	private boolean isSelf;

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public BaseModelCollection<Education> getEducationList() {
		return educationList;
	}

	public void setEducationList(BaseModelCollection<Education> educationList) {
		this.educationList = educationList;
	}

	public List<Education> getEducationDetailsList() {
		return educationDetailsList;
	}

	public void setEducationDetailsList(List<Education> educationDetailsList) {
		this.educationDetailsList = educationDetailsList;
	}

	public BaseModelCollection<LanguageProficiency> getLanguageProficiencyList() {
		return languageProficiencyList;
	}

	public void setLanguageProficiencyList(BaseModelCollection<LanguageProficiency> languageProficiencyList) {
		this.languageProficiencyList = languageProficiencyList;
	}

	public List<String> getLanguageList() {
		return languageList;
	}

	public void setLanguageList(List<String> languageList) {
		this.languageList = languageList;
	}

	public BaseModelCollection<TrainingHeader> getTrainingHederList() {
		return trainingHederList;
	}

	public void setTrainingHederList(BaseModelCollection<TrainingHeader> trainingHederList) {
		this.trainingHederList = trainingHederList;
	}

	public BaseModelCollection<Program> getProgramList() {
		return programList;
	}

	public void setProgramList(BaseModelCollection<Program> programList) {
		this.programList = programList;
	}

	public List<String> getOptinTrainingList() {
		return optinTrainingList;
	}

	public void setOptinTrainingList(List<String> optinTrainingList) {
		this.optinTrainingList = optinTrainingList;
	}

	public boolean isSelf() {
		return isSelf;
	}

	public void setSelf(boolean isSelf) {
		this.isSelf = isSelf;
	}

	public List<Certification> getCertificationList() {
		return certificationList;
	}

	public void setCertificationList(
			List<Certification> certificationList) {
		this.certificationList = certificationList;
	}

	public BaseModelCollection<Certification> getCertifications() {
		return certifications;
	}

	public void setCertifications(BaseModelCollection<Certification> certifications) {
		this.certifications = certifications;
	}

	public BaseModelCollection<SixSigma> getSixSigmaList() {
		return sixSigmaList;
	}

	public void setSixSigmaList(BaseModelCollection<SixSigma> sixSigmaList) {
		this.sixSigmaList = sixSigmaList;
	}

	public BaseModelCollection<CAS> getCASList() {
		return CASList;
	}

	public void setCASList(BaseModelCollection<CAS> cASList) {
		CASList = cASList;
	}

	public long getId() {
		return sso != null ? sso.longValue() : 0;
	}

}
