package com.ge.corporate.hr.profile.employee.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.security.access.prepost.PreAuthorize;

import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dao.mapper.AffinityGroupsMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.InterestAffiliationMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.MentoringMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.OnlineNetworksMapper;
import com.ge.corporate.hr.profile.employee.dto.InterestAffiliationDto;
import com.ge.corporate.hr.profile.employee.model.AffinityGroups;
import com.ge.corporate.hr.profile.employee.model.Mentoring;
import com.ge.corporate.hr.profile.employee.model.OnlineNetwork;
import com.ge.corporate.hr.profile.employee.service.EmployeeProfileService;

public class InterestAffiliationDaoImpl extends AbstractBaseDaoSupport  implements InterestAffiliationDao{

	@Resource(name = "employeeProfileService")
	private EmployeeProfileService personalInfoService;
	
	//@PreAuthorize("hasPermission(#sso, 'ResumeProfessionalPersonalInterestsView', read)")
	public InterestAffiliationDto getEmployeeInterests(Long sso) {
		InterestAffiliationDto interests = new InterestAffiliationDto();
		String query = this.getSql("getEmployeeInterests");
		try{
			//getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new InterestAffiliationMapper());
			interests = getJdbcTemplate().queryForObject(query, new Object[]{sso}, new InterestAffiliationMapper());
		}catch(Exception e){
			logger.debug("Employee interests data could not found");
		}
		return interests;
	}
	
	@PreAuthorize("hasPermission(#sso, 'ResumeProfessionalPersonalInterestsEdit', read)")
	public boolean saveProfessionalInterests(Long sso, String interests){
		String query = this.getSql("saveEmployeeInterests");
		try{
			getJdbcTemplate().update(query, new Object[]{sso, interests});	
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Professional interests data updated successfully");
		}catch(Exception e){
			logger.debug("Professional interests data could not be updated");
			return false;
		}	
		return true;
	}

	//@PreAuthorize("hasPermission(#sso, 'ResumeMentoringView', read)")
	public Mentoring getMentoringData(Long sso, boolean connectFlag) {
		Mentoring mentoring = new Mentoring();
		String query;
		if(connectFlag) {
			 query = this.getSql("getConnectMentoringData");
		} else {
			query = this.getSql("getMentoringData");
		}
		try{
			//getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new InterestAffiliationMapper());
			mentoring=getJdbcTemplate().queryForObject(query, new Object[]{sso}, new MentoringMapper());
		}catch(Exception e){
			logger.debug("Employee interests data could not found");
		}
		return mentoring;
	}
	
	//@PreAuthorize("hasPermission(#sso, 'ResumeOnlineNetworksView', read)")
	public BaseModelCollection<OnlineNetwork> getEmployeeNetworks(Long sso) {
		BaseModelCollection<OnlineNetwork> networks = new BaseModelCollection<OnlineNetwork>();
		String query = this.getSql("getEmployeeNetworks");
		networks.setList(getJdbcTemplate().query(query,new Object[]{sso},new OnlineNetworksMapper()));
		return networks;
	}
	
	@PreAuthorize("hasPermission(#sso, 'ResumeOnlineNetworksEdit', read)")
	public boolean saveOnlineNetworks(Long sso,
			List<OnlineNetwork> networks){
		String addQuery = this.getSql("addNetworksBySso");
		String deleteQuery = this.getSql("deleteNetworksBySso");
		try{
			getJdbcTemplate().update(deleteQuery, new Object[]{sso});
			for(OnlineNetwork ntwrk : networks){
				getJdbcTemplate().update(addQuery, new Object[]{sso, personalInfoService.escapeSpecialCharacters(ntwrk.getName()), personalInfoService.escapeSpecialCharacters(ntwrk.getAddress())});
			}
			logger.debug("Online Networks updated sucessfully");
			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Online Networks could not be updated");
			return false;
		}catch(Exception e){
			logger.debug("Online Networks could not be updated");
			return false;
		}
		return true;
	}

	//@PreAuthorize("hasPermission(#sso, 'ResumeExternalGroupAffiliationsView', read)")
	public BaseModelCollection<AffinityGroups> getExternalAffiliations(Long sso) {
		BaseModelCollection<AffinityGroups> externalAffiliations = new BaseModelCollection<AffinityGroups>();
		String query = this.getSql("getExternalAffiliations");
		externalAffiliations.setList(getJdbcTemplate().query(query,new Object[]{sso},new AffinityGroupsMapper()));
		return externalAffiliations;
	}

	@PreAuthorize("hasPermission(#sso, 'ResumeExternalGroupAffiliationsEdit', read)")
	public boolean saveExternalAffiliations(Long sso,
			List<AffinityGroups> externalAffiliations) {
		String addQuery = this.getSql("addExternalAffiliations");
		String deleteQuery = this.getSql("deleteExternalAffiliations");
		try{
			getJdbcTemplate().update(deleteQuery, new Object[]{sso});
			for(AffinityGroups af : externalAffiliations){
				getJdbcTemplate().update(addQuery, new Object[]{sso, personalInfoService.escapeSpecialCharacters(af.getGroupType()), personalInfoService.escapeSpecialCharacters(af.getGroupName()), personalInfoService.escapeSpecialCharacters(af.getPosition()), af.getDateJoined()});
			}
			logger.debug("External Affiliations updated sucessfully");
			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("External Affiliations could not be updated");
			return false;
		}catch(Exception e){
			logger.debug("External Affiliations could not be updated");
			return false;
		}
		return true;
	}
//	@PreAuthorize("hasPermission(#sso, 'ResumeMentoringEdit', read)")
	public boolean saveMentoringData(Long sso, Mentoring mentoring){
		String query;
		if(mentoring.getConnectFlag()) {
			query = this.getSql("saveConnectMentoringData");
			saveEmpMentoringInterest(sso, mentoring);
		} else {
			query = this.getSql("saveMentoringData");
		}
		try{
			getJdbcTemplate().update(query, new Object[]{sso, mentoring.getMentor(),mentoring.getMentee(),mentoring.getDescription()});	
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Professional interests data updated successfully");
		}catch(Exception e){
			logger.debug("Professional interests data could not be updated");
			return false;
		}	
		return true;
	}
	/*@Override
	public boolean saveExternalAffiliations(Long sso,
		List<AffinityGroups> externalAffiliations) {
		String query = this.getSql("saveExternalAffiliations");
		try{
			for(AffinityGroups af : externalAffiliations){
				getJdbcTemplate().update(query, sso, af.getGroupType(), af.getGroupName(), af.getPosition(), af.getDateJoined());
			}
			//getJdbcTemplate().queryForLong(query, sso);
			logger.debug("External Affiliations saved successfully");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("External Affiliations could not be updated");
			return false;
		}catch(Exception e){
			logger.debug("External Affiliations could not be updated");
			return false;
		}	
		return true;
	}*/

	private void saveEmpMentoringInterest(Long sso, Mentoring mentoring) {
		String query;
		try{
			query = this.getSql("deleteEmpMentoringInterestBySSO");
			getJdbcTemplate().update(query, new Object[]{sso});
			query = this.getSql("saveEmpMentoringInterestBySSO");
			if(null != mentoring.getMentorInterest() && !mentoring.getMentorInterest().isEmpty()) {
				int[] rowsAdded = getJdbcTemplate().batchUpdate(query, new BatchPreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps, int index) throws SQLException {
						ps.setLong(1, sso);
						ps.setString(2, "MR");
						ps.setInt(3, mentoring.getMentorInterest().get(index));
					}
					
					@Override
					public int getBatchSize() {
						return mentoring.getMentorInterest().size();
					}
				});
			}
			if(null != mentoring.getMenteeInterest() && !mentoring.getMenteeInterest().isEmpty()) {
				int[] rowsAdded = getJdbcTemplate().batchUpdate(query, new BatchPreparedStatementSetter() {
					@Override
					public void setValues(PreparedStatement ps, int index) throws SQLException {
						ps.setLong(1, sso);
						ps.setString(2, "ME");
						ps.setInt(3, mentoring.getMenteeInterest().get(index));
					}
					
					@Override
					public int getBatchSize() {
						return mentoring.getMenteeInterest().size();
					}
				});
			}
		} catch(Exception e){
			logger.debug("employee mentoring interests data could not be updated");
		}
	}

}
