/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import java.util.List;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.BonusSIT;
import com.ge.corporate.hr.profile.employee.model.Compensation;
import com.ge.corporate.hr.profile.employee.model.IncentiveCompensation;
import com.ge.corporate.hr.profile.employee.model.LongTermPerformanceAward;
import com.ge.corporate.hr.profile.employee.model.RestrictedStockOptionTotals;
import com.ge.corporate.hr.profile.employee.model.StockOption;
import com.ge.corporate.hr.profile.employee.model.StockOptionTotals;

/**
 * Compensation DTO
 * @author enrique.romero
 *
 */
	
public class CompensationDto extends AbstractBaseDtoSupport{	
	
	private static final long serialVersionUID = -2684896088396513052L;

	/**
	 * Employee SSO
	 */
	private Long sso;
	
	/**
	 * Compensation StartDate
	 */
	private String startDate;
		
	/**
	 * Compensation Model List - contains compensation history
	 */
	BaseModelCollection<Compensation> compensationList = null;	
	
	/**
	 * List of Growth Values
	 */
	BaseModelCollection<IncentiveCompensation> icList = null;
	
	/**
	 * List of Stock Options
	 */
	BaseModelCollection<StockOption> stockOptList = null;
	
	/**
	 * List of Options Outstanding
	 */
	BaseModelCollection<StockOption> optsOutstdngList = null;

	/**
	 * List of Restricted  Stock Options
	 */
	BaseModelCollection<StockOption> restrictedStockOptList = null;
	
	/**
	 * List of Restricted  Stock Options
	 */
	BaseModelCollection<StockOption> nextVestingOptList = null;
	
	/**
	 * List of Restricted  Stock Options
	 */
	BaseModelCollection<LongTermPerformanceAward> ltPerformanceAwardList = null;
	
	/**
	 * Total Current Compensation
	 */
	Long totalCurrentComp = 0L;
	
	/**
	 * Total Current Compensation Converted to USD
	 */
	Long totalCurrentCompConverted = 0L;
	
	/**
	 * Stock option totals
	 */
	StockOptionTotals stockOptionTotals;
	
	/**
	 * Stock option totals
	 */
	StockOptionTotals optsOutstdngTotals;

	/**
	 * Restricted Stock option totals
	 */
	RestrictedStockOptionTotals restrctdStockOptTotals;
	
	/**
	 * List of Growth Values
	 */
	BaseModelCollection<BonusSIT> bonusList = null;
	

	/**
	 * Initializes DTO with Employee SSO
	 * @param sso
	 */
	public CompensationDto(Long sso){
		this.sso = sso;
	}
	
	public long getId() {		
		return (sso==null)?0:sso.longValue();
	}

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}
	
	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public CompensationDto(){
		
	}
	
	public BaseModelCollection<Compensation> getCompensationList() {
		return compensationList;
	}
	
	public void setCompensationList(BaseModelCollection<Compensation> compensationList) {
		this.compensationList = compensationList;
	}
	public void setCompensationList(List<Compensation> compensationList) {
		this.compensationList.setList( compensationList );
	}
	
	public BaseModelCollection<IncentiveCompensation> getIcList() {
		return icList;
	}
	
	public void setIcList(BaseModelCollection<IncentiveCompensation> icList) {
		this.icList = icList;
	}
	
	public void setIcList(List<IncentiveCompensation> icList) {
		this.icList.setList(icList);
	}
	
	public BaseModelCollection<StockOption> getStockOptList() {
		return stockOptList;
	}

	public void setStockOptList(BaseModelCollection<StockOption> stockOptList) {
		this.stockOptList = stockOptList;
	}

	public BaseModelCollection<StockOption> getRestrictedStockOptList() {
		return restrictedStockOptList;
	}

	public void setRestrictedStockOptList(BaseModelCollection<StockOption> restrictedStockOptList) {
		this.restrictedStockOptList = restrictedStockOptList;
	}
		
	public BaseModelCollection<LongTermPerformanceAward> getLtPerformanceAwardList() {
		return ltPerformanceAwardList;
	}

	public void setLtPerformanceAwardList(
			BaseModelCollection<LongTermPerformanceAward> ltPerformanceAwardList) {
		this.ltPerformanceAwardList = ltPerformanceAwardList;
	}
	
	public Long getTotalCurrentComp() {
		return totalCurrentComp;
	}
	
	public void setTotalCurrentComp(Long totalCurrentComp) {
		this.totalCurrentComp = totalCurrentComp;
	}
	
	public StockOptionTotals getStockOptionTotals() {
		return stockOptionTotals;
	}
	
	public void setStockOptionTotals(StockOptionTotals stockOptionTotals) {
		this.stockOptionTotals = stockOptionTotals;
	}
	
	public RestrictedStockOptionTotals getRestrctdStockOptTotals() {
		return restrctdStockOptTotals;
	}
	
	public void setRestrctdStockOptTotals(
			RestrictedStockOptionTotals restrctdStockOptTotals) {
		this.restrctdStockOptTotals = restrctdStockOptTotals;
	}
	
	public BaseModelCollection<StockOption> getOptsOutstdngList() {
		return optsOutstdngList;
	}

	public void setOptsOutstdngList(
			BaseModelCollection<StockOption> optionsOutstdgsList) {
		this.optsOutstdngList = optionsOutstdgsList;
	}
	
	public StockOptionTotals getOptsOutstdngTotals() {
		return optsOutstdngTotals;
	}

	public void setOptsOutstdngTotals(StockOptionTotals optsOutstdngTotals) {
		this.optsOutstdngTotals = optsOutstdngTotals;
	}

	public BaseModelCollection<StockOption> getNextVestingOptList() {
		return nextVestingOptList;
	}

	public void setNextVestingOptList(
			BaseModelCollection<StockOption> nextVestingOptList) {
		this.nextVestingOptList = nextVestingOptList;
	}

	public Long getTotalCurrentCompConverted() {
		return totalCurrentCompConverted;
	}

	public void setTotalCurrentCompConverted(Long totalCurrentCompConverted) {
		this.totalCurrentCompConverted = totalCurrentCompConverted;
	}
	
	public String getCurrency(){
		
		String currency = null;
		
		//A future dated salary record is any record where the Date is > Sys.Date
		if(compensationList != null && !compensationList.isEmpty()){
			
			for(Compensation comp : compensationList.getList()){
				
				if(!comp.isFutureDate()){
					currency = comp.getCurrency();
					break;
				}
				
			}
			
		}
		
		return currency;
	}

	public BaseModelCollection<BonusSIT> getBonusList() {
		return bonusList;
	}

	public void setBonusList(BaseModelCollection<BonusSIT> bonusList) {
		this.bonusList = bonusList;
	}
	
}
