/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.service;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.Assert;

import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dao.EmployeeHistoryDao;
import com.ge.corporate.hr.profile.employee.dao.SearchDao;
import com.ge.corporate.hr.profile.employee.dao.WorkAssignmentDao;
import com.ge.corporate.hr.profile.employee.dto.EmployeeHistoryDto;
import com.ge.corporate.hr.profile.employee.model.CareerAspiration;
import com.ge.corporate.hr.profile.employee.model.CustomerandSuppliers;
import com.ge.corporate.hr.profile.employee.model.EmployeeHistory;
import com.ge.corporate.hr.profile.employee.model.IntiativesandProject;
import com.ge.corporate.hr.profile.employee.model.ServiceDates;
import com.ge.corporate.hr.profile.employee.model.WorkAssignmentRestricted;
import com.ge.corporate.hr.profile.employee.model.WorkMobility;
import com.ge.corporate.hr.profile.employee.service.cache.ServiceKeyGenerator;

public class EmployeeHistoryServiceImpl implements EmployeeHistoryService {

	private final Log logger = LogFactory.getLog(EmployeeHistoryServiceImpl.class);
	
	@Resource(name="employeeHistoryDao")
	private EmployeeHistoryDao employeeHistoryDao;
	
	@Resource(name = "workAssignmentDao")
	private WorkAssignmentDao assignmentDao;

	@Resource(name = "searchDao")
	private SearchDao searchDao;
	
	/*@Cache(
			nodeName="/profile/employee/service/employeeHistoryService",
			keyGeneratorClass=ServiceKeyGenerator.class,
			cacheName=InfinispanCacheFactory.EMPSERVICECACHE	
	)*/
	public EmployeeHistoryDto getEmployeeHistory(EmployeeHistoryDto employeeHistoryDto) {
		
		Assert.notNull(employeeHistoryDto.getSso(), "Invalid SSO, Unable to load Employee History: ");
		
		BaseModelCollection<EmployeeHistory> employeeHistoryList = null;
		
		if(employeeHistoryDto.getSso() > 0){
			WorkAssignmentRestricted workAssgnRestd = null;
			ServiceDates servDates = null;
			employeeHistoryList = employeeHistoryDao.getEmployeeHistoryBySso(employeeHistoryDto.getSso());
			
			if(employeeHistoryList == null){
				employeeHistoryList = new BaseModelCollection<EmployeeHistory>();
			}
			employeeHistoryDto.setWorkAssignmentHistoryInternal(employeeHistoryList);			
			
			//Get Service Dates
			servDates = assignmentDao.getServiceDatesBySso(employeeHistoryDto.getSso());
			if(servDates == null){
				servDates = new ServiceDates();
			}
			employeeHistoryDto.setServiceDates(servDates);
			
			//Get Month in business
			workAssgnRestd = assignmentDao.getMonthInBusinessBySso(employeeHistoryDto.getSso());
			if(workAssgnRestd == null){
				workAssgnRestd = new WorkAssignmentRestricted();
			}
			employeeHistoryDto.setWorkAssignmentRestrd(workAssgnRestd);
					
			
		}else{
			logger.debug("Invalid SSO, Unable to load Employee History: " + employeeHistoryDto.getSso() );
		}
		
		return employeeHistoryDto;
	}
	
	public EmployeeHistoryDto getEmployeeHistoryRoleSelf(EmployeeHistoryDto employeeHistoryDto) {
		
		Assert.notNull(employeeHistoryDto.getSso(), "Invalid SSO, Unable to load Employee History: ");
		
		BaseModelCollection<EmployeeHistory> employeeHistoryList = null;
		
		if(employeeHistoryDto.getSso() > 0){
			WorkAssignmentRestricted workAssgnRestd = null;
			ServiceDates servDates = null;

			employeeHistoryList = employeeHistoryDao.getEmployeeHistoryForRoleSelf(employeeHistoryDto.getSso());
			
			if(employeeHistoryList == null){
				employeeHistoryList = new BaseModelCollection<EmployeeHistory>();
			}
			employeeHistoryDto.setWorkAssignmentHistoryInternal(employeeHistoryList);			
			
			//Get Service Dates
			servDates = assignmentDao.getServiceDatesBySso(employeeHistoryDto.getSso());
			if(servDates == null){
				servDates = new ServiceDates();
			}
			employeeHistoryDto.setServiceDates(servDates);
			
			//Get Month in business
			workAssgnRestd = assignmentDao.getMonthInBusinessBySso(employeeHistoryDto.getSso());
			if(workAssgnRestd == null){
				workAssgnRestd = new WorkAssignmentRestricted();
			}
			employeeHistoryDto.setWorkAssignmentRestrd(workAssgnRestd);		
			
//				//Get Work Mobility 
//			workMobility=employeeHistoryDao.getWorkMobility(employeeHistoryDto.getSso());
//			if(workMobility == null){
//				workMobility = new WorkMobility();
//			}
//			employeeHistoryDto.setWorkMobility(workMobility);
			
			
		}else{
			logger.debug("Invalid SSO, Unable to load Employee History: " + employeeHistoryDto.getSso() );
		}
		
		return employeeHistoryDto;
	}

	public EmployeeHistoryDto getEmploymentHistory(EmployeeHistoryDto employeeHistoryDto, boolean isSelf, boolean hasDataGroup) {
		
		Assert.notNull(employeeHistoryDto.getSso(), "Invalid SSO, Unable to load Employee History: ");
		
		BaseModelCollection<EmployeeHistory> employeeHistoryList = null;
		
		if(employeeHistoryDto.getSso() > 0){
			WorkAssignmentRestricted workAssgnRestd = null;

			employeeHistoryList = employeeHistoryDao.getEmployeeHistoryOptinBySso(employeeHistoryDto.getSso(), isSelf, hasDataGroup);
						
			if(employeeHistoryList == null){
				employeeHistoryList = new BaseModelCollection<EmployeeHistory>();
			}
			employeeHistoryDto.setWorkAssignmentHistoryInternal(employeeHistoryList);	
			
		
			
			employeeHistoryDto.setWorkAssignmentRestrd(workAssgnRestd);
		
		
		}else{
			logger.debug("Invalid SSO, Unable to load Employee History: " + employeeHistoryDto.getSso() );
		}
		
		return employeeHistoryDto;
	}
	
	public EmployeeHistoryDto getEmploymentHistoryAll(EmployeeHistoryDto employeeHistoryDto, boolean isSharing, boolean isSelf, boolean hasDataGroup) {
		
		Assert.notNull(employeeHistoryDto.getSso(), "Invalid SSO, Unable to load Employee History: ");
		
		BaseModelCollection<EmployeeHistory> employeeHistoryList = null;
		
		if(employeeHistoryDto.getSso() > 0){
			WorkAssignmentRestricted workAssgnRestd = null;
			ServiceDates servDates = null;
			employeeHistoryList = employeeHistoryDao.getEmployeeHistoryAllBySso(employeeHistoryDto.getSso(), isSelf, hasDataGroup);
			
			if(employeeHistoryList == null){
				employeeHistoryList = new BaseModelCollection<EmployeeHistory>();
			}
			employeeHistoryDto.setWorkAssignmentHistoryInternal(employeeHistoryList);			
			employeeHistoryDto.setShared(isSharing);
		}else{
			logger.debug("Invalid SSO, Unable to load Employee History: " + employeeHistoryDto.getSso() );
		}
		
		return employeeHistoryDto;
	}
	
	
	public WorkAssignmentDao getAssignmentDao() {
		return assignmentDao;
	}


	public void setAssignmentDao(WorkAssignmentDao assignmentDao) {
		this.assignmentDao = assignmentDao;
	}
	
	@Override
	public boolean setCareerAspiration(Long sso, String goalCombined) {
	
		return employeeHistoryDao.setCareerAspiration(sso,goalCombined);
	}

	@Override
	public BaseModelCollection<IntiativesandProject>  getIntiativesAndProject(Long sso) {
		return employeeHistoryDao.getIntiativesAndProject(sso);
	}

	@Override
	public void updateIntiativesAndProject(EmployeeHistoryDto employeeHistory) {
		employeeHistoryDao.updateIntiativesAndProject(employeeHistory.getSso(),employeeHistory);
	
	}
	@Override
	public BaseModelCollection<CustomerandSuppliers> getCustomerAndSuppliers(
			EmployeeHistoryDto employeeHistory) {
		return employeeHistoryDao.getCustomerAndSuppiler(employeeHistory.getSso());
		
	}

	@Override
	public void updateCustomerSuppliers(EmployeeHistoryDto employeeHistory) {
		employeeHistoryDao.updateCustomerSuppliers(employeeHistory.getSso(),employeeHistory);

}
	@Override
	public boolean saveEmploymentHistory(List<EmployeeHistory> empHistory, Long sso) {
		// TODO Auto-generated method stub
		return employeeHistoryDao.saveEmploymentHistory(sso, empHistory);
	}

	@Override
	public boolean saveCurrentJob(EmployeeHistory currentJob, Long sso) {
		// TODO Auto-generated method stub
		return employeeHistoryDao.saveCurrentJob(sso, currentJob);
	}
	@Override
	public WorkMobility getWorkMobility(Long sso) {
		WorkMobility workMobility = new WorkMobility();	
		workMobility = employeeHistoryDao.getWorkMobility(sso);
		workMobility.setSelectedCountryList(employeeHistoryDao.getSelectedCountries(sso));
		//workMobility.setCountryList(searchDao.getCountryList());
		return workMobility;
	}
	
	public boolean updateEmpistoryAlertFlagService(Long sso){
		return employeeHistoryDao.updateEmpistoryAlertFlagBySSO(sso);
	}

	@Override
	public boolean setWorkMobility(Long sso, WorkMobility workMobility) {	
		return employeeHistoryDao.setWorkMobility(sso,workMobility) ;
	}
	
	@Override
	public CareerAspiration getCareerAspiration(Long sso) {
		return employeeHistoryDao.getCareerAspiration(sso);
	}

	public EmployeeHistoryDao getEmployeeHistoryDao() {
		return employeeHistoryDao;
	}

	public void setEmployeeHistoryDao(EmployeeHistoryDao employeeHistoryDao) {
		this.employeeHistoryDao = employeeHistoryDao;
	}

	public SearchDao getSearchDao() {
		return searchDao;
	}

	public void setSearchDao(SearchDao searchDao) {
		this.searchDao = searchDao;
	}

	@Override
	public BaseModelCollection<EmployeeHistory> populateEmploymentHistory(
			Long sso) {
		BaseModelCollection<EmployeeHistory> employeeHistoryList = null;
		employeeHistoryList = employeeHistoryDao.getEmployeeHistoryBySso(sso);
		
		if(employeeHistoryList == null){
			employeeHistoryList = new BaseModelCollection<EmployeeHistory>();
		}
		return employeeHistoryList;
	}

	@Override
	public boolean setCareerOpportunity(Long sso, String careerOppFlag) {
		
			return employeeHistoryDao.setCareerOpportunity(sso, careerOppFlag) ;
		}

	@Override
	public String getCareerOpportunity(Long sso) {
		String careerOpportunityFlag = "";
		if (sso > 0) {	
			careerOpportunityFlag=	employeeHistoryDao.getCareerOpportunity(sso);
			if (careerOpportunityFlag == null) {
				careerOpportunityFlag = "";
			}
		} else {
			logger.error("Invalid SSO, SSO = " + sso);
		}
		return careerOpportunityFlag;
	}

	}
	
	
