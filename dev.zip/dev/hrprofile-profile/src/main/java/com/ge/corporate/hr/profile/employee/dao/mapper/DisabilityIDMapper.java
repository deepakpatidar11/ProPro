/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.auth.util.PersonAuthUtil;
import com.ge.corporate.hr.profile.employee.model.EmployeeRestricted;

/**
 * Employee Maper
 * @author enrique.romero
 *
 */
public class DisabilityIDMapper implements RowMapper<EmployeeRestricted>{
	
	public static final String DATA_SSO = "sso";
	public static final String DATA_DISABILITY_ID = "emp_disability_id";
	public static final String DATA_HIDDEN = "(data hidden)";
	
	public EmployeeRestricted mapRow(ResultSet rs, int rowNum) throws SQLException {		
		EmployeeRestricted employeeRestd = new EmployeeRestricted();
		
		employeeRestd.setSso(rs.getLong(DATA_SSO));
		if(PersonAuthUtil.getLoggedSSO()==rs.getLong(DATA_SSO)){
			employeeRestd.setDisabilityId(rs.getString(DATA_DISABILITY_ID));
		}else{
			employeeRestd.setDisabilityId(DATA_HIDDEN);
		}
		
		return employeeRestd;		
	}
	
}
