/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="profile")
@XmlAccessorType(XmlAccessType.FIELD)
public class ContingentEmployee extends AbstractBaseModelSupport implements Serializable {



	private static final long serialVersionUID = 3810535569708142534L;
	// personal info
	@XmlElement(name="sso")
	private Long sso;	
	@XmlElement(name="firstName")
	private String firstName;
	@XmlElement(name="lastName")
	private String lastName;
	@XmlElement(name="fullName")
	private String fullName;
	@XmlElement(name="knownAs")
	private String knownAs;	
	@XmlElement(name="address")
	private String address;
	@XmlElement(name="city")
	private String city;
	@XmlElement(name="state")
	private String state;
	@XmlElement(name="country")
	private String country;
	@XmlElement(name="zip")
	private String zip;
	@XmlElement(name="mobile")
	private String mobile;	
	@XmlElement(name="dcomm")
	private String dcomm;
	@XmlElement(name="phone")
	private String phone;
	@XmlElement(name="email")
	private String email;	
	@XmlElement(name="fax")
	private String fax;
	
	@XmlElement(name="mailstop")
	private String mailstop;
	@XmlElement(name="internalLocation")
	private String internalLocation;	
	
	@XmlElement(name="ssoStartDate")
	private Date ssoStartDate;
	@XmlElement(name="ssoEndDate")
	private Date ssoEndDate;
	
	
	// work assignment info
	@XmlElement(name="personType")
	private String personType;
	@XmlElement(name="title")
	private String title;	
	@XmlElement(name="ifgName")
	private String ifgName;	
	@XmlElement(name="businessSegment")
	private String businessSegment;
	@XmlElement(name="subBusiness")
	private String subBusiness;	
	@XmlElement(name="department")
	private String department;	
	@XmlElement(name="jobFunction")
	private String jobFunction;
	@XmlElement(name="jobFamily")
	private String jobFamily;	
	
	
	
	
	@XmlElement(name="sponsorSSO")
	private Long sponsorSSO;	
	@XmlElement(name="sponsorName")
	private String sponsorName;
	@XmlElement(name="sponsorFirstName")
	private String sponsorFirstName;
	@XmlElement(name="sponsorLastName")
	private String sponsorLastName;
		
	
	
	public void setSponsorName(String sponsorName) {
		this.sponsorName = sponsorName;
	}
	public Long getSso() {
		return sso;
	}	
	public void setSso(Long sso) {
		this.sso = sso;
	}	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getKnownAs() {
		return knownAs;
	}
	public void setKnownAs(String knownAs) {
		this.knownAs = knownAs;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getDcomm() {
		return dcomm;
	}
	public void setDcomm(String dcomm) {
		this.dcomm = dcomm;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}

	public void setIfgName(String ifgName) {
		this.ifgName = ifgName;
	}
	public String getIfgName() {
		return ifgName;
	}
	
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getPersonType() {
		return personType;
	}
	public void setPersonType(String personType) {
		this.personType = personType;
	}
	public String getBusinessSegment() {
		return businessSegment;
	}
	public void setBusinessSegment(String businessSegment) {
		this.businessSegment = businessSegment;
	}
	public String getSubBusiness() {
		return subBusiness;
	}
	public void setSubBusiness(String subBusiness) {
		this.subBusiness = subBusiness;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getJobFunction() {
		return jobFunction;
	}
	public void setJobFunction(String jobFunction) {
		this.jobFunction = jobFunction;
	}
	public String getJobFamily() {
		return jobFamily;
	}
	public void setJobFamily(String jobFamily) {
		this.jobFamily = jobFamily;
	}
	public Long getSponsorSSO() {
		return sponsorSSO;
	}
	public void setSponsorSSO(Long sponsorSSO) {
		this.sponsorSSO = sponsorSSO;
	}
	public Date getSsoStartDate() {
		return ssoStartDate;
	}
	public void setSsoStartDate(Date ssoStartDate) {
		this.ssoStartDate = ssoStartDate;
	}
	public Date getSsoEndDate() {
		return ssoEndDate;
	}
	public void setSsoEndDate(Date ssoEndDate) {
		this.ssoEndDate = ssoEndDate;
	}
	public String getSponsorName() {
		return sponsorName;
	}
	public String getSponsorFirstName() {
		return sponsorFirstName;
	}
	public void setSponsorFirstName(String sponsorFirstName) {
		this.sponsorFirstName = sponsorFirstName;
	}
	public String getSponsorLastName() {
		return sponsorLastName;
	}
	public void setSponsorLastName(String sponsorLastName) {
		this.sponsorLastName = sponsorLastName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	
	public String getMailstop() {
		return mailstop;
	}
	public void setMailstop(String mailstop) {
		this.mailstop = mailstop;
	}
	public String getInternalLocation() {
		return internalLocation;
	}
	public void setInternalLocation(String internalLocation) {
		this.internalLocation = internalLocation;
	}

}