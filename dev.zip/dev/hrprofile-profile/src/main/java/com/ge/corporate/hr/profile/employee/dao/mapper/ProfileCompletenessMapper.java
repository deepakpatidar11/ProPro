package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.ProfileCompleteness;

public class ProfileCompletenessMapper implements RowMapper<ProfileCompleteness>{

	public static final String DATA_PROFSUM = "profsum";
	public static final String DATA_JOB_DESC = "jobdesc";
	public static final String DATA_WORK_HIST = "workhist";	
	public static final String DATA_WORK_HIST_DESC = "workhistdesc";
	public static final String DATA_CAREER = "career";
	public static final String DATA_EDUCATION = "education";
	public static final String DATA_LANGUAGE = "language";
	public static final String DATA_PROFINT = "profint";
	public static final String DATA_NETWORK = "net";
	public static final String DATA_EXPERTISE = "expertise";
	public static final String DATA_MOBILITY = "mobility";
	public static final String DATA_AFF_GROUP = "affgroup";
	public static final String DATA_INIT_PROJ = "initproj";
	public static final String DATA_CUST_SUPP = "cutsupplier";
	public static final String DATA_PROF_CERTI = "profcerti";

	
	@Override
	public ProfileCompleteness mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		ProfileCompleteness profileCompleteness = new ProfileCompleteness();
		profileCompleteness.setCareer(rs.getInt(DATA_CAREER));
		profileCompleteness.setEducation(rs.getInt(DATA_EDUCATION));
		profileCompleteness.setJobDesc(rs.getInt(DATA_JOB_DESC));
		profileCompleteness.setLanguageProf(rs.getInt(DATA_LANGUAGE));
		profileCompleteness.setNetworks(rs.getInt(DATA_NETWORK));
		profileCompleteness.setProfInterests(rs.getInt(DATA_PROFINT));
		profileCompleteness.setProfSummary(rs.getInt(DATA_PROFSUM));
		profileCompleteness.setWorkHistory(rs.getInt(DATA_WORK_HIST));
		profileCompleteness.setWorkHistoryDesc(rs.getInt(DATA_WORK_HIST_DESC));
		profileCompleteness.setWorkMobility(rs.getInt(DATA_MOBILITY));
		profileCompleteness.setAffGroups(rs.getInt(DATA_AFF_GROUP));
		profileCompleteness.setInitProjects(rs.getInt(DATA_INIT_PROJ));
		profileCompleteness.setCustSuppliers(rs.getInt(DATA_CUST_SUPP));
		profileCompleteness.setProfCertification(rs.getInt(DATA_PROF_CERTI));
		profileCompleteness.setExpertise(rs.getInt(DATA_EXPERTISE));
		return profileCompleteness;
	}

}
