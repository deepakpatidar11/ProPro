/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.HomeAddress;

/**
 * Emergency Contact Mapper
 * @author enrique.romero
 *
 */
public class HomeAddressMapper implements RowMapper<HomeAddress>{

	
	public static final String DATA_ADDRESS1 = "emp_home_address1";	
	public static final String DATA_ADDRESS2 = "emp_home_address2";
	public static final String DATA_ADDRESS3 = "emp_home_address3";
	public static final String DATA_CITY = "emp_home_city";
	public static final String DATA_STATE = "emp_home_state";
	public static final String DATA_COUNTRY = "emp_home_country";
	public static final String DATA_ZIP = "emp_home_zip";	
	public static final String DATA_PERSONAL_EMAIL = "emp_personal_email";	
	
	public HomeAddress mapRow(ResultSet rs, int rowNum) throws SQLException {
		HomeAddress homeAddress = new HomeAddress();
		
		homeAddress.setAddress1(rs.getString(DATA_ADDRESS1));
		homeAddress.setAddress2(rs.getString(DATA_ADDRESS2));
		homeAddress.setAddress3(rs.getString(DATA_ADDRESS3));
		homeAddress.setCity(rs.getString(DATA_CITY));		
		homeAddress.setState(rs.getString(DATA_STATE));
		homeAddress.setCountry(rs.getString(DATA_COUNTRY));
		homeAddress.setZip(rs.getString(DATA_ZIP));
		homeAddress.setPersonalEmail(rs.getString(DATA_PERSONAL_EMAIL));
		return homeAddress;		
	}
	
}
