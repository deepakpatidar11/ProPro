package com.ge.corporate.hr.profile.employee.service.lucene;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.core.KeywordAnalyzer;
import org.apache.lucene.analysis.miscellaneous.PerFieldAnalyzerWrapper;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.FieldType;
import org.apache.lucene.document.IntField;
import org.apache.lucene.document.SortedDocValuesField;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.facet.FacetField;
import org.apache.lucene.facet.FacetResult;
import org.apache.lucene.facet.Facets;
import org.apache.lucene.facet.FacetsCollector;
import org.apache.lucene.facet.FacetsConfig;
import org.apache.lucene.facet.sortedset.DefaultSortedSetDocValuesReaderState;
import org.apache.lucene.facet.sortedset.SortedSetDocValuesFacetCounts;
import org.apache.lucene.facet.sortedset.SortedSetDocValuesFacetField;
import org.apache.lucene.facet.sortedset.SortedSetDocValuesReaderState;
import org.apache.lucene.facet.taxonomy.FastTaxonomyFacetCounts;
import org.apache.lucene.facet.taxonomy.TaxonomyReader;
import org.apache.lucene.facet.taxonomy.directory.DirectoryTaxonomyReader;
import org.apache.lucene.facet.taxonomy.directory.DirectoryTaxonomyWriter;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexNotFoundException;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.queryparser.classic.QueryParser.Operator;
import org.apache.lucene.search.BooleanClause.Occur;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.BooleanQuery.TooManyClauses;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.NumericRangeQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.QueryWrapperFilter;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.SortField;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.search.highlight.SimpleHTMLFormatter;
import org.apache.lucene.search.highlight.SimpleSpanFragmenter;
import org.apache.lucene.search.join.BitDocIdSetCachingWrapperFilter;
import org.apache.lucene.search.join.BitDocIdSetFilter;
import org.apache.lucene.search.join.ScoreMode;
import org.apache.lucene.search.join.ToParentBlockJoinQuery;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.BytesRef;
import org.apache.lucene.util.Version;
import org.springframework.stereotype.Service;

import com.ge.corporate.hr.profile.auth.model.DataGroup;
import com.ge.corporate.hr.profile.auth.service.ProfileAuthorityEvaluator;
import com.ge.corporate.hr.profile.auth.util.PersonAuthUtil;
import com.ge.corporate.hr.profile.employee.dao.SearchDao;
import com.ge.corporate.hr.profile.employee.dto.ACLBean;
import com.ge.corporate.hr.profile.employee.dto.AutoCompleteDto;
import com.ge.corporate.hr.profile.employee.dto.ExpertiseDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneEducationDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneEmpHistoryDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneLeadershipDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneSearchCompDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneSearchCompListDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneTrainingDto;
import com.ge.corporate.hr.profile.employee.model.AffinityGroups;
import com.ge.corporate.hr.profile.employee.model.AutoCompleteRowModel;
import com.ge.corporate.hr.profile.employee.model.AutoCompleteViewModel;
import com.ge.corporate.hr.profile.employee.model.CustomerandSuppliers;
import com.ge.corporate.hr.profile.employee.model.EmployeeExpertise;
import com.ge.corporate.hr.profile.employee.model.Expertise;
import com.ge.corporate.hr.profile.employee.model.IntiativesandProject;
import com.ge.corporate.hr.profile.employee.model.LPBridgeAssignment;
import com.ge.corporate.hr.profile.employee.model.LanguageProficiency;
import com.ge.corporate.hr.profile.employee.model.Mentoring;
import com.ge.corporate.hr.profile.employee.model.ShortProfile;
import com.ge.corporate.hr.profile.employee.model.WorkMobilityCountry;

@Service("searchIndexService")
public class SearchLuceneService {

	@Resource(name = "searchDao")
	private SearchDao searchDao;

	@Resource(name = "authorityEvaluator")
	private ProfileAuthorityEvaluator authEvaluator;

	private static Logger LOG = Logger.getLogger(SearchLuceneService.class);
	private Version ver = Version.LUCENE_5_1_0;
	private Directory dir = null;
	private Directory expDir = null;
	private Directory taxoDir = null;
	private Analyzer analyzer = null;
	private File employeeSearchfile = null;
	private BitDocIdSetFilter parentFilter;
	private Map<String, Analyzer> analyzerPerField = new HashMap<String, Analyzer>();
	private FacetsConfig config;

	public SearchLuceneService() {

		employeeSearchfile = new File(System.getProperty("geware.dir.shared")
				+ "/" + "HRP_Index_File" + "/" + "onlineFile");
		LOG.info("AbsolutePath for employees search file:"
				+ employeeSearchfile.getAbsolutePath());
		try {
			this.dir = FSDirectory.open(Paths.get(System
					.getProperty("geware.dir.shared")
					+ "/"
					+ "HRP_Index_File"
					+ "/" + "onlineFile"));
			this.taxoDir = FSDirectory.open(Paths.get(System
					.getProperty("geware.dir.shared")
					+ "/"
					+ "HRP_Index_File"
					+ "/" + "onlineTaxoFile"));
			this.expDir = FSDirectory.open(Paths.get(System
					.getProperty("geware.dir.shared")
					+ "/"
					+ "HRP_Index_File"
					+ "/" + "onlineExpFile"));
		} catch (IOException e) {
			new RuntimeException(e);
		}
		analyzerPerField.put("ifg", new KeywordAnalyzer());
		analyzerPerField.put("business", new KeywordAnalyzer());
		analyzerPerField.put("subBusiness", new KeywordAnalyzer());
		analyzerPerField.put("jobFunction", new KeywordAnalyzer());
		analyzerPerField.put("jobFamily", new KeywordAnalyzer());
		analyzerPerField.put("region", new KeywordAnalyzer());
		analyzerPerField.put("country", new KeywordAnalyzer());
		analyzerPerField.put("band", new KeywordAnalyzer());
		analyzerPerField.put("techDisciplineKW", new KeywordAnalyzer());
		analyzerPerField.put("empReportingIFG", new KeywordAnalyzer());
		analyzerPerField.put("empReportingBusiness", new KeywordAnalyzer());
		/*analyzerPerField.put("languagesShared", new KeywordAnalyzer());
		analyzerPerField.put("languagesAll", new KeywordAnalyzer());*/
		this.analyzer = new PerFieldAnalyzerWrapper(new StandardAnalyzer(),
				analyzerPerField);
		// this.analyzer = new PerFieldAnalyzerWrapper(new StandardAnalyzer());
		this.parentFilter = new BitDocIdSetCachingWrapperFilter(
				new QueryWrapperFilter(
						new TermQuery(new Term("type", "parent"))));
		this.config = new FacetsConfig();
		config.setIndexFieldName("ifg", "facet_ifg");
		config.setIndexFieldName("business", "facet_business");
		config.setIndexFieldName("subBusiness", "facet_subBusiness");
		config.setIndexFieldName("jobFunction", "facet_function");
		config.setIndexFieldName("country", "facet_country");
		config.setIndexFieldName("band", "facet_band");
		config.setIndexFieldName("techDisciplineKW", "facet_techDiscipline");
		config.setIndexFieldName("personType", "facet_personType");
		config.setIndexFieldName("jobFamily", "facet_family");
		//config.setIndexFieldName("empCity", "facet_city");

	}

	public AutoCompleteDto searchIntEmployeeByParam(
			AutoCompleteDto autoCompletDto) {
		List<ShortProfile> list = new ArrayList<ShortProfile>();
		AutoCompleteDto autoCompResDto = new AutoCompleteDto();
		List<AutoCompleteRowModel> rows = new ArrayList<AutoCompleteRowModel>();
		try {
			IndexReader reader = DirectoryReader.open(this.dir);
			IndexSearcher searcher = new IndexSearcher(reader);
			ShortProfile rval = new ShortProfile();
			TopDocs matches = null;

			Query q = createTypeAheadQuery(autoCompletDto.getQuery());
			matches = searcher.search(q, 10, Sort.RELEVANCE);

			for (int i = 0; i < matches.scoreDocs.length && i < 15; i++) {
				rval = typeAheadSearchResults(searcher,
						matches.scoreDocs[i].doc);
				list.add(rval);
			}
			reader.close();
		} catch (TooManyClauses e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

		// Populates List to DTO search
		for (ShortProfile p : list) {
			String label = "";
			if (p.getPreferredName() != null && !p.getPreferredName().isEmpty()
					&& p.getPreferredName() != p.getFirstName()) {
				label += p.getLastName() + ", " + p.getPreferredName() + " ("
						+ p.getIndustry() + ")";
			} else {
				label += p.getLastName() + ", " + p.getFirstName() + " ("
						+ p.getIndustry() + ")";
			}

			rows.add(new AutoCompleteRowModel(label, String.valueOf(p.getSso())));
		}

		if (rows.size() > 0) {
			autoCompResDto.setAutoComplete(new AutoCompleteViewModel(rows));
			LOG.debug("Search function found:" + rows.size() + " rows");
		} else {
			rows.add(new AutoCompleteRowModel("No matches found!", ""));
			autoCompResDto.setAutoComplete(new AutoCompleteViewModel(rows));
			LOG.debug("Search function did not find any match");
		}
		return autoCompResDto;
	}

	public LuceneSearchCompListDto advancedSearch(
			LuceneSearchCompListDto luceneSearchDto, int offset, int count,
			boolean clientSearch) {
		try {
			IndexReader reader = DirectoryReader.open(this.dir);
			IndexSearcher searcher = new IndexSearcher(reader);
			DirectoryTaxonomyReader taxoReader = new DirectoryTaxonomyReader(
					taxoDir);
			FacetsCollector fc = new FacetsCollector();
			Sort sort = new Sort();
			List<FacetResult> facetList = new ArrayList<FacetResult>();

			List<LuceneSearchCompDto> results = new ArrayList<LuceneSearchCompDto>();
			LuceneSearchCompDto rval = new LuceneSearchCompDto();
			BooleanQuery mainQuery = new BooleanQuery();
			TopDocs matches = null;
			boolean hitHighlight = false;

			if ((luceneSearchDto.getSearchQuery() != null && !luceneSearchDto
					.getSearchQuery().isEmpty())
					|| (luceneSearchDto.getPrgQuery() != null && !luceneSearchDto
							.getPrgQuery().isEmpty())) {
				QueryParser parser = new QueryParser("ssoName", this.analyzer);
				parser.setAllowLeadingWildcard(true);
				if (luceneSearchDto.getType() != null
						&& luceneSearchDto.getType().equalsIgnoreCase(
								"TYPEAHEAD")) {
					String searchQry = "";
					if (luceneSearchDto.getSearchQuery().matches(
							"^[A-Za-z0-9'+_.-]+@(.+)$")) {
						searchQry = "\"" + luceneSearchDto.getSearchQuery()
								+ "\"";
					} else {
						searchQry = luceneSearchDto.getSearchQuery();
					}
					Query qry = createTypeAheadQuery(searchQry);
					mainQuery.add(qry, Occur.MUST);
				} else if (luceneSearchDto.getType() != null
						&& luceneSearchDto.getType().equalsIgnoreCase(
								"TYPEAHEAD_FACET")) {
					QueryParser qp = new QueryParser("defaultTypeahead",
							this.analyzer);
					StringBuilder searchQry = new StringBuilder();
					if (luceneSearchDto.getSearchQuery().matches(
							"^[A-Za-z0-9+_.-]+@(.+)$")) {
						searchQry.append("\"")
								.append(luceneSearchDto.getSearchQuery())
								.append("\"");
					} else {
						searchQry.append(luceneSearchDto.getSearchQuery());
					}
					Query qry = parseTypeaheadQuery(searchQry, qp, true);
					mainQuery.add(qry, Occur.MUST);
				} else {
					mainQuery = createMainQuery(
							luceneSearchDto.getSearchQuery(),
							luceneSearchDto.getPrgQuery(), parser, mainQuery);
					hitHighlight = true;
				}
			}

			if (luceneSearchDto.getSortBy() != null
					&& !luceneSearchDto.getSortBy().equalsIgnoreCase(
							"relevance")) {
				if(luceneSearchDto.getSortBy().equalsIgnoreCase(
						"empLastName")){
					sort.setSort(new SortField(luceneSearchDto.getSortBy(),
							SortField.Type.STRING),new SortField("empFirstName",
									SortField.Type.STRING));
					/*sort.setSort(new SortField[] {new SortField("empLastName",
							SortField.Type.STRING),new SortField("empFirstName",
									SortField.Type.STRING)});*/
				}else{
					sort.setSort(new SortField(luceneSearchDto.getSortBy(),
							SortField.Type.STRING));
				}				
				matches = searcher.search(mainQuery, (offset + count), sort);
				facetList = facetsOnly(searcher, taxoReader, mainQuery, fc,
						config);
			} else {
				matches = searcher.search(mainQuery, (offset + count),
						Sort.RELEVANCE);
				facetList = facetsOnly(searcher, taxoReader, mainQuery, fc,
						config);
			}
			for (int i = offset; i < matches.scoreDocs.length
					&& i < (offset + count); i++) {
				if (clientSearch) {
					rval = clientSearchResults(searcher,
							matches.scoreDocs[i].doc);
				} else {
					rval = allSearchResults(searcher, matches.scoreDocs[i].doc);
				}
				if (hitHighlight) {
					rval.setHighlights(getHitHighlights(luceneSearchDto,
							mainQuery, searcher.doc(matches.scoreDocs[i].doc)));
				}
				results.add(rval);
			}
			luceneSearchDto.setSearchList(results);
			luceneSearchDto.setFacetList(facetList);
			luceneSearchDto.setTotal(matches.totalHits);

			// searcher.close();
			reader.close();
			taxoReader.close();
		} catch (IndexNotFoundException e) {
			luceneSearchDto
					.setErrorMesage("Search is not available now. Please try again after some time.");
			LOG.debug("Lucene Index not found");
		} catch (IOException e) {
			luceneSearchDto
					.setErrorMesage("Search is not available now. Please try again after some time.");
			LOG.debug(e.getMessage());
			// throw new RuntimeException(e.getMessage());
		} catch (RuntimeException e) {
			luceneSearchDto
					.setErrorMesage(luceneSearchDto.getResultLabel()
							+ " Your input might contain invalid characters. Please input a valid term and try again.");
			LOG.debug(e.getMessage());
		} catch (Exception e) {
			luceneSearchDto
					.setErrorMesage("Search is not available now. Please try again after some time.");
			LOG.debug(e.getMessage());
		}
		return luceneSearchDto;
	}

	// lucene hit highlighter
	public Map<String, String> getHitHighlights(
			LuceneSearchCompListDto luceneSearchDto, Query query, Document doc)
			throws IOException, InvalidTokenOffsetsException {
		Map<String, String> highlights = new HashMap<String, String>();

		Long sso = Long.parseLong(doc.get("sso"));

		Map<String, DataGroup> dataGroups = authEvaluator
				.getDataGroupsForContextAsMap(PersonAuthUtil.getPrincipal(),
						PersonAuthUtil.getAuthorities(), sso);

		// education & training
		if (dataGroups.get("Education") != null
				&& dataGroups.get("Training") != null) {
			if (luceneSearchDto.getSearchQuery().contains(
					"educationTrainingAll:")
					&& doc.get("educationTrainingAll") != null) {
				QueryScorer scorer = new QueryScorer(query,
						"educationTrainingAll");
				Highlighter highlighter = new Highlighter(
						new SimpleHTMLFormatter(
								"<B style='background-color:yellow'>", "</B>"),
						scorer);
				highlighter.setTextFragmenter(new SimpleSpanFragmenter(scorer,
						150));
				highlights.put("Education & Training", highlighter
						.getBestFragment(analyzer, "educationTrainingAll",
								doc.get("educationTrainingAll")));
			}
		} else {
			if (luceneSearchDto.getSearchQuery().contains(
					"educationTrainingShared:")
					&& doc.get("educationTrainingShared") != null) {
				QueryScorer scorer = new QueryScorer(query,
						"educationTrainingShared");
				Highlighter highlighter = new Highlighter(
						new SimpleHTMLFormatter(
								"<B style='background-color:yellow'>", "</B>"),
						scorer);
				highlighter.setTextFragmenter(new SimpleSpanFragmenter(scorer,
						150));
				highlights.put("Education & Training", highlighter
						.getBestFragment(analyzer, "educationTrainingShared",
								doc.get("educationTrainingShared")));
			}
		}

		// work history
		if (dataGroups.get("ResumeWorkHistoryView") != null) {
			if (luceneSearchDto.getSearchQuery().contains("workHistoryAll:")
					&& doc.get("workHistoryAll") != null) {
				QueryScorer scorer = new QueryScorer(query, "workHistoryAll");
				Highlighter highlighter = new Highlighter(
						new SimpleHTMLFormatter(
								"<B style='background-color:yellow'>", "</B>"),
						scorer);
				highlighter.setTextFragmenter(new SimpleSpanFragmenter(scorer,
						150));
				highlights.put("Work & Career", highlighter.getBestFragment(
						analyzer, "workHistoryAll", doc.get("workHistoryAll")));
			}

		} else {
			if (luceneSearchDto.getSearchQuery().contains("workHistoryShared:")
					&& doc.get("workHistoryShared") != null) {
				QueryScorer scorer = new QueryScorer(query, "workHistoryShared");
				Highlighter highlighter = new Highlighter(
						new SimpleHTMLFormatter(
								"<B style='background-color:yellow'>", "</B>"),
						scorer);
				highlighter.setTextFragmenter(new SimpleSpanFragmenter(scorer,
						150));
				highlights.put("Work & Career", highlighter.getBestFragment(
						analyzer, "workHistoryShared",
						doc.get("workHistoryShared")));
			}
		}

		// professionalSummary
		if (luceneSearchDto.getSearchQuery().contains(
				"professionalSummaryShared:")
				&& doc.get("professionalSummaryShared") != null) {
			QueryScorer scorer = new QueryScorer(query,
					"professionalSummaryShared");
			Highlighter highlighter = new Highlighter(new SimpleHTMLFormatter(
					"<B style='background-color:yellow'>", "</B>"), scorer);
			highlighter
					.setTextFragmenter(new SimpleSpanFragmenter(scorer, 150));
			highlights.put("Professional Summary", highlighter.getBestFragment(
					analyzer, "professionalSummaryShared",
					doc.get("professionalSummaryShared")));
		}

		// career interests
		if (dataGroups.get("ResumeCareerAspirationView") != null) {
			if (luceneSearchDto.getSearchQuery()
					.contains("careerInterestsAll:")
					&& doc.get("careerInterestsAll") != null) {
				QueryScorer scorer = new QueryScorer(query,
						"careerInterestsAll");
				Highlighter highlighter = new Highlighter(
						new SimpleHTMLFormatter(
								"<B style='background-color:yellow'>", "</B>"),
						scorer);
				highlighter.setTextFragmenter(new SimpleSpanFragmenter(scorer,
						150));
				highlights.put("Career Aspirations", highlighter
						.getBestFragment(analyzer, "careerInterestsAll",
								doc.get("careerInterestsAll")));
			}

		} else {
			if (luceneSearchDto.getSearchQuery().contains(
					"careerInterestsShared:")
					&& doc.get("careerInterestsShared") != null) {
				QueryScorer scorer = new QueryScorer(query,
						"careerInterestsShared");
				Highlighter highlighter = new Highlighter(
						new SimpleHTMLFormatter(
								"<B style='background-color:yellow'>", "</B>"),
						scorer);
				highlighter.setTextFragmenter(new SimpleSpanFragmenter(scorer,
						150));
				highlights.put("Career Interests", highlighter.getBestFragment(
						analyzer, "careerInterestsShared",
						doc.get("careerInterestsShared")));
			}
		}

		// Initiatives & Projects
		if (dataGroups.get("ResumeInitiativesProjectsView") != null) {
			if (luceneSearchDto.getSearchQuery().contains("projectsAll:")
					&& doc.get("projectsAll") != null) {
				QueryScorer scorer = new QueryScorer(query, "projectsAll");
				Highlighter highlighter = new Highlighter(
						new SimpleHTMLFormatter(
								"<B style='background-color:yellow'>", "</B>"),
						scorer);
				highlighter.setTextFragmenter(new SimpleSpanFragmenter(scorer,
						150));
				highlights.put("Initiatives & Projects", highlighter
						.getBestFragment(analyzer, "projectsAll",
								doc.get("projectsAll")));
			}

		} else {
			if (luceneSearchDto.getSearchQuery().contains("projectsShared:")
					&& doc.get("projectsShared") != null) {
				QueryScorer scorer = new QueryScorer(query, "projectsShared");
				Highlighter highlighter = new Highlighter(
						new SimpleHTMLFormatter(
								"<B style='background-color:yellow'>", "</B>"),
						scorer);
				highlighter.setTextFragmenter(new SimpleSpanFragmenter(scorer,
						150));
				highlights.put("Initiatives & Projects", highlighter
						.getBestFragment(analyzer, "projectsShared",
								doc.get("projectsShared")));
			}
		}

		// Customers & Suppliers
		if (dataGroups.get("ResumeCustomerSuppliersView") != null) {
			if (luceneSearchDto.getSearchQuery().contains(
					"customersSuppliersAll:")
					&& doc.get("customersSuppliersAll") != null) {
				QueryScorer scorer = new QueryScorer(query,
						"customersSuppliersAll");
				Highlighter highlighter = new Highlighter(
						new SimpleHTMLFormatter(
								"<B style='background-color:yellow'>", "</B>"),
						scorer);
				highlighter.setTextFragmenter(new SimpleSpanFragmenter(scorer,
						150));
				highlights.put("Customers & Suppliers", highlighter
						.getBestFragment(analyzer, "customersSuppliersAll",
								doc.get("customersSuppliersAll")));
			}

		} else {
			if (luceneSearchDto.getSearchQuery().contains(
					"customersSuppliersShared:")
					&& doc.get("customersSuppliersShared") != null) {
				QueryScorer scorer = new QueryScorer(query,
						"customersSuppliersShared");
				Highlighter highlighter = new Highlighter(
						new SimpleHTMLFormatter(
								"<B style='background-color:yellow'>", "</B>"),
						scorer);
				highlighter.setTextFragmenter(new SimpleSpanFragmenter(scorer,
						150));
				highlights.put("Customers & Suppliers", highlighter
						.getBestFragment(analyzer, "customersSuppliersShared",
								doc.get("customersSuppliersShared")));
			}
		}

		// Interests
		if (dataGroups.get("ResumeProfessionalPersonalInterestsView") != null) {
			if (luceneSearchDto.getSearchQuery().contains("interestsAll:")
					&& doc.get("interestsAll") != null) {
				QueryScorer scorer = new QueryScorer(query, "interestsAll");
				Highlighter highlighter = new Highlighter(
						new SimpleHTMLFormatter(
								"<B style='background-color:yellow'>", "</B>"),
						scorer);
				highlighter.setTextFragmenter(new SimpleSpanFragmenter(scorer,
						150));
				highlights.put("Interests", highlighter.getBestFragment(
						analyzer, "interestsAll", doc.get("interestsAll")));
			}

		} else {
			if (luceneSearchDto.getSearchQuery().contains("interestsShared:")
					&& doc.get("interestsShared") != null) {
				QueryScorer scorer = new QueryScorer(query, "interestsShared");
				Highlighter highlighter = new Highlighter(
						new SimpleHTMLFormatter(
								"<B style='background-color:yellow'>", "</B>"),
						scorer);
				highlighter.setTextFragmenter(new SimpleSpanFragmenter(scorer,
						150));
				highlights.put("Interests",
						highlighter.getBestFragment(analyzer,
								"interestsShared", doc.get("interestsShared")));
			}
		}
		// Mentoring
				/*if (dataGroups.get("ResumeMentoringView") != null) {
					if ((luceneSearchDto.getSearchQuery().contains("mentorAll:") || luceneSearchDto.getSearchQuery().contains("mentorShared:")
						|| luceneSearchDto.getSearchQuery().contains("menteeAll:") || luceneSearchDto.getSearchQuery().contains("menteeShared:"))
							&& doc.get("mentoringDesc") != null ) {
						//highlights.put("Mentoring", "<B style='background-color:yellow'>" + doc.get("mentoringDesc").substring(0, doc.get("mentoringDesc").length()<=150?doc.get("mentoringDesc").length():150) + "</B>");
						highlights.put("Mentoring", doc.get("mentoringDesc").substring(0, doc.get("mentoringDesc").length()<=150?doc.get("mentoringDesc").length():150));
					}

				}*/ 
		
		// Expertise
		if (luceneSearchDto.getSearchQuery().contains("eeExpertiseAll:")
						&& doc.get("eeExpertiseAll") != null) {
			QueryScorer scorer = new QueryScorer(query, "eeExpertiseAll");
			Highlighter highlighter = new Highlighter(new SimpleHTMLFormatter("<B style='background-color:yellow'>", "</B>"), scorer);
			highlighter.setTextFragmenter(new SimpleSpanFragmenter(scorer, 150));
			String empExp[] = doc.get("eeExpertiseAll").split("-");
			String expertiseList = "";
			for(String eexp: empExp) {
				eexp = eexp.trim();
				if("".equals(eexp)){continue;}
				String highlightedText = highlighter.getBestFragment(analyzer, "eeExpertiseAll", eexp);
				if(null != highlightedText) {
					expertiseList += "<label style='text-transform: capitalize;'>"+highlightedText+"</B>,&nbsp;</label>";
				} else if(eexp != null && !"".equals(eexp)){
					expertiseList += "<label style='text-transform: capitalize;'>"+eexp+",&nbsp;</label>";
				}
			}
			expertiseList = expertiseList.substring(0, expertiseList.lastIndexOf(","));
			highlights.put("Featured Expertise", expertiseList);
		}
				
		return highlights;
	}

	public LuceneSearchCompListDto getNodeCount(
			LuceneSearchCompListDto luceneSearchDto, int offset, int count,
			List<String> fieldsList) {
		try {
			IndexReader reader = DirectoryReader.open(this.dir);
			IndexSearcher searcher = new IndexSearcher(reader);
			BooleanQuery mainQuery = new BooleanQuery();
			TopDocs matches = null;
			if (luceneSearchDto.getSearchQuery() != null
					&& !luceneSearchDto.getSearchQuery().isEmpty()) {
				QueryParser parser = new QueryParser("ssoName", this.analyzer);
				parser.setAllowLeadingWildcard(true);
				mainQuery = createMainQuery(luceneSearchDto.getSearchQuery(),
						"", parser, mainQuery);
			}
			matches = searcher.search(mainQuery, (offset + count),
					Sort.RELEVANCE);
			luceneSearchDto.setTotal(matches.totalHits);

			reader.close();
		} catch (Exception e) {
			luceneSearchDto
					.setErrorMesage("Search is not available now. Please try again after some time.");
			LOG.debug(e.getMessage());
		}
		return luceneSearchDto;
	}

	public BooleanQuery createMainQuery(String query, String lpQuery,
			QueryParser parser, BooleanQuery mainQuery) {
		try {
			if (query != null && !query.isEmpty()) {
				Query q = parser.parse(query);
				mainQuery.add(q, Occur.MUST);
			}
			if (lpQuery != null && !lpQuery.isEmpty()) {
				Query lpq = parser.parse(lpQuery);
				ToParentBlockJoinQuery lpJoinQuery = new ToParentBlockJoinQuery(
						lpq, parentFilter, ScoreMode.Max);
				mainQuery.add(lpJoinQuery, Occur.MUST);
			}
		} catch (ParseException e) {
			throw new RuntimeException(e.getMessage());
		}
		return mainQuery;
	}

	public Query createTypeAheadQuery(String param) {
		QueryParser qp = new QueryParser("defaultTypeahead", this.analyzer);
		StringBuilder query = new StringBuilder();
		param = param.trim();
		if (param.startsWith("*")) {
			param = param.substring(1);
		}
		param = param.replaceAll("\\*", " ");

		String[] terms = param.split(" ");
		for (String t : terms) {
			t = t.replaceAll("[()]", "");
			if (!t.equalsIgnoreCase("AND") && !t.equalsIgnoreCase("OR")
					&& !t.equalsIgnoreCase("(") && !t.equalsIgnoreCase(")")
					&& !t.contains("\"") && !t.equalsIgnoreCase(" ")
					&& !t.equalsIgnoreCase("")) {
				if (t.matches("^[A-Za-z0-9'+_.-]+@(.+)$")) {
					query.append("\"").append(t).append("\"");
				} else {
					query.append(t).append("* ");
				}
			} else {
				query.append(t).append(" ");
			}
		}
		Query q = parseTypeaheadQuery(query, qp, false);
		return q;
	}

	public Query parseTypeaheadQuery(StringBuilder query, QueryParser qp,
			boolean isFacet) {

		String[] fields = { "empLastName", "empFirstName", "empPreferredName",
				"empAsciiName", "empName", "empLocalLangName",
				"defaultTypeahead" };
		Map<String, Float> boosts = new HashMap<String, Float>();
		boosts.put("empLastName", new Float(2.0));

		MultiFieldQueryParser parser = new MultiFieldQueryParser(fields,
				this.analyzer, boosts);
		parser.setDefaultOperator(Operator.AND);
		// parser.setMultiTermRewriteMethod(MultiTermQuery.TopTermsScoringBooleanQueryRewrite);
		try {
			Query q = parser.parse(query.toString());
			if (!isFacet) {
				StringBuilder query1 = new StringBuilder();
				String[] splitquery = q.toString().split(" ");
				for (String s : splitquery) {
					if (s.contains("defaultTypeahead")) {
						s = s.replace("*", "");

					}
					query1.append(s).append(" ");
				}
				q = qp.parse(query1.toString());
			}
			return q;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e.getMessage());
		}
	}

	public LuceneSearchCompDto allSearchResults(IndexSearcher searcher,
			int docId) throws CorruptIndexException, IOException {
		LuceneSearchCompDto searchResults = new LuceneSearchCompDto(
				Long.parseLong(searcher.doc(docId).get("sso")), searcher.doc(
						docId).get("empName"), searcher.doc(docId).get(
						"empAsciiName"), searcher.doc(docId).get(
						"empPreferredName"), searcher.doc(docId).get("title"),
				searcher.doc(docId).get("empEmail"), searcher.doc(docId).get(
						"empWorkPhone"), searcher.doc(docId).get("empMobile"),
				searcher.doc(docId).get("empAddr1"), searcher.doc(docId).get(
						"empAddr2"), searcher.doc(docId).get("empAddr3"),
				 searcher.doc(docId).get("empState"), searcher.doc(docId).get("empStateName"),
				searcher.doc(docId).get("empZip"), searcher.doc(docId).get(
						"empCountry"), searcher.doc(docId).get(
						"empCountryLabel"), searcher.doc(docId).get(
						"empManagerName"), searcher.doc(docId).get(
						"empManagerAsciiName"), Long.parseLong(searcher.doc(
						docId).get("empManagerSso")), searcher.doc(docId).get(
						"mgrPreferredName"), searcher.doc(docId)
						.get("mgrTitle"), searcher.doc(docId).get("mgrEmail"),
				searcher.doc(docId).get("mgrPhone"), searcher.doc(docId).get(
						"mgrMobile"), searcher.doc(docId).get("ohMgrSso"),
				searcher.doc(docId).get("ohMgrSso1"), searcher.doc(docId).get(
						"ohMgrSso2"), searcher.doc(docId).get("ohMgrSso3"),
				searcher.doc(docId).get("ohMgrLastName"), searcher.doc(docId)
						.get("ohMgrLastName1"), searcher.doc(docId).get(
						"ohMgrLastName2"), searcher.doc(docId).get(
						"ohMgrLastName3"), searcher.doc(docId).get(
						"ohMgrFirstName"), searcher.doc(docId).get(
						"ohMgrFirstName1"), searcher.doc(docId).get(
						"ohMgrFirstName2"), searcher.doc(docId).get(
						"ohMgrFirstName3"), searcher.doc(docId).get("ifg"),
				searcher.doc(docId).get("business"), searcher.doc(docId).get(
						"subBusiness"),
				searcher.doc(docId).get("organization"), searcher.doc(docId)
						.get("jobFunction"), searcher.doc(docId).get(
						"jobFamily"), searcher.doc(docId).get("region"),
				searcher.doc(docId).get("country"), searcher.doc(docId).get(
						"empLastName"),
				searcher.doc(docId).get("empFirstName"), searcher.doc(docId)
						.get("empHistorySharedFlag"), searcher.doc(docId).get(
						"educationTrainingShared"), searcher.doc(docId).get(
						"empReportingBusiness"), searcher.doc(docId).get(
						"empReportingIFG"), searcher.doc(docId).get(
						"empLocalLangName"), searcher.doc(docId).get(
						"personType"), searcher.doc(docId).get(
						"techDisciplineKW"), searcher.doc(docId).get(
						"techDisciplineSTD"), searcher.doc(docId).get(
						"directoryInclusion"), searcher.doc(docId).get(
						"empLocalLangTitle"), searcher.doc(docId).get(
						"workHistoryShared"), searcher.doc(docId).get(
						"projectsShared"),
				searcher.doc(docId).get("interests"), searcher.doc(docId).get(
						"careerInterestsShared"), searcher.doc(docId).get(
						"professionalSummaryShared"), searcher.doc(docId).get(
						"initiativeProjectShared"), searcher.doc(docId).get(
						"careerSharedFlag"), searcher.doc(docId).get(
						"talentPoolAll"), searcher.doc(docId).get(
						"customerSuppliersSharedFlag"), searcher.doc(docId)
						.get("languagesSharedFlag"), searcher.doc(docId).get(
						"externalAffiliationsSharedFlag"), searcher.doc(docId)
						.get("interestsSharedFlag"), searcher.doc(docId).get(
						"customersSuppliersShared"), searcher.doc(docId).get(
						"languagesShared"), searcher.doc(docId).get(
						"externalAffiliationsShared"), searcher.doc(docId).get(
						"relocateWithinShared"), searcher.doc(docId).get(
						"relocateOutsideShared"), searcher.doc(docId).get(
						"mobilityCountryShared"), searcher.doc(docId).get(
						"mentoringSharedFlag"), searcher.doc(docId).get(
						"mentorShared"), searcher.doc(docId).get("menteeShared"), searcher.doc(docId).get("mentoringDesc"),
						searcher.doc(docId).get("connectMentoDesc"), searcher.doc(docId).get("eeExpertiseAll"),
						searcher.doc(docId).get("menteeAllInterest"),searcher.doc(docId).get("mentorAllInterest"), searcher.doc(docId).get("rotationNumber")
						, searcher.doc(docId).get("assignmentTitle")
						, searcher.doc(docId).get("assignmentLeaderName")
						, searcher.doc(docId).get("assignmentSubBusiness")
						, searcher.doc(docId).get("assignmentLeaderFor")
						, searcher.doc(docId).get("talentPoolAll"));
		return searchResults;

	}

	public LuceneSearchCompDto clientSearchResults(IndexSearcher searcher,
			int docId) throws CorruptIndexException, IOException {

		ACLBean acl = new ACLBean(searcher.doc(docId).get("sso"), searcher.doc(
				docId).get("acl_SUPV"), searcher.doc(docId).get("acl_MGR"),
				searcher.doc(docId).get("acl_ORG_MGR"), searcher.doc(docId)
						.get("acl_HRM"),
				searcher.doc(docId).get("acl_ORG_HRM"), searcher.doc(docId)
						.get("acl_HRM_SPL"), searcher.doc(docId)
						.get("acl_SHRM"),
				searcher.doc(docId).get("acl_SHRM_F"), searcher.doc(docId).get(
						"acl_SHRM_R"), searcher.doc(docId).get("acl_SHRM_GL"),
				searcher.doc(docId).get("acl_MATRIX_HRM"), searcher.doc(docId)
						.get("acl_O_S_MANAGER"), searcher.doc(docId).get(
						"acl_O_S_MANAGER_CP"), searcher.doc(docId).get(
						"acl_O_S_MANAGER_F"), searcher.doc(docId).get(
						"acl_O_S_MANAGER_GL"), searcher.doc(docId).get(
						"acl_O_S_MANAGER_R"), searcher.doc(docId).get(
						"acl_O_TD_MANAGER"), searcher.doc(docId).get(
						"acl_O_TD_MANAGER_CP"), searcher.doc(docId).get(
						"acl_O_TD_MANAGER_F"), searcher.doc(docId).get(
						"acl_O_TD_MANAGER_GL"), searcher.doc(docId).get(
						"acl_O_TD_MANAGER_R"), searcher.doc(docId).get(
						"acl_HRM_VIEW"), searcher.doc(docId).get("acl_HR_BP"),
				searcher.doc(docId).get("acl_O_TD_NO_COMP"), searcher
						.doc(docId).get("acl_ADMIN_STAFF"), searcher.doc(docId)
						.get("acl_STAFF_HS_STAFFING_SPL"), searcher.doc(docId)
						.get("acl_STAFF_REQ_FLDR_OWNR"), searcher.doc(docId)
						.get("acl_STAFF_HS_LTD_ACCESS"), searcher.doc(docId)
						.get("acl_STAFF_HS_US_LEAD_RCTR"), searcher.doc(docId)
						.get("acl_MGR_1O1"), searcher.doc(docId)
						.get("acl_LP_GLOBAL_PROGRAM_MGR"), searcher.doc(docId)
						.get("acl_LP_PROGRAM_MGR"), searcher.doc(docId)
						.get("acl_LP_OPERATIONS"));

		LuceneSearchCompDto searchResult = new LuceneSearchCompDto(
				Long.parseLong(searcher.doc(docId).get("sso")), searcher.doc(
						docId).get("empName"), searcher.doc(docId).get(
						"empAsciiName"), searcher.doc(docId).get(
						"empPreferredName"), searcher.doc(docId).get("title"),
				searcher.doc(docId).get("empEmail"), searcher.doc(docId).get(
						"empWorkPhone"), searcher.doc(docId).get("empMobile"),
				searcher.doc(docId).get("empAddr1"), searcher.doc(docId).get(
						"empAddr2"), searcher.doc(docId).get("empAddr3"),
				searcher.doc(docId).get("empState"), searcher.doc(docId).get("empStateName"),
				searcher.doc(docId).get("empZip"), searcher.doc(docId).get(
						"empCountry"), searcher.doc(docId).get(
						"empCountryLabel"), searcher.doc(docId).get(
						"empManagerName"), searcher.doc(docId).get(
						"empManagerAsciiName"), Long.parseLong(searcher.doc(
						docId).get("empManagerSso")), searcher.doc(docId).get(
						"mgrPreferredName"), searcher.doc(docId)
						.get("mgrTitle"), searcher.doc(docId).get("mgrEmail"),
				searcher.doc(docId).get("mgrPhone"), searcher.doc(docId).get(
						"mgrMobile"), searcher.doc(docId).get("ohMgrSso"),
				searcher.doc(docId).get("ohMgrSso1"), searcher.doc(docId).get(
						"ohMgrSso2"), searcher.doc(docId).get("ohMgrSso3"),
				searcher.doc(docId).get("ohMgrLastName"), searcher.doc(docId)
						.get("ohMgrLastName1"), searcher.doc(docId).get(
						"ohMgrLastName2"), searcher.doc(docId).get(
						"ohMgrLastName3"), searcher.doc(docId).get(
						"ohMgrFirstName"), searcher.doc(docId).get(
						"ohMgrFirstName1"), searcher.doc(docId).get(
						"ohMgrFirstName2"), searcher.doc(docId).get(
						"ohMgrFirstName3"), searcher.doc(docId).get("ifg"),
				searcher.doc(docId).get("business"), searcher.doc(docId).get(
						"subBusiness"),
				searcher.doc(docId).get("organization"), searcher.doc(docId)
						.get("jobFunction"), searcher.doc(docId).get(
						"jobFamily"),

				searcher.doc(docId).get("region"), searcher.doc(docId).get(
						"country"), searcher.doc(docId).get("band"), acl,
				searcher.doc(docId).get("empLastName"), searcher.doc(docId)
						.get("empFirstName"), searcher.doc(docId).get(
						"empHistorySharedFlag"), searcher.doc(docId).get(
						"educationTrainingAll"), searcher.doc(docId).get(
						"empReportingBusiness"), searcher.doc(docId).get(
						"empReportingIFG"), searcher.doc(docId).get(
						"empLocalLangName"), searcher.doc(docId).get(
						"personType"), searcher.doc(docId).get(
						"techDisciplineKW"), searcher.doc(docId).get(
						"techDisciplineSTD"), searcher.doc(docId).get(
						"directoryInclusion"), searcher.doc(docId).get(
						"empLocalLangTitle"), searcher.doc(docId).get(
						"workHistoryAll"), searcher.doc(docId).get(
						"projectsAll"), searcher.doc(docId).get("interests"),
				searcher.doc(docId).get("careerInterestsAll"), searcher.doc(
						docId).get("professionalSummaryShared"), searcher.doc(
						docId).get("initiativeProjectShared"), searcher.doc(
						docId).get("careerSharedFlag"), searcher.doc(docId)
						.get("talentPoolAll"), searcher.doc(docId).get(
						"customerSuppliersSharedFlag"), searcher.doc(docId)
						.get("languagesSharedFlag"), searcher.doc(docId).get(
						"externalAffiliationsSharedFlag"), searcher.doc(docId)
						.get("interestsSharedFlag"), searcher.doc(docId).get(
						"customersSuppliersAll"), searcher.doc(docId).get(
						"languagesAll"), searcher.doc(docId).get(
						"externalAffiliationsAll"), searcher.doc(docId).get(
						"relocateWithinAll"), searcher.doc(docId).get(
						"relocateOutsideAll"), searcher.doc(docId).get(
						"mobilityCountryAll"), searcher.doc(docId).get(
						"mentoringSharedFlag"), searcher.doc(docId).get(
						"mentorAll"), searcher.doc(docId).get(
						"menteeAll"), searcher.doc(docId).get("mentoringDesc"), searcher.doc(docId).get("rotationNumber")
						, searcher.doc(docId).get("assignmentTitle")
						, searcher.doc(docId).get("assignmentLeaderName")
						, searcher.doc(docId).get("assignmentSubBusiness")
						, searcher.doc(docId).get("assignmentLeaderFor")
						, searcher.doc(docId).get("talentPoolAll"));

		// getting child docs
		/*
		 * if (browserFieldsList.contains("education") ||
		 * browserFieldsList.contains("leadershipProgram") ||
		 * browserFieldsList.contains("workHistory") ||
		 * browserFieldsList.contains("training")) {
		 */
		int j = docId - 1;
		List<LuceneEducationDto> eList = new ArrayList<LuceneEducationDto>();
		List<LuceneLeadershipDto> lpList = new ArrayList<LuceneLeadershipDto>();
		List<LuceneTrainingDto> tList = new ArrayList<LuceneTrainingDto>();
		List<LuceneEmpHistoryDto> emhList = new ArrayList<LuceneEmpHistoryDto>();

		while (j != -1 && !searcher.doc(j).get("type").equals("parent")) {
			if (searcher.doc(j).get("type").equalsIgnoreCase("edu")) {
				LuceneEducationDto edu = new LuceneEducationDto();
				/*
				 * if (clientFieldsList != null) {
				 * edu.setEduDegree(clientFieldsList.contains("eduDegree") ?
				 * searcher .doc(j).get("eduDegree") : null);
				 * edu.setSso(Long.parseLong(null));
				 * edu.setEduMajor(clientFieldsList.contains("eduMajor") ?
				 * searcher .doc(j).get("eduMajor") : null);
				 * edu.setEduUniversity(clientFieldsList
				 * .contains("eduUniversity") ? searcher.doc(j).get(
				 * "eduUniversity") : null);
				 * edu.setEduCountry(clientFieldsList.contains("eduCountry") ?
				 * searcher .doc(j).get("eduCountry") : null); } else {
				 */
				edu.setEduDegree(searcher.doc(j).get("eduDegree"));
				edu.setSso(Long.parseLong(null));
				edu.setEduMajor(searcher.doc(j).get("eduMajor"));
				edu.setEduUniversity(searcher.doc(j).get("eduUniversity"));
				edu.setEduCountry(searcher.doc(j).get("eduCountry"));
				// }
				eList.add(edu);
			} else if (searcher.doc(j).get("type").equalsIgnoreCase("emh")) {
				LuceneEmpHistoryDto emh = new LuceneEmpHistoryDto();

				/*
				 * if (clientFieldsList != null) {
				 * emh.setBusinessCard(clientFieldsList
				 * .contains("businessCard") ? searcher.doc(j).get(
				 * "businessCard") : null);
				 * emh.setGeBusiness(clientFieldsList.contains("geBusiness") ?
				 * searcher .doc(j).get("geBusiness") : null);
				 * emh.setLocation(clientFieldsList.contains("location") ?
				 * searcher .doc(j).get("location") : null);
				 * emh.setManager(clientFieldsList.contains("manager") ?
				 * searcher .doc(j).get("manager") : null);
				 * emh.setFunctionDes(clientFieldsList .contains("functionDesc")
				 * ? searcher.doc(j).get( "functionDesc") : null);
				 * emh.setExpDesc(clientFieldsList.contains("expDesc") ?
				 * searcher .doc(j).get("expDesc") : null); } else {
				 */
				emh.setBusinessCard(searcher.doc(j).get("businessCard"));
				emh.setGeBusiness(searcher.doc(j).get("geBusiness"));
				emh.setLocation(searcher.doc(j).get("location"));
				emh.setManager(searcher.doc(j).get("manager"));
				emh.setFunctionDes(searcher.doc(j).get("functionDesc"));
				emh.setExpDesc(searcher.doc(j).get("expDesc"));
				// }
				emhList.add(emh);
			} else if (searcher.doc(j).get("type").equalsIgnoreCase("trng")) {
				LuceneTrainingDto trng = new LuceneTrainingDto();

				/*
				 * if (clientFieldsList != null) {
				 * trng.setTrngDescriptiom(clientFieldsList
				 * .contains("trngDesc") ? searcher.doc(j).get( "trngDesc") :
				 * null); trng.setTrngID(clientFieldsList.contains("trngId") ?
				 * searcher .doc(j).get("trngId") : null); } else {
				 */
				trng.setTrngDescriptiom(searcher.doc(j).get("trngDesc"));
				trng.setTrngID(searcher.doc(j).get("trngId"));
				// }
				tList.add(trng);
			} else if (searcher.doc(j).get("type").equalsIgnoreCase("ldrprg")) {
				LuceneLeadershipDto lp = new LuceneLeadershipDto();

				/*
				 * if (clientFieldsList != null) {
				 * lp.setPrgName(clientFieldsList.contains("prgName") ? searcher
				 * .doc(j).get("prgName") : null);
				 * lp.setPrgLongName(clientFieldsList.contains("prgLongName") ?
				 * searcher .doc(j).get("prgLongName") : null);
				 * lp.setPrgStatus(clientFieldsList.contains("prgStatus") ?
				 * searcher .doc(j).get("prgStatus") : null); } else {
				 */
				lp.setPrgName(searcher.doc(j).get("prgName"));
				lp.setPrgLongName(searcher.doc(j).get("prgLongName"));
				lp.setPrgStatus(searcher.doc(j).get("prgStatus"));
				// }
				lpList.add(lp);
			}
			j--;
		}
		searchResult.setEducation(eList);
		searchResult.setLeadershipProgram(lpList);
		searchResult.setWorkHistory(emhList);
		searchResult.setTraining(tList);
		// }

		return searchResult;
	}

	public ShortProfile typeAheadSearchResults(IndexSearcher searcher, int docId)
			throws CorruptIndexException, IOException {
		ShortProfile searchResults = new ShortProfile(Long.parseLong(searcher
				.doc(docId).get("sso")), searcher.doc(docId)
				.get("empFirstName"), searcher.doc(docId).get(
				"empPreferredName"), searcher.doc(docId).get("empLastName"),
				searcher.doc(docId).get("ifg"));
		return searchResults;

	}

	public List<String> getFieldsList(String input) {

		List<String> rval = new ArrayList<String>();
		List<String> fieldsList = getAllPublicFields();

		if (input != null && input.length() > 0) {
			String[] tempList = input.split(",");
			for (String item : tempList) {
				item = item.trim();
				if (fieldsList.contains(item)) {
					rval.add(item);
				} else {
					throw new IllegalArgumentException(String.format(
							"Invalid input field name=%s", item));
				}
			}
		}
		return rval;
	}

	// Persons with only public data
	public void index(LuceneSearchCompDto searchDto, IndexWriter writer) {
		try {
			if (searchDto != null) {
				writer.addDocument(createEmpDoc(searchDto, null, null, null,
						null, null, null, null,null,null,null,null));

			}
		} catch (CorruptIndexException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public void indexExpertise(Expertise expertise, IndexWriter writer) {
		try {
			if (expertise != null) {
				writer.addDocument(createExpertiseDoc(expertise));

			}
		} catch (CorruptIndexException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	private Document createExpertiseDoc(Expertise expertise) {
		Document doc = new Document();
		if (expertise != null) {

			doc.add(new IntField("expID", expertise.getId(), Field.Store.YES));
			doc.add(new IntField("expParentID", expertise.getParentId(), Field.Store.YES));
			if (expertise.getName() != null) {
				doc.add(new TextField("expName", expertise.getName().toString(), Field.Store.YES));
			}
		}
		return doc;
	}

	public void index(LuceneSearchCompDto ls, List<LuceneLeadershipDto> lpList,
			List<LuceneEmpHistoryDto> emhList, List<LuceneEducationDto> eList,
			List<LuceneTrainingDto> tList,
			List<IntiativesandProject> projectList,
			List<CustomerandSuppliers> csList,
			List<LanguageProficiency> lprList, List<AffinityGroups> eaList,
			List<WorkMobilityCountry> wmList, List<LPBridgeAssignment> lpbList,
			List<EmployeeExpertise> expList, List<Mentoring> mentoringInterestList, IndexWriter writer, DirectoryTaxonomyWriter taxo) {

		try {
			if (ls != null) {
				Document parentDoc = createEmpDoc(ls, emhList, eList, tList,
						projectList, csList, lprList, eaList,wmList,lpbList,expList,mentoringInterestList);
				indexAclAndPrivateFields(ls, parentDoc);
				if (lpList != null) {
					ArrayList<Document> docs = new ArrayList<Document>();
					// adding child docs
					for (LuceneLeadershipDto lp : lpList) {
						docs.add(createLeadershipPrgDoc(lp));
					}
					// adding parent doc as last
					docs.add(config.build(taxo, parentDoc));
					writer.addDocuments(docs);
				} else {
					// writer.addDocument(parentDoc);
					writer.addDocument(config.build(taxo, parentDoc));
				}
				taxo.commit();
			}
		} catch (CorruptIndexException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	private Document createEmpDoc(LuceneSearchCompDto ls,
			List<LuceneEmpHistoryDto> emhList,
			List<LuceneEducationDto> eduList, List<LuceneTrainingDto> trngList,
			List<IntiativesandProject> projectList,
			List<CustomerandSuppliers> csList,
			List<LanguageProficiency> lprList, List<AffinityGroups> eaList,List<WorkMobilityCountry> wmList,
			List<LPBridgeAssignment> lpbList, List<EmployeeExpertise> eeList, List<Mentoring> mentInterestList) {
		Document doc = new Document();
		if (ls != null) {

			StringBuilder combinedSharedData = new StringBuilder();
			StringBuilder combinedAllData = new StringBuilder();
			String sharedFlag = "";
			/* Indexing Employee Details */
			FieldType fType = new FieldType(StringField.TYPE_STORED);
			fType.setOmitNorms(false);
			doc.add(new Field("type", "parent", fType));

			if (ls.getSso() != null) {
				doc.add(new TextField("employeeDetails", ls.getSso().toString()
						+ " " + ls.getEmpAsciiName() + " " + ls.getEmpEmail()
						+ " " + ls.getEmpName() + " " + ls.getEmpWorkPhone()
						+ " " + ls.getEmpMobile() + " "
						+ ls.getEmpPreferredName() + " "
						+ ls.getEmpLocalLangName() + " " + ls.getTitle(),
						Field.Store.YES));
				combinedSharedData.append(ls.getSso().toString() + " "
						+ ls.getEmpAsciiName() + " " + ls.getEmpEmail() + " "
						+ ls.getEmpName() + " " + ls.getEmpWorkPhone() + " "
						+ ls.getEmpMobile() + " " + ls.getEmpPreferredName()
						+ " " + ls.getEmpLocalLangName() + " " + ls.getTitle()
						+ " - ");
				combinedAllData.append(ls.getSso().toString() + " "
						+ ls.getEmpAsciiName() + " " + ls.getEmpEmail() + " "
						+ ls.getEmpName() + " " + ls.getEmpWorkPhone() + " "
						+ ls.getEmpMobile() + " " + ls.getEmpPreferredName()
						+ " " + ls.getEmpLocalLangName() + " " + ls.getTitle()
						+ " - ");
			}
			if (ls.getSso() != null && ls.getEmpName() != null) {
				doc.add(new TextField("ssoName", ls.getSso().toString() + " "
						+ ls.getEmpAsciiName() + " " + ls.getEmpEmail() + " "
						+ ls.getEmpName() + " " + ls.getEmpPreferredName()
						+ " " + ls.getEmpLocalLangName(), Field.Store.YES));
			}
			if (ls.getEmpEmail() != null && ls.getEmpWorkPhone() != null
					&& ls.getEmpMobile() != null) {
				doc.add(new TextField("emailPhone", ls.getEmpEmail().toString()
						+ " " + ls.getEmpWorkPhone().toString() + " "
						+ ls.getEmpMobile().toString(), Field.Store.YES));
			}
			if (ls.getEmpManagerSso() != null) {
				doc.add(new TextField("managerDetails", ls.getEmpManagerSso()
						.toString()
						+ " "
						+ ls.getEmpManagerAsciiName()
						+ " "
						+ ls.getMgrEmail()
						+ " "
						+ ls.getEmpManagerName()
						+ " "
						+ ls.getMgrPhone()
						+ " "
						+ ls.getMgrMobile()
						+ " "
						+ ls.getMgrPreferredName() + " " + ls.getMgrTitle(),
						Field.Store.YES));
				combinedSharedData.append(ls.getEmpManagerSso().toString()
						+ " " + ls.getEmpManagerAsciiName() + " "
						+ ls.getMgrEmail() + " " + ls.getEmpManagerName() + " "
						+ ls.getMgrPhone() + " " + ls.getMgrMobile() + " "
						+ ls.getMgrPreferredName() + " " + ls.getMgrTitle()
						+ " - ");
				combinedAllData.append(ls.getEmpManagerSso().toString() + " "
						+ ls.getEmpManagerAsciiName() + " " + ls.getMgrEmail()
						+ " " + ls.getEmpManagerName() + " " + ls.getMgrPhone()
						+ " " + ls.getMgrMobile() + " "
						+ ls.getMgrPreferredName() + " " + ls.getMgrTitle()
						+ " - ");
			}
			if (ls.getSso() != null) {
				doc.add(new TextField("sso", ls.getSso().toString(),
						Field.Store.YES));
			}
			if (ls.getBand() != null) {
				doc.add(new StringField("band", ls.getBand().toString(),
						Field.Store.YES));
				doc.add(new FacetField("band", ls.getBand().toString()));
				combinedAllData.append(ls.getBand().toString() + " - ");
			}
			if (ls.getBusiness() != null) {
				doc.add(new StringField("business",
						ls.getBusiness().toString(), Field.Store.YES));
				doc.add(new FacetField("business", ls.getBusiness().toString()));
				combinedAllData.append(ls.getBusiness().toString() + " - ");
				combinedSharedData.append(ls.getBusiness().toString() + " - ");
			}
			if (ls.getCountry() != null) {
				doc.add(new StringField("country", ls.getCountry().toString(),
						Field.Store.YES));
				doc.add(new FacetField("country", ls.getCountry().toString()));
				combinedAllData.append(ls.getCountry().toString() + " - ");
				combinedSharedData.append(ls.getCountry().toString() + " - ");
			}
			if (ls.getEmpAsciiName() != null) {
				doc.add(new TextField("empAsciiName", ls.getEmpAsciiName()
						.toString(), Field.Store.YES));
			}
			if (ls.getEmpEmail() != null) {
				doc.add(new TextField("empEmail", ls.getEmpEmail().toString(),
						Field.Store.YES));
			}
			if (ls.getEmpFirstName() != null) {
				doc.add(new TextField("empFirstName", ls.getEmpFirstName()
						.toString(), Field.Store.YES));
				doc.add(new SortedDocValuesField("empFirstName", new BytesRef(ls
						.getEmpFirstName().toString().toLowerCase().trim())));
			}
			if (ls.getEmpHistorySharedFlag() != null) {
				doc.add(new TextField("empHistorySharedFlag", ls
						.getEmpHistorySharedFlag().toString(), Field.Store.YES));
			}
			if (ls.getEmpLastName() != null) {
				Field lastNameField = new TextField("empLastName", ls
						.getEmpLastName().toString(), Field.Store.YES);
				lastNameField.setBoost(1.4f);
				doc.add(lastNameField);
				doc.add(new SortedDocValuesField("empLastName", new BytesRef(ls
						.getEmpLastName().toString().toLowerCase().trim())));
			}
			if (ls.getEmpManagerAsciiName() != null) {
				doc.add(new TextField("empManagerAsciiName", ls
						.getEmpManagerAsciiName().toString(), Field.Store.YES));
			}
			if (ls.getEmpManagerName() != null) {
				doc.add(new TextField("empManagerName", ls.getEmpManagerName()
						.toString(), Field.Store.YES));
			}
			if (ls.getEmpManagerSso() != null) {
				doc.add(new TextField("empManagerSso", ls.getEmpManagerSso()
						.toString(), Field.Store.YES));
			}
			if (ls.getEmpName() != null) {
				doc.add(new TextField("empName", ls.getEmpName().toString(),
						Field.Store.YES));
			}
			if (ls.getEmpLocalLangName() != null) {
				doc.add(new TextField("empLocalLangName", ls
						.getEmpLocalLangName().toString(), Field.Store.YES));
			}
			if (ls.getEmpWorkPhone() != null) {
				doc.add(new TextField("empWorkPhone", ls.getEmpWorkPhone()
						.toString(), Field.Store.YES));
			}
			if (ls.getEmpMobile() != null) {
				doc.add(new TextField("empMobile",
						ls.getEmpMobile().toString(), Field.Store.YES));
			}
			if (ls.getEmpPreferredName() != null) {
				doc.add(new TextField("empPreferredName", ls
						.getEmpPreferredName().toString(), Field.Store.YES));
			}
			if (ls.getFunc() != null) {
				doc.add(new StringField("jobFunction", ls.getFunc().toString(),
						Field.Store.YES));
				doc.add(new FacetField("jobFunction", ls.getFunc().toString()));
				combinedAllData.append(ls.getFunc().toString() + " - ");
				combinedSharedData.append(ls.getFunc().toString() + " - ");
			}
			if (ls.getIfg() != null) {
				doc.add(new StringField("ifg", ls.getIfg().toString(),
						Field.Store.YES));
				doc.add(new FacetField("ifg", ls.getIfg().toString()));
				combinedAllData.append(ls.getIfg().toString() + " - ");
			}
			if (ls.getJobFamily() != null) {
				doc.add(new StringField("jobFamily", ls.getJobFamily()
						.toString(), Field.Store.YES));
				doc.add(new FacetField("jobFamily", ls.getJobFamily().toString()));
				combinedAllData.append(ls.getJobFamily().toString() + " - ");
			}
			if (ls.getMgrEmail() != null) {
				doc.add(new TextField("mgrEmail", ls.getMgrEmail().toString(),
						Field.Store.YES));
			}
			if (ls.getMgrPhone() != null) {
				doc.add(new TextField("mgrPhone", ls.getMgrPhone().toString(),
						Field.Store.YES));
			}
			if (ls.getMgrMobile() != null) {
				doc.add(new TextField("mgrMobile",
						ls.getMgrMobile().toString(), Field.Store.YES));
			}
			if (ls.getMgrPreferredName() != null) {
				doc.add(new TextField("mgrPreferredName", ls
						.getMgrPreferredName().toString(), Field.Store.YES));
			}
			if (ls.getMgrTitle() != null) {
				doc.add(new TextField("mgrTitle", ls.getMgrTitle().toString(),
						Field.Store.YES));
			}
			if (ls.getOrganization() != null) {
				doc.add(new TextField("organization", ls.getOrganization()
						.toString(), Field.Store.YES));
				combinedAllData.append(ls.getOrganization().toString() + " - ");
				combinedSharedData.append(ls.getOrganization().toString()
						+ " - ");
			}
			if (ls.getRegion() != null) {
				doc.add(new StringField("region", ls.getRegion().toString(),
						Field.Store.YES));
				combinedAllData.append(ls.getRegion().toString() + " - ");
				combinedSharedData.append(ls.getRegion().toString() + " - ");
			}
			if (ls.getSubBusiness() != null) {
				doc.add(new StringField("subBusiness", ls.getSubBusiness()
						.toString(), Field.Store.YES));
				doc.add(new FacetField("subBusiness", ls.getSubBusiness()
						.toString()));
				combinedAllData.append(ls.getSubBusiness().toString() + " - ");
				combinedSharedData.append(ls.getSubBusiness().toString()
						+ " - ");
			}
			if (ls.getTitle() != null) {
				doc.add(new TextField("title", ls.getTitle().toString(),
						Field.Store.YES));
			}
			if (ls.getEmpLocalLangTitle() != null) {
				doc.add(new TextField("empLocalTitle", ls
						.getEmpLocalLangTitle().toString(), Field.Store.YES));
				combinedAllData.append(ls.getEmpLocalLangTitle().toString()
						+ " - ");
				combinedSharedData.append(ls.getEmpLocalLangTitle().toString()
						+ " - ");
			}
			if (ls.getEmpAddr1() != null || ls.getEmpAddr1() != null
					|| ls.getEmpAddr2() != null || ls.getEmpAddr3() != null
					|| ls.getEmpState() != null
					|| ls.getEmpZip() != null || ls.getEmpCountry() != null) {
				doc.add(new TextField("employeeLocation", ls.getEmpAddr1()
						+ " " + ls.getEmpAddr1() + " " + ls.getEmpAddr2() + " "
						+ ls.getEmpAddr3() + " " 
						+ ls.getEmpState() + " " + ls.getEmpStateName() + " "
						+ ls.getEmpZip() + " " + ls.getEmpCountry() + " "
						+ ls.getEmpCountryLabel(), Field.Store.YES));
				combinedAllData.append(ls.getEmpAddr1() + " "
						+ ls.getEmpAddr1() + " " + ls.getEmpAddr2() + " "
						+ ls.getEmpAddr3() + " " 
						+ ls.getEmpState() + " " + ls.getEmpStateName() + " "
						+ ls.getEmpZip() + " " + ls.getEmpCountry() + " "
						+ ls.getEmpCountryLabel() + " - ");
				combinedSharedData.append(ls.getEmpAddr1() + " "
						+ ls.getEmpAddr1() + " " + ls.getEmpAddr2() + " "
						+ ls.getEmpAddr3() + " " 
						+ ls.getEmpState() + " " + ls.getEmpStateName() + " "
						+ ls.getEmpZip() + " " + ls.getEmpCountry() + " "
						+ ls.getEmpCountryLabel() + " - ");
			}
			/*if (ls.getEmpCity() != null) {
				doc.add(new TextField("empCity", ls.getEmpCity().toString(),
						Field.Store.YES));
				doc.add(new FacetField("empCity", ls.getEmpCity().toString()));
			}*/
			if (ls.getEmpState() != null) {
				doc.add(new TextField("empState", ls.getEmpState().toString(),
						Field.Store.YES));
			}
			if (ls.getEmpCountry() != null) {
				doc.add(new TextField("empCountry", ls.getEmpCountry()
						.toString(), Field.Store.YES));
			}
			if (ls.getOhMgrSso() != null) {
				doc.add(new TextField("ohMgrSso", ls.getOhMgrSso().toString(),
						Field.Store.YES));
			}
			if (ls.getOhMgrFirstName() != null) {
				doc.add(new TextField("ohMgrFirstName", ls.getOhMgrFirstName(),
						Field.Store.YES));
			}
			if (ls.getOhMgrLastName() != null) {
				doc.add(new TextField("ohMgrLastName", ls.getOhMgrLastName(),
						Field.Store.YES));
			}

			if (ls.getOhMgrSso1() != null) {
				doc.add(new TextField("ohMgrSso1",
						ls.getOhMgrSso1().toString(), Field.Store.YES));
			}
			if (ls.getOhMgrFirstName1() != null) {
				doc.add(new TextField("ohMgrFirstName1", ls
						.getOhMgrFirstName1(), Field.Store.YES));
			}
			if (ls.getOhMgrLastName1() != null) {
				doc.add(new TextField("ohMgrLastName1", ls.getOhMgrLastName1(),
						Field.Store.YES));
			}

			if (ls.getOhMgrSso2() != null) {
				doc.add(new TextField("ohMgrSso2",
						ls.getOhMgrSso2().toString(), Field.Store.YES));
			}
			if (ls.getOhMgrFirstName2() != null) {
				doc.add(new TextField("ohMgrFirstName2", ls
						.getOhMgrFirstName2(), Field.Store.YES));
			}
			if (ls.getOhMgrLastName2() != null) {
				doc.add(new TextField("ohMgrLastName2", ls.getOhMgrLastName2(),
						Field.Store.YES));
			}

			if (ls.getOhMgrSso3() != null) {
				doc.add(new TextField("ohMgrSso3",
						ls.getOhMgrSso3().toString(), Field.Store.YES));
			}
			if (ls.getOhMgrFirstName3() != null) {
				doc.add(new TextField("ohMgrFirstName3", ls
						.getOhMgrFirstName3(), Field.Store.YES));
			}
			if (ls.getOhMgrLastName3() != null) {
				doc.add(new TextField("ohMgrLastName3", ls.getOhMgrLastName3(),
						Field.Store.YES));
			}
			if (ls.getSso() != null || ls.getEmpFirstName() != null
					|| ls.getEmpLastName() != null
					|| ls.getEmpAsciiName() != null
					|| ls.getEmpPreferredName() != null
					|| ls.getEmpWorkPhone() != null
					|| ls.getEmpMobile() != null || ls.getEmpEmail() != null
					|| ls.getIfg() != null || ls.getBusiness() != null
					|| ls.getSubBusiness() != null || ls.getFunc() != null
					|| ls.getTitle() != null || ls.getJobFamily() != null
					|| ls.getOrganization() != null || ls.getEmpAddr1() != null
					|| ls.getEmpAddr1() != null || ls.getEmpAddr2() != null
					|| ls.getEmpAddr3() != null 
					|| ls.getEmpState() != null || ls.getEmpZip() != null
					|| ls.getEmpCountry() != null) {
				doc.add(new TextField("defaultTypeahead", ls.getSso() + " "
						+ ls.getEmpFirstName() + " " + ls.getEmpLastName()
						+ " " + ls.getEmpAsciiName() + " "
						+ ls.getEmpPreferredName() + " "
						+ ls.getEmpLocalLangName() + " " + ls.getEmpWorkPhone()
						+ " " + ls.getEmpMobile() + " " + ls.getEmpEmail()
						+ " " + ls.getIfg() + " " + ls.getBusiness() + " "
						+ ls.getSubBusiness() + " " + ls.getFunc() + " "
						+ ls.getTitle() + " " + ls.getJobFamily() + " "
						+ ls.getOrganization() + " " + ls.getEmpAddr1() + " "
						+ ls.getEmpAddr1() + " " + ls.getEmpAddr2() + " "
						+ ls.getEmpAddr3() + " "
						+ ls.getEmpState() + " " + ls.getEmpCountry() + " "
						+ ls.getEmpLocalLangTitle(), Field.Store.YES));
			}
			if (ls.getEmpReportingBusiness() != null) {
				doc.add(new StringField("empReportingBusiness", ls
						.getEmpReportingBusiness().toString(), Field.Store.YES));
				combinedAllData.append(ls.getEmpReportingBusiness().toString()
						+ " - ");
				combinedSharedData.append(ls.getEmpReportingBusiness()
						.toString() + " - ");
			}
			if (ls.getEmpReportingIFG() != null) {
				doc.add(new StringField("empReportingIFG", ls
						.getEmpReportingIFG().toString(), Field.Store.YES));
				combinedAllData.append(ls.getEmpReportingIFG().toString()
						+ " - ");
				combinedSharedData.append(ls.getEmpReportingIFG().toString()
						+ " - ");
			}
			if (ls.getTechDisciplineKW() != null) {
				doc.add(new StringField("techDisciplineKW", ls
						.getTechDisciplineKW(), Field.Store.YES));
				doc.add(new SortedSetDocValuesFacetField("techDisciplineKW", ls
						.getTechDisciplineKW().toString()));
				combinedAllData.append(ls.getTechDisciplineKW() + " - ");
				combinedSharedData.append(ls.getTechDisciplineKW() + " - ");

			}
			if (ls.getTechDisciplineSTD() != null) {
				doc.add(new TextField("techDisciplineSTD", ls
						.getTechDisciplineSTD(), Field.Store.YES));
			}
			if (ls.getDirectoryIncl() != null) {
				doc.add(new TextField("directoryInclusion", ls
						.getDirectoryIncl(), Field.Store.YES));
			}
			if (ls.getPrsnType() != null) {
				doc.add(new TextField("personType", ls.getPrsnType(),
						Field.Store.YES));
				doc.add(new FacetField("personType", ls.getPrsnType()
						.toString()));
				combinedAllData.append(ls.getPrsnType() + " - ");
				combinedSharedData.append(ls.getPrsnType() + " - ");
			}
			if (emhList != null) {
				StringBuilder workHistory = createWorkHistoryDoc(emhList);
				doc.add(new TextField("workHistoryAll", workHistory.toString(),
						Field.Store.YES));
				// combinedAllData.append(workHistory.toString() + " - ");
				if (ls.getEmpHistorySharedFlag() == null
						|| ls.getEmpHistorySharedFlag() == "") {
					sharedFlag = "N";
				} else {
					sharedFlag = ls.getEmpHistorySharedFlag();
				}
				StringBuilder workHistoryShared = createWorkHistorySharedDoc(
						emhList, sharedFlag);
				doc.add(new TextField("workHistoryShared", workHistoryShared
						.toString(), Field.Store.YES));
				// combinedSharedData.append(workHistoryShared + " - ");
			}
			if (trngList != null || eduList != null) {
				StringBuilder training = createTrainingDoc(trngList, eduList);
				doc.add(new TextField("educationTrainingAll", training
						.toString(), Field.Store.YES));
				// combinedAllData.append(training.toString() + " - ");
				if (ls.getEducationSharedFlag() == null
						|| ls.getEducationSharedFlag() == "") {
					sharedFlag = "N";
				} else {
					sharedFlag = ls.getEducationSharedFlag();
				}
				StringBuilder educationTrainingShared = createTrainingSharedDoc(
						trngList, eduList, sharedFlag);
				doc.add(new TextField("educationTrainingShared",
						educationTrainingShared.toString(), Field.Store.YES));
				// combinedSharedData.append(educationTrainingShared + " - ");
			}
			if (projectList != null) {
				StringBuilder projects = createInitiativeProjectDoc(projectList);
				doc.add(new TextField("projectsAll", projects.toString(),
						Field.Store.YES));
				// combinedAllData.append(projects.toString() + " - ");
				if (ls.getInitiativeProjectSharedFlag() == null
						|| ls.getInitiativeProjectSharedFlag() == "") {
					sharedFlag = "N";
				} else {
					sharedFlag = ls.getInitiativeProjectSharedFlag();
				}
				StringBuilder projectsShared = createInitiativeProjectSharedDoc(
						projectList, sharedFlag);
				doc.add(new TextField("projectsShared", projectsShared
						.toString(), Field.Store.YES));
				// combinedSharedData.append(projectsShared + " - ");
			}
			if (csList != null) {
				StringBuilder cs = createCustomersSupplierstDoc(csList);
				doc.add(new TextField("customersSuppliersAll", cs.toString(),
						Field.Store.YES));
				// combinedAllData.append(cs.toString() + " - ");
				if (ls.getCustomerSuppliersSharedFlag() == null
						|| ls.getCustomerSuppliersSharedFlag() == "") {
					sharedFlag = "N";
				} else {
					sharedFlag = ls.getCustomerSuppliersSharedFlag();
				}
				StringBuilder csShared = createCustomersSuppliersSharedDoc(
						csList, sharedFlag);
				doc.add(new TextField("customersSuppliersShared", csShared
						.toString(), Field.Store.YES));
				// combinedSharedData.append(csShared + " - ");
			}
			if (lprList != null) {
				StringBuilder lp = createLanguagesDoc(lprList);
				doc.add(new TextField("languagesAll", lp.toString(),
						Field.Store.YES));
				// combinedAllData.append(lp.toString() + " - ");
				if (ls.getLanguagesSharedFlag() == null
						|| ls.getLanguagesSharedFlag() == "") {
					sharedFlag = "N";
				} else {
					sharedFlag = ls.getLanguagesSharedFlag();
				}
				StringBuilder lpShared = createLanguagesSharedDoc(lprList,
						sharedFlag);
				doc.add(new TextField("languagesShared", lpShared.toString(),
						Field.Store.YES));
				// combinedSharedData.append(lpShared + " - ");
			}
			if (eaList != null) {
				StringBuilder ea = createExternalAffiliationsDoc(eaList);
				doc.add(new TextField("externalAffiliationsAll", ea.toString(),
						Field.Store.YES));
				// combinedAllData.append(ea.toString() + " - ");
				if (ls.getExternalAffiliationsSharedFlag() == null
						|| ls.getExternalAffiliationsSharedFlag() == "") {
					sharedFlag = "N";
				} else {
					sharedFlag = ls.getExternalAffiliationsSharedFlag();
				}
				StringBuilder eaShared = createExternalAffiliationsSharedDoc(
						eaList, sharedFlag);
				doc.add(new TextField("externalAffiliationsShared", eaShared
						.toString(), Field.Store.YES));
				// combinedSharedData.append(eaShared + " - ");
			}

			if (ls.getInterests() != null) {
				doc.add(new TextField("interestsAll", ls.getInterests()
						.toString(), Field.Store.YES));
				// combinedAllData.append(ls.getInterests() + " - ");
				if (ls.getInterestsSharedFlag() != null
						&& ls.getInterestsSharedFlag().equalsIgnoreCase("Y")) {
					doc.add(new TextField("interestsShared", ls.getInterests()
							.toString(), Field.Store.YES));
					// combinedSharedData.append(ls.getInterests() + " - ");
				}
			}

			if (ls.getCareerInterests() != null) {
				doc.add(new TextField("careerInterestsAll", ls
						.getCareerInterests().toString(), Field.Store.YES));
				// combinedAllData.append(ls.getCareerInterests() + " - ");
				if (ls.getCareerSharedFlag() != null
						&& ls.getCareerSharedFlag().equalsIgnoreCase("Y")) {
					doc.add(new TextField("careerInterestsShared", ls
							.getCareerInterests().toString(), Field.Store.YES));
					// combinedSharedData.append(ls.getCareerInterests() +
					// " - ");
				}
			}
			if (ls.getProfessionalSummary() != null) {
				doc.add(new TextField("professionalSummaryShared", ls
						.getProfessionalSummary(), Field.Store.YES));
				// combinedSharedData.append(ls.getProfessionalSummary() +
				// " - ");
				// combinedAllData.append(ls.getProfessionalSummary() + " - ");
			}
			
			if (ls.getCareerOpportunity() != null) {
				doc.add(new TextField("talentPoolAll", ls.getCareerOpportunity(),
						Field.Store.YES));
			}
			
			/*if(ls.getIfg().equalsIgnoreCase("GE Global Operations") ||
				ls.getIfg().equalsIgnoreCase("GE Corporate") ||
				ls.getIfg().equalsIgnoreCase("GE Digital") ||
				ls.getIfg().equalsIgnoreCase("GE Global Growth Organization")){
				if (ls.getCareerOpportunity() != null) {
					doc.add(new TextField("talentPoolAll", ls.getCareerOpportunity(),
							Field.Store.YES));
				}
			}else{
				if (ls.getTalentPool() != null) {
					doc.add(new TextField("talentPoolAll", ls.getTalentPool(),
							Field.Store.YES));
					// combinedAllData.append(ls.getTalentPool() + " - ");
				}
			}*/
			
			if (ls.getRelocateOutside() != null) {
				doc.add(new TextField("relocateOutsideAll", ls
						.getRelocateOutside().toString(), Field.Store.YES));
				if (ls.getWorkMobilityShared() != null
						&& ls.getWorkMobilityShared().equalsIgnoreCase("Y")) {
					doc.add(new TextField("relocateOutsideShared", ls
							.getRelocateOutside().toString(), Field.Store.YES));
				
				}
			}
			if (ls.getRelocateWithin() != null) {
				doc.add(new TextField("relocateWithinAll", ls
						.getRelocateWithin().toString(), Field.Store.YES));
				// combinedAllData.append(ls.getInterests() + " - ");
				if (ls.getWorkMobilityShared() != null
						&& ls.getWorkMobilityShared().equalsIgnoreCase("Y")) {
					doc.add(new TextField("relocateWithinShared", ls
							.getRelocateWithin().toString(), Field.Store.YES));
					// combinedSharedData.append(ls.getInterests() + " - ");
				}
			}
			if(wmList!=null){
				StringBuilder mobilityAll = new StringBuilder();
				for (WorkMobilityCountry wm : wmList) {
					if (wm.getMobilityCountry() != null) {
						mobilityAll.append(wm.getMobilityCountry().toString() + " | ");
					}
				}
				doc.add(new TextField("mobilityCountryAll", mobilityAll.toString(),
						Field.Store.YES));
				if (ls.getWorkMobilityShared() == null
						|| ls.getWorkMobilityShared() == "") {
					sharedFlag = "N";
				} else {
					sharedFlag = ls.getWorkMobilityShared();
				}
				StringBuilder mobilityShared = new StringBuilder();
				if (sharedFlag.equalsIgnoreCase("Y")) {
					for (WorkMobilityCountry wm : wmList) {
						if (wm.getMobilityCountry() != null) {
							mobilityShared.append(wm.getMobilityCountry().toString() + " | ");
						}
					}
				}
				doc.add(new TextField("mobilityCountryShared", mobilityShared
						.toString(), Field.Store.YES));
			}
			
			if(lpbList!=null){
				//StringBuilder lpbDefaultText = new StringBuilder();
				if (lpbList != null) {
					for (LPBridgeAssignment lpb : lpbList) {
						if (lpb.getAssignmentLeaderFor() != null) {
							//lpbDefaultText.append(lpb.getAssignmentLeaderFor() + " - ");
							doc.add(new TextField("assignmentLeaderFor", lpb.getAssignmentLeaderFor().toString(),
									Field.Store.YES));
						}
						if (lpb.getAssignmentLeaderName() != null) {
							//lpbDefaultText.append(lpb.getAssignmentLeaderFor() + " - ");
							doc.add(new TextField("assignmentLeaderName", lpb.getAssignmentLeaderName().toString(),
									Field.Store.YES));
						}
						if (lpb.getAssignmentSubBusiness() != null) {
							//lpbDefaultText.append(lpb.getAssignmentLeaderFor() + " - ");
							doc.add(new TextField("assignmentSubBusiness", lpb.getAssignmentSubBusiness().toString(),
									Field.Store.YES));
						}
						if (lpb.getAssignmentTitle() != null) {
							//lpbDefaultText.append(lpb.getAssignmentLeaderFor() + " - ");
							doc.add(new TextField("assignmentTitle", lpb.getAssignmentTitle().toString(),
									Field.Store.YES));
						}
						if (lpb.getRotationNumber() != null) {
							//lpbDefaultText.append(lpb.getAssignmentLeaderFor() + " - ");
							doc.add(new TextField("rotationNumber", lpb.getRotationNumber().toString(),
									Field.Store.YES));
						}
					}
				}			
			}
			
			if(eeList != null && !eeList.isEmpty()) {
				StringBuilder expertiseAll = new StringBuilder();
				for (EmployeeExpertise ee : eeList) {
					if(ee.getExpertise() != null) {
						if (ee.getExpertise().getName() != null) {
							expertiseAll.append(ee.getExpertise().getName().toString().toLowerCase() + " - ");
						}
					}
				}
				doc.add(new TextField("eeExpertiseAll", expertiseAll.toString(),
						Field.Store.YES));
			}
			
			if(mentInterestList != null && !mentInterestList.isEmpty()) {
				StringBuilder mentorAllInterest = new StringBuilder();
				StringBuilder menteeAllInterest = new StringBuilder();
				for (Mentoring interest : mentInterestList) {
					if(interest.getConnectFlag()) {
						menteeAllInterest.append(interest.getDescription().toString().toLowerCase() + " - ");
					} else {
						mentorAllInterest.append(interest.getDescription().toString().toLowerCase() + " - ");
					}
				}
				if(!menteeAllInterest.toString().isEmpty()) {
					doc.add(new TextField("menteeAllInterest", menteeAllInterest.toString(), Field.Store.YES));
				}
				if(!mentorAllInterest.toString().isEmpty()) {
					doc.add(new TextField("mentorAllInterest", mentorAllInterest.toString(), Field.Store.YES));
				}
			}
			
			if (ls.getMenteeInfo() != null) {
				doc.add(new TextField("menteeAll", ls
						.getMenteeInfo().toString(), Field.Store.YES));
				if (ls.getMentoringSharedFlag() != null
						&& ls.getMentoringSharedFlag().equalsIgnoreCase("Y")) {
					doc.add(new TextField("menteeShared", ls
							.getMenteeInfo().toString(), Field.Store.YES));
				}
			}
			if (ls.getMentorInfo() != null) {
				doc.add(new TextField("mentorAll", ls
						.getMentorInfo().toString(), Field.Store.YES));
				if (ls.getMentoringSharedFlag() != null
						&& ls.getMentoringSharedFlag().equalsIgnoreCase("Y")) {
					doc.add(new TextField("mentorShared", ls
							.getMentorInfo().toString(), Field.Store.YES));
				}
			}
			if (ls.getMentoringDesc() != null) {
				doc.add(new TextField("mentoringDesc", ls
						.getMentoringDesc().toString(), Field.Store.YES));
			}
			
			if(ls.getConnectionSharedFlag() != null) {
				doc.add(new TextField("connectionShared", ls
						.getConnectionSharedFlag().toString(), Field.Store.YES));
			}
			
			// below 3 fields for mentoring connections feature
			if (ls.getConnectMenteeInfo() != null) {
				doc.add(new TextField("connectMenteeAll", ls
						.getConnectMenteeInfo().toString(), Field.Store.YES));
			}
			if (ls.getConnectMentorInfo() != null) {
				doc.add(new TextField("connectMentorAll", ls
						.getConnectMentorInfo().toString(), Field.Store.YES));
			}
			if (ls.getConnectMentoDesc() != null) {
				doc.add(new TextField("connectMentoDesc", ls
						.getConnectMentoDesc().toString(), Field.Store.YES));
			}
			
			doc.add(new TextField("combinedSharedData", combinedSharedData
					.toString(), Field.Store.NO));
			doc.add(new TextField("combinedAllData",
					combinedAllData.toString(), Field.Store.NO));
		}
		return doc;
	}

	// To create work history lucene index document
	private StringBuilder createWorkHistoryDoc(List<LuceneEmpHistoryDto> emhList) {
		StringBuilder emhDefaultText = new StringBuilder();
		if (emhList != null) {
			for (LuceneEmpHistoryDto emh : emhList) {
				if (emh.getBusinessCard() != null) {
					emhDefaultText.append(emh.getBusinessCard().toString()
							+ " - ");
				}
				if (emh.getFunctionDes() != null) {
					emhDefaultText.append(emh.getFunctionDes().toString()
							+ " - ");
				}
				if (emh.getGeBusiness() != null) {
					emhDefaultText.append(emh.getGeBusiness().toString()
							+ " - ");
				}
				if (emh.getLocation() != null) {
					emhDefaultText.append(emh.getLocation().toString() + " - ");
				}
				if (emh.getManager() != null) {
					emhDefaultText.append(emh.getManager().toString() + " - ");
				}
				if (emh.getExpDesc() != null) {
					emhDefaultText.append(emh.getExpDesc().toString() + " | ");
				}
			}
		}
		return emhDefaultText;
	}

	// To create work history lucene index document
	private StringBuilder createWorkHistorySharedDoc(
			List<LuceneEmpHistoryDto> emhList, String whShared) {
		StringBuilder emhDefaultText = new StringBuilder();
		if (emhList != null && whShared.equalsIgnoreCase("Y")) {
			for (LuceneEmpHistoryDto emh : emhList) {
				if (emh.getBusinessCard() != null) {
					emhDefaultText.append(emh.getBusinessCard().toString()
							+ " - ");
				}
				if (emh.getFunctionDes() != null) {
					emhDefaultText.append(emh.getFunctionDes().toString()
							+ " - ");
				}
				if (emh.getGeBusiness() != null) {
					emhDefaultText.append(emh.getGeBusiness().toString()
							+ " - ");
				}
				if (emh.getLocation() != null) {
					emhDefaultText.append(emh.getLocation().toString() + " - ");
				}
				if (emh.getManager() != null) {
					emhDefaultText.append(emh.getManager().toString() + " - ");
				}
				if (emh.getExpDesc() != null) {
					emhDefaultText.append(emh.getExpDesc().toString() + " | ");
				}
			}
		}
		return emhDefaultText;
	}

	// To create all training lucene index document
	private StringBuilder createTrainingDoc(List<LuceneTrainingDto> trngList,
			List<LuceneEducationDto> eduList) {
		StringBuilder trainingDefaultText = new StringBuilder();
		if (trngList != null) {
			for (LuceneTrainingDto trng : trngList) {
				if (trng.getTrngID() != null) {
					trainingDefaultText.append(trng.getTrngID().toString()
							+ " - ");
				}
				if (trng.getTrngDescriptiom() != null) {
					trainingDefaultText.append(trng.getTrngDescriptiom()
							.toString() + " | ");
				}
			}
		}
		if (eduList != null) {
			for (LuceneEducationDto edu : eduList) {
				if (edu.getEduUniversity() != null) {
					trainingDefaultText.append(edu.getEduUniversity()
							.toString() + " - ");
				}
				if (edu.getEduCountry() != null) {
					trainingDefaultText.append(edu.getEduCountry().toString()
							+ " - ");
				}
				if (edu.getEduDegree() != null) {
					trainingDefaultText.append(edu.getEduDegree().toString()
							+ " - ");
				}
				if (edu.getEduMajor() != null) {
					trainingDefaultText.append(edu.getEduMajor().toString()
							+ " | ");
				}
			}
		}
		return trainingDefaultText;
	}

	// To create training lucene index document
	private StringBuilder createTrainingSharedDoc(
			List<LuceneTrainingDto> trngList, List<LuceneEducationDto> eduList,
			String eduShared) {
		StringBuilder trainingDefaultText = new StringBuilder();
		if (trngList != null) {
			for (LuceneTrainingDto trng : trngList) {
				if (trng.getSharedFlag().equalsIgnoreCase("Y")) {
					if (trng.getTrngID() != null) {
						trainingDefaultText.append(trng.getTrngID().toString()
								+ " - ");
					}
					if (trng.getTrngDescriptiom() != null) {
						trainingDefaultText.append(trng.getTrngDescriptiom()
								.toString() + " | ");
					}
				}
			}
		}
		if (eduList != null && eduShared.equalsIgnoreCase("Y")) {
			for (LuceneEducationDto edu : eduList) {
				if (edu.getEduUniversity() != null) {
					trainingDefaultText.append(edu.getEduUniversity()
							.toString() + " - ");
				}
				if (edu.getEduCountry() != null) {
					trainingDefaultText.append(edu.getEduCountry().toString()
							+ " - ");
				}
				if (edu.getEduDegree() != null) {
					trainingDefaultText.append(edu.getEduDegree().toString()
							+ " - ");
				}
				if (edu.getEduMajor() != null) {
					trainingDefaultText.append(edu.getEduMajor().toString()
							+ " | ");
				}

			}
		}
		return trainingDefaultText;
	}

	// To create leadership program lucene index document
	private Document createLeadershipPrgDoc(LuceneLeadershipDto lp) {
		Document doc = new Document();
		StringBuilder leadershipDefaultText = new StringBuilder();

		if (lp != null) {
			// for child filtering
			FieldType fType = new FieldType(StringField.TYPE_STORED);
			fType.setOmitNorms(false);
			doc.add(new Field("type", "ldrprg", fType));

			if (lp.getPrgName() != null) {
				doc.add(new TextField("prgName", lp.getPrgName().toString(),
						Field.Store.YES));
				leadershipDefaultText.append(lp.getPrgName().toString() + " ");
			}

			if (lp.getPrgLongName() != null) {
				doc.add(new TextField("prgLongName", lp.getPrgLongName()
						.toString(), Field.Store.YES));
				leadershipDefaultText.append(lp.getPrgLongName().toString()
						+ " ");
			}
			if (lp.getPrgStatus() != null) {
				doc.add(new TextField("prgStatus",
						lp.getPrgStatus().toString(), Field.Store.YES));
				leadershipDefaultText
						.append(lp.getPrgStatus().toString() + " ");
			}

			doc.add(new TextField("leadershipDefault", leadershipDefaultText
					.toString(), Field.Store.NO));
		}
		return doc;
	}

	// To create external affiliations lucene index
	private StringBuilder createExternalAffiliationsSharedDoc(
			List<AffinityGroups> eaList, String eaShared) {
		StringBuilder emhDefaultText = new StringBuilder();
		if (eaList != null && eaShared.equalsIgnoreCase("Y")) {
			for (AffinityGroups ip : eaList) {
				if (ip.getGroupName() != null) {
					emhDefaultText.append(ip.getGroupName().toString() + " - ");
				}
				if (ip.getPosition() != null) {
					emhDefaultText.append(ip.getPosition().toString() + " | ");
				}

			}
		}
		return emhDefaultText;
	}

	private StringBuilder createExternalAffiliationsDoc(
			List<AffinityGroups> eaList) {
		StringBuilder emhDefaultText = new StringBuilder();
		if (eaList != null) {
			for (AffinityGroups ip : eaList) {
				if (ip.getGroupName() != null) {
					emhDefaultText.append(ip.getGroupName().toString() + " - ");
				}
				if (ip.getPosition() != null) {
					emhDefaultText.append(ip.getPosition().toString() + " | ");
				}

			}
		}
		return emhDefaultText;
	}

	// To create languages lucene index
	private StringBuilder createLanguagesSharedDoc(
			List<LanguageProficiency> lprList, String lpShared) {
		StringBuilder emhDefaultText = new StringBuilder();
		if (lprList != null && lpShared.equalsIgnoreCase("Y")) {
			for (LanguageProficiency ip : lprList) {
				/*
				 * '|' character signifies end of record if (ip.getLanguage() !=
				 * null) { emhDefaultText.append(ip.getLanguage().toString() +
				 * " - "); } if (ip.getLevel() != null) {
				 * emhDefaultText.append(ip.getLevel().toString() + " | "); }
				 */
				if (ip.getLanguage() != null) {
					emhDefaultText.append(ip.getLanguage().toString().toLowerCase() + " - ");
				}
			}
		}
		return emhDefaultText;
	}

	private StringBuilder createLanguagesDoc(List<LanguageProficiency> lprList) {
		StringBuilder emhDefaultText = new StringBuilder();
		if (lprList != null) {
			for (LanguageProficiency ip : lprList) {
				/*
				 * '|' character signifies end of record if (ip.getLanguage() !=
				 * null) { emhDefaultText.append(ip.getLanguage().toString() +
				 * " - "); } if (ip.getLevel() != null) {
				 * emhDefaultText.append(ip.getLevel().toString() + " | "); }
				 */
				if (ip.getLanguage() != null) {
					emhDefaultText.append(ip.getLanguage().toString().toLowerCase() + " - ");
				}

			}
		}
		return emhDefaultText;
	}

	// To create initiatives & projects lucene index
	private StringBuilder createInitiativeProjectDoc(
			List<IntiativesandProject> projectList) {
		StringBuilder emhDefaultText = new StringBuilder();
		if (projectList != null) {
			for (IntiativesandProject ip : projectList) {
				if (ip.getTitle() != null) {
					emhDefaultText.append(ip.getTitle().toString() + " - ");
				}
				if (ip.getDescription() != null) {
					emhDefaultText.append(ip.getDescription().toString()
							+ " | ");
				}

			}
		}
		return emhDefaultText;
	}

	private StringBuilder createInitiativeProjectSharedDoc(
			List<IntiativesandProject> projectList, String ipShared) {
		StringBuilder emhDefaultText = new StringBuilder();
		if (projectList != null && ipShared.equalsIgnoreCase("Y")) {
			for (IntiativesandProject ip : projectList) {
				if (ip.getTitle() != null) {
					emhDefaultText.append(ip.getTitle().toString() + " - ");
				}
				if (ip.getDescription() != null) {
					emhDefaultText.append(ip.getDescription().toString()
							+ " | ");
				}

			}
		}
		return emhDefaultText;
	}

	// To create customer and suppliers lucene index
	private StringBuilder createCustomersSupplierstDoc(
			List<CustomerandSuppliers> csList) {
		StringBuilder emhDefaultText = new StringBuilder();
		if (csList != null) {
			for (CustomerandSuppliers ip : csList) {
				if (ip.getTitle() != null) {
					emhDefaultText.append(ip.getTitle().toString() + " - ");
				}
				if (ip.getLocation() != null) {
					emhDefaultText.append(ip.getLocation().toString() + " - ");
				}
				if (ip.getDescription() != null) {
					emhDefaultText.append(ip.getDescription().toString()
							+ " | ");
				}

			}
		}
		return emhDefaultText;
	}

	private StringBuilder createCustomersSuppliersSharedDoc(
			List<CustomerandSuppliers> csList, String csShared) {
		StringBuilder emhDefaultText = new StringBuilder();
		if (csList != null && csShared.equalsIgnoreCase("Y")) {
			for (CustomerandSuppliers ip : csList) {
				if (ip.getTitle() != null) {
					emhDefaultText.append(ip.getTitle().toString() + " - ");
				}
				if (ip.getLocation() != null) {
					emhDefaultText.append(ip.getLocation().toString() + " - ");
				}
				if (ip.getDescription() != null) {
					emhDefaultText.append(ip.getDescription().toString()
							+ " | ");
				}

			}
		}
		return emhDefaultText;
	}

	// aclList for lucene search
	private void indexAclAndPrivateFields(LuceneSearchCompDto el, Document doc) {

		if (el != null) {
			if (el.getAcl().getSUPV() != null) {
				doc.add(new TextField("acl_SUPV", el.getAcl().getSUPV()
						.toString(), Field.Store.NO));
			}
			if (el.getAcl().getMGR() != null) {
				doc.add(new TextField("acl_MGR", el.getAcl().getMGR()
						.toString(), Field.Store.NO));
			}
			if (el.getAcl().getORG_MGR() != null) {
				doc.add(new TextField("acl_ORG_MGR", el.getAcl().getORG_MGR()
						.toString(), Field.Store.NO));
			}
			if (el.getAcl().getORG_HRM() != null) {
				doc.add(new TextField("acl_ORG_HRM", el.getAcl().getORG_HRM()
						.toString(), Field.Store.NO));
			}
			if (el.getAcl().getHRM() != null) {
				doc.add(new TextField("acl_HRM", el.getAcl().getHRM()
						.toString(), Field.Store.NO));
			}
			if (el.getAcl().getHRM_SPL() != null) {
				doc.add(new TextField("acl_HRM_SPL", el.getAcl().getHRM_SPL()
						.toString(), Field.Store.NO));
			}
			if (el.getAcl().getSHRM() != null) {
				doc.add(new TextField("acl_SHRM", el.getAcl().getSHRM()
						.toString(), Field.Store.NO));
			}

			if (el.getAcl().getSHRM_F() != null) {
				doc.add(new TextField("acl_SHRM_F", el.getAcl().getSHRM_F()
						.toString(), Field.Store.NO));
			}
			if (el.getAcl().getSHRM_R() != null) {
				doc.add(new TextField("acl_SHRM_R", el.getAcl().getSHRM_R()
						.toString(), Field.Store.NO));
			}
			if (el.getAcl().getSHRM_GL() != null) {
				doc.add(new TextField("acl_SHRM_GL", el.getAcl().getSHRM_GL()
						.toString(), Field.Store.NO));
			}

			if (el.getAcl().getMATRIX_HRM() != null) {
				doc.add(new TextField("acl_MATRIX_HRM", el.getAcl()
						.getMATRIX_HRM().toString(), Field.Store.NO));
			}
			if (el.getAcl().getO_S_MANAGER() != null) {
				doc.add(new TextField("acl_O_S_MANAGER", el.getAcl()
						.getO_S_MANAGER().toString(), Field.Store.NO));
			}
			if (el.getAcl().getO_S_MANAGER_CP() != null) {
				doc.add(new TextField("acl_O_S_MANAGER_CP", el.getAcl()
						.getO_S_MANAGER_CP().toString(), Field.Store.NO));
			}
			if (el.getAcl().getO_S_MANAGER_F() != null) {
				doc.add(new TextField("acl_O_S_MANAGER_F", el.getAcl()
						.getO_S_MANAGER_F().toString(), Field.Store.NO));
			}
			if (el.getAcl().getO_S_MANAGER_GL() != null) {
				doc.add(new TextField("acl_O_S_MANAGER_GL", el.getAcl()
						.getO_S_MANAGER_GL().toString(), Field.Store.NO));
			}
			if (el.getAcl().getO_S_MANAGER_R() != null) {
				doc.add(new TextField("acl_O_S_MANAGER_R", el.getAcl()
						.getO_S_MANAGER_R().toString(), Field.Store.NO));
			}

			if (el.getAcl().getO_TD_MANAGER() != null) {
				doc.add(new TextField("acl_O_TD_MANAGER", el.getAcl()
						.getO_TD_MANAGER().toString(), Field.Store.NO));
			}
			if (el.getAcl().getO_TD_MANAGER_CP() != null) {
				doc.add(new TextField("acl_O_TD_MANAGER_CP", el.getAcl()
						.getO_TD_MANAGER_CP().toString(), Field.Store.NO));
			}
			if (el.getAcl().getO_TD_MANAGER_F() != null) {
				doc.add(new TextField("acl_O_TD_MANAGER_F", el.getAcl()
						.getO_TD_MANAGER_F().toString(), Field.Store.NO));
			}
			if (el.getAcl().getO_TD_MANAGER_GL() != null) {
				doc.add(new TextField("acl_O_TD_MANAGER_GL", el.getAcl()
						.getO_TD_MANAGER_GL().toString(), Field.Store.NO));
			}
			if (el.getAcl().getO_TD_MANAGER_R() != null) {
				doc.add(new TextField("acl_O_TD_MANAGER_R", el.getAcl()
						.getO_TD_MANAGER_R().toString(), Field.Store.NO));
			}

			if (el.getAcl().getHRM_VIEW() != null) {
				doc.add(new TextField("acl_HRM_VIEW", el.getAcl().getHRM_VIEW()
						.toString(), Field.Store.NO));
			}
			if (el.getAcl().getHR_BP() != null) {
				doc.add(new TextField("acl_HR_BP", el.getAcl().getHR_BP()
						.toString(), Field.Store.NO));
			}

			if (el.getAcl().getO_TD_NO_COMP() != null) {
				doc.add(new TextField("acl_O_TD_NO_COMP", el.getAcl()
						.getO_TD_NO_COMP().toString(), Field.Store.NO));
			}
			if (el.getAcl().getADMIN_STAFF() != null) {
				doc.add(new TextField("acl_ADMIN_STAFF", el.getAcl()
						.getADMIN_STAFF().toString(), Field.Store.NO));
			}
			if (el.getAcl().getSTAFF_HS_STAFFING_SPL() != null) {
				doc.add(new TextField("acl_STAFF_HS_STAFFING_SPL", el.getAcl()
						.getSTAFF_HS_STAFFING_SPL().toString(), Field.Store.NO));
			}
			if (el.getAcl().getSTAFF_REQ_FLDR_OWNR() != null) {
				doc.add(new TextField("acl_STAFF_REQ_FLDR_OWNR", el.getAcl()
						.getSTAFF_REQ_FLDR_OWNR().toString(), Field.Store.NO));
			}
			if (el.getAcl().getSTAFF_HS_LTD_ACCESS() != null) {
				doc.add(new TextField("acl_STAFF_HS_LTD_ACCESS", el.getAcl()
						.getSTAFF_HS_LTD_ACCESS().toString(), Field.Store.NO));
			}
			if (el.getAcl().getSTAFF_HS_US_LEAD_RCTR() != null) {
				doc.add(new TextField("acl_STAFF_HS_US_LEAD_RCTR", el.getAcl()
						.getSTAFF_HS_US_LEAD_RCTR().toString(), Field.Store.NO));
			}
			if (el.getAcl().getMGR_1O1() != null) {
				doc.add(new TextField("acl_MGR_1O1", el.getAcl()
						.getMGR_1O1().toString(), Field.Store.NO));
			}
			if (el.getAcl().getLP_GLOBAL_PROGRAM_MGR() != null) {
				doc.add(new TextField("acl_LP_GLOBAL_PROGRAM_MGR", el.getAcl()
						.getLP_GLOBAL_PROGRAM_MGR().toString(), Field.Store.NO));
			}
			if (el.getAcl().getLP_PROGRAM_MGR() != null) {
				doc.add(new TextField("acl_LP_PROGRAM_MGR", el.getAcl()
						.getLP_PROGRAM_MGR().toString(), Field.Store.NO));
			}
			if (el.getAcl().getLP_OPERATIONS() != null) {
				doc.add(new TextField("acl_LP_OPERATIONS", el.getAcl()
						.getLP_OPERATIONS().toString(), Field.Store.NO));
			}

		}
	}

	// List of all public fields
	public List<String> getAllPublicFields() {
		return new ArrayList<String>(Arrays.asList("employeeDetails",
				"managerDetails", "sso", "empFirstName", "empLastName",
				"empName", "preferredName", "empLocalLangName", "empAsciiName",
				"title", "empEmail", "empWorkPhone", "empMobile",
				"empManagerName", "empManagerSso", "empManagerAsciiName",
				"mgrPreferredName", "mgrTitle", "mgrEmail", "mgrPhone",
				"mgrMobile", "ifg", "business", "subBusiness", "organization",
				"jobFunction", "jobFamily", "region", "country", /* "band", */
				"workHistoryShared", "educationTrainingShared",
				"ssoName",
				"emailPhone",
				"employeeLocation",
				"empReportingBusiness",
				"empReportingIFG",
				"personType",
				"directoryInclusion",
				"techDisciplineSTD",
				"techDisciplineKW",
				"interestsShared",
				"careerInterestsShared",
				"professionalSummaryShared","menteeShared","mentorShared",
				"talentPoolAll",
				// Acl data
				"acl_SUPV", "acl_MGR", "acl_ORG_MGR", "acl_HRM", "acl_ORG_HRM",
				"acl_HRM_SPL", "acl_SHRM", "acl_SHRM_F", "acl_SHRM_R",
				"acl_SHRM_GL", "acl_MATRIX_HRM", "acl_O_S_MANAGER",
				"acl_O_S_MANAGER_CP", "acl_O_S_MANAGER_F",
				"acl_O_S_MANAGER_GL", "acl_O_S_MANAGER_R", "acl_O_TD_MANAGER",
				"acl_O_TD_MANAGER_CP", "acl_O_TD_MANAGER_F",
				"acl_O_TD_MANAGER_GL", "acl_O_TD_MANAGER_R", "acl_HRM_VIEW",
				"acl_HR_BP", "acl_O_TD_NO_COMP", "acl_ADMIN_STAFF",
				"acl_STAFF_HS_STAFFING_SPL", "acl_STAFF_REQ_FLDR_OWNR",
				"acl_STAFF_HS_LTD_ACCESS", "acl_STAFF_HS_US_LEAD_RCTR", "acl_MGR_1O1", "acl_LP_GLOBAL_PROGRAM_MGR", 
				"acl_LP_PROGRAM_MGR", "acl_LP_OPERATIONS"));

	}

	/**
	 * User runs a query and counts facets only without collecting the matching
	 * documents.
	 */
	private List<FacetResult> facetsOnly(IndexSearcher searcher,
			TaxonomyReader taxoReader, BooleanQuery mainQuery,
			FacetsCollector fc, FacetsConfig config) throws IOException {
		// config = new FacetsConfig();

		FacetsCollector.search(searcher, mainQuery, 10, fc);

		List<FacetResult> results = new ArrayList<>();

		Facets facets = new FastTaxonomyFacetCounts("facet_ifg", taxoReader,
				config, fc);
		Facets facets1 = new FastTaxonomyFacetCounts("facet_business",
				taxoReader, config, fc);
		Facets facets2 = new FastTaxonomyFacetCounts("facet_subBusiness",
				taxoReader, config, fc);
		Facets facets3 = new FastTaxonomyFacetCounts("facet_function",
				taxoReader, config, fc);
		Facets facets4 = new FastTaxonomyFacetCounts("facet_country",
				taxoReader, config, fc);
		Facets facets5 = new FastTaxonomyFacetCounts("facet_band", taxoReader,
				config, fc);
		Facets facets6 = new FastTaxonomyFacetCounts("facet_personType",
				taxoReader, config, fc);
		Facets facets7 = new FastTaxonomyFacetCounts("facet_techDiscipline",
				taxoReader, config, fc);
		Facets facets8 = new FastTaxonomyFacetCounts("facet_family", taxoReader, config, fc);
		//Facets facets9= new FastTaxonomyFacetCounts("facet_city", taxoReader, config, fc);	

		results.add(facets.getTopChildren(10, "ifg"));
		results.add(facets1.getTopChildren(10, "business"));
		results.add(facets2.getTopChildren(10, "subBusiness"));
		results.add(facets3.getTopChildren(10, "jobFunction"));
		results.add(facets4.getTopChildren(10, "country"));
		results.add(facets5.getTopChildren(10, "band"));
		results.add(facets6.getTopChildren(10, "personType"));
		results.add(facets7.getTopChildren(10, "techDisciplineKW"));
		results.add(facets8.getTopChildren(10, "jobFamily"));
		//results.add(facets9.getTopChildren(10, "empCity"));

		return results;
	}

	/**
	 * Used to retrieve the Technical Discipline taxonomy facets
	 */
	public List<FacetResult> facetTechnicalDiscipline() throws IOException {
		// config = new FacetsConfig();
		IndexReader reader = DirectoryReader.open(this.dir);
		IndexSearcher searcher = new IndexSearcher(reader);
		/*
		 * DirectoryTaxonomyReader taxoReader = new DirectoryTaxonomyReader(
		 * taxoDir);
		 */
		List<FacetResult> results = new ArrayList<>();
		SortedSetDocValuesReaderState state = new DefaultSortedSetDocValuesReaderState(
				reader, "facet_techDiscipline");
		FacetsCollector fc = new FacetsCollector();
		QueryParser qp = new QueryParser("techDisciplineKW", this.analyzer);
		try {
			qp.setAllowLeadingWildcard(true);
			Query q = qp.parse("*");

			FacetsCollector.search(searcher, q, 10, fc);

			Facets facets = new SortedSetDocValuesFacetCounts(state, fc);
			results.add(facets.getTopChildren(1100, "techDisciplineKW"));

			// results.sort(null);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return results;
	}

	/**
	 * Used to retrieve the Expertise definitions
	 */
	public AutoCompleteDto getExpertiseByParam(AutoCompleteDto autoCompDto) {
		AutoCompleteDto autoCompResDto = new AutoCompleteDto();
		List<AutoCompleteRowModel> rows = new ArrayList<AutoCompleteRowModel>();
		try {
			IndexReader reader = DirectoryReader.open(this.expDir);
			IndexSearcher searcher = new IndexSearcher(reader);
			TopDocs matches = null;
			
			Query q = createExpertiseTypeAheadQuery(autoCompDto.getQuery());
			matches = searcher.search(q, 100, Sort.RELEVANCE);

			for (int i = 0; i < matches.scoreDocs.length; i++) {
				int docId = matches.scoreDocs[i].doc;
				int value = Integer.parseInt(searcher.doc(docId).get("expID"));
				String label = searcher.doc(docId).get("expName");
				rows.add(new AutoCompleteRowModel(label, String.valueOf(value)));
			}
			reader.close();
		} catch (TooManyClauses e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

		if (rows.size() > 0) {
			autoCompResDto.setAutoComplete(new AutoCompleteViewModel(rows));
		} else {
			autoCompResDto.setAutoComplete(new AutoCompleteViewModel(rows));
		}
		return autoCompResDto;
	}

	private Query createExpertiseTypeAheadQuery(String param) {
		QueryParser qp = new QueryParser("expName", this.analyzer);
		StringBuilder query = new StringBuilder();
		param = param.trim();
		if (param.startsWith("*")) {
			param = param.substring(1);
		}
		param = param.replaceAll("\\*", " ");

		String[] terms = param.split(" ");
		for (String t : terms) {
			t = t.replaceAll("[()]", "");
			if (!t.equalsIgnoreCase("AND") && !t.equalsIgnoreCase("OR")
					&& !t.equalsIgnoreCase("(") && !t.equalsIgnoreCase(")")
					&& !t.contains("\"") && !t.contains("&") && !t.equalsIgnoreCase(" ")
					&& !t.equalsIgnoreCase("")) {
				if (t.matches("^[A-Za-z0-9'+_.-]+@(.+)$")) {
					query.append("\"").append(t).append("\"");
				} else {
					query.append(t).append("* ");
				}
			} else {
				query.append(t).append(" ");
			}
		}
		
		String[] fields = { "expName" };

		MultiFieldQueryParser parser = new MultiFieldQueryParser(fields, this.analyzer);
		parser.setDefaultOperator(Operator.AND);
		try {
			Query q = parser.parse(query.toString());
			q = qp.parse(q.toString());
			return q;
		} catch (ParseException e) {
			throw new RuntimeException(e.getMessage());
		}
		
	}

	public List<ExpertiseDto> getExpertiseByParentId(int parentId) {

		List<ExpertiseDto> expertiseList = new ArrayList<>();

		try {
			IndexReader reader = DirectoryReader.open(this.expDir);
			IndexSearcher searcher = new IndexSearcher(reader);
			TopDocs matches = null;
			String fieldName = "expParentID";
			NumericRangeQuery<Integer> query = NumericRangeQuery.newIntRange(fieldName, parentId, parentId, true,	true);

			matches = searcher.search(query, 100, Sort.RELEVANCE);
			for (int i = 0; i < matches.scoreDocs.length; i++) {
				int docId = matches.scoreDocs[i].doc;
				int id = Integer.parseInt(searcher.doc(docId).get("expID"));
				String label = searcher.doc(docId).get("expName");
				ExpertiseDto exp = new ExpertiseDto();
				exp.setId(id);
				exp.setLabel(label);
				exp.setText(label);
				expertiseList.add(exp);
			}
			reader.close();
		} catch (Exception e) {
			LOG.debug("getExpertiseByParentId > " + e.getMessage());
		}
		return expertiseList;
	}
	
	/*@Cache(
			nodeName="/profile/employee/service/lucene/searchLuceneService",
			keyGeneratorClass=SearchKeyGenerator.class,
			cacheName=InfinispanCacheFactory.SEARCHCACHE	
		)*/
	public List<ExpertiseDto> getExpertiseByParentChild() {
		List<ExpertiseDto> parentList = getExpertiseByParentId(0);
		for(int i=0; i<parentList.size(); i++) {
			List<ExpertiseDto> childList = getExpertiseByParentId(parentList.get(i).getId());
			parentList.get(i).setChildren(childList);
		}
		return parentList;
	}
}
