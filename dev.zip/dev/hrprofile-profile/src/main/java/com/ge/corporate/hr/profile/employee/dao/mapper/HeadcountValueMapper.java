/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.WorkAssignmentRestricted;


public class HeadcountValueMapper implements RowMapper<WorkAssignmentRestricted> {
	
	public static final String DATA_HEADCOUNT = "wa_headcount_value";
		
	public WorkAssignmentRestricted mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		WorkAssignmentRestricted assignment = new WorkAssignmentRestricted();	
		DecimalFormat df = new DecimalFormat("0.0");
		
		assignment.setHeadCount(rs.getString(DATA_HEADCOUNT)==null?rs.getString(DATA_HEADCOUNT):df.format(Float.parseFloat(rs.getString(DATA_HEADCOUNT))));				
		
		return assignment;		
	}
}
