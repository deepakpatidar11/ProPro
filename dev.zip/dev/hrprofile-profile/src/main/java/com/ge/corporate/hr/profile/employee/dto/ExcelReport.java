package com.ge.corporate.hr.profile.employee.dto;

import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;

public class ExcelReport {
	
	private String datagroup;
	private String role;
	public String getDatagroup() {
		return datagroup;
	}
	public void setDatagroup(String datagroup) {
		this.datagroup = datagroup;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	

}
