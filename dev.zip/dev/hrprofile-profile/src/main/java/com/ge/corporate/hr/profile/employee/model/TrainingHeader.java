/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="trainingHeader")
@XmlAccessorType(XmlAccessType.FIELD)

public class TrainingHeader extends AbstractBaseModelSupport{
	
	private static final long serialVersionUID = 5969382423167807102L;

	
	@XmlAttribute(name="id")
	private Long id;
	
	@XmlElement(name="uiDisplayHeading")
	private String uiDisplayHeading;
	
	@XmlElement(name="uiDisplayHeading")
	private List<Training> trainingList;
	
	@XmlElement(name="shared")
	private boolean shared;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUiDisplayHeading() {
		return uiDisplayHeading;
	}

	public void setUiDisplayHeading(String uiDisplayHeading) {
		this.uiDisplayHeading = uiDisplayHeading;
	}

	public List<Training> getTrainingList() {
		return trainingList;
	}

	public void setTrainingList(List<Training> trainingList) {
		this.trainingList = trainingList;
	}
	
	public boolean isShared() {
		return shared;
	}

	public void setShared(boolean shared) {
		this.shared = shared;
	}

	
}
