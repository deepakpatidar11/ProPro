/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="priorperformance")
@XmlAccessorType(XmlAccessType.FIELD)
public class Performance extends AbstractBaseModelSupport{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 120570252065628774L;

	@XmlElement(name="sso")
	private Long sso;
	@XmlAttribute(name="id")
	private Long id;	
	@XmlElement(name="year")
	private Short year;
	@XmlElement(name="overallPerformance")
	private String overallPerformance;
	@XmlElement(name="overallGrowthValue")
	private String overallGrowthValue;
	@XmlElement(name="overallRating")
	private String overallRating;
	@XmlElement(name="perfEndDate")
	private Date perfEndDate;
	@XmlElement(name="reviewEndDate")
	private Date reviewEndDate;
	@XmlElement(name="ratingStatus")
	private String ratingStatus;
	@XmlElement(name="easAppraisalSystem")
	private String easAppraisalSystem;
	@XmlElement(name="easAssessmentType")
	private String easAssessmentType;
	@XmlElement(name="easAppraisalScenario")
	private String easAppraisalScenario;
	@XmlElement(name="easNoImpactIndicatorFlag")
	private String easNoImpactIndicatorFlag;
	@XmlElement(name="easAssessmentRating")
	private String easAssessmentRating;
	@XmlElement(name="geLockFlag")
	private String geLockFlag;
	@XmlElement(name="bMgrValueCdDesc")
	private String bMgrValueCdDesc;
	@XmlElement(name="bRatingStatus")
	private String bRatingStatus;
	@XmlElement(name="perfPromotability")
	private String perfPromotability;
	@XmlElement(name="perfExtraordinarySkills")
	private String perfExtraordinarySkills;
	@XmlElement(name="gvExternalFocus")
	private String gvExternalFocus;
	@XmlElement(name="gvClearThinker")
	private String gvClearThinker;
	@XmlElement(name="gvExpertise")
	private String gvExpertise;
	@XmlElement(name="gvInclusiveLeadership")
	private String gvInclusiveLeadership;
	@XmlElement(name="gvImagination")
	private String gvImagination;
	@XmlElement(name="perfStartDate")
	private Date perfStartDate;
	@XmlElement(name="reviewStartDate")
	private Date reviewStartDate;
	@XmlElement(name="iiImpactIndicator")
	private String iiImpactIndicator;
	@XmlElement(name="iiReviewStartDate")
	private Date iiReviewStartDate;
	@XmlElement(name="iiReviewEndDate")
	private Date iiReviewEndDate;
	@XmlElement(name="iiSourceSystem")
	private String iiSourceSystem;
	@XmlElement(name="iiArchiveFlag")
	private String iiArchiveFlag;
	@XmlElement(name="iiStatus")
	private String iiStatus;
	
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Short getYear() {
		return year;
	}
	public void setYear(Short year) {
		this.year = year;
	}
	public String getOverallPerformance() {
		return overallPerformance;
	}
	public void setOverallPerformance(String overallPerformance) {
		this.overallPerformance = overallPerformance;
	}
	public String getOverallGrowthValue() {
		return overallGrowthValue;
	}
	public void setOverallGrowthValue(String overallGrowthValue) {
		this.overallGrowthValue = overallGrowthValue;
	}
	public String getOverallRating() {
		return overallRating;
	}
	public void setOverallRating(String overallRating) {
		this.overallRating = overallRating;
	}
	public Date getPerfEndDate() {
		return perfEndDate;
	}
	public void setPerfEndDate(Date perfEndDate) {
		this.perfEndDate = perfEndDate;
	}
	public Date getReviewEndDate() {
		return reviewEndDate;
	}
	public void setReviewEndDate(Date reviewEndDate) {
		this.reviewEndDate = reviewEndDate;
	}
	public String getRatingStatus() {
		return ratingStatus;
	}
	public void setRatingStatus(String ratingStatus) {
		this.ratingStatus = ratingStatus;
	}
	public String getEasAppraisalSystem() {
		return easAppraisalSystem;
	}
	public void setEasAppraisalSystem(String easAppraisalSystem) {
		this.easAppraisalSystem = easAppraisalSystem;
	}
	public String getEasAssessmentType() {
		return easAssessmentType;
	}
	public void setEasAssessmentType(String easAssessmentType) {
		this.easAssessmentType = easAssessmentType;
	}
	public String getEasAppraisalScenario() {
		return easAppraisalScenario;
	}
	public void setEasAppraisalScenario(String easAppraisalScenario) {
		this.easAppraisalScenario = easAppraisalScenario;
	}
	public String getEasNoImpactIndicatorFlag() {
		return easNoImpactIndicatorFlag;
	}
	public void setEasNoImpactIndicatorFlag(String easNoImpactIndicatorFlag) {
		this.easNoImpactIndicatorFlag = easNoImpactIndicatorFlag;
	}
	public String getEasAssessmentRating() {
		return easAssessmentRating;
	}
	public void setEasAssessmentRating(String easAssessmentRating) {
		this.easAssessmentRating = easAssessmentRating;
	}
	public String getGeLockFlag() {
		return geLockFlag;
	}
	public void setGeLockFlag(String geLockFlag) {
		this.geLockFlag = geLockFlag;
	}
	public String getbMgrValueCdDesc() {
		return bMgrValueCdDesc;
	}
	public void setbMgrValueCdDesc(String bMgrValueCdDesc) {
		this.bMgrValueCdDesc = bMgrValueCdDesc;
	}
	public String getbRatingStatus() {
		return bRatingStatus;
	}
	public void setbRatingStatus(String bRatingStatus) {
		this.bRatingStatus = bRatingStatus;
	}
	public String getPerfPromotability() {
		return perfPromotability;
	}
	public void setPerfPromotability(String perfPromotability) {
		this.perfPromotability = perfPromotability;
	}
	public String getPerfExtraordinarySkills() {
		return perfExtraordinarySkills;
	}
	public void setPerfExtraordinarySkills(String perfExtraordinarySkills) {
		this.perfExtraordinarySkills = perfExtraordinarySkills;
	}
	public String getGvExternalFocus() {
		return gvExternalFocus;
	}
	public void setGvExternalFocus(String gvExternalFocus) {
		this.gvExternalFocus = gvExternalFocus;
	}
	public String getGvClearThinker() {
		return gvClearThinker;
	}
	public void setGvClearThinker(String gvClearThinker) {
		this.gvClearThinker = gvClearThinker;
	}
	public String getGvExpertise() {
		return gvExpertise;
	}
	public void setGvExpertise(String gvExpertise) {
		this.gvExpertise = gvExpertise;
	}
	public String getGvInclusiveLeadership() {
		return gvInclusiveLeadership;
	}
	public void setGvInclusiveLeadership(String gvInclusiveLeadership) {
		this.gvInclusiveLeadership = gvInclusiveLeadership;
	}
	public String getGvImagination() {
		return gvImagination;
	}
	public void setGvImagination(String gvImagination) {
		this.gvImagination = gvImagination;
	}
	public Date getPerfStartDate() {
		return perfStartDate;
	}
	public void setPerfStartDate(Date perfStartDate) {
		this.perfStartDate = perfStartDate;
	}
	public Date getReviewStartDate() {
		return reviewStartDate;
	}
	public void setReviewStartDate(Date reviewStartDate) {
		this.reviewStartDate = reviewStartDate;
	}
	public String getIiImpactIndicator() {
		return iiImpactIndicator;
	}
	public void setIiImpactIndicator(String iiImpactIndicator) {
		this.iiImpactIndicator = iiImpactIndicator;
	}
	public Date getIiReviewStartDate() {
		return iiReviewStartDate;
	}
	public void setIiReviewStartDate(Date iiReviewStartDate) {
		this.iiReviewStartDate = iiReviewStartDate;
	}
	public Date getIiReviewEndDate() {
		return iiReviewEndDate;
	}
	public void setIiReviewEndDate(Date iiReviewEndDate) {
		this.iiReviewEndDate = iiReviewEndDate;
	}
	public String getIiSourceSystem() {
		return iiSourceSystem;
	}
	public void setIiSourceSystem(String iiSourceSystem) {
		this.iiSourceSystem = iiSourceSystem;
	}
	public String getIiArchiveFlag() {
		return iiArchiveFlag;
	}
	public void setIiArchiveFlag(String iiArchiveFlag) {
		this.iiArchiveFlag = iiArchiveFlag;
	}
	public String getIiStatus() {
		return iiStatus;
	}
	public void setIiStatus(String iiStatus) {
		this.iiStatus = iiStatus;
	}
	
	
	
}
