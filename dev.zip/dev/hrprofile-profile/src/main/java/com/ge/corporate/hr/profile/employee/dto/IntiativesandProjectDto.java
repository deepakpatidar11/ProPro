package com.ge.corporate.hr.profile.employee.dto;

import java.util.List;



import com.ge.corporate.hr.profile.employee.model.IntiativesandProject;

public class IntiativesandProjectDto {

	private List<IntiativesandProject> nintiativesandProject;

	
	public List<IntiativesandProject> getNintiativesandProject() {
		return nintiativesandProject;
	}


	public void setNintiativesandProject(
			List<IntiativesandProject> nintiativesandProject) {
		this.nintiativesandProject = nintiativesandProject;
	}


	/*	public List<IntiativesandProject> getDeleteIntiativesandProject() {
		return deleteIntiativesandProject;
	}
	public void setDeleteIntiativesandProject(
			List<IntiativesandProject> deleteIntiativesandProject) {
		this.deleteIntiativesandProject = deleteIntiativesandProject;
	}*/
	@Override
	public String toString() {
		return "IntiativesandProjectDto [nintiativesandProject="
				+ nintiativesandProject + "]";
	}
	
}
