/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;
import com.ge.corporate.hr.profile.employee.serializer.CustomDateSerializer;

@XmlRootElement(name="lumpCompensation")
@XmlAccessorType(XmlAccessType.FIELD)
public class LumpCompensation extends AbstractBaseModelSupport{

	private static final long serialVersionUID = 5099578513065376768L;
	
	@XmlElement(name="sso")
	private Long sso;
	@XmlAttribute(name="id")
	private Long id;	
	@XmlElement(name="amount")
	private Date  date;
	@XmlElement(name="amount")
	private Double amount;
	@XmlElement(name="currency")
	private String currency;
	
	public LumpCompensation(){
		
	}
	
	public LumpCompensation(Long sso, Date  date, Double amount, String currency){
		this.sso = sso;
		this.date = date;
		this.amount = amount;
		this.currency = currency;
	}
	
	public void setId(Long id) {
		this.id = id;
	}	
	public Long getId() {
		return id;
	}	
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getCurrency() {
		return currency;
	}
	
	public void setCurrency(String currency) {
		this.currency = currency;
	}	
}
