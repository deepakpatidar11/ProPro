package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


import com.ge.corporate.hr.profile.employee.model.WorkAssignmentRestricted;
public class ProfessionalSummaryMapper implements RowMapper<WorkAssignmentRestricted>{

	
	
	public static final String DATA_SSO = "sso";
	public static final String DATA_SUMMARY = "professional_summary";
	
	@Override
	public WorkAssignmentRestricted mapRow(ResultSet rs, int rowNum)
			throws SQLException {

		WorkAssignmentRestricted assignment = new WorkAssignmentRestricted();	
		assignment.setId(rs.getLong(DATA_SSO));
		assignment.setProfessionalSummary(rs.getString(DATA_SUMMARY));
		
		return assignment;
	}
	
	
	
	
	
	
	
}