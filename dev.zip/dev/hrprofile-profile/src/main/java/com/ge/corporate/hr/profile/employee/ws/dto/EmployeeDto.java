/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
	package com.ge.corporate.hr.profile.employee.ws.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.dto.BaseDtoSupport;

@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name="employee")
public class EmployeeDto implements BaseDtoSupport,Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@XmlElement(name="subject")
	EmployeeBasicInfoDto basicInfo;
	
	@XmlElement(name="assignment")
	AssignmentDto assignment;	
	
	public EmployeeBasicInfoDto getBasicInfo() {
		return basicInfo;
	}

	public void setBasicInfo(EmployeeBasicInfoDto basicInfo) {
		this.basicInfo = basicInfo;
	}

	public AssignmentDto getAssignment() {
		return assignment;
	}

	public void setAssignment(AssignmentDto assignment) {
		this.assignment = assignment;
	}

	public long getId() {
		
		return 0;
	}
	
}
