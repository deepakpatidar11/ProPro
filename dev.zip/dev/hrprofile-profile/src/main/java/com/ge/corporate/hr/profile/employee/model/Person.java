package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="person")
@XmlAccessorType(XmlAccessType.FIELD)
public class Person extends AbstractBaseModelSupport{
	
	private static final long serialVersionUID = 46981221793287345L;
	
	@XmlAttribute(name="sso")
	private Long sso; //SSO Id
	
	@XmlElement(name="firstName")
	private String firstName;

	@XmlElement(name="lastName")
	private String lastName;

	@XmlElement(name="positionTitle")	
	private String positionTitle;
	
	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPositionTitle() {
		return positionTitle;
	}

	public void setPositionTitle(String positionTitle) {
		this.positionTitle = positionTitle;
	}
	
}
