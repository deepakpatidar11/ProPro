/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.security.access.prepost.PreAuthorize;

import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dao.mapper.ProgramMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.ProgramNoYearMapper;
import com.ge.corporate.hr.profile.employee.model.Program;
import com.ge.corporate.hr.profile.employee.service.cache.DaoKeyGenerator;
/**
 * Program Dao Implementation
 * @author enrique.romero
 */
public class ProgramDaoImpl extends AbstractBaseDaoSupport  implements ProgramDao{

	
	@Cache(nodeName="/profile/employee/dao/program", keyGeneratorClass = DaoKeyGenerator.class, cacheName="profile-employee-dao")
	//@PreAuthorize("hasPermission(#sso, 'Training', read)")
	public BaseModelCollection<Program> getProgramListBySso(Long sso) {
		BaseModelCollection<Program> programList = null;
		String query = this.getSql("getProgramListBySso");	
		try{
			programList = new BaseModelCollection<Program>();
			programList.setList( getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new ProgramMapper())) ;
			logger.debug("Program data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Program data Not found");
		}
		
		return programList;
	}
	
	public BaseModelCollection<Program> getProgramListAllBySso(Long sso) {
		BaseModelCollection<Program> programList = null;
		String query = this.getSql("getProgramListBySso");	
		try{
			programList = new BaseModelCollection<Program>();
			programList.setList( getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new ProgramNoYearMapper())) ;
			logger.debug("Program data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Program data Not found");
		}
		
		return programList;
	}
	
	public BaseModelCollection<Program> getProgramListOptinBySso(Long sso) {
		BaseModelCollection<Program> programList = null;
		String query = this.getSql("getProgramListOptinBySso");	
		try{
			programList = new BaseModelCollection<Program>();
			programList.setList( getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new ProgramNoYearMapper())) ;
			logger.debug("Program data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Program data Not found");
		}
		
		return programList;
	}
}
