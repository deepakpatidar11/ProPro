package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.WorkMobilityCountry;

public class WorkMobilityCountryMapper implements RowMapper<WorkMobilityCountry>  {

	public static final String DATA_SSO = "sso";
	public static final String DATA_MOBILITY_COUNTRY = "country_region";
	
	@Override
	public WorkMobilityCountry mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		WorkMobilityCountry country = new WorkMobilityCountry();
		country.setSso(rs.getLong(DATA_SSO));
		country.setMobilityCountry(rs.getString(DATA_MOBILITY_COUNTRY));
		return country;
	}

	
}
