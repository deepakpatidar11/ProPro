/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.Training;

/**
 * Education Mapper
 * @author enrique.romero
 *
 */
public class TrainingNoYearMapper implements RowMapper<Training>{
	
	public static final String DATA_DESCRIPTION = "trcat_description";	
	public static final String DATA_TYPE = "trcat_program_type";
	public static final String DATA_SCREEN_UNDER = "trcat_screen_under";
	public static final String DATA_DISPLAY_HEADING = "trcat_ui_diaplay_heading";
	public static final String DATA_COMPLETATION_DATE = "etrn_completion_date";
	public static final String DATA_COL_NUM = "trcat_colnum";
	public static final String DATA_HAS_SCREEN_UNDER = "trcat_has_screen_under";
	
	public Training mapRow(ResultSet rs, int rowNum) throws SQLException {		
		Training training = new Training();
		
		training.setTrainingTitle(rs.getString(DATA_DESCRIPTION));		
		training.setType(rs.getString(DATA_TYPE));
		training.setScreenUnder(rs.getString(DATA_SCREEN_UNDER));		
		training.setDisplayHeading(rs.getString(DATA_DISPLAY_HEADING));
		training.setColumNum(rs.getShort(DATA_COL_NUM));	
		training.setHasScreenUnder(rs.getBoolean(DATA_HAS_SCREEN_UNDER));
		
		return training;
	}

}
