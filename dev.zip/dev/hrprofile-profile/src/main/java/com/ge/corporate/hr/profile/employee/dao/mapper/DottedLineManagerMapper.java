/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.DottedLineManager;

/**
 * Currenrt Work Assignment mapper
 * @author enrique.romero
 *
 */
public class DottedLineManagerMapper implements RowMapper<DottedLineManager> {
		
	public static final String DATA_DOTTED_LINE_MANAGER = "EMP_DOTTED_LINE_MANAGER";
	public static final String DATA_DOTTED_LINE_MANAGER_NAME = "WA_DOTTED_LINE_MANAGER_NAME";
	
	
	public DottedLineManager mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		DottedLineManager dottedLineManager = new DottedLineManager();		
		
		dottedLineManager.setDottedLineManager(rs.getLong(DATA_DOTTED_LINE_MANAGER));
		dottedLineManager.setDottedLineManagerName(rs.getString(DATA_DOTTED_LINE_MANAGER_NAME));
	
		
		return dottedLineManager;		
	}
}
