/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import javax.xml.bind.annotation.XmlElement;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.Reports;

public class MyReportsDto extends AbstractBaseDtoSupport {

	/**
	 * Default serial ID
	 */
	private static final long serialVersionUID = 1L;
	@XmlElement(name="sso")
	private Long sso;

	@XmlElement(name="viewSuspendedEmployees")
	private boolean viewSuspendedEmployees;

	private String fullname;

	private String format;
 
	private BaseModelCollection<Reports> directReportList;
	private BaseModelCollection<Reports> dottedReportList;
	private BaseModelCollection<Reports> contingentReportList;
	private BaseModelCollection<Reports> lpList;
	
	public BaseModelCollection<Reports> getLpList() {
		return lpList;
	}

	public void setLpList(BaseModelCollection<Reports> lpList) {
		this.lpList = lpList;
	}

	private BaseModelCollection<Reports> reportList;

	public long getId() {
		return sso != null ? sso.longValue() : 0;
	}
	
	public Long getSso() {
		return sso;
	}

	public BaseModelCollection<Reports> getDottedReportList() {
		return dottedReportList;
	}

	public void setDottedReportList(BaseModelCollection<Reports> dottedReportList) {
		this.dottedReportList = dottedReportList;
	}

	public BaseModelCollection<Reports> getContingentReportList() {
		return contingentReportList;
	}

	public void setContingentReportList(
			BaseModelCollection<Reports> contingentReportList) {
		this.contingentReportList = contingentReportList;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public BaseModelCollection<Reports> getDirectReportList() {
		return directReportList;
	}

	public void setDirectReportList(BaseModelCollection<Reports> directReportList) {
		this.directReportList = directReportList;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public boolean isViewSuspendedEmployees() {
		return viewSuspendedEmployees;
	}

	public void setViewSuspendedEmployees(boolean viewSuspendedEmployees) {
		this.viewSuspendedEmployees = viewSuspendedEmployees;
	}
	
	public BaseModelCollection<Reports> getReportList() {
		return reportList;
	}

	public void setReportList(BaseModelCollection<Reports> reportList) {
		this.reportList = reportList;
	}
}
