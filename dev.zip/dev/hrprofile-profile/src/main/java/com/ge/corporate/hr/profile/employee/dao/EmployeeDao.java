/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import java.util.List;
import java.util.Map;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dto.LuceneEducationDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneEmpHistoryDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneLeadershipDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneSearchCompDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneTrainingDto;
import com.ge.corporate.hr.profile.employee.dto.SearchCompDto;
import com.ge.corporate.hr.profile.employee.model.AffinityGroups;
import com.ge.corporate.hr.profile.employee.model.AuthoritySupervisorHierarchy;
import com.ge.corporate.hr.profile.employee.model.ContingentEmployee;
import com.ge.corporate.hr.profile.employee.model.ContingentManagement;
import com.ge.corporate.hr.profile.employee.model.CustomerandSuppliers;
import com.ge.corporate.hr.profile.employee.model.DottedLineManager;
import com.ge.corporate.hr.profile.employee.model.Employee;
import com.ge.corporate.hr.profile.employee.model.EmployeeAssignment;
import com.ge.corporate.hr.profile.employee.model.EmployeeExpertise;
import com.ge.corporate.hr.profile.employee.model.EmployeeRestricted;
import com.ge.corporate.hr.profile.employee.model.HomeAddress;
import com.ge.corporate.hr.profile.employee.model.IntiativesandProject;
import com.ge.corporate.hr.profile.employee.model.JVEmployee;
import com.ge.corporate.hr.profile.employee.model.LPBridgeAssignment;
import com.ge.corporate.hr.profile.employee.model.LanguageProficiency;
import com.ge.corporate.hr.profile.employee.model.Mentoring;
import com.ge.corporate.hr.profile.employee.model.Person;
import com.ge.corporate.hr.profile.employee.model.PersonLevel;
import com.ge.corporate.hr.profile.employee.model.ProfileCompleteness;
import com.ge.corporate.hr.profile.employee.model.ProfileUserMetrics;
import com.ge.corporate.hr.profile.employee.model.ShortProfile;
import com.ge.corporate.hr.profile.employee.model.ShortProfileList;
import com.ge.corporate.hr.profile.employee.model.UserInfo;
import com.ge.corporate.hr.profile.employee.model.WorkMobilityCountry;

/**
 * Employee Dao Interface
 * 
 * @author enrique.romero
 *
 */
public interface EmployeeDao {
	/**
	 * Returns Employee information by sso, this information belongs to
	 * "Personal Info" Data Group
	 * 
	 * @param sso
	 *            Employee SSO
	 * @return
	 */
	public Employee getEmployeeBySso(Long sso);

	/**
	 * Returns Employee information by sso, this information belongs to
	 * "Personal Info Restricted" Data Group
	 * 
	 * @param sso
	 *            Employee SSO
	 * @return
	 */

	public EmployeeRestricted getEmployeeRestrictedBySso(Long sso);

	/**
	 * Returns Gender + Citizenship data by SSO this info belongs to
	 * "Gender Citizenship" DG
	 * 
	 * @param sso
	 * @return
	 */
	public EmployeeRestricted getGenderCitizenshipBySso(Long sso);

	/**
	 * Returns Direct Reports information by sso, this information belongs to
	 * "Personal Info" Data Group
	 * 
	 * @param sso
	 *            Employee SSO
	 * @return
	 */
	public EmployeeRestricted getDisabilityIdBySso(Long sso);

	public EmployeeRestricted getGLBTSelfIdBySso(Long sso);

	public BaseModelCollection<Person> getDirectReportsListByManger(Long sso);

	public BaseModelCollection<Person> getDirectoryDirectReportsListByManger(
			Long sso);

	/**
	 * Returns Supervisor information by sso, this information belongs to
	 * "Personal Info" Data Group
	 * 
	 * @param sso
	 *            Employee SSO
	 * @return
	 */
	public BaseModelCollection<PersonLevel> getSupervisorHierarchyList(Long sso);

	/**
	 * returns a list of employees using only the basic information. sso,
	 * firstName and Last Name
	 * 
	 * @param ssoList
	 * @return
	 */
	public BaseModelCollection<Employee> getBasicEmployeeListBySsoList(
			List<Long> ssoList);

	/**
	 * returns a list of Employees with basic Information and Assignment
	 * Information
	 * 
	 * @param ssoList
	 * @return
	 */
	public BaseModelCollection<EmployeeAssignment> getEmployeeListBySsoList(
			List<Long> ssoList);

	/**
	 * Get Information about search field
	 * 
	 * @param string
	 *            to search first name or last name
	 * @return
	 */
	public BaseModelCollection<ShortProfile> searchEmployeeByParam(String param);

	/**
	 * Get Information about search field
	 * 
	 * @param string
	 *            to search sso
	 * @return
	 */
	public BaseModelCollection<ShortProfile> searchEmployeeByParam(Long param);

	/**
	 * Get Information about search field ordered by sso
	 * 
	 * @param string
	 *            to search could be sso, first name or last name
	 * @return
	 */
	public BaseModelCollection<ShortProfile> searchEmployeeByParamOrderBySso(
			String param);

	/**
	 * Get Information about search field ordered by sso. This is a slower
	 * search method that includes additional basic info
	 * 
	 * @param string
	 *            to search could be sso, first name or last name
	 * @return
	 */
	public BaseModelCollection<ShortProfileList> searchEmployeeListByParam(
			String param);

	/**
	 * Get Information about search field This is a slower search method that
	 * includes additional basic info
	 * 
	 * @param string
	 *            to search sso
	 * @return
	 */
	public BaseModelCollection<ShortProfileList> searchEmployeeListByParam(
			Long param);

	/**
	 * 
	 * @return
	 */
	public AuthoritySupervisorHierarchy getHighAutoritySupervisorHierarchy();

	/**
	 * Get Dotted Line Manager
	 * 
	 * @param sso
	 * @return
	 */
	public DottedLineManager getDottedLineManagerBySso(Long sso);

	/**
	 * Get Home Adress
	 * 
	 * @param sso
	 * @return
	 */
	public HomeAddress getHomeAdressBySso(Long sso);

	/**
	 * Get Employees List by HR Manager sso
	 * 
	 * @param sso
	 * @return
	 */
	public List<Long> getEmployeeListByHRManager(Long sso);

	public ContingentEmployee getContEmployeeBySso(Long sso);

	public ContingentEmployee getContWorkAssgnmtbySso(Long sso);

	public ContingentManagement getContManagement(Long sso);

	/*public void sensitiveDataPopupDao(Long sso, String flag);

	public boolean isValidSensitiveDataPopupDao(Long sso);

	public void sensitiveDataPopupDeleteRolesDao(Long sso);*/

	public boolean isValidSSO(Long sso);

	public boolean showInfoPopupStatusBySSODao(Long sso);
	
	public boolean showWhatsNewPopupBySSODao(Long sso);

	public void infoPopupInsertBySSODao(Long sso, String flag);
	
	public void whatsnewInsertBySSODao(Long sso, String flag);

	public UserInfo loggedUserInfo(Long sso);

	public BaseModelCollection<SearchCompDto> getAllEmployeeListDao();

	public List<LuceneSearchCompDto> getEmployeeListDao();

	public List<Long> getAllSso();

	public List<LuceneEducationDto> getEducationData();

	public List<LuceneEmpHistoryDto> getWorkHistoryData();

	public List<LuceneTrainingDto> getTrainingData();

	public List<LuceneLeadershipDto> getLeadershipData();

	public int  setProfessionalSummary(Long sso, String profSummary);

	public ProfileCompleteness getProfileCompleteness(Long sso, Boolean expertiseFlag);
	
	public ProfileCompleteness getProfileBreakdown(Long sso);

	public List<IntiativesandProject> getInitiativeProjectData();

	public List<CustomerandSuppliers> getCustomersAndSuppliersData();

	public List<LanguageProficiency> getLanguagesData();

	public List<AffinityGroups> getExternalAffiliationsData();
	
	public List<WorkMobilityCountry> getWorkMobilityData();

	public List<LPBridgeAssignment> getLPBridgeData();

	public boolean addConnection(Long sso, Long connectSSO, int connectionType);

	public boolean deleteConnection(Long sso, Long connectSSO, int connectionType);
	
	public BaseModelCollection<EmployeeExpertise> getExpertiseListBySSO(Long sso);
	
	public BaseModelCollection<EmployeeExpertise> updateEmpExpertise(Long sso, List<EmployeeExpertise> expertises);

	public List<EmployeeExpertise> getEmpExpertiseData();
	
	public BaseModelCollection<Long> getAllMentors(Long sso);
	
	public BaseModelCollection<Long> getAllMentees(Long sso);
	
	public Map<String, List<Integer>> getEmpMentoringInterest(Long sso);
	
	public BaseModelCollection<String> getEmpMenteeInterests(Long sso);
	
	public List<Mentoring> getEmpMentoringInterestData();
	
	public void insertLoginMetrics(ProfileUserMetrics metrics);

	public JVEmployee getJVEmployeeBySso(Long sso);
	
	public JVEmployee getJVWorkAssgnmtbySso(Long sso);
	
	public void insertExpertiseEmptyPopupBySSO(Long sso, String flag);
	
	public boolean showExpertiseEmptyPopupBySSO(Long sso);

}
