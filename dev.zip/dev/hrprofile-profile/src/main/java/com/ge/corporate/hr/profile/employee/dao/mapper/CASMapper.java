package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.CAS;

public class CASMapper implements RowMapper<CAS> {

	public static final String DATA_SSO = "sso";
	public static final String DATA_YEAR = "year";
	public static final String DATA_TITLE = "title";


	@Override
	public CAS mapRow(ResultSet rs, int rowNum) throws SQLException {
		CAS cas = new CAS();
		cas.setSso(rs.getLong(DATA_SSO));
		cas.setYear(rs.getShort(DATA_YEAR));
		cas.setTitle(rs.getString(DATA_TITLE));
		return cas;
	}

}
