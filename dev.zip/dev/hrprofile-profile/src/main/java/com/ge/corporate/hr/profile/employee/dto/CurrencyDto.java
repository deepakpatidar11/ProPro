/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;

public class CurrencyDto extends AbstractBaseDtoSupport{

	private static final long serialVersionUID = -4094765911965791990L;
	
	private String formerCurrency;
	private String convertedCurrency;
	private Double formerAmmount;
	private Double convertedAmmount;
	
	public long getId() {
		return 0;
	}

	public String getFormerCurrency() {
		return formerCurrency;
	}

	public void setFormerCurrency(String formerCurrency) {
		this.formerCurrency = formerCurrency;
	}

	public String getConvertedCurrency() {
		return convertedCurrency;
	}

	public void setConvertedCurrency(String convertedCurrency) {
		this.convertedCurrency = convertedCurrency;
	}

	public Double getFormerAmmount() {
		return formerAmmount;
	}

	public void setFormerAmmount(Double formerAmmount) {
		this.formerAmmount = formerAmmount;
	}

	public Double getConvertedAmmount() {
		return convertedAmmount;
	}

	public void setConvertedAmmount(Double convertedAmmount) {
		this.convertedAmmount = convertedAmmount;
	}	
	
	
	
	
}
