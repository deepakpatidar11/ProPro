/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.ws.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.dto.BaseDtoSupport;

@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name="basicInfo")
public class EmployeeBasicInfoDto implements BaseDtoSupport,Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@XmlElement(name="sso")
	private Long sso;	
	
	@XmlElement(name="firstName")
	private String firstName;	
	
	@XmlElement(name="lastName")
	private String lastName;
	
	@XmlElement(name="preferredName")
	private String preferredName;
	
	@XmlElement(name="industryFocusGroupName")
	private String ifgName;
	
	public long getId() {	
		return 0;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public Long getSso() {
		return sso;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setPreferredName(String preferredName) {
		this.preferredName = preferredName;
	}

	public String getPreferredName() {
		return preferredName;
	}

	public void setIfgName(String ifgName) {
		this.ifgName = ifgName;
	}

	public String getIfgName() {
		return ifgName;
	}
	
}
