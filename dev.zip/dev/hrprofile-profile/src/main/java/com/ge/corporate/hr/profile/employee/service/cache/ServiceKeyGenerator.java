/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/

package com.ge.corporate.hr.profile.employee.service.cache;
import com.ge.corporate.hr.profile.auth.util.PersonAuthUtil;
import com.ge.corporate.hr.profile.common.cache.KeyGenerator;
import com.ge.corporate.hr.profile.common.dto.BaseDtoSupport;

/**
 * Key Generator used when jboss cache stores dtos in cache,
 * each dto stored in cache belongs to each authenticated user
 * @author enrique.romero
 * @param <T>
 *
 */
public class ServiceKeyGenerator implements KeyGenerator<String> {
	public String generateKey(
			String className, 
			String methodName,
			Object[] args) {		
		BaseDtoSupport dto = (BaseDtoSupport)args[0];
	    StringBuilder key = new StringBuilder();
	    if(dto != null){
		    //long sso = dto.getId();	
			//Generates the key , example: "getPersonalInfo-200000300-501906414"
			//above means that sso=200000300 wants to get Personal Info from sso=501906414
			//Each dto cached belongs to an authenticated user
		    key.append(methodName).append("_").append(PersonAuthUtil.getLoggedSSO()).append("_").append(Long.toString(dto.getId()));
	    }
	    return key.toString();		
	}
}