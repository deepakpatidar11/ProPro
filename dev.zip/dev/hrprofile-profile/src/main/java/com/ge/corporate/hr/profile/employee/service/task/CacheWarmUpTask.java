/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
/**
 * 
 */
package com.ge.corporate.hr.profile.employee.service.task;


public interface CacheWarmUpTask {
	
	/**
	 *  Executes Cache Warm-up
	 * 
	 * @param user 
	 * @param grantedAuthorities
	 * @param sso
	 * @return
	 */
	public void executeScheduledCacheWarmUp();
	public void executeCacheWarmUp();
	public void clearCache() throws Exception;
	public int getSubLevelsToRun();
	public void setSubLevelsToRun(int subLevelsToRun);
	public boolean isEnabled();
	public void setEnabled(boolean enabled);
	public void debugNavigateLevels();
	public int getCachedEmployeeCount();
}
