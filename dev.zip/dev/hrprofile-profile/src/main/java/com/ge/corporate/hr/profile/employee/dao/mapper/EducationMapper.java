/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.Education;

/**
 * Education Mapper
 * @author enrique.romero
 *
 */
public class EducationMapper implements RowMapper<Education>{
	
	public static final String DATA_SSO = "sso";
	public static final String EDU_TYPE = "EDU_TYPE";
	public static final String DATA_DEGREE = "edu_degree";
	public static final String DATA_MAJOR = "edu_major";
	public static final String DATA_MAJOR2 = "edu_major2";
	public static final String DATA_UNIVERSITY = "edu_university";
	public static final String DATA_COUNTRY = "edu_country";
	public static final String DATA_COUNTRY_CODE = "country_code";
	public static final String DATA_GRAD_YEAR = "edu_grad_year";
	public static final String OTHER_SCHOOL = "OTHER_SCHOOL";
	public static final String OTHER_DIPLOMA_CERTIFICATE = "OTHER_DIPLOMA_CERTIFICATE";
	public static final String OTHER_LOCATION = "OTHER_LOCATION";
	public static final String DATA_STATUS = "STATUS";

	private boolean isSelf = false;
	
	public EducationMapper() {	
		isSelf=false;
	}
	
	public EducationMapper(boolean _isSelf) {	
		isSelf=_isSelf;
	}
	
	public Education mapRow(ResultSet rs, int rowNum) throws SQLException {
		Education education = new Education();
		education.setCountry(rs.getString(DATA_COUNTRY));
		education.setDegree(rs.getString(DATA_DEGREE));
		education.setDiplomaCertificate(rs.getString(OTHER_DIPLOMA_CERTIFICATE));
		education.setEduType(rs.getString(EDU_TYPE));
		if(isSelf){
			education.setGraduationYear(rs.getShort(DATA_GRAD_YEAR));
			education.setStatus(rs.getString(DATA_STATUS));
		}
		education.setLocation(rs.getString(OTHER_LOCATION));
		education.setMajor(rs.getString(DATA_MAJOR));
		education.setMajor2(rs.getString(DATA_MAJOR2));
		education.setSchool(rs.getString(OTHER_SCHOOL));
		education.setSso(rs.getLong(DATA_SSO));
		education.setUniversity(rs.getString(DATA_UNIVERSITY));
		education.setCountryCode(rs.getString(DATA_COUNTRY_CODE));
		
		return education;
	}

}
