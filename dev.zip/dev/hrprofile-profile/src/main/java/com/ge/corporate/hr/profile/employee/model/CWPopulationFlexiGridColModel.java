package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="cwPopulationFlexiGridColModel")
@XmlAccessorType(XmlAccessType.FIELD)
public class CWPopulationFlexiGridColModel extends AbstractBaseModelSupport{
	
	private static final long serialVersionUID = 46981221793287345L;
	
	@XmlElement(name="id")
	private int id; //SSO Id
	
	@XmlElement(name="cell")
	private MyCWPopulation cell;
		
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public MyCWPopulation getCell() {
		return cell;
	}

	public void setCell(MyCWPopulation cell) {
		this.cell = cell;
	}

}

