/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="myCWPopulation")
@XmlAccessorType(XmlAccessType.FIELD)
public class MyCWPopulation extends AbstractBaseModelSupport{
	
	private static final long serialVersionUID = 46981221793287345L;
	
	@XmlAttribute(name="sso")
	private Long sso; //SSO Id
	 
	@XmlElement(name="full_name")
	private String full_name;
	
	@XmlElement(name="wr_no")
	private Long wr_no; 
	
	@XmlElement(name="persontype")
	private String persontype;
	
	@XmlElement(name="subpersontype")
	private String subpersontype;
	
	@XmlElement(name="company")
	private String company;
	
	@XmlElement(name="jobtitle")
	private String jobtitle;
	
	@XmlElement(name="jobfunction")
	private String jobfunction;
	
	@XmlElement(name="effectivestartdate")
	private Date effectivestartdate; 
	
	@XmlElement(name="effectiveenddate")
	private Date effectiveenddate; 
	
	@XmlElement(name="wr_status")
	private String wr_status;
	
	@XmlElement(name="supervisorid")
	private Long supervisorid;  
	
	@XmlElement(name="supervisorname")
	private String supervisorname;
	
	@XmlElement(name="emp_hr_manager")
	private Long emp_hr_manager;
	
	@XmlElement(name="emp_hrm_name")
	private String emp_hrm_name;

	@XmlElement(name="industrygroup")
	private String industrygroup; 
	
	@XmlElement(name="businesssegment")
	private String businesssegment;
	
	@XmlElement(name="businessunit")
	private String businessunit;
	
	@XmlElement(name="country")
	private String country; 
	
	@XmlElement(name="city")
	private String city; 
	
	@XmlElement(name="given_name")
	private String given_name;
	
	@XmlElement(name="surname")
	private String surname;

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public String getFull_name() {
		return full_name;
	}

	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}

	public Long getWr_no() {
		return wr_no;
	}

	public void setWr_no(Long wr_no) {
		this.wr_no = wr_no;
	}

	public String getPersontype() {
		return persontype;
	}

	public void setPersontype(String persontype) {
		this.persontype = persontype;
	}

	public String getSubpersontype() {
		return subpersontype;
	}

	public void setSubpersontype(String subpersontype) {
		this.subpersontype = subpersontype;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getJobtitle() {
		return jobtitle;
	}

	public void setJobtitle(String jobtitle) {
		this.jobtitle = jobtitle;
	}

	public String getJobfunction() {
		return jobfunction;
	}

	public void setJobfunction(String jobfunction) {
		this.jobfunction = jobfunction;
	}

	public Date getEffectivestartdate() {
		return effectivestartdate;
	}

	public void setEffectivestartdate(Date effectivestartdate) {
		this.effectivestartdate = effectivestartdate;
	}

	public Date getEffectiveenddate() {
		return effectiveenddate;
	}

	public void setEffectiveenddate(Date effectiveenddate) {
		this.effectiveenddate = effectiveenddate;
	}

	public String getWr_status() {
		return wr_status;
	}

	public void setWr_status(String wr_status) {
		this.wr_status = wr_status;
	}

	public Long getSupervisorid() {
		return supervisorid;
	}

	public void setSupervisorid(Long supervisorid) {
		this.supervisorid = supervisorid;
	}

	public String getSupervisorname() {
		return supervisorname;
	}

	public void setSupervisorname(String supervisorname) {
		this.supervisorname = supervisorname;
	}

	public Long getEmp_hr_manager() {
		return emp_hr_manager;
	}

	public void setEmp_hr_manager(Long emp_hr_manager) {
		this.emp_hr_manager = emp_hr_manager;
	}
	
	public String getEmp_hrm_name() {
		return emp_hrm_name;
	}

	public void setEmp_hrm_name(String emp_hrm_name) {
		this.emp_hrm_name = emp_hrm_name;
	}

	public String getIndustrygroup() {
		return industrygroup;
	}

	public void setIndustrygroup(String industrygroup) {
		this.industrygroup = industrygroup;
	}

	public String getBusinesssegment() {
		return businesssegment;
	}

	public void setBusinesssegment(String businesssegment) {
		this.businesssegment = businesssegment;
	}

	public String getBusinessunit() {
		return businessunit;
	}

	public void setBusinessunit(String businessunit) {
		this.businessunit = businessunit;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getGiven_name() {
		return given_name;
	}

	public void setGiven_name(String given_name) {
		this.given_name = given_name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}
	
}
