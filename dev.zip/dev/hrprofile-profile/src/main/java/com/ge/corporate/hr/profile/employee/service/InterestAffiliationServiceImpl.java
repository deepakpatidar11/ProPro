package com.ge.corporate.hr.profile.employee.service;

import java.util.List;

import javax.annotation.Resource;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dao.InterestAffiliationDao;
import com.ge.corporate.hr.profile.employee.dto.InterestAffiliationDto;
import com.ge.corporate.hr.profile.employee.model.AffinityGroups;
import com.ge.corporate.hr.profile.employee.model.Mentoring;
import com.ge.corporate.hr.profile.employee.model.OnlineNetwork;

public class InterestAffiliationServiceImpl implements InterestAffiliationService{

	@Resource(name="interestAffiliationDao")
	private InterestAffiliationDao interestDao;
	
	@Override
	public InterestAffiliationDto getInterestAffiliations(Long sso, boolean showProfInterests, boolean showExtGroupAffiliations, boolean showOnlineNetworks) {
		// TODO Auto-generated method stub
		InterestAffiliationDto interestsAffiliations = new InterestAffiliationDto();
		BaseModelCollection<OnlineNetwork> networks = new BaseModelCollection<OnlineNetwork>();
		BaseModelCollection<AffinityGroups> externalAffiliations = new BaseModelCollection<AffinityGroups>();
		//Mentoring mentoringData=new Mentoring();
		if(showOnlineNetworks){
		networks = interestDao.getEmployeeNetworks(sso);
		}
		if(showProfInterests){
		interestsAffiliations = interestDao.getEmployeeInterests(sso);
		}
		interestsAffiliations.setNetworks(networks);
		if(showExtGroupAffiliations){
		externalAffiliations = interestDao.getExternalAffiliations(sso);
		}
		interestsAffiliations.setExternalGroupAffiliations(externalAffiliations);
		
		/*if(showMentoring){
			mentoringData = interestDao.getMentoringData(sso, false);
			}
			interestsAffiliations.setMentoring(mentoringData);*/
		return interestsAffiliations;
	}

	@Override
	public Mentoring getMentoringData(Long sso, boolean connectFlag) {
		return interestDao.getMentoringData(sso, connectFlag);
	}
	
	@Override
	public boolean saveProfessionalInterests(Long sso, String interests) {
		// TODO Auto-generated method stub
		return interestDao.saveProfessionalInterests(sso, interests);
	}

	@Override
	public boolean saveOnlineNetworks(Long sso, List<OnlineNetwork> networks){
		return interestDao.saveOnlineNetworks(sso, networks);
	}
	@Override
	public boolean saveMentoringData(Long sso, Mentoring mentoring){
		return interestDao.saveMentoringData(sso, mentoring);
	}

	@Override
	public boolean saveExternalAffiliations(Long sso,
			List<AffinityGroups> externalAffiliations) {
		return interestDao.saveExternalAffiliations(sso, externalAffiliations);
	}
}
