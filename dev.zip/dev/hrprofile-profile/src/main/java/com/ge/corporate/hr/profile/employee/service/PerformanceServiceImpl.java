/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.service;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.common.service.AbstractBaseServiceSupport;
import com.ge.corporate.hr.profile.employee.dao.PerformanceDao;
import com.ge.corporate.hr.profile.employee.dto.PerformanceDto;
import com.ge.corporate.hr.profile.employee.model.Performance;
import com.ge.corporate.hr.profile.employee.service.cache.ServiceKeyGenerator;
/**
 * Performance Service 
 * @author enrique.romero
 *
 */
public class PerformanceServiceImpl extends AbstractBaseServiceSupport implements PerformanceService{
	private final Log logger = LogFactory.getLog(WorkAssignmentServiceImpl.class);
	
	@Resource(name = "performanceDao")
	private PerformanceDao performanceDao;
	
	public PerformanceDao getPerformanceDao() {
		return performanceDao;
	}

	public void setPerformanceDao(PerformanceDao performanceDao) {
		this.performanceDao = performanceDao;
	}


	@Cache(
			nodeName="/profile/employee/service/performanceService",
			keyGeneratorClass=ServiceKeyGenerator.class,
			cacheName=InfinispanCacheFactory.EMPSERVICECACHE	
		)			
	public PerformanceDto getPerformance(PerformanceDto performanceDto) {
		BaseModelCollection<Performance> performance = null;
		//Set employee information to performanceResDto
		if(performanceDto.getSso() > 0){
			performance = performanceDao.getPerformanceBySso(performanceDto.getSso());
			if(performance == null){
				performance = new BaseModelCollection<Performance>();
			}
			performanceDto.setPerformance(performance);
		}else{
			logger.error("Invalid SSO, SSO = " + performanceDto.getSso());
		}
		
		return performanceDto;	
	}
}
