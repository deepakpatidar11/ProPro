package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "certification")
@XmlAccessorType(XmlAccessType.FIELD)
public class Certification {

	private long sso;

	private String trainingName;

	private Short certificationYear;

	public long getSso() {
		return sso;
	}

	public void setSso(long sso) {
		this.sso = sso;
	}

	public String getTrainingName() {
		return trainingName;
	}

	public void setTrainingName(String trainingName) {
		this.trainingName = trainingName;
	}

	public Short getCertificationYear() {
		return certificationYear;
	}

	public void setCertificationYear(Short certificationYear) {
		this.certificationYear = certificationYear;
	}

}
