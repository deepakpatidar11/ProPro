/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="profile")
@XmlAccessorType(XmlAccessType.FIELD)
public class EmployeeAssignment extends AbstractBaseModelSupport {

	private static final long serialVersionUID = 4760712755094392751L;
	
	Employee employee;
	
	WorkAssignment workAssignment;

	public Employee getEmployee() {
		return employee;
	}
	
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public WorkAssignment getWorkAssignment() {
		return workAssignment;
	}

	public void setWorkAssignment(WorkAssignment workAssignment) {
		this.workAssignment = workAssignment;
	}
	
}