package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.OnlineNetwork;

public class OnlineNetworksMapper implements RowMapper<OnlineNetwork> {

	public static final String DATA_SSO = "sso";
	public static final String DATA_NAME= "name";
	public static final String DATA_URL= "url";
	@Override
	public OnlineNetwork mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		OnlineNetwork network = new OnlineNetwork();
		network.setSso(rs.getLong(DATA_SSO));
		network.setName(rs.getString(DATA_NAME));
		network.setAddress(rs.getString(DATA_URL));
		
		return network;
	}
	


}
