package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.EmployeeExpertise;
import com.ge.corporate.hr.profile.employee.model.Expertise;

public class EmployeeExpertiseMapper implements RowMapper<EmployeeExpertise> {

	public static final String DATA_SSO = "sso";
	public static final String DATA_EXP_NAME = "exp_name";
	public static final String DATA_EXP_ID = "exp_id";
	
	@Override
	public EmployeeExpertise mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		EmployeeExpertise expertise = new EmployeeExpertise();
		expertise.setSso(rs.getLong(DATA_SSO));
		Expertise exp = new Expertise();
		exp.setName(rs.getString(DATA_EXP_NAME));
		exp.setId(rs.getInt(DATA_EXP_ID));
		expertise.setExpertise(exp);
		return expertise;
	}


}
