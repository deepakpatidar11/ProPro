package com.ge.corporate.hr.profile.employee.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.LanguageProficiency;


public interface LanguageDao {
	public BaseModelCollection<LanguageProficiency> getlanguageProficiencyList(Long sso);
	public List<String> getLanguageList();
	public boolean addLanguages(Long sso, ArrayList<Map<String, String>> langProfList);
	public boolean deleteLanguages(Long sso, ArrayList<Map<String, String>> langProfList);
	public boolean updateLanguages(Long sso, ArrayList<Map<String, String>> langProfList);
	public boolean setLanguageProficieny(Long sso, ArrayList<Map<String, String>> langProfList);
	
}
