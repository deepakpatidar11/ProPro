package com.ge.corporate.hr.profile.employee.dao.mapper;



import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.Reports;

/**
 * Direct Reports mapper
 * @author enrique.romero
 *
 */
public class DirectReportMapper implements RowMapper<Reports>{
	
	public static final String DATA_SSO = "sso";
	public static final String DATA_FIRST_NAME = "emp_first_name";
	public static final String DATA_LAST_NAME = "emp_last_name";	
	public static final String DATA_POSITION_TITLE = "emp_title";
	public static final String DATA_EMAIL = "emp_email";
	public static final String DATA_FUNCTION = "emp_function";
	public static final String DATA_BUSINESS = "emp_business";
	public static final String DATA_SUBBUSINESS= "emp_sub_business";
	
	public Reports mapRow(ResultSet rs, int rowNum) throws SQLException {
		Reports reports = new Reports();
		try{
			reports.setSso(rs.getLong(DATA_SSO));
			reports.setFirstName(rs.getString(DATA_FIRST_NAME));
			reports.setLastName(rs.getString(DATA_LAST_NAME));
			reports.setPositionTitle(rs.getString(DATA_POSITION_TITLE));
			reports.setEmail(rs.getString(DATA_EMAIL));
			reports.setFnction(rs.getString(DATA_FUNCTION));
			reports.setBusiness(rs.getString(DATA_BUSINESS));
			reports.setSubBusiness(rs.getString(DATA_SUBBUSINESS));
		}catch(SQLException e)
		{
			throw new SQLException("data not loaded");
		}		
			return 	reports;		
	}
}