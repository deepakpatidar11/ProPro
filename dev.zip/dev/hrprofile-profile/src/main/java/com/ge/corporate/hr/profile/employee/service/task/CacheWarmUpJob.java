package com.ge.corporate.hr.profile.employee.service.task;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;

public class CacheWarmUpJob extends QuartzJobBean{

	public CacheWarmUpTask task;
		
	public void setTask(CacheWarmUpTask task) {
		this.task = task;
	}

	@Override
	protected void executeInternal(JobExecutionContext context)
			throws JobExecutionException {
		task.executeScheduledCacheWarmUp();		
	}
}
