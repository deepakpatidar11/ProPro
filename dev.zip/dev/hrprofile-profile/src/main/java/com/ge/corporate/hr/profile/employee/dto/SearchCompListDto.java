/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;


public class SearchCompListDto extends AbstractBaseDtoSupport{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3954425810252008717L;

	@XmlElement(name="query")
	private String query;
	
	@XmlElement(name="searchList")
	private List<SearchCompDto> searchList;
	
	public List<SearchCompDto> getSearchList() {
		return searchList;
	}

	public void setSearchList(List<SearchCompDto> searchList) {
		this.searchList = searchList;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}
	
	public Integer getSize(){
		Integer size = 0;
		if(searchList != null){
			size = 	searchList.size();		
		}
		return size;
	}
	
	public long getId() {
		return 0;
	}

}
