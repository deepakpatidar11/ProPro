/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.ws.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.dto.BaseDtoSupport;

@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name="assignment")
public class AssignmentDto implements BaseDtoSupport,Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// Work Contact
		
	@XmlElement(name="address")
	private String address;
	
	@XmlElement(name="city")
	private String city;
	
	@XmlElement(name="state")
	private String state;
	
	@XmlElement(name="zip")
	private String zip;
	
	@XmlElement(name="country")
	private String country;
	
	@XmlElement(name="email")
	private String email;
	
	@XmlElement(name="phone")
	private String phone;
	
	@XmlElement(name="dcomm")
	private String dcomm;
	
	@XmlElement(name="cell")
	private String cell;
	
	@XmlElement(name="fax")
	private String fax;	
	
	@XmlElement(name="title")
	private String title;
			
	@XmlElement(name="industryFocusGroup")
	private Long industrySegmentId;
	
	@XmlElement(name="industryFocusGroupName")
	private String industrySegment;
	
	@XmlElement(name="businessSegment")
	private Long businessSegmentId;
	
	@XmlElement(name="subBusiness")
	private Long subBusinessId;
	
	@XmlElement(name="org")
	private String organization;
	
	@XmlElement(name="organization")
	private Long organizationId;
	
	@XmlElement(name="employeeType")
	private String employeeType;
	
	@XmlElement(name="jobFucntion")
	private String jobFucntion;
	
	@XmlElement(name="jobFamily")
	private String jobFamily;	
	
	@XmlElement(name="managerSso")
	private Long managerSso;
	
	@XmlElement(name="manager")
	private String manager;
	
	@XmlElement(name="hrManagerSso")
	private Long hrManagerSso;
	
	@XmlElement(name="hrManager")
	private String hrManager;
	
	@XmlElement(name="localHrManagerSso")
	private Long localHrManagerSso;
	
	@XmlElement(name="localHrManager")
	private String localHrManager;
	
	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getDcomm() {
		return dcomm;
	}

	public void setDcomm(String dcomm) {
		this.dcomm = dcomm;
	}

	public String getCell() {
		return cell;
	}

	public void setCell(String cell) {
		this.cell = cell;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}

	public String getJobFucntion() {
		return jobFucntion;
	}

	public void setJobFucntion(String jobFucntion) {
		this.jobFucntion = jobFucntion;
	}

	public String getJobFamily() {
		return jobFamily;
	}

	public void setJobFamily(String jobFamily) {
		this.jobFamily = jobFamily;
	}

	public Long getManagerSso() {
		return managerSso;
	}

	public void setManagerSso(Long managerSso) {
		this.managerSso = managerSso;
	}

	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	public Long getHrManagerSso() {
		return hrManagerSso;
	}
	
	public void setHrManagerSso(Long hrManagerSso) {
		this.hrManagerSso = hrManagerSso;
	}

	public String getHrManager() {
		return hrManager;
	}

	public void setHrManager(String hrManager) {
		this.hrManager = hrManager;
	}

	public Long getLocalHrManagerSso() {
		return localHrManagerSso;
	}

	public void setLocalHrManagerSso(Long localHrManagerSso) {
		this.localHrManagerSso = localHrManagerSso;
	}

	public String getLocalHrManager() {
		return localHrManager;
	}

	public void setLocalHrManager(String localHrManager) {
		this.localHrManager = localHrManager;
	}

	public long getId() {	
		return 0;
	}

	public void setIndustrySegmentId(Long industrySegmentId) {
		this.industrySegmentId = industrySegmentId;
	}

	public Long getIndustrySegmentId() {
		return industrySegmentId;
	}

	public void setBusinessSegmentId(Long businessSegmentId) {
		this.businessSegmentId = businessSegmentId;
	}

	public Long getBusinessSegmentId() {
		return businessSegmentId;
	}

	public void setSubBusinessId(Long subBusinessId) {
		this.subBusinessId = subBusinessId;
	}

	public Long getSubBusinessId() {
		return subBusinessId;
	}

	public void setIndustrySegment(String industrySegment) {
		this.industrySegment = industrySegment;
	}

	public String getIndustrySegment() {
		return industrySegment;
	}

	public void setOrganizationId(Long organizationId) {
		this.organizationId = organizationId;
	}

	public Long getOrganizationId() {
		return organizationId;
	}
	
}
