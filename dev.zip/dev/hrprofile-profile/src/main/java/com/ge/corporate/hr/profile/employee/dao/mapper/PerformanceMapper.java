/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.Performance;

/**
 * Performance mapper
 * @author enrique.romero
 *
 */
public class PerformanceMapper implements RowMapper<Performance>{
	
	public static final String DATA_SSO = "sso";
	public static final String DATA_YEAR = "perf_year";
	public static final String DATA_OVERALL_PERFORMANCE = "perf_overall_performance";
	public static final String DATA_OVERALL_GROWTH_VAL = "perf_overall_growth_value";
	public static final String DATA_OVERALL_RATING = "perf_overall_rating";
	public static final String DATA_PERF_END_DATE = "perf_end_date";
	public static final String DATA_REVIEW_END_DAT = "review_end_date";
	public static final String DATA_RATING_STATUS = "rating_status";
	public static final String DATA_EAS_APPRAISAL_SYS = "eas_appraisal_system";
	public static final String DATA_EAS_ASSESSMENT_TYPE = "eas_assessment_type";
	public static final String DATA_EAS_APPRAISAL_SCENARIO = "eas_appraisal_scenario";
	public static final String DATA_EAS_NO_IMPACT_INDICATOR_FLAG = "eas_no_impact_indicator_flag";
	public static final String DATA_EAS_ASSESSMENT_RATING = "eas_assessment_rating";
	public static final String DATA_GE_LOCK_FLAG = "ge_lock_flag";
	public static final String DATA_B_MGR_VALUE_CD_DESC = "b_mgr_value_cd_desc";
	public static final String DATA_B_RATING_STATUS = "b_rating_status";
	public static final String DATA_PERF_PROMOTABILITY = "perf_promotability";
	public static final String DATA_PERF_EXTRAORDINARY_SKILLS = "perf_extraordinary_skills";
	public static final String DATA_GV_EXTERNAL_FOCUS = "gv_external_focus";
	public static final String DATA_GV_CLEAR_THINKER = "gv_clear_thinker";
	public static final String DATA_GV_EXPERTISE = "gv_expertise";
	public static final String DATA_GV_INCLUSIVE_LEADERSHIP = "gv_inclusive_leadership";
	public static final String DATA_GV_IMAGINATION = "gv_imagination";
	public static final String DATA_PERF_START_DATE = "perf_start_date";
	public static final String DATA_REVIEW_START_DATE = "review_start_date";
	public static final String DATA_II_IMPACT_INDICATOR = "ii_impact_indicator";
	public static final String DATA_II_REVIEW_START_DATE = "ii_review_start_date";
	public static final String DATA_II_REVIEW_END_DATE = "ii_review_end_date";
	public static final String DATA_II_SOURCE_SYSTEM = "ii_source_system";
	public static final String DATA_II_ARCHIVE_FLAG = "ii_archive_flag";
	public static final String DATA_II_STATUS = "ii_status";
	
	public Performance mapRow(ResultSet rs, int rowNum) throws SQLException {		
		Performance performance = new Performance();
		performance.setSso(rs.getLong(DATA_SSO));
		performance.setYear(rs.getShort(DATA_YEAR));
		performance.setOverallPerformance(rs.getString(DATA_OVERALL_PERFORMANCE));
		performance.setOverallRating(rs.getString(DATA_OVERALL_RATING));
		performance.setOverallGrowthValue(rs.getString(DATA_OVERALL_GROWTH_VAL));
		performance.setPerfEndDate(rs.getDate(DATA_PERF_END_DATE));
		performance.setReviewEndDate(rs.getDate(DATA_REVIEW_END_DAT));
		performance.setRatingStatus(rs.getString(DATA_RATING_STATUS));
		performance.setEasAppraisalSystem(rs.getString(DATA_EAS_APPRAISAL_SYS));
		performance.setEasAssessmentType(rs.getString(DATA_EAS_ASSESSMENT_TYPE));
		performance.setEasAppraisalScenario(rs.getString(DATA_EAS_APPRAISAL_SCENARIO));
		performance.setEasNoImpactIndicatorFlag(rs.getString(DATA_EAS_NO_IMPACT_INDICATOR_FLAG));
		performance.setEasAssessmentRating(rs.getString(DATA_EAS_ASSESSMENT_RATING));
		performance.setGeLockFlag(rs.getString(DATA_GE_LOCK_FLAG));
		performance.setbMgrValueCdDesc(rs.getString(DATA_B_MGR_VALUE_CD_DESC));
		performance.setbRatingStatus(rs.getString(DATA_B_RATING_STATUS));
		performance.setPerfPromotability(rs.getString(DATA_PERF_PROMOTABILITY));
		performance.setPerfExtraordinarySkills(rs.getString(DATA_PERF_EXTRAORDINARY_SKILLS));
		performance.setGvExternalFocus(rs.getString(DATA_GV_EXTERNAL_FOCUS));
		performance.setGvClearThinker(rs.getString(DATA_GV_CLEAR_THINKER));
		performance.setGvExpertise(rs.getString(DATA_GV_EXPERTISE));
		performance.setGvInclusiveLeadership(rs.getString(DATA_GV_INCLUSIVE_LEADERSHIP));
		performance.setGvImagination(rs.getString(DATA_GV_IMAGINATION));
		performance.setPerfStartDate(rs.getDate(DATA_PERF_START_DATE));
		performance.setReviewStartDate(rs.getDate(DATA_REVIEW_START_DATE));
		performance.setIiImpactIndicator(rs.getString(DATA_II_IMPACT_INDICATOR));
		performance.setIiReviewStartDate(rs.getDate(DATA_II_REVIEW_START_DATE));
		performance.setIiReviewEndDate(rs.getDate(DATA_II_REVIEW_END_DATE));
		performance.setIiSourceSystem(rs.getString(DATA_II_SOURCE_SYSTEM));
		performance.setIiArchiveFlag(rs.getString(DATA_II_ARCHIVE_FLAG));
		performance.setIiStatus(rs.getString(DATA_II_STATUS));
		
		return performance;		
	}
	
}
