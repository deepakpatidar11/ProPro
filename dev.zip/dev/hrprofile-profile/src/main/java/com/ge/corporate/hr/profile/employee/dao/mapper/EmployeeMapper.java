/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.Employee;

/**
 * Employee Maper
 * @author enrique.romero
 *
 */
public class EmployeeMapper implements RowMapper<Employee>{
	
	public static final String DATA_SSO = "sso";
	public static final String DATA_FIRST_NAME = "emp_first_name";
	public static final String DATA_LAST_NAME = "emp_last_name";
	public static final String DATA_MANAGER_NAME = "emp_manager_name";
	public static final String DATA_HR_MANAGER_NAME = "emp_hr_manager_name";
	public static final String DATA_EMAIL = "emp_email";
	public static final String DATA_WORK_PHONE = "emp_work_phone";
	public static final String DATA_MOBILE = "emp_mobile";
	public static final String DATA_DCOMM = "emp_dcomm";
	
	public static final String DATA_MAILSTOP = "emp_mailstop";
	public static final String DATA_INTERNAL_LOCATION = "emp_internal_location";
	
	public static final String DATA_MANAGER_SSO = "emp_manager";
	public static final String DATA_HR_MANAGER_SSO = "emp_hr_manager";
	// Data for Demographics
	public static final String DATA_BIRTH_DATE = "emp_birth_date";
	public static final String DATA_CITIZENSHIP = "emp_citizenship";
	public static final String DATA_US_EEO_CATEGORY = "emp_us_eeo_category";
	public static final String DATA_GENDER = "emp_gender";
	public static final String DATA_VETERAN_STATUS = "emp_veteran_status";
	public static final String DATA_AGE = "emp_age";
	public static final String DATA_PREFERRED_NAME = "emp_preferred_name";
	
	public static final String DATA_PAYROLL_PROCESSOR = "emp_payroll_processor_code";
	public static final String DATA_LEGAL_ENTITY = "emp_legal_entity";
	
	public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {		
		Employee employee = new Employee();
		
		employee.setSso(rs.getLong(DATA_SSO));		
		employee.setFirstName(rs.getString(DATA_FIRST_NAME));
		employee.setLastName(rs.getString(DATA_LAST_NAME));
		employee.setManagerName(rs.getString(DATA_MANAGER_NAME));
		employee.setHrManagerName(rs.getString(DATA_HR_MANAGER_NAME));
		employee.setEmail(rs.getString(DATA_EMAIL));
		employee.setPhone(rs.getString(DATA_WORK_PHONE));
		employee.setMobile(rs.getString(DATA_MOBILE));
		employee.setDcomm(rs.getString(DATA_DCOMM));
		employee.setMailstop(rs.getString(DATA_MAILSTOP));
		employee.setInternalLocation(rs.getString(DATA_INTERNAL_LOCATION));
		employee.setManagerSso(rs.getLong(DATA_MANAGER_SSO));
		employee.setHrManagerSso(rs.getLong(DATA_HR_MANAGER_SSO));
		// Data for Demographics		
		employee.setBirthDate(rs.getDate(DATA_BIRTH_DATE));
		employee.setCitizenShip(rs.getString(DATA_CITIZENSHIP));
		employee.setUsEeoCategory(rs.getString(DATA_US_EEO_CATEGORY));
		employee.setGender(rs.getString(DATA_GENDER));
		employee.setVeteranStatus(rs.getString(DATA_VETERAN_STATUS));
		employee.setAge(rs.getShort(DATA_AGE));
		employee.setPreferedName(rs.getString(DATA_PREFERRED_NAME));
		//ToDo  missing fields ......			
		employee.setPayrollProcessorCode(rs.getString(DATA_PAYROLL_PROCESSOR));
		employee.setLegalEntity(rs.getString(DATA_LEGAL_ENTITY));
		return employee;		
	}
	
}
