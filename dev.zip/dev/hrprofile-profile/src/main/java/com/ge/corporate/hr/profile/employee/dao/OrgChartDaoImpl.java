package com.ge.corporate.hr.profile.employee.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.EmptyResultDataAccessException;

import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;
import com.ge.corporate.hr.profile.employee.dao.mapper.OrgChartDirectReportsMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.OrgChartMapper;
import com.ge.corporate.hr.profile.employee.dto.DirectReportsDto;
import com.ge.corporate.hr.profile.employee.dto.OrgChartDto;
import com.ge.corporate.hr.profile.employee.dto.OrgChartDirectReportsDto;

public class OrgChartDaoImpl extends AbstractBaseDaoSupport implements
		OrgChartDao {

	private static Log logger = LogFactory.getLog(OrgChartDaoImpl.class);

	@Override
	public List<OrgChartDirectReportsDto> getEmployeeDetailsForOrgChart(Long sso) {
		String query = this.getSql("getOrgHeirarchyBySSO");
		List<OrgChartDirectReportsDto> orgChartList = new ArrayList<OrgChartDirectReportsDto>();
		try{
		orgChartList = getJdbcTemplate().query(query, new Object[] { sso }, new OrgChartMapper());

		}catch (EmptyResultDataAccessException eex) {	
			logger.info("Org Heirarchy info not loaded for sso:" + sso);
		}
		return orgChartList;
	}
	
	@Override
	public OrgChartDto getOrgChartBySSO(Long sso, boolean showCW, boolean toggleDirectReports) {

		String query = this.getSql("getOrgHeirarchyBySSO");
		String detailsQuery = this.getSql("employeeDetailsBySSO");
		List<OrgChartDirectReportsDto> orgChartList = new ArrayList<OrgChartDirectReportsDto>();
		List<OrgChartDirectReportsDto> directReportList = new ArrayList<OrgChartDirectReportsDto>();
		List<OrgChartDirectReportsDto> contingentList = new ArrayList<OrgChartDirectReportsDto>();
		List<DirectReportsDto> directReports = null;
		//String isContingent = "";
		OrgChartDto orgChart = new OrgChartDto();
		try{
			orgChartList = getJdbcTemplate().query(query, new Object[] { sso }, new OrgChartMapper());

		if (orgChartList != null) {
			orgChart.setTotalNodes(orgChartList.size());
			for (OrgChartDirectReportsDto odr : orgChartList) {
				if (odr.getOrgLevel() == 1) {
					orgChart.setSso(odr.getSso());
					orgChart.setFirstName(odr.getFirstName());
					orgChart.setLastName(odr.getLastName());
					orgChart.setTitle(odr.getTitle());
					orgChart.setIfg(odr.getIfg());
					orgChart.setBusiness(odr.getBusiness());
					orgChart.setIsContingentWorker(odr.getIsContingentWorker());
					if(odr.getManagerSso()!=0){
						orgChart.setManager(getJdbcTemplate().queryForObject(
							detailsQuery, new Object[] { odr.getManagerSso() }, new OrgChartDirectReportsMapper()));
					}else{
						orgChart.setManager(null);
					}
					if(orgChart.getManager()!=null){
						if(orgChart.getManager().getManager()!=0){
							orgChart.setOneOverOneManager(getJdbcTemplate() .queryForObject( detailsQuery,
										new Object[] { orgChart.getManager().getManager() },
										new OrgChartDirectReportsMapper()));
						}
					}else{
						orgChart.setOneOverOneManager(null);
					}
					if(orgChart.getOneOverOneManager()!=null){
						if(orgChart.getOneOverOneManager().getManager()!=0){
							orgChart.setOrgHeirarchy1(getJdbcTemplate() .queryForObject( detailsQuery,
										new Object[] { orgChart.getOneOverOneManager().getManager() },
										new OrgChartDirectReportsMapper()));
						}
					}else{
						orgChart.setOrgHeirarchy1(null);
					}
					if(orgChart.getOrgHeirarchy1()!=null){
						if(orgChart.getOrgHeirarchy1().getManager()!=0){
						orgChart.setOrgHeirarchy2(getJdbcTemplate() .queryForObject( detailsQuery,
									new Object[] { orgChart.getOrgHeirarchy1().getManager() },
									new OrgChartDirectReportsMapper()));
						}
					}else{
							orgChart.setOrgHeirarchy1(null);
					}					
				}
				if (odr.getOrgLevel() == 2) {
					if(!toggleDirectReports){
					directReports = new ArrayList<DirectReportsDto>();
					for (OrgChartDirectReportsDto ocl : orgChartList) {
						if (ocl.getOrgLevel() == 3
								&& ocl.getManagerSso().equals(odr.getSso()) ) {
							//if(!ocl.getSso().toString().startsWith("5")){
								DirectReportsDto drd = new DirectReportsDto();
								drd.setFirstName(ocl.getFirstName());
								drd.setLastName(ocl.getLastName());
								drd.setManager(ocl.getManagerSso());
								drd.setSso(ocl.getSso());
								drd.setTitle(ocl.getTitle());
								drd.setIsContingentWorker(ocl.getIsContingentWorker());
								if(!showCW){
									if(!drd.getSso().toString().startsWith("5")){
										directReports.add(drd);
									}
								}else{
									directReports.add(drd);
								}
							//}
						}
					}
					odr.setDirectReports(directReports);
					}
					if(!odr.getSso().toString().startsWith("5")){
						directReportList.add(odr);
					}else{
						if(showCW){
							contingentList.add(odr);
						}
					}
				}
			}
			orgChart.setDirectReportList(directReportList);
			orgChart.setContingentList(contingentList);
			orgChart.setTotalDirectReports(directReportList.size());
		}
		}catch(EmptyResultDataAccessException ex){
			logger.info("Org Heirarchy info not loaded for sso:" + sso);
		}
		return orgChart;
	
	}

}