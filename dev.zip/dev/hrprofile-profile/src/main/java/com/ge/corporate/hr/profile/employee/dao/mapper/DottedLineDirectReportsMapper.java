package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.Person;

public class DottedLineDirectReportsMapper implements RowMapper<Person>{
	
	public static final String DATA_SSO = "sso";
	public static final String DATA_FIRST_NAME = "emp_first_name";
	public static final String DATA_LAST_NAME = "emp_last_name";	
	public static final String DATA_POSITION_TITLE = "wa_position_title";
	
	public Person mapRow(ResultSet rs, int rowNum) throws SQLException {
		Person dottedLineDirectReports = new Person();
		
		
		dottedLineDirectReports.setSso(rs.getLong(DATA_SSO));		
		dottedLineDirectReports.setFirstName(rs.getString(DATA_FIRST_NAME));
		dottedLineDirectReports.setLastName(rs.getString(DATA_LAST_NAME));
		dottedLineDirectReports.setPositionTitle(rs.getString(DATA_POSITION_TITLE));
				
		return 	dottedLineDirectReports;		
	}
}
