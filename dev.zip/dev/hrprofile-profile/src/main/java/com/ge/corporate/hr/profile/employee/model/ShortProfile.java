/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

public class  ShortProfile extends AbstractBaseModelSupport implements Comparable<Object> {

	public ShortProfile(Long sso, String firstName, String preferredName, String lastName,
			String industry) {
		super();
		this.sso = sso;
		this.firstName = firstName;
		this.preferredName = preferredName;
		this.lastName = lastName;
		this.industry = industry;
	}

	public ShortProfile() {
		// TODO Auto-generated constructor stub
	}

	private static final long serialVersionUID = -8855513688906648553L;
	@XmlElement(name="sso")
	private Long sso;	
	@XmlElement(name="firstName")
	private String firstName;
	@XmlElement(name="preferredName")
	private String preferredName;
	@XmlElement(name="lastName")
	private String lastName;
	@XmlElement(name="industry")
	private String industry;
	
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getIndustry() {
		return industry;
	}
	
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	
	public String getPreferredName() {
		return preferredName;
	}

	public void setPreferredName(String preferredName) {
		this.preferredName = preferredName;
	}

	public int compareTo(Object o) {
		
		if(((ShortProfile)o).lastName.equals(this.lastName))
		{
			return  this.firstName.compareToIgnoreCase(((ShortProfile)o).firstName);
		}else{
			
			return this.lastName.compareToIgnoreCase(((ShortProfile)o).lastName);
		}			
		
	}
}
