/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.security.access.prepost.PreAuthorize;

import com.ge.corporate.hr.profile.auth.dao.UserDao;
import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;
import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dao.mapper.CareerInterestMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.ContingentReportMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.CorpBandMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.CostCenterMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.DirectReportAssignmtMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.DirectReportMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.DottedLineDirectReportsMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.DottedLineReportMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.FinanceContactsMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.HeadCountCostCenterMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.HeadcountValueMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.LeadershipProgramAssignmentMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.LocalBandMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.LpListMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.MyClientsMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.PayrollMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.ProfessionalSummaryMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.ProgramListMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.ReportingOrgsMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.ServiceDatesMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.WorkAssignmentListMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.WorkAssignmentMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.WorkAssignmentRestrictedListMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.WorkAssignmentRestrictedMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.WorkRegionMapper;
import com.ge.corporate.hr.profile.employee.model.FinanceContacts;
import com.ge.corporate.hr.profile.employee.model.LeadershipProgramAssignment;
import com.ge.corporate.hr.profile.employee.model.MyClient;
import com.ge.corporate.hr.profile.employee.model.Person;
import com.ge.corporate.hr.profile.employee.model.Reports;
import com.ge.corporate.hr.profile.employee.model.ServiceDates;
import com.ge.corporate.hr.profile.employee.model.WorkAssignment;
import com.ge.corporate.hr.profile.employee.model.WorkAssignmentHistortyInt;
import com.ge.corporate.hr.profile.employee.model.WorkAssignmentRestricted;
import com.ge.corporate.hr.profile.employee.service.cache.DaoKeyGenerator;

/**
 * Work Assignment Dao Implementation
 * 
 * @author enrique.romero
 * 
 */
public class WorkAssignmentDaoImpl extends AbstractBaseDaoSupport implements
		WorkAssignmentDao {
	private static Log logger = LogFactory.getLog(WorkAssignmentDaoImpl.class);

	@Resource(name = "userDao")
	private UserDao userDao;

	@Resource(name = "employeeDao")
	private EmployeeDao employeeDao;

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	public void setEmployeeDao(EmployeeDao employeeDao) {
		this.employeeDao = employeeDao;
	}

	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'WorkAssignment', read)")
	public WorkAssignment getCurrentWorkAssignmentBySso(Long sso) {
		WorkAssignment assignment = new WorkAssignment();
		String query = this.getSql("getCurrentWorkAssignmentBySso");
		try {
			assignment = getJdbcTemplate()
					.queryForObject(query, new Object[] { sso.intValue() },
							new WorkAssignmentMapper());
			logger.debug("Current WorkAssignment data was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("WorkAssignment Not found");
		}
		return assignment;
	}
	
	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'WorkAssignment', read)")
	public WorkAssignment getCurrentWorkAssignmentAlstomBySso(Long sso) {
		WorkAssignment assignment = new WorkAssignment();
		String query = this.getSql("getCurrentWorkAssignmentAlstomBySso");
		try {
			assignment = getJdbcTemplate()
					.queryForObject(query, new Object[] { sso.intValue() },
							new WorkAssignmentMapper());
			logger.debug("Current WorkAssignment data was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("WorkAssignment Not found");
		}
		return assignment;
	}

	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'WorkAssignmentRestricted', read)")
	public WorkAssignmentRestricted getCurrentWorkAssignmentRestrictedBySso(
			Long sso) {
		WorkAssignmentRestricted assignment = new WorkAssignmentRestricted();
		String query = this.getSql("getCurrentWorkAssignmentRestrictedBySso");
		try {
			assignment = getJdbcTemplate().queryForObject(query,
					new Object[] { sso.intValue() },
					new WorkAssignmentRestrictedMapper());
			logger.debug("Current WorkAssignment Restricted data was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("WorkAssignment Not found");
		}
		return assignment;
	}
	
	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'LocalBand', read)")
	public WorkAssignmentRestricted getCurrentLocalBandBySso(Long sso) {
		WorkAssignmentRestricted assignment = new WorkAssignmentRestricted();
		String query = this.getSql("getCurrentWorkAssignmentRestrictedBySso");
		try {
			assignment = getJdbcTemplate().queryForObject(query,
					new Object[] { sso.intValue() }, new LocalBandMapper());
			logger.debug("Current Local Band data was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("WorkAssignment Not found");
		}
		return assignment;
	}
	
	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'CorporateBand', read)")
	public WorkAssignmentRestricted getCurrentCorpBandBySso(Long sso) {
		WorkAssignmentRestricted assignment = new WorkAssignmentRestricted();
		String query = this.getSql("getCurrentWorkAssignmentRestrictedBySso");
		try {
			assignment = getJdbcTemplate().queryForObject(query,
					new Object[] { sso.intValue() }, new CorpBandMapper());
			logger.debug("Current Corporate Band data was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("WorkAssignment Not found");
		}
		return assignment;
	}

	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'CostCenter', read)")
	public WorkAssignmentRestricted getCurrentCostCenterBySso(Long sso) {
		WorkAssignmentRestricted assignment = new WorkAssignmentRestricted();
		String query = this.getSql("getCurrentWorkAssignmentRestrictedBySso");
		try {
			assignment = getJdbcTemplate().queryForObject(query,
					new Object[] { sso.intValue() }, new CostCenterMapper());
			logger.debug("Current CostCenter data was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("WorkAssignment Not found");
		}
		return assignment;
	}
	
	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'HeadCountCostCenter', read)")
	public WorkAssignmentRestricted getHeadCountCostCenterBySso(Long sso) {
		WorkAssignmentRestricted assignment = new WorkAssignmentRestricted();
		String query = this.getSql("getCurrentWorkAssignmentRestrictedBySso");
		try {
			assignment = getJdbcTemplate().queryForObject(query,
					new Object[] { sso.intValue() }, new HeadCountCostCenterMapper());
			logger.debug("Current CostCenter data was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("WorkAssignment Not found");
		}
		return assignment;
	}
	
	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'WorkAssignment', read)")
	public BaseModelCollection<FinanceContacts> getFinanceContactsListBySso(
			Long sso) {

		BaseModelCollection<FinanceContacts> financeContactsList = new BaseModelCollection<FinanceContacts>();
		String query = this.getSql("getFinanceContactsDetails");
		try {
			financeContactsList.setList(getJdbcTemplate().query(query,
					new Object[] { sso.intValue() },
					new FinanceContactsMapper()));
			logger.debug("Finance Contacts Data Loaded Successfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("Finance Contacts Data Not found");
		}
		return financeContactsList;
	}

	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'WorkAssignmentHistroyInternal', read)")
	public BaseModelCollection<WorkAssignmentHistortyInt> getWorkAssignmentListBySso(
			Long sso) {

		BaseModelCollection<WorkAssignmentHistortyInt> workAssignments = new BaseModelCollection<WorkAssignmentHistortyInt>();
		String query = this.getSql("getWorkAssignmentListBySso");
		try {
			workAssignments.setList(getJdbcTemplate().query(query,
					new Object[] { sso.intValue() },
					new WorkAssignmentListMapper()));
			logger.debug("WorkAssignments data was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("WorkAssignments Not found");
		}
		return workAssignments;
	}

	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'LocalBand', read)")
	public BaseModelCollection<WorkAssignmentRestricted> getWorkAssignmentRestrictedListBySso(
			Long sso) {

		BaseModelCollection<WorkAssignmentRestricted> workAssignments = new BaseModelCollection<WorkAssignmentRestricted>();
		String query = this.getSql("getWorkAssignmentRestrictedListBySso");
		try {
			workAssignments.setList(getJdbcTemplate().query(query,
					new Object[] { sso.intValue() },
					new WorkAssignmentRestrictedListMapper()));
			logger.debug("WorkAssignment Restricted data was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("WorkAssignments Not found");
		}
		return workAssignments;
	}

	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'ServiceDates', read)")
	public ServiceDates getServiceDatesBySso(Long sso) {

		ServiceDates serviceDates = new ServiceDates();
		String query = this.getSql("getServiceDatesBySso");
		try {
			serviceDates = getJdbcTemplate().queryForObject(query,
					new Object[] { sso.intValue() }, new ServiceDatesMapper());
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("WorkAssignment Not found");
		}
		return serviceDates;
	}

	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'WorkAssignmentRestricted', read)")
	public WorkAssignmentRestricted getMonthInBusinessBySso(Long sso) {

		WorkAssignmentRestricted workAssignmentRestricted = new WorkAssignmentRestricted();
		String query = this.getSql("getMonthInBusinessBySso");
		try {
			workAssignmentRestricted.setMonthsInBusiness(getJdbcTemplate()
					.queryForInt(query, new Object[] { sso.intValue() }));
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("MonthInBusiness Not found");
		}
		return workAssignmentRestricted;
	}

	/*
	 * Populates the name, sso and title in "Employee" model by Manager sso
	 */
	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'WorkAssignment', read)")
	public BaseModelCollection<Person> getDirectReportsListByManger(
			Long sso) {

		BaseModelCollection<Person> employeeList = new BaseModelCollection<Person>();
		String query = this.getSql("getDirectReportsListByManger");
		try {
			employeeList.setList(getJdbcTemplate().query(query,
					new Object[] { sso.intValue() },
					new DirectReportAssignmtMapper()));
			logger.debug("Direct reports data was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("Direct reports data Not found");
		}

		return employeeList;
	}

	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'WorkAssignment', read)")
	public BaseModelCollection<Person> getDirectoryDirectReportsListByManger(
			Long sso) {

		BaseModelCollection<Person> employeeList = new BaseModelCollection<Person>();
		String query = this.getSql("getDirectoryDirectReportsListByManger");
		try {
			employeeList.setList(getJdbcTemplate().query(query,
					new Object[] { sso.intValue() },
					new DirectReportAssignmtMapper()));
			logger.debug("Direct reports data was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("Direct reports data Not found");
		}

		return employeeList;
	}
	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'LPBridgeMembers', read)")
	public BaseModelCollection<Reports> getLpList(
			Long sso) {

		BaseModelCollection<Reports> employeeList = new BaseModelCollection<Reports>();
		String query = this.getSql("getLpList");
		try {
			employeeList.setList(getJdbcTemplate().query(query,
					new Object[] { sso.intValue() },
					new LpListMapper()));
			logger.debug("Leadership Program members data was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("Leadership Program members data Not found");
		}

		return employeeList;
	}

	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'WorkAssignment', read)")
	public BaseModelCollection<Person> getContingentReportsListBySupervisor(Long sso){
		
		BaseModelCollection<Person> employeeList = new BaseModelCollection<Person>();
		String query = this.getSql("getContingentReportsListBySupervisor");
		try {
			employeeList.setList(getJdbcTemplate().query(query,
					new Object[] { sso.intValue() },
					new DottedLineDirectReportsMapper()));
			logger.debug("Contingent reports data was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("Contingent reports data Not found");
		}

		return employeeList;
		
	}
	
	
	/*
	 * Populates the name, sso and title in "Employee" model by Manager sso
	 */
	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'DottedLineDirectReports', read)")
	public BaseModelCollection<Person> getDirectReportsListByDottedLineManger(
			Long sso) {

		BaseModelCollection<Person> employeeList = new BaseModelCollection<Person>();
		String query = this.getSql("getDirectReportsListByDottedLineManager");
		try {
			employeeList.setList(getJdbcTemplate().query(query,
					new Object[] { sso.intValue() },
					new DottedLineDirectReportsMapper()));
			logger.debug("Dotted Line Manager Direct reports data was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("Dotted Line Manager Direct reports data Not found");
		}

		return employeeList;
	}

	/*
	 * Populates the name, sso and title in "Employee" model by Manager sso
	 */
	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'WorkAssignmentRestricted', read)")
	public WorkAssignmentHistortyInt getMonthsInPositionBySso(Long sso) {

		WorkAssignmentHistortyInt workAssgnmtHistInt = new WorkAssignmentHistortyInt();
		String query = this.getSql("getMonthsInPositionBySso");

		try {
			workAssgnmtHistInt.setMonthsInPosition(getJdbcTemplate()
					.queryForInt(query, new Object[] { sso.intValue() }));
			logger.debug("Months in position data was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("Months in position data Not found");
		}

		return workAssgnmtHistInt;
	}

	@Cache(nodeName="/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)	
	@PreAuthorize("(hasRole('HRM') or hasRole('ORG_HRM') or hasRole('ROLE_SA')) and hasPermission(#sso, 'MyClients', read)")	
	public BaseModelCollection<MyClient> getMyClientsListBySso(Long sso) {
		
		BaseModelCollection<MyClient> employeeList = new BaseModelCollection<MyClient>();
		String query = this.getSql("getMyClientsListBySso");		
		List<Long> clients;		
		clients = userDao.loadMyClientsSsoBySso(sso);
		if(clients != null && clients.size() > 0){
			try{
	 			employeeList.setList(getJdbcTemplate().query(dynamicPlaceHolderSet(query,clients ),clients.toArray(), new MyClientsMapper()));
				logger.debug("My Clients data was loaded susscesfully");
			}catch (EmptyResultDataAccessException eex) {
				logger.debug("My Clients data  Not found");
			}			
		}
		return employeeList;				
	}
	
    public String getFullNameDao(Long sso){
    	String query = this.getSql("getFullNameBySso");
		return getJdbcTemplate().queryForObject(query,new Object[] { sso.intValue() }, String.class);
    	
    }
    
	//Direct Report popup
	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'WorkAssignment', read)")
	public BaseModelCollection<Reports> getDirectReportsList(Long sso) {
		// TODO Auto-generated method stub
		BaseModelCollection<Reports> employeeList = new BaseModelCollection<Reports>();
		String query = this.getSql("getDirectReportsList");
		try {
			employeeList.setList(getJdbcTemplate().query(query,
					new Object[] { sso.intValue() },
					new DirectReportMapper()));
			logger.debug("Direct reports popup  was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("Direct reports popup data Not found");
		}

		return employeeList;
	}
	
	
	//Dotted Report popup
	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'DottedLineDirectReports', read)")
	public BaseModelCollection<Reports> getDottedLineReportsList(Long sso) {
		// TODO Auto-generated method stub
		BaseModelCollection<Reports> employeeList = new BaseModelCollection<Reports>();
		String query = this.getSql("getDottedLineReportsList");
		try {
			employeeList.setList(getJdbcTemplate().query(query,
					new Object[] { sso.intValue() },
					new DottedLineReportMapper()));
			logger.debug("Dotted reports popup  was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("Dotted reports popup data Not found");
		}

		return employeeList;
	}
	
	//Direct Report popup
	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'WorkAssignment', read)")
	public BaseModelCollection<Reports> getDirectoryDirectReportsList(Long sso) {
		// TODO Auto-generated method stub
		BaseModelCollection<Reports> employeeList = new BaseModelCollection<Reports>();
		String query = this.getSql("getDirectoryDirectReportsList");
		try {
			employeeList.setList(getJdbcTemplate().query(query,
					new Object[] { sso.intValue() },
					new DirectReportMapper()));
			logger.debug("Direct reports popup  was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("Direct reports popup data Not found");
		}

		return employeeList;
	}
	
	
	//Dotted Report popup
	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'DottedLineDirectReports', read)")
	public BaseModelCollection<Reports> getDirectoryDottedLineReportsList(Long sso) {
		// TODO Auto-generated method stub
		BaseModelCollection<Reports> employeeList = new BaseModelCollection<Reports>();
		String query = this.getSql("getDirectoryDottedLineReportsList");
		try {
			employeeList.setList(getJdbcTemplate().query(query,
					new Object[] { sso.intValue() },
					new DottedLineReportMapper()));
			logger.debug("Dotted reports popup  was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("Dotted reports popup data Not found");
		}

		return employeeList;
	}
	
	//Contingent Report popup
	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'WorkAssignment', read)")
	public BaseModelCollection<Reports> getContingentReportsList(Long sso) {
		BaseModelCollection<Reports> employeeList = new BaseModelCollection<Reports>();
		String query = this.getSql("getContingentLineReportsList");
		try {
			employeeList.setList(getJdbcTemplate().query(query,
					new Object[] { sso.intValue() },
					new ContingentReportMapper()));
			logger.debug("Contingent reports popup  was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("Contingent reports popup data Not found");
		}

		return employeeList;
	}

	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'ReportingOrgs', read)")
	public WorkAssignmentRestricted getReportingOrgsBySso(Long sso) {
		WorkAssignmentRestricted assignment = new WorkAssignmentRestricted();
		String query = this.getSql("getCurrentWorkAssignmentRestrictedBySso");
		try {
			assignment = getJdbcTemplate().queryForObject(query,
					new Object[] { sso.intValue() }, new ReportingOrgsMapper());
			logger.debug("Reporting Organization data was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("WorkAssignment Not found");
		}
		return assignment;
	}
	
	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'WorkRegion', read)")
	public WorkAssignmentRestricted getWorkRegionBySso(Long sso) {
		WorkAssignmentRestricted assignment = new WorkAssignmentRestricted();
		String query = this.getSql("getCurrentWorkAssignmentRestrictedBySso");
		try {
			assignment = getJdbcTemplate().queryForObject(query,
					new Object[] { sso.intValue() }, new WorkRegionMapper());
			logger.debug("Work Region data was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("WorkAssignment Not found");
		}
		return assignment;
	}
	
	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'HeadcountValue', read)")
	public WorkAssignmentRestricted getHeadcountValueBySso(Long sso) {
		WorkAssignmentRestricted assignment = new WorkAssignmentRestricted();
		String query = this.getSql("getCurrentWorkAssignmentRestrictedBySso");
		try {
			assignment = getJdbcTemplate().queryForObject(query,
					new Object[] { sso.intValue() }, new HeadcountValueMapper());
			logger.debug("Headcount data was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("WorkAssignment Not found");
		}
		return assignment;
	}
	
	@PreAuthorize("hasPermission(#sso, 'ResumeProfessionalSummaryView', read)")
	public String getProfessionalSummary(Long sso) {
		String query = this.getSql("getProfessionalSummary");		
		String summary = "";
		try{
			summary = getJdbcTemplate().queryForObject(query, new Object[]{sso},String.class);
			logger.debug("Logged User Prof. summary  data was loaded susscesfully");			
			}catch (EmptyResultDataAccessException eex) {
				summary="";
			logger.debug("Prof. summary data not found for "+sso);
		}
		return summary;
	}
	
	@PreAuthorize("hasPermission(#sso, 'ResumeProfessionalSummaryEdit', read)")
	public boolean setProfessionalSummary(Long sso,String text) {
		String query = this.getSql("updateProfessionalSummary");
		boolean success = true;
		try{
			getJdbcTemplate().update(query, text, sso);
			logger.debug("Logged User Prof. summary data was updated successfully");		
		}catch(Exception e){
			logger.debug("Prof. summary data insert/update failed");
			success = false;
		}
		return success;
	}

	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'LPBridgeAssignment', read)")
	public LeadershipProgramAssignment getProgramAssignment(Long sso) {
		String query = this.getSql("getLpAssignment");		
		LeadershipProgramAssignment lpAssignment = new LeadershipProgramAssignment();
		try{
			lpAssignment = getJdbcTemplate().queryForObject(query, new Object[]{sso},new LeadershipProgramAssignmentMapper());
			logger.debug("Leadership Program Assignment data was loaded successfully");			
			}catch (EmptyResultDataAccessException eex) {
			logger.debug("Leadership Program Assignment not found for "+sso);
		}
		return lpAssignment;
	}

	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'LPBridgeLeaderFor', read)")
	public WorkAssignmentRestricted getProgramList(Long sso) {
		WorkAssignmentRestricted assignment = new WorkAssignmentRestricted();
		String query = this.getSql("getProgramList");
		try {
			assignment = getJdbcTemplate().queryForObject(query,
					new Object[] { sso.intValue() }, new ProgramListMapper());
			logger.debug("Assignment Leader data was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("Assignment Leader data Not found");
		}
		return assignment;
	}

	@Cache(nodeName = "/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'Payroll', read)")
	public WorkAssignmentRestricted getCurrentPayrollBySso(Long sso) {
		WorkAssignmentRestricted assignment = new WorkAssignmentRestricted();
		String query = this.getSql("getCurrentWorkAssignmentRestrictedBySso");
		try {
			assignment = getJdbcTemplate().queryForObject(query,
					new Object[] { sso.intValue() }, new PayrollMapper());
			logger.debug("Payroll data was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("WorkAssignment Not found");
		}
		return assignment;
	}
}
