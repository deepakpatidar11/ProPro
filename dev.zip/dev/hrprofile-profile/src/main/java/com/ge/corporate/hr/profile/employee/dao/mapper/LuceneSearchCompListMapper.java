/*******************************************************************************
 * Copyright © 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.dto.ACLBean;
import com.ge.corporate.hr.profile.employee.dto.LuceneSearchCompDto;


public class LuceneSearchCompListMapper implements RowMapper<LuceneSearchCompDto>{

	public static final String DATA_SSO = "sso";
	public static final String DATA_FULL_NAME = "emps_uper_full_name";
	public static final String DATA_FULL_ASCII_NAME = "emps_full_ascii_name";
	public static final String DATA_FULL_PREFERRED_NAME = "emps_preferred_name";
	public static final String DATA_TITLE = "emps_title_name";
	public static final String DATA_LOCAL_LANG_TITLE ="EMP_LOCAL_LANG_TITLE";
	public static final String DATA_LOCAL_LANG_FULL_NAME = "emp_local_lang_full_name"; // added
	public static final String DATA_EMAIL = "emp_email";
	public static final String DATA_MOBILE_PHONE = "emp_mobile";
	public static final String DATA_WORK_PHONE = "emp_work_phone";
	public static final String DATA_MANAGER_SSO = "mgr_sso";
	public static final String DATA_MANAGER_FULL_NAME = "mgr_uper_full_name";
	public static final String DATA_MANAGER_ASCII_NAME = "mgr_full_ascii_name";
	public static final String DATA_MANAGER_PREFERRED_NAME = "mgr_preferred_name";
	public static final String DATA_MANAGER_TITLE = "mgr_title_name";
	public static final String DATA_MANAGER_EMAIL = "mgr_email";
	public static final String DATA_MANAGER_PHONE = "mgr_phone";
	public static final String DATA_MANAGER_MOBILE = "mgr_mobile";
	public static final String DATA_IFG = "emps_ifg";
	public static final String DATA_BUSINESS = "emps_business_name";
	public static final String DATA_SUB_BUSINESS = "emps_subbusiness_name";
	public static final String DATA_ORGANIZATION = "emps_org_name";
	public static final String DATA_REPORTING_IFG = "emp_reporting_ifg";	// added
	public static final String DATA_REPORTING_BIZ = "emp_reporting_business";	// added
	public static final String DATA_FUNCTION = "emps_function";
	public static final String DATA_JOB_FAMILY = "emps_job_family";
	public static final String DATA_REGION = "emps_region";
	public static final String DATA_COUNTRY = "emps_country";
	public static final String DATA_BAND = "emps_band";
	public static final String DATA_ACL = "*";
	public static final String DATA_ACL_SSO = "SSO";  
	public static final String DATA_ACL_SUPV ="SUPV"; 
	public static final String DATA_ACL_MGR ="MGR";
	public static final String DATA_ACL_ORG_MGR ="ORG_MGR"; 
	public static final String DATA_ACL_HRM ="HRM";
	public static final String DATA_ACL_ORG_HRM ="ORG_HRM"; 
	public static final String DATA_ACL_HRM_SPL ="HRM_SPL"; 
	public static final String DATA_ACL_SHRM ="SHRM"; 
	public static final String DATA_ACL_SHRM_F ="SHRM_F"; 
	public static final String DATA_ACL_SHRM_R ="SHRM_R";
	public static final String DATA_ACL_SHRM_GL ="SHRM_GL"; 
	public static final String DATA_ACL_MATRIX_HRM ="MATRIX_HRM"; 
	public static final String DATA_ACL_O_S_MANAGER ="O_S_MANAGER"; 
	public static final String DATA_ACL_O_S_MANAGER_CP ="O_S_MANAGER_CP"; 
	public static final String DATA_ACL_O_S_MANAGER_F ="O_S_MANAGER_F";
	public static final String DATA_ACL_O_S_MANAGER_GL ="O_S_MANAGER_GL";
	public static final String DATA_ACL_O_S_MANAGER_R ="O_S_MANAGER_R";
	public static final String DATA_ACL_O_TD_MANAGER ="O_TD_MANAGER"; 
	public static final String DATA_ACL_O_TD_MANAGER_CP ="O_TD_MANAGER_CP"; 
	public static final String DATA_ACL_O_TD_MANAGER_F ="O_TD_MANAGER_F";
	public static final String DATA_ACL_O_TD_MANAGER_GL ="O_TD_MANAGER_GL";
	public static final String DATA_ACL_O_TD_MANAGER_R ="O_TD_MANAGER_R";
	public static final String DATA_ACL_HRM_VIEW ="HRM_VIEW";
	public static final String DATA_ACL_HR_BP="HR_BP";
	
	public static final String DATA_ACL_O_TD_NO_COMP="O_TD_NO_COMP";
	public static final String DATA_ACL_ADMIN_STAFF="ADMIN_STAFF";
	public static final String DATA_ACL_STAFF_HS_STAFFING_SPL="STAFF_HS_STAFFING_SPL";
	public static final String DATA_ACL_STAFF_REQ_FLDR_OWNR="STAFF_REQ_FLDR_OWNR";
	public static final String DATA_ACL_STAFF_HS_LTD_ACCESS="STAFF_HS_LTD_ACCESS";
	public static final String DATA_ACL_STAFF_HS_US_LEAD_RCTR="STAFF_HS_US_LEAD_RCTR";

	public static final String DATA_EMP_LAST_NAME = "emps_last_name";
	public static final String DATA_EMP_FIRST_NAME = "emps_first_name";
	public static final String DATA_EMP_HISTORY_SHARED = "emp_history_shared";
	public static final String DATA_EDUCATION_SHARED = "education_shared";
	public static final String DATA_TRAINING_SHARED = "training_shared";
	public static final String DATA_LOC_ADDR1 = "wa_address1";
	public static final String DATA_LOC_ADDR2 = "wa_address2";
	public static final String DATA_LOC_ADDR3 = "wa_address3";
	public static final String DATA_LOC_CITY = "wa_city";
	public static final String DATA_LOC_STATE = "wa_state";
	public static final String DATA_LOC_STATE_NAME = "state_name";
	public static final String DATA_LOC_ZIP = "wa_zip";
	public static final String DATA_LOC_COUNTRY= "wa_country";
	public static final String DATA_LOC_COUNTRY_LABEL= "country_label";
	public static final String DATA_OH_MGR_SSO= "oh_mgr_sso";
	public static final String DATA_OH_MGR_LASTNAME= "oh_mgr_lastname";
	public static final String DATA_OH_MGR_FIRSTNAME = "oh_mgr_firstname";
	public static final String DATA_OH_MGR_SSO1 = "oh1_mgr_sso";
	public static final String DATA_OH_MGR_LASTNAME1 = "oh1_mgr_lastname";
	public static final String DATA_OH_MGR_FIRSTNAME1 = "oh1_mgr_firstname";
	public static final String DATA_OH_MGR_SSO2 = "oh2_mgr_sso";
	public static final String DATA_OH_MGR_LASTNAME2 = "oh2_mgr_lastname";
	public static final String DATA_OH_MGR_FIRSTNAME2 = "oh2_mgr_firstname";
	public static final String DATA_OH_MGR_SSO3 = "oh3_mgr_sso";
	public static final String DATA_OH_MGR_LASTNAME3 = "oh3_mgr_lastname";
	public static final String DATA_OH_MGR_FIRSTNAME3 = "oh3_mgr_firstname";
	public static final String DATA_PERSON_TYPE = "person_type";
	public static final String DATA_TECHNICAL_DISCIPLINE = "emp_tech_discipline";
	public static final String DATA_DIRECTORY_INCL = "directory_inclusion";
	public static final String DATA_PROF_SUMMARY = "professional_summary";
	public static final String DATA_CAREER_INTERESTS = "career_goal_combined"; 
	public static final String DATA_EMP_INTERESTS = "employee_interests";
	public static final String DATA_INITITATIVES_SHARED = "initiatives_projects_shared";
	public static final String DATA_TALENT_POOL = "optin_talentpool";
	public static final String DATA_RELOCATE_WITHIN = "MOBILITY_RELOCATEWITHIN";
	public static final String DATA_RELOCATE_OUTSIDE = "RELOCATE_OUTSIDE";
	public static final String DATA_CUSTOMERS_SUPPLIERS_SHARED = "customers_suppliers_shared";
	public static final String DATA_LANGUAGES_SHARED = "languages_shared";
	public static final String DATA_EXTERNAL_AFFILIATIONS_SHARED = "external_affiliations_shared";
	public static final String DATA_CAREER_ASPIRATION_SHARED = "career_aspirations_shared";
	public static final String DATA_PROF_INTEREST_SHARED = "prof_interests_shared";
	public static final String DATA_WORK_MOBILITY_SHARED = "work_mobility_shared";
	/*public static final String DATA_MENTORING_SHARED = "mentoring_shared";
	public static final String DATA_MENTORING_MENTOR = "mentor_flag";
	public static final String DATA_MENTORING_MENTEE = "mentee_flag";
	public static final String DATA_MENTORING_DESC = "mentoring_desc";*/
	public static final String DATA_CONNECT_MENTOR = "connect_mentor";
	public static final String DATA_CONNECT_MENTEE = "connect_mentee";
	public static final String DATA_CONNECT_MENTO_DESC = "mento_desc";
	public static final String DATA_CONNECTION_SHARED = "connection_shared";
	public static final String DATA_ACL_MGR_1O1 = "MGR_1O1";
	public static final String DATA_ACL_LP_GLOBAL_PROGRAM_MGR = "LP_GLOBAL_PROGRAM_MGR";
	public static final String DATA_ACL_LP_PROGRAM_MGR = "LP_PROGRAM_MGR";
	public static final String DATA_ACL_LP_OPERATIONS = "LP_OPERATIONS";
	public static final String DATA_CAREER_OPP = "CAREER_OPPORTUNITIES";
			
	public LuceneSearchCompDto mapRow(ResultSet rs, int rowNum) throws SQLException {		
		LuceneSearchCompDto employee = new LuceneSearchCompDto();
		ACLBean acl = new ACLBean();
		acl.setHR_BP(rs.getString(DATA_ACL_HR_BP));
		acl.setHRM_SPL(rs.getString(DATA_ACL_HRM_SPL));
		acl.setHRM_VIEW(rs.getString(DATA_ACL_HRM_VIEW));
		acl.setMATRIX_HRM(rs.getString(DATA_ACL_MATRIX_HRM));
		acl.setO_S_MANAGER(rs.getString(DATA_ACL_O_S_MANAGER));
		acl.setO_S_MANAGER_CP(rs.getString(DATA_ACL_O_S_MANAGER_CP));
		acl.setO_S_MANAGER_F(rs.getString(DATA_ACL_O_S_MANAGER_F));
		acl.setO_S_MANAGER_GL(rs.getString(DATA_ACL_O_S_MANAGER_GL));
		acl.setO_S_MANAGER_R(rs.getString(DATA_ACL_O_S_MANAGER_R));	
		acl.setO_TD_MANAGER(rs.getString(DATA_ACL_O_TD_MANAGER));
		acl.setO_TD_MANAGER_CP(rs.getString(DATA_ACL_O_TD_MANAGER_CP));
		acl.setO_TD_MANAGER_F(rs.getString(DATA_ACL_O_TD_MANAGER_F));
		acl.setO_TD_MANAGER_GL(rs.getString(DATA_ACL_O_TD_MANAGER_GL));
		acl.setO_TD_MANAGER_R(rs.getString(DATA_ACL_O_TD_MANAGER_R));
		acl.setORG_HRM(rs.getString(DATA_ACL_ORG_HRM));
		acl.setHRM(rs.getString(DATA_ACL_HRM));
		acl.setORG_MGR(rs.getString(DATA_ACL_ORG_MGR));
		acl.setMGR(rs.getString(DATA_ACL_MGR));
		acl.setSUPV(rs.getString(DATA_ACL_SUPV));
		acl.setSHRM(rs.getString(DATA_ACL_SHRM));
		acl.setSHRM_F(rs.getString(DATA_ACL_SHRM_F));
		acl.setSHRM_GL(rs.getString(DATA_ACL_SHRM_GL));
		acl.setSHRM_R(rs.getString(DATA_ACL_SHRM_R));
		acl.setO_TD_NO_COMP(rs.getString(DATA_ACL_O_TD_NO_COMP));
		acl.setADMIN_STAFF(rs.getString(DATA_ACL_ADMIN_STAFF));
		acl.setSTAFF_HS_STAFFING_SPL(rs.getString(DATA_ACL_STAFF_HS_STAFFING_SPL));
		acl.setSTAFF_REQ_FLDR_OWNR(rs.getString(DATA_ACL_STAFF_REQ_FLDR_OWNR));
		acl.setSTAFF_HS_LTD_ACCESS(rs.getString(DATA_ACL_STAFF_HS_LTD_ACCESS));
		acl.setSTAFF_HS_US_LEAD_RCTR(rs.getString(DATA_ACL_STAFF_HS_US_LEAD_RCTR));
		acl.setSso(rs.getString(DATA_SSO));
		acl.setMGR_1O1(rs.getString(DATA_ACL_MGR_1O1));
		acl.setLP_GLOBAL_PROGRAM_MGR(rs.getString(DATA_ACL_LP_GLOBAL_PROGRAM_MGR));
		acl.setLP_OPERATIONS(rs.getString(DATA_ACL_LP_OPERATIONS));
		acl.setLP_PROGRAM_MGR(rs.getString(DATA_ACL_LP_PROGRAM_MGR));
		employee.setAcl(acl);		
		employee.setSso(rs.getLong(DATA_SSO));
		employee.setEmpName(rs.getString(DATA_FULL_NAME));
		employee.setEmpAsciiName(rs.getString(DATA_FULL_ASCII_NAME));
		employee.setEmpPreferredName(rs.getString(DATA_FULL_PREFERRED_NAME));
		employee.setTitle(rs.getString(DATA_TITLE));
		employee.setEmpEmail(rs.getString(DATA_EMAIL));
		String empWorkPhone = rs.getString(DATA_WORK_PHONE)==null?"":rs.getString(DATA_WORK_PHONE);
		employee.setEmpWorkPhone(empWorkPhone.replaceAll("[^0-9\\s]"," ").trim());
		String empMobile = rs.getString(DATA_MOBILE_PHONE)==null?"":rs.getString(DATA_MOBILE_PHONE);
		employee.setEmpMobile(empMobile.replaceAll("[^0-9\\s]"," ").trim());
		employee.setEmpAddr1(rs.getString(DATA_LOC_ADDR1));
		employee.setEmpAddr2(rs.getString(DATA_LOC_ADDR2));
		employee.setEmpAddr3(rs.getString(DATA_LOC_ADDR3));
		//employee.setEmpCity(rs.getString(DATA_LOC_CITY));
		employee.setEmpState(rs.getString(DATA_LOC_STATE));
		employee.setEmpStateName(rs.getString(DATA_LOC_STATE_NAME));
		employee.setEmpZip(rs.getString(DATA_LOC_ZIP));
		employee.setEmpCountry(rs.getString(DATA_LOC_COUNTRY));
		employee.setEmpCountryLabel(rs.getString(DATA_LOC_COUNTRY_LABEL));
		employee.setEmpManagerSso(rs.getLong(DATA_MANAGER_SSO));
		employee.setEmpManagerName(rs.getString(DATA_MANAGER_FULL_NAME));
		employee.setEmpManagerAsciiName(rs.getString(DATA_MANAGER_ASCII_NAME));
		employee.setMgrPreferredName(rs.getString(DATA_MANAGER_PREFERRED_NAME));
		employee.setMgrTitle(rs.getString(DATA_MANAGER_TITLE));
		employee.setMgrEmail(rs.getString(DATA_MANAGER_EMAIL));
		String mgrPhone = rs.getString(DATA_MANAGER_PHONE)==null?"":rs.getString(DATA_MANAGER_PHONE);
		employee.setMgrPhone(mgrPhone.replaceAll("[^0-9\\s]"," ").trim());
		String mgrMobile = rs.getString(DATA_MANAGER_MOBILE)==null?"":rs.getString(DATA_MANAGER_MOBILE);
		employee.setMgrMobile(mgrMobile.replaceAll("[^0-9\\s]"," ").trim());
		employee.setOhMgrSso(rs.getString(DATA_OH_MGR_SSO));
		employee.setOhMgrFirstName(rs.getString(DATA_OH_MGR_FIRSTNAME));
		employee.setOhMgrLastName(rs.getString(DATA_OH_MGR_LASTNAME));
		employee.setOhMgrSso1(rs.getString(DATA_OH_MGR_SSO1));
		employee.setOhMgrFirstName1(rs.getString(DATA_OH_MGR_FIRSTNAME1));
		employee.setOhMgrLastName1(rs.getString(DATA_OH_MGR_LASTNAME1));
		employee.setOhMgrSso2(rs.getString(DATA_OH_MGR_SSO2));
		employee.setOhMgrFirstName2(rs.getString(DATA_OH_MGR_FIRSTNAME2));
		employee.setOhMgrLastName2(rs.getString(DATA_OH_MGR_LASTNAME2));
		employee.setOhMgrSso3(rs.getString(DATA_OH_MGR_SSO3));
		employee.setOhMgrFirstName3(rs.getString(DATA_OH_MGR_FIRSTNAME3));
		employee.setOhMgrLastName3(rs.getString(DATA_OH_MGR_LASTNAME3));
		employee.setIfg(rs.getString(DATA_IFG));
		employee.setBusiness(rs.getString(DATA_BUSINESS));
		employee.setSubBusiness(rs.getString(DATA_SUB_BUSINESS));
		employee.setOrganization(rs.getString(DATA_ORGANIZATION));
		employee.setFunc(rs.getString(DATA_FUNCTION));
		employee.setJobFamily(rs.getString(DATA_JOB_FAMILY));
		employee.setRegion(rs.getString(DATA_REGION));
		employee.setCountry(rs.getString(DATA_COUNTRY));
		employee.setBand(rs.getString(DATA_BAND));
		employee.setEmpLastName(rs.getString(DATA_EMP_LAST_NAME));		
		employee.setEmpFirstName(rs.getString(DATA_EMP_FIRST_NAME));	
		employee.setEmpReportingBusiness(rs.getString(DATA_REPORTING_BIZ));
		employee.setEmpReportingIFG(rs.getString(DATA_REPORTING_IFG));
		employee.setEmpLocalLangName(rs.getString(DATA_LOCAL_LANG_FULL_NAME));
		employee.setPrsnType(rs.getString(DATA_PERSON_TYPE));
		employee.setDirectoryIncl(rs.getString(DATA_DIRECTORY_INCL));
		employee.setTechDisciplineKW(rs.getString(DATA_TECHNICAL_DISCIPLINE));
		employee.setTechDisciplineSTD(rs.getString(DATA_TECHNICAL_DISCIPLINE));
		employee.setEmpLocalLangTitle(rs.getString(DATA_LOCAL_LANG_TITLE));
		employee.setEducationSharedFlag(rs.getString(DATA_EDUCATION_SHARED));
		employee.setTrainingSharedFlag(rs.getString(DATA_TRAINING_SHARED));
		employee.setEmpHistorySharedFlag(rs.getString(DATA_EMP_HISTORY_SHARED));
		employee.setCustomerSuppliersSharedFlag(rs.getString(DATA_CUSTOMERS_SUPPLIERS_SHARED));
		employee.setLanguagesSharedFlag(rs.getString(DATA_LANGUAGES_SHARED));
		employee.setExternalAffiliationsSharedFlag(rs.getString(DATA_EXTERNAL_AFFILIATIONS_SHARED));
		employee.setCareerSharedFlag(rs.getString(DATA_CAREER_ASPIRATION_SHARED));
		employee.setInterestsSharedFlag(rs.getString(DATA_PROF_INTEREST_SHARED));
		employee.setInitiativeProjectSharedFlag(rs.getString(DATA_INITITATIVES_SHARED));
		employee.setProfessionalSummary(rs.getString(DATA_PROF_SUMMARY));
		employee.setCareerInterests(rs.getString(DATA_CAREER_INTERESTS));
		employee.setInterests(rs.getString(DATA_EMP_INTERESTS));
		employee.setTalentPool(rs.getString(DATA_TALENT_POOL));
		employee.setWorkMobilityShared(rs.getString(DATA_WORK_MOBILITY_SHARED));
		employee.setRelocateOutside(rs.getString(DATA_RELOCATE_OUTSIDE));
		employee.setRelocateWithin(rs.getString(DATA_RELOCATE_WITHIN));
		/*employee.setMenteeInfo(rs.getString(DATA_MENTORING_MENTEE));
		employee.setMentorInfo(rs.getString(DATA_MENTORING_MENTOR));
		employee.setMentoringSharedFlag(rs.getString(DATA_MENTORING_SHARED));
		employee.setMentoringDesc(rs.getString(DATA_MENTORING_DESC));*/
		employee.setConnectionSharedFlag(rs.getString(DATA_CONNECTION_SHARED));
		employee.setConnectMenteeInfo(rs.getString(DATA_CONNECT_MENTEE));
		employee.setConnectMentorInfo(rs.getString(DATA_CONNECT_MENTOR));
		employee.setConnectMentoDesc(rs.getString(DATA_CONNECT_MENTO_DESC));
		employee.setCareerOpportunity(rs.getString(DATA_CAREER_OPP));
		return employee;				
	}	
}
