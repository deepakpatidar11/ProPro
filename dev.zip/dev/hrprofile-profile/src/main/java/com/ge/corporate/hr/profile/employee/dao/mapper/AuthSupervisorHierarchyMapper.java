/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.AuthoritySupervisorHierarchy;


/**
 * AuthSupervisorHierarchyMapper 
 * @author hrTeam
 *
 */
public class AuthSupervisorHierarchyMapper implements RowMapper<AuthoritySupervisorHierarchy> {
	
	public static final String DATA_SSO = "sso";
	public static final String DATA_REPORTS_TO = "REPORTS_TO";
	public static final String DATA_HR_MANAGER = "HR_MANAGER";

	
	public AuthoritySupervisorHierarchy mapRow(ResultSet rs, int rowNum) throws SQLException {		
		AuthoritySupervisorHierarchy authSupHierachy = new AuthoritySupervisorHierarchy();
		
		authSupHierachy.setSso(rs.getLong(DATA_SSO));		
		authSupHierachy.setReportsTo(rs.getString(DATA_REPORTS_TO));
		authSupHierachy.setHrManager(rs.getString(DATA_HR_MANAGER));
	
		//ToDo  missing fields ......			
		return authSupHierachy;		
	}
	
}
