package com.ge.corporate.hr.profile.employee.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dao.CurrencyConversionDao;
import com.ge.corporate.hr.profile.employee.dao.OneHrCompensationDao;
import com.ge.corporate.hr.profile.employee.dao.WorkAssignmentDao;
import com.ge.corporate.hr.profile.employee.dto.OneHrCompensationDto;
import com.ge.corporate.hr.profile.employee.model.BonusSIT;
import com.ge.corporate.hr.profile.employee.model.Compensation;
import com.ge.corporate.hr.profile.employee.model.Currency;
import com.ge.corporate.hr.profile.employee.model.IncentiveCompensation;
import com.ge.corporate.hr.profile.employee.model.WorkAssignmentRestricted;
import com.ge.corporate.hr.profile.employee.util.DateUtil;


public class OneHrCompensationServiceImpl implements OneHrCompensationService  {
	
	private static Log logger = LogFactory.getLog(OneHrCompensationServiceImpl.class);
	
	private static final String IC_EPP = "EPP";
	
	@Resource(name = "oneHrCompensationDao")
	private OneHrCompensationDao oneHrCompensationDao;
	
	@Resource(name = "currencyDao")
	private CurrencyConversionDao currencyDao;
	
	@Resource(name = "workAssignmentDao")
	private WorkAssignmentDao assignmentDao;
	
	public OneHrCompensationDto getOneHrCompensation(OneHrCompensationDto onehrcompensationDto) {		
		OneHrCompensationDto compensationResDto = null;
		BaseModelCollection<Compensation> compensationList = null;
		BaseModelCollection<IncentiveCompensation> icLsit = null;		
		BaseModelCollection<BonusSIT> bonus = null;		
		WorkAssignmentRestricted corpBand = null;
		ArrayList<Compensation> oneHRCompensationList = new ArrayList<Compensation>();
		ArrayList<IncentiveCompensation> oneHRIcLsit = new ArrayList<IncentiveCompensation>();
		double sum = 0;
		if(onehrcompensationDto.getSso() > 0){	
			Date date = new Date();
			Calendar calendar = new GregorianCalendar();
			calendar.setTime(date);
			int year = calendar.get(Calendar.YEAR);
			
			compensationResDto  = new OneHrCompensationDto();
			compensationResDto.setSso(onehrcompensationDto.getSso());
			
			//Get Compensation History						
			compensationList = oneHrCompensationDao.getOneHrCompensationHistoryBySso(onehrcompensationDto.getSso());
			
			//
			
			if(compensationList == null){				
				compensationList = new BaseModelCollection<Compensation>(); //
			}
			
			//Calculate V% field
			sum = createCalculatedDataToComp((ArrayList<Compensation>)compensationList.getList(),onehrcompensationDto.getSso());
			
			
			for(Compensation comp: (ArrayList<Compensation>)compensationList.getList() ){
				if(comp.getEfectiveDate()!=null && !comp.isFutureDate() ){
						//&& 0 > date.compareTo(comp.getEfectiveDate())){
					calendar.setTime(comp.getEfectiveDate());
					if(calendar.get(Calendar.YEAR) >= 2014 && calendar.get(Calendar.YEAR) >=year-2){
						oneHRCompensationList.add(comp);
					}
				}
				if(comp.getMinSalary()!=null && comp.getMinSalary()!="0"){
					compensationResDto.setMinSalary(comp.getMinSalary());
				}
				if(comp.getMaxSalary()!=null && comp.getMaxSalary()!="0"){
					compensationResDto.setMaxSalary(comp.getMaxSalary());
				}				
			}
			compensationList.setList(oneHRCompensationList);

			compensationResDto.setCompensationList(compensationList);
			
			//Get incentive Compensation
			icLsit = oneHrCompensationDao.getOneHrIncentiveCompensationHistoryBySso(onehrcompensationDto.getSso());	
			if(icLsit== null){
				icLsit= new BaseModelCollection<IncentiveCompensation>(); 
			}
			bonus = oneHrCompensationDao.getOneHrBonusSITBySso(onehrcompensationDto.getSso());
			if(bonus== null){
				bonus= new BaseModelCollection<BonusSIT>(); 
			}
			//Calculate V% field
			sum += createCalculatedDataToIncentiveComp( (ArrayList<IncentiveCompensation>) icLsit.getList(), compensationResDto.getCurrency());	
			for(IncentiveCompensation ic: (ArrayList<IncentiveCompensation>)icLsit.getList() ){	
				if(ic.getPerfYear() >= 2014 && ic.getPerfYear() >=year-2 && !ic.isFutureDate() ){
					oneHRIcLsit.add(ic);
				}
			}
			icLsit.setList(oneHRIcLsit);
			
			compensationResDto.setIcList(icLsit);
			compensationResDto.setBonusList(bonus);
			//Set Total Current Compensation to DTO
			compensationResDto.setTotalCurrentComp((new Double(sum)).longValue());	
			corpBand = assignmentDao.getCurrentCorpBandBySso(onehrcompensationDto
					.getSso());
			if(corpBand.getBand().equalsIgnoreCase("OTHSAL")||corpBand.getBand().equalsIgnoreCase("HRLY"))
			{
				compensationResDto.setStatus("Non-exempt");
			}
			else if(corpBand.getBand().equalsIgnoreCase("LTB") || corpBand.getBand().equalsIgnoreCase("PB") ||
					corpBand.getBand().equalsIgnoreCase("LPB") || corpBand.getBand().equalsIgnoreCase("SPB") ||
					corpBand.getBand().equalsIgnoreCase("EB") || corpBand.getBand().equalsIgnoreCase("SEB") ||
					corpBand.getBand().equalsIgnoreCase("VP") || corpBand.getBand().equalsIgnoreCase("SVP") ||
					corpBand.getBand().equalsIgnoreCase("EO"))
			{
				compensationResDto.setStatus("Exempt");
			}
								
		}else{
			logger.error("Invalid SSO, SSO = " + onehrcompensationDto.getSso());
		}
		return compensationResDto;		
	}	
		
	

	/**
	 * Calculate all calculated fields for Compensation, set interval value for each compensation
	 * 	Set Lump value to compensation that belongs to.
	 * 
	 *  Rules for Total Current Cash Comp:
	 *   a) Total Current Cash Comp = most current (not future dated) salary 
     *		+ last IC amout from current or previous 2 years (currently that would be 2012 or 2011 or 2010) 
     *		+ most current (not future dated) lump sum from current or previous year (ignore negative lump sums though)
     *
	 *  Rules for V%
	 *  	a) the V% is based in the previous Compensation that is not Lump
	 *  	b) The V% For lump should be N/A 
	 *    
	 *	Rules for Interval:
	 *		a ) Calculates diference beteewn line and its previous one depending the date 
	 *
	 * @param compeList
	 * @return Lump sum plus Latest salary
	 */
	private double createCalculatedDataToComp(Collection<Compensation> compList, Long sso){		
		double lumpSum = 0;
		double latestSalary = 0;	
		String lumpCurrency = "";
		String salaryCurrency = "";
		
		if(compList != null){			
			//Calculate Interval Field		
			//Interval = #month between current line date and previous line date (rounded)
			Compensation previousComp = null;	
			
			for(Compensation comp:compList ){		
				//if compensation is lump then percentage should be N/A (null)
				if(comp.isLump()){				
					comp.setChangePercent(null);
				}
				
				if(comp.isLump()){
					int currYear = DateUtil.getYear(new Date());
					int lumpYear = DateUtil.getYear(comp.getEfectiveDate());
					// include lump to "Total Cash Comp" :most current (not future dated) lump sum from current or previous year (ignore negative lump sums though)				
					if( comp.getLumpAmmount()>0 
							&& (lumpYear == currYear || lumpYear == (currYear-1))){			
						lumpSum += comp.getLumpAmmount();
						lumpCurrency = comp.getCurrency();
					}
				}
				if(previousComp!=null)
				{	
					try{
						if(latestSalary == 0 && !comp.isFutureDate() && !comp.isLump()){
							latestSalary = comp.getSalary();	
							salaryCurrency = comp.getCurrency();
						}					
						if(previousComp.getEfectiveDate() != null && comp.getEfectiveDate() != null ){
							if(comp.getSalary()!= 0){
								if(previousComp.getCurrency().equals(comp.getCurrency()))
								{
									double value = ((previousComp.getSalary().doubleValue()/ comp.getSalary().doubleValue())-1)*100;							
									previousComp.setChangePercent(value);
								}else{
									//If currency changes ... Don't calculate V% 
									previousComp.setChangePercent(null);
								}
							}						
						}
					}catch(NullPointerException e){
						logger.debug("Null pointer exception has been thrown in 'Calculates V%' process in method createCalculatedDataToComp");
					}
				}else{
					//Set Lastest Salary;
					if(!comp.isFutureDate() && !comp.isLump()){						
						latestSalary = comp.getSalary();
						salaryCurrency = comp.getCurrency();
					}					
				}				
				//if comp is not lump
				if(!comp.isLump()){
					previousComp = comp;
				}
			}	
			List<Compensation> lumpComList = new ArrayList<Compensation>();
			
			////////////////////////////////////////////
			//Calculates Interval And Repeat the previous base salary on the lump line
			///////////////////////////////////////////
			for(Compensation comp:compList ){
				
				//Repeat the previous base salary on the lump line
				if(comp.isLump()){
					lumpComList.add(comp);
				}else{					
					for(Compensation lumpComp:lumpComList){
						lumpComp.setSalary(comp.getSalary());
					}
					lumpComList.clear();
				}
				
				//Calculates Interval
				if(previousComp!=null)
				{			
					try{
						if(previousComp.getEfectiveDate() != null && comp.getEfectiveDate() != null ){					
							Double d;
							Long inteval;
							//Calculates interval
							d = DateUtil.monthsBetween(
									previousComp.getEfectiveDate(), comp.getEfectiveDate());
							inteval = Math.round(d);
							previousComp.setInterval(inteval.shortValue());
						}	
					}catch(NullPointerException e){
						logger.debug("Null pointer exception has been thrown in 'Calculates Interval' process ");
					}
				}				
				previousComp = comp;				
			}			
		}
		
		if(lumpCurrency!=null && salaryCurrency!=null && !lumpCurrency.equalsIgnoreCase("") && !salaryCurrency.equalsIgnoreCase("") && !lumpCurrency.equalsIgnoreCase(salaryCurrency)){
			lumpSum = (lumpSum * currencyDao.getCurrency(lumpCurrency, "USD").getAmmountConverted().doubleValue())/currencyDao.getCurrency(salaryCurrency, "USD").getAmmountConverted().doubleValue();
		}
		
		return lumpSum + latestSalary;
	}
	
	/**
	 * Create Calculated data to Incentive Compensation
	 * 
	 * 	Rules For Calculate V%
	 * 		a)	If type = EPP the V% = N/A
	 * 		b)	If IC is the last then V% = N/A
	 * 		c)  the IC V% ... calcuate that based on the previous IC amount ... 
	 *		��� 	so compare 2010 IC to 2009 IC ...�� 370000 vs. 330000 
	 * 
	 * 	Rules for Return the IC value that will be added to Total Current Compensation Sum:
	 * 		a)   The value should be the most current compensation that year date is current or last year (Current Year - 1):
	 * 		b)   IC type should not be  EPP
	 * 		c)	 IC should not be future date. 
	 *  
	 *  Rules for incentive compensation type = EPP
	 * 			a) always have IC be above EPP in the same year 
	 *			b) never use EPP when calculating "Total Current Cash Comp" ...
	 *			��� Total Current Cash Comp shows 475000 right now ... but it should show 770000 (400000 + 370000) 
	 *			c) for EPP lines ... don't show V% ... show "N/A" instead
	 *
	 *	
	 * @param incentCompList
	 * @return latest IC
	 */
	private double createCalculatedDataToIncentiveComp( Collection<IncentiveCompensation> incentCompList, String salaryCurrency){
		
		IncentiveCompensation beforeIncentComp = null;
		double latestICAmount = 0;
		String icCurrency = "";
		if(incentCompList != null){
			
			for(IncentiveCompensation comp:incentCompList ){				
				//Calculating IC Total Current Compensation Value
				if(latestICAmount == 0 && !comp.isFutureDate()){
					if(comp.getType() == null || !comp.getType().equals(IC_EPP)){
						int currYear = DateUtil.getYear(new Date());
						int icYear = comp.getPerfYear();						
						if(icYear == currYear || icYear == (currYear-1) || icYear == (currYear-2)){					
							latestICAmount = comp.getAmount();
							icCurrency = comp.getCurrency();
						}
					}
				}				
				
				if(beforeIncentComp!=null)
				{	
					try{
						//Calculates V% field
						//V% = ((current year value / previous year value) - 1 ) * 100		
						if(comp.getAmount()!= null && comp.getAmount() != 0){
							if(beforeIncentComp.getCurrency() != null && beforeIncentComp.getCurrency().equals(comp.getCurrency())){
								double value = ((beforeIncentComp.getAmount().doubleValue()/ comp.getAmount().doubleValue())-1)*100;					
								beforeIncentComp.setChangePercent(value);
							}else{
								//If currency changes ... Don't calculate V% 
								beforeIncentComp.setChangePercent(null);
							}						
						}					
					}catch(NullPointerException e){
						logger.debug("Null pointer exception has been thrown in 'Calculating V% field' ");
					}					
				}
								 
				if(comp.getType() == null || !comp.getType().equals(IC_EPP)){	
					// this help to calculate V% 
					// the IC V% ... calcuate that based on the previous IC amount
					beforeIncentComp = comp; 
				}else{
					//Show "N/A" for Lines with Type = EPP					
					comp.setChangePercent(null);					
				}				
			}
		}
		
		if(icCurrency!=null && salaryCurrency!=null && !icCurrency.equalsIgnoreCase("") && !salaryCurrency.equalsIgnoreCase("") && !icCurrency.equalsIgnoreCase(salaryCurrency)){
			latestICAmount = (latestICAmount * currencyDao.getCurrency(icCurrency, "USD").getAmmountConverted().doubleValue())/currencyDao.getCurrency(salaryCurrency, "USD").getAmmountConverted().doubleValue();
		}

		return latestICAmount;
	}
	
}
