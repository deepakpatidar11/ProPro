package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.Certification;

public class CertificationMapper implements RowMapper<Certification> {

	public static final String DATA_SSO = "sso";
	public static final String DATA_YEAR = "year";
	public static final String DATA_NAME = "name";

	@Override
	public Certification mapRow(ResultSet rs, int rowNum) throws SQLException {
		Certification certification = new Certification();
		certification.setSso(rs.getLong(DATA_SSO));
		certification.setCertificationYear(rs.getShort(DATA_YEAR));
		certification.setTrainingName(rs.getString(DATA_NAME));

		return certification;
	}

}
