package com.ge.corporate.hr.profile.employee.dto;

import java.util.List;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.LanguageProficiency;

public class LanguageProficiencyDto  extends AbstractBaseDtoSupport {
	
	private static final long serialVersionUID = -6246023705366590869L;
	
	private Long sso;
	private BaseModelCollection<LanguageProficiency> languageProficiencyList;
	private List<String> languageList;
	
	public BaseModelCollection<LanguageProficiency> getLanguageProficiencyList() {
		return languageProficiencyList;
	}
	public void setLanguageProficiencyList(
			BaseModelCollection<LanguageProficiency> languageProficiencyList) {
		this.languageProficiencyList = languageProficiencyList;
	}
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	public List<String> getLanguageList() {
		return languageList;
	}
	public void setLanguageList(List<String> languageList) {
		this.languageList = languageList;
	}

	public long getId() {
		return 0;
	}
}
