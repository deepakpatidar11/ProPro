/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.MyClient;

/**
 * Direct Reports mapper
 * @author enrique.romero
 *
 */
public class MyClientsMapper implements RowMapper<MyClient>{
	
	public static final String DATA_SSO = "sso";
	public static final String DATA_FIRST_NAME = "emp_first_name";
	public static final String DATA_LAST_NAME = "emp_last_name";	
	public static final String DATA_FULL_NAME = "full_name";
	public static final String DATA_POSITION_TITLE = "wa_position_title";
	public static final String DATA_BUSINESS = "wa_business_name";
	public static final String DATA_SUB_BUSINESS = "wa_sub_business_name";
	public static final String DATA_ORGANIZATION = "wa_org_name";
	public static final String DATA_FUNCTION = "wa_function";
	
	public MyClient mapRow(ResultSet rs, int rowNum) throws SQLException {
		MyClient myClient = new MyClient();	
		
		myClient.setSso(rs.getLong(DATA_SSO));		
		myClient.setFirstName(rs.getString(DATA_FIRST_NAME));
		myClient.setLastName(rs.getString(DATA_LAST_NAME));
		myClient.setFullName(rs.getString(DATA_FULL_NAME));
		myClient.setPositionTitle(rs.getString(DATA_POSITION_TITLE));
		myClient.setBusiness(rs.getString(DATA_BUSINESS));
		myClient.setSubBusiness(rs.getString(DATA_SUB_BUSINESS));
		myClient.setOrg(rs.getString(DATA_ORGANIZATION));
		myClient.setFunction(rs.getString(DATA_FUNCTION));
				
		return myClient;		
	}	
}
