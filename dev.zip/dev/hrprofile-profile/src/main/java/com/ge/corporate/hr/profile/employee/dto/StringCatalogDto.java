/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;

public class StringCatalogDto extends AbstractBaseDtoSupport{

	private static final long serialVersionUID = -4094765911965791990L;
	
	private BaseModelCollection<String> catalog;
	
	private String crieria;
	
	public long getId() {
		return 0;
	}
	
	public BaseModelCollection<String> getCatalog() {
		return catalog;
	}

	public void setCatalog(BaseModelCollection<String> catalog) {
		this.catalog = catalog;
	}

	public String getCrieria() {
		return crieria;
	}

	public void setCrieria(String crieria) {
		this.crieria = crieria;
	}

	
}
