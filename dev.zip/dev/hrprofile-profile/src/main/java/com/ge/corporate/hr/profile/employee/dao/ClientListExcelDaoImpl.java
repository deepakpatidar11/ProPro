package com.ge.corporate.hr.profile.employee.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;

import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dao.mapper.DataGroupListMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.MyCWPopulationMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.MyHrPopulationMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.MyHrPopulationOthersMapper;
import com.ge.corporate.hr.profile.employee.dto.ExcelReport;
import com.ge.corporate.hr.profile.employee.model.MyCWPopulation;
import com.ge.corporate.hr.profile.employee.model.MyHrPopulation;

public class ClientListExcelDaoImpl extends AbstractBaseDaoSupport implements ClientListExcelDao{
	private static Log logger = LogFactory.getLog(ClientListExcelDaoImpl.class);
	
	//@PreAuthorize("(hasHRPropulationAcess() or hasRole('ROLE_SA')) and hasPermission(#sso, 'MyClients', read)")	
		@PreAuthorize("(hasRole('ROLE_SA') or hasRole('HRM') or hasRole('ORG_HRM') or hasRole('HRM_SPL') or hasRole('HRM_VIEW') or hasRole('HR_BP') or hasRole('O_S_MANAGER') or hasRole('O_S_MANAGER_CP') or hasRole('O_S_MANAGER_F') or hasRole('O_S_MANAGER_GL') or hasRole('O_S_MANAGER_R') or hasRole('O_TD_MANAGER') or hasRole('O_TD_MANAGER_CP') or hasRole('O_TD_MANAGER_F') or hasRole('O_TD_MANAGER_GL') or hasRole('O_TD_MANAGER_R') or hasRole('O_TD_NO_COMP') or hasRole('SHRM') or hasRole('SHRM_F') or hasRole('SHRM_GL') or hasRole('SHRM_R')) and (hasPermission(#sso, 'MyHRPopulation', read) or hasPermission(#sso, 'MyHRPopulationAPI', read))")	
		public BaseModelCollection<MyHrPopulation> getMyHrPopulationListBySso(Long sso, List<String> roles, String param, int start, int limit, String sortName, String sortOrder, Locale locale, String format, boolean isSuspended) {
			
			BaseModelCollection<MyHrPopulation> employeeList = new BaseModelCollection<MyHrPopulation>();
			String query = this.getSql("getMyHrPopulationListBySso");		
			String orderby = "";
			String role=StringUtils.join(roles,"','");
			boolean isNoCompRole = StringUtils.containsIgnoreCase(role, "O_TD_NO_COMP");
			
			if(roles.size()>0){
				query=query.replaceAll("ROLE_NAME_LIST", " AND ea.role_id in (SELECT r.role_id FROM t_role r WHERE r.role_name in ('"+role+"'))");
			}else{
				query=query.replaceAll("ROLE_NAME_LIST", " ");
			}

			if(param != ""){
				query=query.replaceAll("SEARCH_BY", " AND UPPER(hrp.full_table_search) LIKE UPPER('%"+param+"%')");
			}else{
				query=query.replaceAll("SEARCH_BY", "");
			}
			
			if(isSuspended){
				query=query.replaceAll("SUSPENDED", " AND hrp.assignment_status = 'Suspend Assignment'");
			}else{
				query=query.replaceAll("SUSPENDED", "");
			}
			
	   		if(sortName!=""){		
	   			orderby = sortName;
	   		}else{
	   			orderby = "full_name";
	   		}
	   		
	   		if(sortOrder!=""){		
	   			orderby = orderby+" "+sortOrder;
	   		}else{
	   			orderby = orderby+" asc";
	   		}
	   		
	   		query=query.replaceAll("ORDER_NAME", orderby);
			
			if(limit!=0){
				query=query.replaceAll("ROW_LIMIT"," WHERE ROWNUMBER BETWEEN "+start+" AND "+limit);
			}else{
				query=query.replaceAll("ROW_LIMIT","");
			}
			
			JdbcTemplate jdbcTemplate = getJdbcTemplate();
			
			jdbcTemplate.setFetchSize(500);
					try{
			 			employeeList.setList(jdbcTemplate.query(query ,new Object[] { sso.intValue() }, new MyHrPopulationMapper(locale, format, isNoCompRole)));
						logger.debug("My HR Population data was loaded susscesfully");
					}catch (EmptyResultDataAccessException eex) {
						logger.debug("My HR Population data  Not found");
					}	
			return employeeList;					
		}
		
		//@PreAuthorize("(hasRole('HRM') or hasRole('ORG_HRM') or hasRole('ROLE_SA')) and hasPermission(#sso, 'MyClients', read)")	
		@PreAuthorize("(hasRole('ROLE_SA') or hasRole('HRM') or hasRole('ORG_HRM') or hasRole('HRM_SPL') or hasRole('HRM_VIEW') or hasRole('HR_BP') or hasRole('O_S_MANAGER') or hasRole('O_S_MANAGER_CP') or hasRole('O_S_MANAGER_F') or hasRole('O_S_MANAGER_GL') or hasRole('O_S_MANAGER_R') or hasRole('O_TD_MANAGER') or hasRole('O_TD_MANAGER_CP') or hasRole('O_TD_MANAGER_F') or hasRole('O_TD_MANAGER_GL') or hasRole('O_TD_MANAGER_R') or hasRole('O_TD_NO_COMP') or hasRole('SHRM') or hasRole('SHRM_F') or hasRole('SHRM_GL') or hasRole('SHRM_R')) and (hasPermission(#sso, 'MyHRPopulation', read) or hasPermission(#sso, 'MyHRPopulationAPI', read))")
		public List<String> getMyHrPopulationRolesBySso(Long sso) {
			
			List<String> roleList = null;
			String query = this.getSql("getMyHrPopulationRolesBySso");		
			
					try{
						roleList=getJdbcTemplate().queryForList(query,new Object[] { sso.intValue() }, String.class);
						logger.debug("My HR Population Roles was loaded susscesfully");
					}catch (EmptyResultDataAccessException eex) {
						logger.debug("My HR Population Roles Not found");
					}				
			return roleList;					
		}
			
		//@PreAuthorize("(hasRole('HRM') or hasRole('ORG_HRM') or hasRole('ROLE_SA')) and hasPermission(#sso, 'MyClients', read)")
		@PreAuthorize("(hasRole('ROLE_SA') or hasRole('HRM') or hasRole('ORG_HRM') or hasRole('HRM_SPL') or hasRole('HRM_VIEW') or hasRole('HR_BP') or hasRole('O_S_MANAGER') or hasRole('O_S_MANAGER_CP') or hasRole('O_S_MANAGER_F') or hasRole('O_S_MANAGER_GL') or hasRole('O_S_MANAGER_R') or hasRole('O_TD_MANAGER') or hasRole('O_TD_MANAGER_CP') or hasRole('O_TD_MANAGER_F') or hasRole('O_TD_MANAGER_GL') or hasRole('O_TD_MANAGER_R') or hasRole('O_TD_NO_COMP') or hasRole('SHRM') or hasRole('SHRM_F') or hasRole('SHRM_GL') or hasRole('SHRM_R')) and (hasPermission(#sso, 'MyHRPopulation', read) or hasPermission(#sso, 'MyHRPopulationAPI', read))")
		public int getMyHrPopulationCountBySso(Long sso, List<String> roles, String param, boolean isSuspended) {
			
			int count = 0;
			
			StringBuilder query = new StringBuilder();
			query.append(this.getSql("getMyHrPopulationCountBySso"));
			String role=StringUtils.join(roles,"','");
			
			if(roles.size()>0){
				query.append(" AND ea.role_id in (SELECT r.role_id FROM t_role r WHERE r.role_name in ('"+role+"'))");
			}
			query.append(")");
			if(isSuspended){
				query.append(" AND assignment_status = 'Suspend Assignment'");
			}
			if(param != ""){
				query.append(" AND UPPER(full_table_search) LIKE UPPER('%"+param+"%')");
			}
					try{
						count=getJdbcTemplate().queryForInt(query.toString(),new Object[] { sso.intValue() });
						logger.debug("My HR Population Count was Calculated susscesfully");
					}catch (EmptyResultDataAccessException eex) {
						logger.debug("My HR Population Count not Calculated");
					}				
			return count;					
		}
		
		//@PreAuthorize("(hasRole('HRM') or hasRole('ORG_HRM') or hasRole('ROLE_SA')) and hasPermission(#sso, 'MyClients', read)")	
		@PreAuthorize("(hasRole('ROLE_SA') or hasRole('HRM') or hasRole('ORG_HRM') or hasRole('HRM_SPL') or hasRole('HRM_VIEW') or hasRole('HR_BP') or hasRole('O_S_MANAGER') or hasRole('O_S_MANAGER_CP') or hasRole('O_S_MANAGER_F') or hasRole('O_S_MANAGER_GL') or hasRole('O_S_MANAGER_R') or hasRole('O_TD_MANAGER') or hasRole('O_TD_MANAGER_CP') or hasRole('O_TD_MANAGER_F') or hasRole('O_TD_MANAGER_GL') or hasRole('O_TD_MANAGER_R') or hasRole('O_TD_NO_COMP') or hasRole('SHRM') or hasRole('SHRM_F') or hasRole('SHRM_GL') or hasRole('SHRM_R')) and (hasPermission(#sso, 'MyHRPopulation', read) or hasPermission(#sso, 'MyHRPopulationAPI', read))")
		public double getMyHrPopulationHeadCountBySso(Long sso, List<String> roles, String param, boolean isSuspended) {
			
			double count = 0;
			
			StringBuilder query = new StringBuilder();
			query.append(this.getSql("getMyHrPopulationHeadCountBySso"));
			String role=StringUtils.join(roles,"','");
			
			if(roles.size()>0){
				query.append(" AND ea.role_id in (SELECT r.role_id FROM t_role r WHERE r.role_name in ('"+role+"'))");
			}
			query.append(")");
			if(isSuspended){
				query.append(" AND assignment_status = 'Suspend Assignment'");
			}
			if(param != ""){
				query.append(" AND UPPER(full_table_search) LIKE UPPER('%"+param+"%')");
			}
					try{
						count=getJdbcTemplate().queryForObject(query.toString(),new Object[] { sso.intValue() }, Double.class);
						logger.debug("My HR Population HeadCount was Calculated susscesfully");
					}catch (EmptyResultDataAccessException eex) {
						logger.debug("My HR Population HeadCount not Calculated");
					}				
			return count;					
		}
		
		//@PreAuthorize("(hasHRPropulationAcess() or hasRole('ROLE_SA')) and hasPermission(#sso, 'MyClients', read)")   
		@Transactional
	    @PreAuthorize("(hasRole('ROLE_SA') or hasRole('ORG_MGR') or hasRole('SUPV') or hasRole('MGR') or hasRole('HRM') or hasRole('ORG_HRM') or hasRole('HRM_SPL') or hasRole('HRM_VIEW') or hasRole('HR_BP') or hasRole('O_S_MANAGER') or hasRole('O_S_MANAGER_CP') or hasRole('O_S_MANAGER_F') or hasRole('O_S_MANAGER_GL') or hasRole('O_S_MANAGER_R') or hasRole('O_TD_MANAGER') or hasRole('O_TD_MANAGER_CP') or hasRole('O_TD_MANAGER_F') or hasRole('O_TD_MANAGER_GL') or hasRole('O_TD_MANAGER_R') or hasRole('O_TD_NO_COMP') or hasRole('SHRM') or hasRole('SHRM_F') or hasRole('SHRM_GL') or hasRole('SHRM_R')) and hasPermission(#sso, 'MyHRPopulationAPI', read)")      
	    public BaseModelCollection<MyHrPopulation> getMyHrPopulationOthersListBySso(Long sso, String roles, String param, int start, int limit, String sortName, String sortOrder, String type, Locale locale, String format) {
	           
	           BaseModelCollection<MyHrPopulation> employeeList = new BaseModelCollection<MyHrPopulation>();
	          String query = this.getSql("getMyHrPopulationOthersBySso");
	           //StringBuilder query = new StringBuilder();
	   			//query.append(this.getSql("getMyHrPopulationOthersBySso"));		
	   			String orderby = "";
	           String execute = this.getSql("executeMyHrPopulationOthers");
	           String param1 = "";
	           String param2 = "";
	           param1 = sso+roles;
	           
	           if(type.equalsIgnoreCase("LEAVING")){
	        	   param2 = "METRIC_LEAVING_CL-"+param1+"---";
	        	   query=query.replaceAll("T_HR_POPULATION_TABLE_NAME", "T_HR_POPULATION_LEAVING");
	           }else if(type.equalsIgnoreCase("EXIT")){
	        	   param2 = "METRIC_EXIT_CL-"+param1+"---";
	        	   query=query.replaceAll("T_HR_POPULATION_TABLE_NAME", "T_HR_POPULATION_EXITS");
	           }else if(type.equalsIgnoreCase("ADDS")){
	        	   param2 = "METRIC_ADDS_CL-"+param1+"---";
	        	   query=query.replaceAll("T_HR_POPULATION_TABLE_NAME", "T_HR_POPULATION_ADDS");
	           }else if(type.equalsIgnoreCase("PENDING")){
	        	   param2 = "METRIC_PENDING_CL-"+param1+"---";
	        	   query=query.replaceAll("T_HR_POPULATION_TABLE_NAME", "T_HR_POPULATION_PENDINGADDS");
	           }   
	           
	     		if(param != ""){
	       			query= query + " AND UPPER(full_table_search) LIKE UPPER('%"+param+"%')";
	       		}
	     		
	     		query= query + ")";
	   		
	   		if(sortName!=""){		
	   			orderby = sortName;
	   		}else{
	   			orderby = "full_name";
	   		}
	   		
	   		if(sortOrder!=""){		
	   			orderby = orderby+" "+sortOrder;
	   		}else{
	   			orderby = orderby+" asc";
	   		}
	   		
	   		query=query.replaceAll("ORDER_NAME", orderby);
	   		
	   		if(limit!=0)
	   			query=query+" WHERE ROWNUMBER BETWEEN "+start+" AND "+limit;
	   		
	   		JdbcTemplate jdbcTemplate = getJdbcTemplate();   
	   		jdbcTemplate.setFetchSize(500);
	        try{   
	        	   jdbcTemplate.execute(execute.replaceAll("[?]",param2));
	               employeeList.setList(jdbcTemplate.query(query,new Object[] { param1 }, new MyHrPopulationOthersMapper(locale, format)));
	               logger.debug("My HR Population data was loaded susscesfully");
	        } catch (EmptyResultDataAccessException e) {
				logger.debug("My HR Population data  Not found " + e.getMessage());
			} catch (Exception e) {
				logger.debug("My HR Population data  Not found " + e.getMessage());
			}	      
	           return employeeList;                            
	    }
	    
		@Transactional
	    @PreAuthorize("(hasRole('ROLE_SA') or hasRole('ORG_MGR') or hasRole('SUPV') or hasRole('MGR') or hasRole('HRM') or hasRole('ORG_HRM') or hasRole('HRM_SPL') or hasRole('HRM_VIEW') or hasRole('HR_BP') or hasRole('O_S_MANAGER') or hasRole('O_S_MANAGER_CP') or hasRole('O_S_MANAGER_F') or hasRole('O_S_MANAGER_GL') or hasRole('O_S_MANAGER_R') or hasRole('O_TD_MANAGER') or hasRole('O_TD_MANAGER_CP') or hasRole('O_TD_MANAGER_F') or hasRole('O_TD_MANAGER_GL') or hasRole('O_TD_MANAGER_R') or hasRole('O_TD_NO_COMP') or hasRole('SHRM') or hasRole('SHRM_F') or hasRole('SHRM_GL') or hasRole('SHRM_R')) and hasPermission(#sso, 'MyHRPopulationAPI', read)")
		public int getMyHrPopulationOthersCountBySso(Long sso, String roles, String param, String type) {
			
			int count = 0;
			String query = this.getSql("getMyHrPopulationOthersCountBySso");
	        String execute = this.getSql("executeMyHrPopulationOthers");
	        String param1 = "";
	        String param2 = "";
			
	        param1 = sso+roles;
	        
	        if(type.equalsIgnoreCase("LEAVING")){
	     	   param2 = "METRIC_LEAVING_CL-"+param1+"---";
	     	   query=query.replaceAll("T_HR_POPULATION_TABLE_NAME", "T_HR_POPULATION_LEAVING");
	        }else if(type.equalsIgnoreCase("EXIT")){
	     	   param2 = "METRIC_EXIT_CL-"+param1+"---";
	     	   query=query.replaceAll("T_HR_POPULATION_TABLE_NAME", "T_HR_POPULATION_EXITS");
	        }else if(type.equalsIgnoreCase("ADDS")){
	     	   param2 = "METRIC_ADDS_CL-"+param1+"---";
	     	   query=query.replaceAll("T_HR_POPULATION_TABLE_NAME", "T_HR_POPULATION_ADDS");
	        }else if(type.equalsIgnoreCase("PENDING")){
	     	   param2 = "METRIC_PENDING_CL-"+param1+"---";
	     	   query=query.replaceAll("T_HR_POPULATION_TABLE_NAME", "T_HR_POPULATION_PENDINGADDS");
	        }   
	        
	  		if(param != ""){
	    			query= query + " AND UPPER(full_table_search) LIKE UPPER('%"+param+"%')";
	    	}

			try{
				JdbcTemplate jdbcTemplate = getJdbcTemplate(); 
				jdbcTemplate.execute(execute.replaceAll("[?]",param2));
				count=jdbcTemplate.queryForInt(query,new Object[] { param1 });
				logger.debug("My HR Population Count was Calculated susscesfully");
			} catch (EmptyResultDataAccessException e) {
				logger.debug("My HR Population Count not Calculated " + e.getMessage());
			} catch (Exception e) {
				logger.debug("My HR Population Count not Calculated " + e.getMessage());
			}				
			return count;					
		}
	    
		@Transactional
	    @PreAuthorize("(hasRole('ROLE_SA') or hasRole('ORG_MGR') or hasRole('SUPV') or hasRole('MGR') or hasRole('HRM') or hasRole('ORG_HRM') or hasRole('HRM_SPL') or hasRole('HRM_VIEW') or hasRole('HR_BP') or hasRole('O_S_MANAGER') or hasRole('O_S_MANAGER_CP') or hasRole('O_S_MANAGER_F') or hasRole('O_S_MANAGER_GL') or hasRole('O_S_MANAGER_R') or hasRole('O_TD_MANAGER') or hasRole('O_TD_MANAGER_CP') or hasRole('O_TD_MANAGER_F') or hasRole('O_TD_MANAGER_GL') or hasRole('O_TD_MANAGER_R') or hasRole('O_TD_NO_COMP') or hasRole('SHRM') or hasRole('SHRM_F') or hasRole('SHRM_GL') or hasRole('SHRM_R')) and hasPermission(#sso, 'MyHRPopulationAPI', read)")
		public double getMyHrPopulationOthersHeadCountBySso(Long sso, String roles, String param, String type) {
		
	    	double count = 0;
			String query = this.getSql("getMyHrPopulationOthersHeadCountBySso");
	        String execute = this.getSql("executeMyHrPopulationOthers");
	        String param1 = "";
	        String param2 = "";
			
	        param1 = sso+roles;
	        
	        if(type.equalsIgnoreCase("LEAVING")){
	     	   param2 = "METRIC_LEAVING_CL-"+param1+"---";
	     	   query=query.replaceAll("T_HR_POPULATION_TABLE_NAME", "T_HR_POPULATION_LEAVING");
	        }else if(type.equalsIgnoreCase("EXIT")){
	     	   param2 = "METRIC_EXIT_CL-"+param1+"---";
	     	   query=query.replaceAll("T_HR_POPULATION_TABLE_NAME", "T_HR_POPULATION_EXITS");
	        }else if(type.equalsIgnoreCase("ADDS")){
	     	   param2 = "METRIC_ADDS_CL-"+param1+"---";
	     	   query=query.replaceAll("T_HR_POPULATION_TABLE_NAME", "T_HR_POPULATION_ADDS");
	        }else if(type.equalsIgnoreCase("PENDING")){
	     	   param2 = "METRIC_PENDING_CL-"+param1+"---";
	     	   query=query.replaceAll("T_HR_POPULATION_TABLE_NAME", "T_HR_POPULATION_PENDINGADDS");
	        }   
	        
	  		if(param != ""){
	    			query= query + " AND UPPER(full_table_search) LIKE UPPER('%"+param+"%')";
	    	}

			try{
				JdbcTemplate jdbcTemplate = getJdbcTemplate(); 
				jdbcTemplate.execute(execute.replaceAll("[?]",param2));
				count=jdbcTemplate.queryForObject(query, new Object[] { param1 }, Double.class);
				logger.debug("My HR Population Count was Calculated susscesfully");
			} catch (EmptyResultDataAccessException e) {
				logger.debug("My HR Population Count not Calculated " + e.getMessage());
			} catch (Exception e) {
				logger.debug("My HR Population Count not Calculated " + e.getMessage());
			}					
			return count;			
		}
	    
	  //@PreAuthorize("(hasHRPropulationAcess() or hasRole('ROLE_SA')) and hasPermission(#sso, 'MyClients', read)") 
	    @PreAuthorize("(hasRole('ROLE_SA') or hasRole('HRM') or hasRole('ORG_HRM') or hasRole('HRM_SPL') or hasRole('HRM_VIEW') or hasRole('HR_BP') or hasRole('O_S_MANAGER') or hasRole('O_S_MANAGER_CP') or hasRole('O_S_MANAGER_F') or hasRole('O_S_MANAGER_GL') or hasRole('O_S_MANAGER_R') or hasRole('O_TD_MANAGER') or hasRole('O_TD_MANAGER_CP') or hasRole('O_TD_MANAGER_F') or hasRole('O_TD_MANAGER_GL') or hasRole('O_TD_MANAGER_R') or hasRole('O_TD_NO_COMP') or hasRole('SHRM') or hasRole('SHRM_F') or hasRole('SHRM_GL') or hasRole('SHRM_R')) and (hasPermission(#sso, 'MyHRPopulation', read) or hasPermission(#sso, 'MyHRPopulationAPI', read))") 
	    public BaseModelCollection<MyHrPopulation> getMyHrPopulationListBySsoExcel(Long sso, List<String> roles, String param, int start, int limit, String sortName, String sortOrder, Locale locale, String format, boolean isSuspended) {

	    BaseModelCollection<MyHrPopulation> employeeList = new BaseModelCollection<MyHrPopulation>();
	    String query = this.getSql("getMyHrPopulationExcelBySso"); 
	    String orderby = "";
	    String role=StringUtils.join(roles,"','");
	    boolean isNoCompRole = StringUtils.containsIgnoreCase(role, "O_TD_NO_COMP");

		if(roles.size()>0){
			query=query.replaceAll("ROLE_NAME_LIST", " AND ea.role_id in (SELECT r.role_id FROM t_role r WHERE r.role_name in ('"+role+"'))");
		}else{
			query=query.replaceAll("ROLE_NAME_LIST", " ");
		}

	    if(param != ""){
	    query=query.replaceAll("SEARCH_BY", " AND UPPER(hrp.full_table_search) LIKE UPPER('%"+param+"%')");
	    }else{
	    query=query.replaceAll("SEARCH_BY", "");
	    }
	    
		if(isSuspended){
			query=query.replaceAll("SUSPENDED", " AND hrp.assignment_status = 'Suspend Assignment'");
		}else{
			query=query.replaceAll("SUSPENDED", "");
		}

	       if(sortName!=""){ 
	       orderby = sortName;
	       }else{
	       orderby = "sso";
	       }
	       
	       if(sortOrder!=""){ 
	       orderby = orderby+" "+sortOrder;
	       }else{
	       orderby = orderby+" asc";
	       }
	       
	       query=query.replaceAll("ORDER_NAME", orderby);

	    if(limit!=0){
	    query=query.replaceAll("ROW_LIMIT"," WHERE ROWNUMBER BETWEEN "+start+" AND "+limit);
	    }else{
	    query=query.replaceAll("ROW_LIMIT","");
	    }
	    JdbcTemplate jdbcTemplate = getJdbcTemplate(); 
	    jdbcTemplate.setFetchSize(50000);
	    try{
	    employeeList.setList(jdbcTemplate.query(query ,new Object[] { sso.intValue() }, new MyHrPopulationMapper(locale, format, isNoCompRole)));
	    logger.debug("My HR PopulationExcel data was loaded susscesfully");
	    }catch (EmptyResultDataAccessException eex) {
	    logger.debug("My HR PopulationExcel data  Not found");
	    } 
	    return employeeList; 
	    }
	    
	    public String getFullNameDao(Long sso){
	    	String query = this.getSql("getFullNameBySso");
			return getJdbcTemplate().queryForObject(query,new Object[] { sso.intValue() }, String.class);
	    	
	    }
	    
	    @PreAuthorize("(hasRole('ROLE_SA') or hasRole('ORG_MGR') or hasRole('SUPV') or hasRole('MGR')) and hasPermission(#sso, 'MyHRPopulationAPI', read)")
		public BaseModelCollection<MyHrPopulation> getMyOrgMgrClientListBySso(
				Long sso, List<String> rel_types, String param, int start,
				int limit, String sortName, String sortOrder, Locale locale,
				String format, boolean isSuspended){
			BaseModelCollection<MyHrPopulation> employeeList = new BaseModelCollection<MyHrPopulation>();
			String query = this.getSql("getMyOrgMgrClientListBySso");		
			String orderby = "";
			String rel_type=StringUtils.join(rel_types,"','");
			
	        if(rel_types.size()>0){
	        	query=query.replaceAll("REL_TYPE_LIST",  " AND ea.rel_type IN ('"+rel_type.toUpperCase()+"')");
			}else{
				query=query.replaceAll("REL_TYPE_LIST", " AND ea.rel_type='FULL_CLIENT' ");
			}

			if(param != ""){
				query=query.replaceAll("SEARCH_BY", " AND UPPER(hrp.full_table_search) LIKE UPPER('%"+param+"%')");
			}else{
				query=query.replaceAll("SEARCH_BY", "");
			}
			if(isSuspended){
				query=query.replaceAll("SUSPENDED", " AND hrp.assignment_status = 'Suspend Assignment'");
			}else{
				query=query.replaceAll("SUSPENDED", "");
			}
			
	   		if(sortName!=""){		
	   			orderby = sortName;
	   		}else{
	   			orderby = "full_name";
	   		}
	   		
	   		if(sortOrder!=""){		
	   			orderby = orderby+" "+sortOrder;
	   		}else{
	   			orderby = orderby+" asc";
	   		}
	   		
	   		query=query.replaceAll("ORDER_NAME", orderby);
			
			if(limit!=0){
				query=query.replaceAll("ROW_LIMIT"," WHERE ROWNUMBER BETWEEN "+start+" AND "+limit);
			}else{
				query=query.replaceAll("ROW_LIMIT","");
			}
			JdbcTemplate jdbcTemplate = getJdbcTemplate();
			jdbcTemplate.setFetchSize(500);
					try{
			 			employeeList.setList(jdbcTemplate.query(query ,new Object[] { sso.intValue() }, new MyHrPopulationMapper(locale, format)));
						logger.debug("My Org Mgr Client List data was loaded susscesfully");
					}catch (EmptyResultDataAccessException eex) {
						logger.debug("My Org Mgr Client List data  Not found");
					}	
			return employeeList;	
		}
	    
	    @PreAuthorize("(hasRole('ROLE_SA') or hasRole('ORG_MGR') or hasRole('SUPV') or hasRole('MGR')) and hasPermission(#sso, 'MyHRPopulationAPI', read)")
	    public BaseModelCollection<MyHrPopulation> getMyOrgMgrClientListBySsoExcel(Long sso, List<String> rel_types, String param, int start, int limit, String sortName, String sortOrder, Locale locale, String format, boolean isSuspended) {

	        BaseModelCollection<MyHrPopulation> employeeList = new BaseModelCollection<MyHrPopulation>();
	        String query = this.getSql("getMyOrgMgrClientListExcelBySso"); 
	        String orderby = "";
	        String rel_type=StringUtils.join(rel_types,"','");

	        if(rel_types.size()>0){
	        	query=query.replaceAll("REL_TYPE_LIST",  " AND ea.rel_type IN ('"+rel_type.toUpperCase()+"')");
			}else{
				query=query.replaceAll("REL_TYPE_LIST", " AND ea.rel_type='FULL_CLIENT' ");
			}
	        
	        if(param != ""){
	        query=query.replaceAll("SEARCH_BY", " AND UPPER(hrp.full_table_search) LIKE UPPER('%"+param+"%')");
	        }else{
	        query=query.replaceAll("SEARCH_BY", "");
	        }
	    	if(isSuspended){
	    		query=query.replaceAll("SUSPENDED", " AND hrp.assignment_status = 'Suspend Assignment'");
	    	}else{
	    		query=query.replaceAll("SUSPENDED", "");
	    	}

	           if(sortName!=""){ 
	           orderby = sortName;
	           }else{
	           orderby = "sso";
	           }
	           
	           if(sortOrder!=""){ 
	           orderby = orderby+" "+sortOrder;
	           }else{
	           orderby = orderby+" asc";
	           }
	           
	           query=query.replaceAll("ORDER_NAME", orderby);

	        if(limit!=0){
	        query=query.replaceAll("ROW_LIMIT"," WHERE ROWNUMBER BETWEEN "+start+" AND "+limit);
	        }else{
	        query=query.replaceAll("ROW_LIMIT","");
	        }
	        JdbcTemplate jdbcTemplate = getJdbcTemplate();
	        jdbcTemplate.setFetchSize(50000);
	        try{
	        employeeList.setList(jdbcTemplate.query(query ,new Object[] { sso.intValue() }, new MyHrPopulationMapper(locale, format)));
	        logger.debug("My HR PopulationExcel data was loaded susscesfully");
	        }catch (EmptyResultDataAccessException eex) {
	        logger.debug("My HR PopulationExcel data  Not found");
	        } 
	        return employeeList; 
	    }
		
		@PreAuthorize("(hasRole('ROLE_SA') or hasRole('ORG_MGR') or hasRole('SUPV') or hasRole('MGR')) and hasPermission(#sso, 'MyHRPopulationAPI', read)")
		public int getMyOrgMgrClientListCountBySso(Long sso,
				List<String> rel_types, String param, boolean isSuspended){
			int count = 0;
			
			StringBuilder query = new StringBuilder();
			query.append(this.getSql("getMyOrgMgrClientListCountBySso"));
			String rel_type=StringUtils.join(rel_types,"','");
			
			if(rel_types.size()>0){
				query.append(" AND ea.rel_type in ('"+rel_type.toUpperCase()+"')");
			}else{
				query.append(" AND ea.rel_type='FULL_CLIENT' ");
			}
			query.append(")");
			if(isSuspended){
				query.append(" AND assignment_status = 'Suspend Assignment'");
			}
			if(param != ""){
				query.append(" AND UPPER(full_table_search) LIKE UPPER('%"+param+"%')");
			}
					try{
						count=getJdbcTemplate().queryForInt(query.toString(),new Object[] { sso.intValue() });
						logger.debug("My Org Mgr Client List Count was Calculated susscesfully");
					}catch (EmptyResultDataAccessException eex) {
						logger.debug("My Org Mgr Client List Count not Calculated");
					}				
			return count;
		}

		@PreAuthorize("(hasRole('ROLE_SA') or hasRole('ORG_MGR') or hasRole('SUPV') or hasRole('MGR')) and hasPermission(#sso, 'MyHRPopulationAPI', read)")
		public int getMyOrgMgrClientListHeadCountBySso(Long sso,
				List<String> rel_types, String param, boolean isSuspended){
			int count = 0;
			
			StringBuilder query = new StringBuilder();
			query.append(this.getSql("getMyOrgMgrClientListHeadCountBySso"));
			String rel_type=StringUtils.join(rel_types,"','");
			
			if(rel_types.size()>0){
				query.append(" AND ea.rel_type in ('"+rel_type.toUpperCase()+"')");
			}else{
				query.append(" AND ea.rel_type='FULL_CLIENT' ");
			}
			query.append(")");
			if(isSuspended){
				query.append(" AND assignment_status = 'Suspend Assignment'");
			}
			if(param != ""){
				query.append(" AND UPPER(full_table_search) LIKE UPPER('%"+param+"%')");
			}
					try{
						count=getJdbcTemplate().queryForInt(query.toString(),new Object[] { sso.intValue() });
						logger.debug("My Org Mgr Client List HeadCount was Calculated susscesfully");
					}catch (EmptyResultDataAccessException eex) {
						logger.debug("My Org Mgr Client List HeadCount not Calculated");
					}				
			return count;	
		}
		
		@PreAuthorize("(hasRole('ROLE_SA') or hasRole('ORG_MGR') or hasRole('SUPV') or hasRole('MGR')) and hasPermission(#sso, 'MyHRPopulationAPI', read)")
		public List<String> getMymyOrgMgrRelTypesBySso(Long sso){
			List<String> relTypes = null;
			String query = this.getSql("getMymyOrgMgrRelTypesBySso");		
			
					try{
						relTypes=getJdbcTemplate().queryForList(query,new Object[] { sso.intValue() }, String.class);
						logger.debug("My Org Mgr Client List Rel Types  was loaded susscesfully");
					}catch (EmptyResultDataAccessException eex) {
						logger.debug("My Org Mgr Client List Rel Types Not found");
					}				
			return relTypes;
		}
		
		@PreAuthorize("(hasRole('ROLE_SA') or hasRole('HRM') or hasRole('ORG_HRM') or hasRole('HRM_SPL') or hasRole('HRM_VIEW') or hasRole('HR_BP') or hasRole('O_S_MANAGER') or hasRole('O_S_MANAGER_CP') or hasRole('O_S_MANAGER_F') or hasRole('O_S_MANAGER_GL') or hasRole('O_S_MANAGER_R') or hasRole('O_TD_MANAGER') or hasRole('O_TD_MANAGER_CP') or hasRole('O_TD_MANAGER_F') or hasRole('O_TD_MANAGER_GL') or hasRole('O_TD_MANAGER_R') or hasRole('O_TD_NO_COMP') or hasRole('SHRM') or hasRole('SHRM_F') or hasRole('SHRM_GL') or hasRole('SHRM_R')) and hasPermission(#sso, 'MyCWPopulationAPI', read)")    
		public BaseModelCollection<MyCWPopulation> getMyCWPopulationListBySso(
				Long sso, List<String> roles, String param, int start, int limit,
				String sortName, String sortOrder, List<String> subpersontype, String format){
			BaseModelCollection<MyCWPopulation> employeeList = new BaseModelCollection<MyCWPopulation>();
			String query = this.getSql("getMyCWPopulationListBySso");		
			String orderby = "";
			String role=StringUtils.join(roles,"','");
			String subpersontypes=StringUtils.join(subpersontype,"','");
			
			if(roles.size()>0){
				query=query.replaceAll("ROLE_NAME_LIST", " AND cwa.role_id in (SELECT r.role_id FROM t_role r WHERE r.role_name in ('"+role+"'))");
			}else{
				query=query.replaceAll("ROLE_NAME_LIST", " ");
			}
			
			if(subpersontype.size()>0){
				query=query.replaceAll("SUB_PER_TYPE_LIST", " AND cwa.cw_subpersontype in ('"+subpersontypes+"')");
			}else{
				query=query.replaceAll("SUB_PER_TYPE_LIST", " ");
			}

			if(param != ""){
				query=query.replaceAll("SEARCH_BY", " AND UPPER(cwp.full_table_search) LIKE UPPER('%"+param+"%')");
			}else{
				query=query.replaceAll("SEARCH_BY", "");
			}
			
	   		if(sortName!=""){		
	   			orderby = sortName;
	   		}else{
	   			orderby = "full_name";
	   		}
	   		
	   		if(sortOrder!=""){		
	   			orderby = orderby+" "+sortOrder;
	   		}else{
	   			orderby = orderby+" asc";
	   		}
	   		
	   		query=query.replaceAll("ORDER_NAME", orderby);
			
			if(limit!=0){
				query=query.replaceAll("ROW_LIMIT"," WHERE ROWNUMBER BETWEEN "+start+" AND "+limit);
			}else{
				query=query.replaceAll("ROW_LIMIT","");
			}
			JdbcTemplate jdbcTemplate = getJdbcTemplate();
			if(format.equalsIgnoreCase("EXCEL")){
				jdbcTemplate.setFetchSize(3000);
			}else{
				jdbcTemplate.setFetchSize(500);
			}
					try{
			 			employeeList.setList(jdbcTemplate.query(query ,new Object[] { sso.intValue() }, new MyCWPopulationMapper()));
						logger.debug("My CW Population data was loaded susscesfully");
					}catch (EmptyResultDataAccessException eex) {
						logger.debug("My CW Population data  Not found");
					}	
			return employeeList;
		}

		@PreAuthorize("(hasRole('ROLE_SA') or hasRole('HRM') or hasRole('ORG_HRM') or hasRole('HRM_SPL') or hasRole('HRM_VIEW') or hasRole('HR_BP') or hasRole('O_S_MANAGER') or hasRole('O_S_MANAGER_CP') or hasRole('O_S_MANAGER_F') or hasRole('O_S_MANAGER_GL') or hasRole('O_S_MANAGER_R') or hasRole('O_TD_MANAGER') or hasRole('O_TD_MANAGER_CP') or hasRole('O_TD_MANAGER_F') or hasRole('O_TD_MANAGER_GL') or hasRole('O_TD_MANAGER_R') or hasRole('O_TD_NO_COMP') or hasRole('SHRM') or hasRole('SHRM_F') or hasRole('SHRM_GL') or hasRole('SHRM_R')) and hasPermission(#sso, 'MyCWPopulationAPI', read)")
		public int getMyCWPopulationCountBySso(Long sso, List<String> roles, String param, List<String> subpersontype){
			int count = 0;
			
			StringBuilder query = new StringBuilder();
			query.append(this.getSql("getMyCWPopulationCountBySso"));
			String role=StringUtils.join(roles,"','");
			String subpersontypes=StringUtils.join(subpersontype,"','");
			
			if(roles.size()>0){
				query.append(" AND cwa.role_id in (SELECT r.role_id FROM t_role r WHERE r.role_name in ('"+role+"'))");
			}
			if(subpersontype.size()>0){
				query.append(" AND cwa.cw_subpersontype in ('"+subpersontypes+"')");
			}
			query.append(")");

			if(param != ""){
				query.append(" AND UPPER(full_table_search) LIKE UPPER('%"+param+"%')");
			}
					try{
						count=getJdbcTemplate().queryForInt(query.toString(),new Object[] { sso.intValue() });
						logger.debug("My CW Population Count was Calculated susscesfully");
					}catch (EmptyResultDataAccessException eex) {
						logger.debug("My CW Population Count not Calculated");
					}				
			return count;
		}
		
		@PreAuthorize("(hasRole('ROLE_SA') or hasRole('ORG_MGR') or hasRole('SUPV') or hasRole('MGR')) and hasPermission(#sso, 'MyCWPopulationAPI', read)")
		public BaseModelCollection<MyCWPopulation> getMyCWMgrPopulationListBySso(
				Long sso, List<String> rel_types, String param, int start, int limit,
				String sortName, String sortOrder, List<String> subpersontype, String format){
			BaseModelCollection<MyCWPopulation> employeeList = new BaseModelCollection<MyCWPopulation>();
			String query = this.getSql("getMyCWMgrPopulationListBySso");		
			String orderby = "";
			String rel_type=StringUtils.join(rel_types,"','");
			String subpersontypes=StringUtils.join(subpersontype,"','");
			
			if(rel_types.size()>0){
				query=query.replaceAll("REL_TYPE_LIST", " AND cwa.rel_type in ('"+rel_type+"')");
			}else{
				query=query.replaceAll("REL_TYPE_LIST", " AND cwa.rel_type in ('FULL_CLIENT')");
			}
			
			if(subpersontype.size()>0){
				query=query.replaceAll("SUB_PER_TYPE_LIST", " AND cwa.cw_subpersontype in ('"+subpersontypes+"')");
			}else{
				query=query.replaceAll("SUB_PER_TYPE_LIST", " ");
			}

			if(param != ""){
				query=query.replaceAll("SEARCH_BY", " AND UPPER(cwp.full_table_search) LIKE UPPER('%"+param+"%')");
			}else{
				query=query.replaceAll("SEARCH_BY", "");
			}
			
	   		if(sortName!=""){		
	   			orderby = sortName;
	   		}else{
	   			orderby = "full_name";
	   		}
	   		
	   		if(sortOrder!=""){		
	   			orderby = orderby+" "+sortOrder;
	   		}else{
	   			orderby = orderby+" asc";
	   		}
	   		
	   		query=query.replaceAll("ORDER_NAME", orderby);
			
			if(limit!=0){
				query=query.replaceAll("ROW_LIMIT"," WHERE ROWNUMBER BETWEEN "+start+" AND "+limit);
			}else{
				query=query.replaceAll("ROW_LIMIT","");
			}
			JdbcTemplate jdbcTemplate = getJdbcTemplate();
			if(format.equalsIgnoreCase("EXCEL")){
				jdbcTemplate.setFetchSize(3000);
			}else{
				jdbcTemplate.setFetchSize(500);
			}
					try{
			 			employeeList.setList(getJdbcTemplate().query(query ,new Object[] { sso.intValue() }, new MyCWPopulationMapper()));
						logger.debug("My CW ORG_MGRPopulation data was loaded susscesfully");
					}catch (EmptyResultDataAccessException eex) {
						logger.debug("My CW ORG_MGR Population data  Not found");
					}	
			return employeeList;
		}

		@PreAuthorize("(hasRole('ROLE_SA') or hasRole('ORG_MGR') or hasRole('SUPV') or hasRole('MGR')) and hasPermission(#sso, 'MyCWPopulationAPI', read)")
		public int getMyCWMgrPopulationCountBySso(Long sso, List<String> rel_types, String param, List<String> subpersontype){
			int count = 0;
			
			StringBuilder query = new StringBuilder();
			query.append(this.getSql("getMyCWMgrPopulationCountBySso"));
			String rel_type=StringUtils.join(rel_types,"','");
			String subpersontypes=StringUtils.join(subpersontype,"','");
			
			if(rel_types.size()>0){
				query.append(" AND cwa.rel_type in ('"+rel_type+"')");
			}else{
				query.append(" AND cwa.rel_type in ('FULL_CLIENT')");
			}
			if(subpersontype.size()>0){
				query.append(" AND cwa.cw_subpersontype in ('"+subpersontypes+"')");
			}
			query.append(")");

			if(param != ""){
				query.append(" AND UPPER(full_table_search) LIKE UPPER('%"+param+"%')");
			}
					try{
						count=getJdbcTemplate().queryForInt(query.toString(),new Object[] { sso.intValue() });
						logger.debug("My CW ORG_MGR Population Count was Calculated susscesfully");
					}catch (EmptyResultDataAccessException eex) {
						logger.debug("My CW ORG_MGR Population Count not Calculated");
					}				
			return count;
		}

		@Override
		public List<ExcelReport>  getDatagroupReport(List<ExcelReport> datgroupList,String type) {
			String query="";
			if(type.equalsIgnoreCase("byRole"))
			{
			 query = this.getSql("getReportByRole");	
			}
			else
				
			{
				 query = this.getSql("getReportByDatagroup");	
			}
			try{

		   		JdbcTemplate jdbcTemplate = getJdbcTemplate();   
				
				datgroupList=jdbcTemplate.query(query, new DataGroupListMapper());
				
			}
			catch (Exception e) {
				
				logger.debug(" ");
			}
			return datgroupList;
		}

}
