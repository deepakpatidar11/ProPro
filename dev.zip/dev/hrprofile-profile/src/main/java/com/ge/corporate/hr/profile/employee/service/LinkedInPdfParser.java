package com.ge.corporate.hr.profile.employee.service;

import java.io.File;
import java.io.InputStream;
import java.net.URI;
import java.nio.file.Path;

import com.ge.corporate.hr.profile.employee.model.LinkedInPdfData;

public interface LinkedInPdfParser {

	public LinkedInPdfData parse(File file);
	public LinkedInPdfData parse(URI uri);
	public LinkedInPdfData parse(String path);
	public LinkedInPdfData parse(Path path);
	public LinkedInPdfData parse(InputStream is);

}