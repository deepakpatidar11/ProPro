/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dto.ContactsDemographicsDto;
import com.ge.corporate.hr.profile.employee.dto.EducationCatalogs;
import com.ge.corporate.hr.profile.employee.dto.EducationDto;
import com.ge.corporate.hr.profile.employee.dto.EducationTrainingDto;
import com.ge.corporate.hr.profile.employee.dto.PersonalCVDto;
import com.ge.corporate.hr.profile.employee.dto.TrainingDto;
import com.ge.corporate.hr.profile.employee.model.Certification;
import com.ge.corporate.hr.profile.employee.model.LanguageProficiency;
import com.ge.corporate.hr.profile.employee.model.OptinSharing;


public interface PersonalCVService {	
	public PersonalCVDto getDemographics(PersonalCVDto personalCVDto);
	public ContactsDemographicsDto getContactsDemographics(ContactsDemographicsDto contactsDemographicsDto);
	public EducationTrainingDto getEducationAndTraining(EducationTrainingDto educationDto);
	public EducationTrainingDto getEducationAndTrainingOptin(EducationTrainingDto educationDto, OptinSharing optinSharing);
	public EducationDto getEducation(EducationDto educationDto);
	public TrainingDto getTraining(TrainingDto trainingDto, List<String> allTraining, List<String> optinTraining);
	public EducationDto getEducationAll(EducationDto educationDto, boolean isSharing);
	public TrainingDto getTrainingAll(TrainingDto trainingDto, boolean isSharing, List<String> optinTraining);
	public EducationTrainingDto getEducationBySso(EducationTrainingDto educationDto);
	public EducationTrainingDto getTrainingBySso(EducationTrainingDto educationDto, boolean datagroupAccess, OptinSharing optinSharing);
	public EducationTrainingDto getCertificationsBySso(EducationTrainingDto educationDto);

	public List<String> getLanguageList();
	public boolean addLanguages(Long sso, ArrayList<Map<String, String>> langProfList);
	public boolean deleteLanguages(Long sso, ArrayList<Map<String, String>> langProfList);
	public boolean updateLanguages(Long sso, ArrayList<Map<String, String>> langProfList);
	public boolean setLanguageProficieny(Long sso, ArrayList<Map<String, String>> langProfList);
	public EducationTrainingDto getLanguageProficieny(EducationTrainingDto educationDto);
	public EducationCatalogs loadEducationCatalogs(String country, String query);
	public boolean saveEducationDetails(Long sso,
			EducationTrainingDto educationDetails);
	public boolean saveProfessionalCertifications(Long sso,
			List<Certification> list);
	public boolean hasEducation(Long sso);
}
