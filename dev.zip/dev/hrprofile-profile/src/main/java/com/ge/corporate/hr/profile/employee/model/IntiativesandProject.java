package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;
@XmlRootElement(name="intiativesandproject")
@XmlAccessorType(XmlAccessType.FIELD)
public class IntiativesandProject extends AbstractBaseModelSupport{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3409231649687852125L;
	/**
	 * 
	 */
	@XmlElement(name="sso")
	private Long sso;
	@XmlElement(name="title")
	private String title;
	@XmlElement(name="fromDate")
	private String fromDate;
	@XmlElement(name="toDate")
	private String toDate;
	@XmlElement(name="description")
	private String description;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}

}
