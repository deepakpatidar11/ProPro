/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.MyClient;

public class MyClientsDto extends AbstractBaseDtoSupport{

	/**
	 *Default serial ID 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 *Employee SSO
	 */
	private Long sso;
	
	/**
	 * My Clients Model
	 */
	private BaseModelCollection<MyClient> myClientsList;

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public BaseModelCollection<MyClient> getMyClientsList() {
		return myClientsList;
	}

	public void setMyClientsList(BaseModelCollection<MyClient> myClientsList) {
		this.myClientsList = myClientsList;
	}
	
	public long getId() {
		return sso != null ? sso.longValue() : 0;
	}
	
		
}
