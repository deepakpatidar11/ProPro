/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import java.util.List;

import com.ge.corporate.hr.profile.employee.dto.CurrencyDto;
import com.ge.corporate.hr.profile.employee.model.Currency;

public interface CurrencyConversionDao {

	public void setCurrency(CurrencyDto currency);
	
	public void setCurrency(List<CurrencyDto> currencyList);
	
	public Currency getCurrency(String currencyName, String currencyConverted);
	
	public List<String> getAvaliableCurrencies();
	
	public void clearConversionRatings();
	
	public void swapConversionRates();
	
}
