/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import java.util.List;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.Education;

public class EducationDto extends AbstractBaseDtoSupport {

	/**
	 * Default serial ID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Employee SSO
	 */
	private Long sso;

	private boolean shared;
	/**
	 * Education Model
	 */
	private BaseModelCollection<Education> educationList;

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public BaseModelCollection<Education> getEducationList() {
		return educationList;
	}

	public void setEducationList(List<Education> education) {
		this.educationList.setList(education);
	}

	public void setEducationList(BaseModelCollection<Education> education) {
		this.educationList = education;
	}

	public long getId() {
		return sso != null ? sso.longValue() : 0;
	}

	public boolean getShared() {
		return shared;
	}

	public void setShared(boolean shared) {
		this.shared = shared;
	}

}