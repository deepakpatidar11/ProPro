/*package com.ge.corporate.hr.profile.employee.service.mail;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.mail.MailException;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import com.ge.corporate.hr.profile.employee.service.mail.SensitiveDataPopupMail;

public class SensitiveDataPopupMailImpl implements SensitiveDataPopupMail{
	private static Log log = LogFactory.getLog(SensitiveDataPopupMailImpl.class);

	private String mailTo = null;
	
	private MailSender mailSender;
	
    private SimpleMailMessage templateMessageSensitiveDataPopup;
    
	public void setMailTo(String mailTo) {
		this.mailTo = mailTo;
	}

	public void setMailSender(MailSender mailSender) {
		this.mailSender = mailSender;
	}
	
	public void setTemplateMessageSensitiveDataPopup(
			SimpleMailMessage templateMessageSensitiveDataPopup) {
		this.templateMessageSensitiveDataPopup = templateMessageSensitiveDataPopup;
	}

	public Log getLog() {
		return log;
	}

	public boolean sendMail(Long principal, Long sso, List<String> roles,
			List<String> rolesForContext){

		SimpleMailMessage msg = new SimpleMailMessage(this.templateMessageSensitiveDataPopup);			
		
		StringBuilder strFileContent = new StringBuilder();
		strFileContent
				.append("Please review the Security Roles assigned to the user listed below in order to validate whether or not the access should allow view to sensitive employee data, such as salary."
						+ "\n\n");
		strFileContent.append("SSO ID: " + principal + "\n");
		strFileContent.append("Roles: " + StringUtils.join(roles, ", "));
		msg.setTo(mailTo.split(","));
		msg.setText(strFileContent.toString());	
		
        try{
            this.mailSender.send(msg);
        }
        catch(MailException ex) {
            log.debug(ex.getMessage());    
            return false;
        }catch (Exception e) {
        	log.debug(e.getMessage()); 
        	return false;
        }
		return true;
	}
	
	public String getMailTo() {
		return mailTo;
	}

	public MailSender getMailSender() {
		return mailSender;
	}

	public SimpleMailMessage getTemplateMessageSensitiveDataPopup() {
		return templateMessageSensitiveDataPopup;
	}
	

}*/
