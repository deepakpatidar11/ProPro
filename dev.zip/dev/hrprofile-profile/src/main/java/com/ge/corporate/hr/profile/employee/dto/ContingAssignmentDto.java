package com.ge.corporate.hr.profile.employee.dto;

import java.util.Date;

import javax.xml.bind.annotation.XmlElement;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;

public class ContingAssignmentDto extends AbstractBaseDtoSupport{


	/**
	 * 
	 */
	private static final long serialVersionUID = 8325858576841329028L;

	public long getId() {
		// TODO Auto-generated method stub
		return 0;
	}

	@XmlElement(name="title")
	private String title;
	
	@XmlElement(name="industrySegment")
	private String industrySegment;

	@XmlElement(name="businessSegmentName")
	private String businessSegmentName;
	
	@XmlElement(name="subBusinessName")
	private String subBusinessName;
		
	@XmlElement(name="employeeType")
	private String employeeType;
	
	@XmlElement(name="jobFucntion")
	private String jobFucntion;
	
	@XmlElement(name="jobFamily")
	private String jobFamily;	
	
	@XmlElement(name="department")
	private String department;
		
	@XmlElement(name="personType")
	private String personType;
	
	@XmlElement(name="sponsorSso")
	private Long sponsorSso;	

	@XmlElement(name="sponsorName")
	private String sponsorName;

	@XmlElement(name="sponsorFirstName")
	private String sponsorFirstName;
	
	@XmlElement(name="sponsorLastName")
	private String sponsorLastName;
	
	@XmlElement(name="ssoStartDate")
	private Date ssoStartDate;
	
	@XmlElement(name="ssoEndDate")
	private Date ssoEndDate;
	
	public String getSponsorName() {
		return sponsorName;
	}

	public void setSponsorName(String sponsorName) {
		this.sponsorName = sponsorName;
	}
	
	public String getSponsorFirstName() {
		return sponsorFirstName;
	}

	public void setSponsorFirstName(String sponsorFirstName) {
		this.sponsorFirstName = sponsorFirstName;
	}

	public String getSponsorLastName() {
		return sponsorLastName;
	}

	public void setSponsorLastName(String sponsorLastName) {
		this.sponsorLastName = sponsorLastName;
	}

	public Long getSponsorSso() {
		return sponsorSso;
	}

	public void setSponsorSso(Long sponsorSso) {
		this.sponsorSso = sponsorSso;
	}
	
	public Date getSsoStartDate() {
		return ssoStartDate;
	}

	public void setSsoStartDate(Date ssoStartDate) {
		this.ssoStartDate = ssoStartDate;
	}

	public Date getSsoEndDate() {
		return ssoEndDate;
	}

	public void setSsoEndDate(Date ssoEndDate) {
		this.ssoEndDate = ssoEndDate;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getPersonType() {
		return personType;
	}

	public void setPersonType(String personType) {
		this.personType = personType;
	}


	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getIndustrySegment() {
		return industrySegment;
	}

	public void setIndustrySegment(String industrySegment) {
		this.industrySegment = industrySegment;
	}

	public String getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}

	public String getJobFucntion() {
		return jobFucntion;
	}

	public void setJobFucntion(String jobFucntion) {
		this.jobFucntion = jobFucntion;
	}

	public String getJobFamily() {
		return jobFamily;
	}

	public void setJobFamily(String jobFamily) {
		this.jobFamily = jobFamily;
	}

	public String getBusinessSegmentName() {
		return businessSegmentName;
	}

	public void setBusinessSegmentName(String businessSegmentName) {
		this.businessSegmentName = businessSegmentName;
	}

	public String getSubBusinessName() {
		return subBusinessName;
	}

	public void setSubBusinessName(String subBusinessName) {
		this.subBusinessName = subBusinessName;
	}
}
