/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.dto.SearchCompDto;
import com.ge.corporate.hr.profile.employee.model.ShortProfileList;


public class SearchCompListMapper implements RowMapper<SearchCompDto>{

	public static final String DATA_SSO = "sso";
	public static final String DATA_NAME = "emps_full_name";
	public static final String DATA_MANAGER_NAME = "emps_manager_name";
	public static final String DATA_BUSINESS = "emps_business_name";
	public static final String DATA_SUB_BUSINESS = "emps_subbusiness_name";
	public static final String DATA_ORGANIZATION = "emps_org_name";
	public static final String DATA_FUNCTION = "emps_function";
	public static final String DATA_IFG = "emps_ifg";
	public static final String DATA_TITLE = "emps_title_name";
	public static final String DATA_MANAGER_SSO = "emps_manager_sso";
	public static final String DATA_BAND = "emps_band";
	public static final String DATA_COUNTRY = "emps_country";
	public static final String DATA_REGION = "emps_region";
	public static final String DATA_JOB_FAMILY = "emps_job_family";
	public static final String DATA_LDR_PRG = "emps_leadership_program";
	public static final String DATA_LDR_PRG_TYPE = "emps_leadership_program_type";
	
	
	public SearchCompDto mapRow(ResultSet rs, int rowNum) throws SQLException {		
		SearchCompDto employee = new SearchCompDto();
		
		employee.setSso(rs.getLong(DATA_SSO));
		employee.setEmpName(rs.getString(DATA_NAME));
		employee.setFunc(rs.getString(DATA_FUNCTION));
		employee.setEmpManagerName(rs.getString(DATA_MANAGER_NAME));
		employee.setBusiness(rs.getString(DATA_BUSINESS));
		employee.setSubBusiness(rs.getString(DATA_SUB_BUSINESS));
		employee.setOrganization(rs.getString(DATA_ORGANIZATION));
		employee.setIfg(rs.getString(DATA_IFG));
		employee.setTitle(rs.getString(DATA_TITLE));
		employee.setEmpManagerSso(rs.getLong(DATA_MANAGER_SSO));
		employee.setBand(DATA_BAND);
		employee.setCountry(DATA_COUNTRY);
		employee.setRegion(DATA_REGION);
		employee.setJobFamily(DATA_JOB_FAMILY);
		employee.setLeadershipProgram(DATA_LDR_PRG);
		employee.setLeadershipProgramType(DATA_LDR_PRG_TYPE);
		
		return employee;		
		
	}
	
}
