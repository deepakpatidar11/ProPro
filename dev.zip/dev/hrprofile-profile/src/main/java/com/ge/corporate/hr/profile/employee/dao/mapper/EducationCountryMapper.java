package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.EducationCountry;

public class EducationCountryMapper implements RowMapper<EducationCountry> {
	public static final String COUNTRY_CODE = "COUNTRY_CODE";
	public static final String COUNTRY_LABEL = "COUNTRY_LABEL";

	public EducationCountry mapRow(ResultSet rs, int rowNum) throws SQLException {
		EducationCountry country = new EducationCountry();
		country.setCountryCode(rs.getString(COUNTRY_CODE));
		country.setCountryName(rs.getString(COUNTRY_LABEL));
		return country;
	}

}
