package com.ge.corporate.hr.profile.employee.service;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.nio.file.Path;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.sax.BodyContentHandler;
/*
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.nio.file.Path;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.sax.BodyContentHandler;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

import com.ge.corporate.hr.profile.employee.model.LinkedInPdfData;
import com.ge.corporate.hr.profile.employee.model.LinkedInPdfEducation;
import com.ge.corporate.hr.profile.employee.model.LinkedInPdfEmploymentHistory;
*/
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

import com.ge.corporate.hr.profile.employee.model.LinkedInPdfData;
import com.ge.corporate.hr.profile.employee.model.LinkedInPdfEducation;
import com.ge.corporate.hr.profile.employee.model.LinkedInPdfEmploymentHistory;

public class LinkedInPdfParserImpl implements LinkedInPdfParser {

	private static final Logger LOGGER = LoggerFactory.getLogger(LinkedInPdfParser.class);

	private static final String FOOTER_BEGIN_REGEX_VALUE = "\\w+ \\w+\\n[\\s\\S]*\\nContact \\w+ on LinkedIn";
	private static final String MONTH_REGEX_VALUE = "(January|February|March|April|May|"
			+ "June|July|August|September|October|November|December)";
	private static final String DATE_REGEX_VALUE = "(" + MONTH_REGEX_VALUE + " )?\\d{4}";

	private static final Pattern END_LINE_REGEX = Pattern.compile("\\n", Pattern.MULTILINE);
	private static final Pattern MONTH_REGEX = Pattern.compile(MONTH_REGEX_VALUE);
	private static final Pattern DATE_REGEX = Pattern.compile(DATE_REGEX_VALUE);
	private static final Pattern COMMA_REGEX = Pattern.compile(", ?");
	private static final Pattern TRIM_CHARS_REGEX = Pattern.compile("^(\\s+|Page \\d+\\n?$)", Pattern.MULTILINE);

	private static final Pattern SUMMARY_REGEX = Pattern.compile(
			"(?<=^Summary\n)[\\s\\S]+?(?=^(Experience|Education|Honors and Awards|" + FOOTER_BEGIN_REGEX_VALUE + ")$)",
			Pattern.MULTILINE);

	private static final Pattern EXPERIENCE_REGEX = Pattern.compile(
			"(?<=^Experience\n)[\\s\\S]+?(?=^(Education|Honors and Awards|" + FOOTER_BEGIN_REGEX_VALUE + ")$)",
			Pattern.MULTILINE);
	private static final Pattern EXPERIENCE_HEADERS_REGEX = Pattern.compile(
			"^.+?\\n^" + DATE_REGEX_VALUE + " +- +(Present|" + DATE_REGEX_VALUE + " \\(\\d+ \\w+( \\d+ \\w+)?\\))$",
			Pattern.MULTILINE);
	private static final Pattern EXPERIENCE_TITLE_REGEX = Pattern.compile("^.+(?= at .+$)", Pattern.MULTILINE);
	private static final Pattern EXPERIENCE_COMPANY_REGEX = Pattern.compile("(?<= at ).+$", Pattern.MULTILINE);

	private static final Pattern EDUCATION_REGEX = Pattern.compile(
			"(?<=^Education\n)[\\s\\S]+?(?=^(Honors and Awards|" + FOOTER_BEGIN_REGEX_VALUE + ")$)", Pattern.MULTILINE);
	private static final Pattern EDUCATION_ACTIVITIES_AND_SOCIETIES_TRIM_REGEX = Pattern
			.compile("^Activities and Societies: [\\s\\S]+?$", Pattern.MULTILINE);

	private static final DateFormat MONTH_YEAR_DATE_FORMAT = new SimpleDateFormat("MMMM yyyy");
	private static final DateFormat YEAR_DATE_FORMAT = new SimpleDateFormat("yyyy");

	private ExecutorService executor = new ThreadPoolExecutor(3, 10, 2L, TimeUnit.SECONDS,
			new LinkedBlockingQueue<Runnable>());
	
	@Override
	public LinkedInPdfData parse(final File file) {
		return parse(file.toURI());
	}

	@Override
	public LinkedInPdfData parse(final URI uri) {
		try (InputStream is = new BufferedInputStream(uri.toURL().openStream())) {
			return parse(is);
		} catch (IOException e) {
			LOGGER.error("Unable to open '{}'", uri.getPath());
			throw new UnrecoverableParsingRuntimeException(e);
		}
	}

	@Override
	public LinkedInPdfData parse(final String path) {
		try (InputStream is = new BufferedInputStream(new FileInputStream(path))) {
			return parse(is);
		} catch (IOException e) {
			LOGGER.error("Unable to open '{}'", path);
			throw new UnrecoverableParsingRuntimeException(e);
		}
	}

	@Override
	public LinkedInPdfData parse(final Path path) {
		return parse(path.toUri());
	}

	@Override
	public LinkedInPdfData parse(final InputStream is) {

		try {
			ContentHandler contentHandler = new BodyContentHandler(-1);
			new AutoDetectParser().parse(is, contentHandler, new Metadata());
			String content = TRIM_CHARS_REGEX.matcher(contentHandler.toString()).replaceAll("");
			
			return executeParse(content);

		} catch (IOException | SAXException | TikaException e) {
			LOGGER.error("Exception occured during parsing", e);
			throw new UnrecoverableParsingRuntimeException(e);
		}
	}

	private LinkedInPdfData executeParse(String content) {
		Future<List<LinkedInPdfEmploymentHistory>> employmentHistory = executor
				.submit(new Callable<List<LinkedInPdfEmploymentHistory>>() {
					@Override
					public List<LinkedInPdfEmploymentHistory> call() throws Exception {
						return parseExperience(content);
					}
				});

		Future<List<LinkedInPdfEducation>> education = executor.submit(new Callable<List<LinkedInPdfEducation>>() {
			@Override
			public List<LinkedInPdfEducation> call() throws Exception {
				return parseEducation(content);
			}
		});

		Future<String> summary = executor.submit(new Callable<String>() {
			@Override
			public String call() throws Exception {
				return parseSummary(content);
			}
		});

		try {
			LinkedInPdfData data = new LinkedInPdfData();
			data.setEmploymentHistory(employmentHistory.get());
			data.setEducation(education.get());
			data.setSummary(summary.get());
			return data;
		} catch (InterruptedException | ExecutionException e) {
			LOGGER.error("Exception occured during parsing", e);
			if (e.getCause() instanceof UnrecoverableParsingRuntimeException) {
				throw (UnrecoverableParsingRuntimeException) e.getCause();
			}
			throw new UnrecoverableParsingRuntimeException(e);
		} finally {
			employmentHistory.cancel(true);
			education.cancel(true);
			summary.cancel(true);
		}
	}

	private String parseSummary(String content) {
		Matcher matcher = SUMMARY_REGEX.matcher(content);
		if (matcher.find()) {
			return content.substring(matcher.start(), matcher.end()).trim();
		}

		return "";
	}

	private List<LinkedInPdfEmploymentHistory> parseExperience(String content) {
		List<LinkedInPdfEmploymentHistory> employmentHistoryList = new ArrayList<>();
		LinkedInPdfEmploymentHistory employmentHistory;
		String experienceHeaders;
		Matcher experienceParserRegex;
		Matcher matcher = EXPERIENCE_REGEX.matcher(content);
		if (matcher.find()) {
			String experience = content.substring(matcher.start(), matcher.end());
			matcher = EXPERIENCE_HEADERS_REGEX.matcher(experience);
			String[] experienceDescriptions = EXPERIENCE_HEADERS_REGEX.split(experience);
			int count = 0;
			while (matcher.find() && ++count != 0) {
				employmentHistory = new LinkedInPdfEmploymentHistory();
				experienceHeaders = experience.substring(matcher.start(), matcher.end());

				experienceParserRegex = EXPERIENCE_TITLE_REGEX.matcher(experienceHeaders);
				if (experienceParserRegex.find()) {
					employmentHistory.setTitle(
							experienceHeaders.substring(experienceParserRegex.start(), experienceParserRegex.end()));
				} else {
					employmentHistory.setTitle(experienceHeaders.substring(0, experienceHeaders.indexOf("\n")));
				}

				experienceParserRegex = EXPERIENCE_COMPANY_REGEX.matcher(experienceHeaders);
				if (experienceParserRegex.find()) {
					employmentHistory.setBusiness(experienceHeaders
							.substring(experienceParserRegex.start(), experienceParserRegex.end()).trim());
				}

				experienceParserRegex = DATE_REGEX.matcher(experienceHeaders);
				if (experienceParserRegex.find()) {
					employmentHistory.setStartDate(formatDateString(
							experienceHeaders.substring(experienceParserRegex.start(), experienceParserRegex.end())));
					if (experienceParserRegex.find()) {
						employmentHistory.setEndDate(formatDateString(experienceHeaders
								.substring(experienceParserRegex.start(), experienceParserRegex.end())));
					}
				}

				employmentHistory.setDescription(experienceDescriptions[count]);
				employmentHistoryList.add(employmentHistory);
			}
		}

		return employmentHistoryList;
	}

	private List<LinkedInPdfEducation> parseEducation(String content) {
		List<LinkedInPdfEducation> educationList = new ArrayList<>();
		LinkedInPdfEducation education = null;
		Matcher matcher = EDUCATION_REGEX.matcher(content);
		if (matcher.find()) {
			byte flag = 0;
			String[] tokenizedEducationDetails;
			Matcher dateMatcher;
			for (String line : END_LINE_REGEX.split(EDUCATION_ACTIVITIES_AND_SOCIETIES_TRIM_REGEX
					.matcher(content.substring(matcher.start(), matcher.end())).replaceAll(""))) {
				if (line.isEmpty()) {
					continue;
				}
				if (flag == 0) {
					education = new LinkedInPdfEducation();
					education.setSchoolName(line);
				} else {
					tokenizedEducationDetails = COMMA_REGEX.split(line);
					for (int i = 0; i < tokenizedEducationDetails.length; i++) {
						if (i == 0) {
							education.setDegree(tokenizedEducationDetails[i]);
							continue;
						} else if (i == tokenizedEducationDetails.length - 1) {
							dateMatcher = DATE_REGEX.matcher(tokenizedEducationDetails[i]);
							if (dateMatcher.find()) {
								do {
									education.setGraduationDate(formatDateString(tokenizedEducationDetails[i]
											.substring(dateMatcher.start(), dateMatcher.end())));
								} while (dateMatcher.find());

								continue;
							}
						}

						education.addMajor(tokenizedEducationDetails[i]);
					}

					educationList.add(education);
				}

				flag ^= 0xFF;
			}
		}

		return educationList;
	}

	private Date formatDateString(final String dateString) {
		try {
			Matcher matcher = MONTH_REGEX.matcher(dateString);

			if (matcher.find()) {
				return MONTH_YEAR_DATE_FORMAT.parse(dateString);
			}

			return YEAR_DATE_FORMAT.parse(dateString);
		} catch (ParseException e) {
			LOGGER.error("Exception occured during parsing", e);
			throw new UnrecoverableParsingRuntimeException(e);
		}
	}

	public static class UnrecoverableParsingRuntimeException extends RuntimeException {

		private static final long serialVersionUID = 7683281852976884399L;

		public UnrecoverableParsingRuntimeException() {
			super();
		}

		public UnrecoverableParsingRuntimeException(String msg) {
			super(msg);
		}

		public UnrecoverableParsingRuntimeException(Throwable cause) {
			super(cause);
		}

		public UnrecoverableParsingRuntimeException(String msg, Throwable cause) {
			super(msg, cause);
		}

		protected UnrecoverableParsingRuntimeException(String msg, Throwable cause, boolean enableSuppression,
				boolean writableStackTrace) {
			super(msg, cause, enableSuppression, writableStackTrace);
		}

	}

}
