package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.Mentoring;

public class MentoringMapper implements RowMapper<Mentoring>{

	public static final String DATA_SSO = "sso";
	//public static final String DATA_SHARED = "shared";
	public static final String DATA_MENTOR= "MENTOR_FLAG";
	public static final String DATA_MENTEE= "MENTEE_FLAG";
	public static final String DATA_DESCRIPTION= "DESCRIPTION";
	
	@Override
	public Mentoring mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		Mentoring mentoring = new Mentoring();
		mentoring.setSso(rs.getLong(DATA_SSO));
		
		mentoring.setMentor(rs.getString(DATA_MENTOR));
		mentoring.setMentee(rs.getString(DATA_MENTEE));
		mentoring.setDescription(rs.getString(DATA_DESCRIPTION));
		return mentoring;
	}

}
