package com.ge.corporate.hr.profile.employee.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.common.service.AbstractBaseServiceSupport;
import com.ge.corporate.hr.profile.employee.dao.ClientListExcelDao;
import com.ge.corporate.hr.profile.employee.dao.WorkAssignmentDao;
import com.ge.corporate.hr.profile.employee.dto.ExcelReport;
import com.ge.corporate.hr.profile.employee.dto.MyCWPopulationDto;
import com.ge.corporate.hr.profile.employee.dto.MyHrPopulationDto;
import com.ge.corporate.hr.profile.employee.model.MyCWPopulation;
import com.ge.corporate.hr.profile.employee.model.MyHrPopulation;

public class ClientListExcelServiceImpl extends AbstractBaseServiceSupport implements ClientListExcelService{
	private final Log logger = LogFactory.getLog(ClientListExcelServiceImpl.class);

	@Resource(name = "clientListExcelDao")
	private ClientListExcelDao clientListExcelDao;
	
	public ClientListExcelDao getClientListExcelDao() {
		return clientListExcelDao;
	}

	public void setClientListExcelDao(ClientListExcelDao clientListExcelDao) {
		this.clientListExcelDao = clientListExcelDao;
	}
	
	public MyHrPopulationDto getMyHrPopulation(
			MyHrPopulationDto myHrPopulationDtoPar, List<String> roles,
			String param, int start, int limit, String sortName,
			String sortOrder, boolean isSuspended) {
		MyHrPopulationDto myHrPopulationDto = null;

		if (myHrPopulationDtoPar.getSso() > 0) {

			BaseModelCollection<MyHrPopulation> myHrPopulationDtoList = null;
			List<String> myHrPopulationRoleList = null;
			int count = 0;
			double headcount = 0;

			myHrPopulationDto = new MyHrPopulationDto();
			myHrPopulationDto.setSso(myHrPopulationDtoPar.getSso());
			myHrPopulationDto.setLocale(myHrPopulationDtoPar.getLocale());
			myHrPopulationDto.setFormat(myHrPopulationDtoPar.getFormat());
			myHrPopulationRoleList = clientListExcelDao
					.getMyHrPopulationRolesBySso(myHrPopulationDto.getSso());
			if (roles.size() > 0) {
				myHrPopulationDtoList = clientListExcelDao
						.getMyHrPopulationListBySso(myHrPopulationDto.getSso(),
								roles, param, start, limit, sortName, sortOrder, myHrPopulationDto.getLocale(), myHrPopulationDto.getFormat(), isSuspended);
			} else {
				myHrPopulationDtoList = clientListExcelDao
						.getMyHrPopulationListBySso(myHrPopulationDto.getSso(),
								myHrPopulationRoleList, param, start, limit,
								sortName, sortOrder, myHrPopulationDto.getLocale(), myHrPopulationDto.getFormat(), isSuspended);
			}
			count = clientListExcelDao.getMyHrPopulationCountBySso(
					myHrPopulationDto.getSso(), roles, param, isSuspended);
			headcount = clientListExcelDao.getMyHrPopulationHeadCountBySso(
					myHrPopulationDto.getSso(), roles, param, isSuspended);
			if (myHrPopulationDtoList == null) {
				myHrPopulationDtoList = new BaseModelCollection<MyHrPopulation>();
			}
			myHrPopulationDto.setCount(count);
			myHrPopulationDto.setHeadcount(headcount);
			myHrPopulationDto.setRole(myHrPopulationRoleList);
			myHrPopulationDto.setMyHrPopulationList(myHrPopulationDtoList);

		} else {
			logger.error("Invalid SSO, SSO = " + myHrPopulationDtoPar.getSso());
		}

		return myHrPopulationDto;
	}

	public MyHrPopulationDto getMyHrPopulationExcel(
			MyHrPopulationDto myHrPopulationDtoPar, List<String> roles,
			String param, int start, int limit, String sortName,
			String sortOrder, boolean isSuspended) {
		MyHrPopulationDto myHrPopulationDto = null;

		if (myHrPopulationDtoPar.getSso() > 0) {

			BaseModelCollection<MyHrPopulation> myHrPopulationDtoList = null;
			List<String> myHrPopulationRoleList = null;
			int count = 0;
			int headcount = 0;

			myHrPopulationDto = new MyHrPopulationDto();
			myHrPopulationDto.setSso(myHrPopulationDtoPar.getSso());
			myHrPopulationDto.setLocale(myHrPopulationDtoPar.getLocale());
			myHrPopulationDto.setFormat(myHrPopulationDtoPar.getFormat());
			myHrPopulationRoleList = clientListExcelDao
					.getMyHrPopulationRolesBySso(myHrPopulationDto.getSso());
			if (roles.size() > 0) {
				myHrPopulationDtoList = clientListExcelDao
						.getMyHrPopulationListBySsoExcel(
								myHrPopulationDto.getSso(), roles, param,
								start, limit, sortName, sortOrder, myHrPopulationDto.getLocale(), myHrPopulationDto.getFormat(), isSuspended);
			} else {
				myHrPopulationDtoList = clientListExcelDao
						.getMyHrPopulationListBySsoExcel(
								myHrPopulationDto.getSso(),
								myHrPopulationRoleList, param, start, limit,
								sortName, sortOrder, myHrPopulationDto.getLocale(), myHrPopulationDto.getFormat(), isSuspended);
			}
			count = clientListExcelDao.getMyHrPopulationCountBySso(
					myHrPopulationDto.getSso(), roles, param, isSuspended);
			if (myHrPopulationDtoList == null) {
				myHrPopulationDtoList = new BaseModelCollection<MyHrPopulation>();
			}
			myHrPopulationDto.setCount(count);
			myHrPopulationDto.setExcelLimit(limit);
			myHrPopulationDto.setRole(myHrPopulationRoleList);
			myHrPopulationDto.setMyHrPopulationList(myHrPopulationDtoList);

		} else {
			logger.error("Invalid SSO, SSO = " + myHrPopulationDtoPar.getSso());
		}

		return myHrPopulationDto;
	}
	
	public MyHrPopulationDto getMyHrPopulationOthers(
			MyHrPopulationDto myHrPopulationDtoPar, String roles, String param,
			int start, int limit, String sortName, String sortOrder, String type) {
		MyHrPopulationDto myHrPopulationDto = null;

		if (myHrPopulationDtoPar.getSso() > 0) {

			BaseModelCollection<MyHrPopulation> myHrPopulationDtoList = null;
			List<String> myHrPopulationRoleList = null;
			int count = 0;
			double headcount = 0;

			myHrPopulationDto = new MyHrPopulationDto();
			myHrPopulationDto.setSso(myHrPopulationDtoPar.getSso());
			myHrPopulationDto.setLocale(myHrPopulationDtoPar.getLocale());
			myHrPopulationDto.setFormat(myHrPopulationDtoPar.getFormat());
			// Get Service Dates
			myHrPopulationDtoList = clientListExcelDao
					.getMyHrPopulationOthersListBySso(
							myHrPopulationDto.getSso(), roles, param, start,
							limit, sortName, sortOrder, type, myHrPopulationDto.getLocale(), myHrPopulationDto.getFormat());
			// myHrPopulationRoleList =
			// assignmentDao.getMyHrPopulationRolesBySso(myHrPopulationDto.getSso());
			count = clientListExcelDao.getMyHrPopulationOthersCountBySso(
					myHrPopulationDto.getSso(), roles, param, type);
			if(myHrPopulationDto.getFormat().equalsIgnoreCase("EXCEL")){
				myHrPopulationDto.setExcelLimit(limit);
			}else{
				headcount = clientListExcelDao.getMyHrPopulationOthersHeadCountBySso(
						myHrPopulationDto.getSso(), roles, param, type);
				myHrPopulationDto.setHeadcount(headcount);
			}
			if (myHrPopulationDtoList == null) {
				myHrPopulationDtoList = new BaseModelCollection<MyHrPopulation>();
			}

			myHrPopulationDto.setCount(count);

			myHrPopulationDto.setRole(myHrPopulationRoleList);

			myHrPopulationDto.setMyHrPopulationList(myHrPopulationDtoList);

		} else {
			logger.error("Invalid SSO, SSO = " + myHrPopulationDtoPar.getSso());
		}

		return myHrPopulationDto;
	}
	
	public MyHrPopulationDto getMyOrgMgrClientListService(MyHrPopulationDto myHrPopulationDtoPar, List<String> rel_types, String param, int start, int limit, String sortName, String sortOrder, boolean isSuspended){
		MyHrPopulationDto myHrPopulationDto = null;
		List<String> myOrgMgrRelTypeList = null;

		if (myHrPopulationDtoPar.getSso() > 0) {

			BaseModelCollection<MyHrPopulation> myHrPopulationDtoList = null;
			int count = 0;
			int headcount = 0;

			myHrPopulationDto = new MyHrPopulationDto();
			myHrPopulationDto.setSso(myHrPopulationDtoPar.getSso());
			myHrPopulationDto.setLocale(myHrPopulationDtoPar.getLocale());
			myHrPopulationDto.setFormat(myHrPopulationDtoPar.getFormat());
			myOrgMgrRelTypeList = clientListExcelDao
					.getMymyOrgMgrRelTypesBySso(myHrPopulationDto.getSso());
			myHrPopulationDtoList = clientListExcelDao
						.getMyOrgMgrClientListBySso(myHrPopulationDto.getSso(),
								rel_types, param, start, limit, sortName, sortOrder, myHrPopulationDto.getLocale(), myHrPopulationDto.getFormat(), isSuspended);
			count = clientListExcelDao.getMyOrgMgrClientListCountBySso(
					myHrPopulationDto.getSso(), rel_types, param, isSuspended);
			headcount = clientListExcelDao.getMyOrgMgrClientListHeadCountBySso(
					myHrPopulationDto.getSso(), rel_types, param, isSuspended);
			if (myHrPopulationDtoList == null) {
				myHrPopulationDtoList = new BaseModelCollection<MyHrPopulation>();
			}
			myHrPopulationDto.setCount(count);
			myHrPopulationDto.setHeadcount(headcount);
			myHrPopulationDto.setRole(myOrgMgrRelTypeList);
			myHrPopulationDto.setMyHrPopulationList(myHrPopulationDtoList);

		} else {
			logger.error("Invalid SSO, SSO = " + myHrPopulationDtoPar.getSso());
		}

		return myHrPopulationDto;
	}
	public MyHrPopulationDto getMyOrgMgrClientListExcelService(MyHrPopulationDto myHrPopulationDtoPar, List<String> rel_types, String param, int start, int limit, String sortName, String sortOrder, boolean isSuspended){
		MyHrPopulationDto myHrPopulationDto = null;

		if (myHrPopulationDtoPar.getSso() > 0) {

			BaseModelCollection<MyHrPopulation> myHrPopulationDtoList = null;
			int count = 0;
			int headcount = 0;

			myHrPopulationDto = new MyHrPopulationDto();
			myHrPopulationDto.setSso(myHrPopulationDtoPar.getSso());
			myHrPopulationDto.setLocale(myHrPopulationDtoPar.getLocale());
			myHrPopulationDto.setFormat(myHrPopulationDtoPar.getFormat());
			myHrPopulationDtoList = clientListExcelDao
						.getMyOrgMgrClientListBySsoExcel(
								myHrPopulationDto.getSso(), rel_types, param,
								start, limit, sortName, sortOrder, myHrPopulationDto.getLocale(), myHrPopulationDto.getFormat(), isSuspended);
			count = clientListExcelDao.getMyOrgMgrClientListCountBySso(
					myHrPopulationDto.getSso(), rel_types, param, isSuspended);
			if (myHrPopulationDtoList == null) {
				myHrPopulationDtoList = new BaseModelCollection<MyHrPopulation>();
			}
			myHrPopulationDto.setCount(count);
			myHrPopulationDto.setExcelLimit(limit);
			myHrPopulationDto.setMyHrPopulationList(myHrPopulationDtoList);

		} else {
			logger.error("Invalid SSO, SSO = " + myHrPopulationDtoPar.getSso());
		}

		return myHrPopulationDto;

	}

	public List<String> getMyHrPopulationRoles(Long sso) {
		List<String> myHrPopulationRoleList = null;
		if (sso != null) {
			myHrPopulationRoleList = clientListExcelDao
					.getMyHrPopulationRolesBySso(sso);
		} else {
			logger.error("Invalid SSO, SSO = " + sso);
		}
		return myHrPopulationRoleList;
	}
	
	public String getFullName(Long sso) {
		return clientListExcelDao.getFullNameDao(sso);
	}
	
	public MyCWPopulationDto getMyCWPopulation(MyCWPopulationDto myCWPopulationDtoPar, List<String> roles, List<String> rel_types, String param, int start, int limit, String sortName, String sortOrder, List<String> subpersontype){
		MyCWPopulationDto myCWPopulationDto = null;

		if (myCWPopulationDtoPar.getSso() > 0) {

			BaseModelCollection<MyCWPopulation> myCWPopulationDtoList = null;
			List<String> myCWPopulationRoleList = null;
			int count = 0;

			myCWPopulationDto = new MyCWPopulationDto();
			myCWPopulationDto.setSso(myCWPopulationDtoPar.getSso());
			myCWPopulationDto.setLocale(myCWPopulationDtoPar.getLocale());
			myCWPopulationDto.setFormat(myCWPopulationDtoPar.getFormat());

			if(StringUtils.join(roles,",").equalsIgnoreCase("SUPV") || StringUtils.join(roles,",").equalsIgnoreCase("MGR") || StringUtils.join(roles,",").equalsIgnoreCase("ORG_MGR")){
				myCWPopulationDtoList = clientListExcelDao
						.getMyCWMgrPopulationListBySso(
								myCWPopulationDto.getSso(), rel_types, param, start,
								limit, sortName, sortOrder, subpersontype, myCWPopulationDto.getFormat());
				count = clientListExcelDao.getMyCWMgrPopulationCountBySso(
						myCWPopulationDto.getSso(), rel_types, param, subpersontype);
			
			}else{
				myCWPopulationDtoList = clientListExcelDao
						.getMyCWPopulationListBySso(
								myCWPopulationDto.getSso(), roles, param, start,
								limit, sortName, sortOrder, subpersontype, myCWPopulationDto.getFormat());
				count = clientListExcelDao.getMyCWPopulationCountBySso(
						myCWPopulationDto.getSso(), roles, param, subpersontype);
			}
			if(myCWPopulationDto.getFormat().equalsIgnoreCase("EXCEL")){
				myCWPopulationDto.setExcelLimit(limit);
			}
			if (myCWPopulationDtoList == null) {
				myCWPopulationDtoList = new BaseModelCollection<MyCWPopulation>();
			}

			myCWPopulationDto.setCount(count);

			myCWPopulationDto.setRole(myCWPopulationRoleList);

			myCWPopulationDto.setMyCWPopulationList(myCWPopulationDtoList);

		} else {
			logger.error("Invalid SSO, SSO = " + myCWPopulationDtoPar.getSso());
		}

		return myCWPopulationDto;
		
	}

	@Override
	public List<ExcelReport>  getDataGroupReport(List<ExcelReport>  dataGroup,String type) {
		return clientListExcelDao.getDatagroupReport(dataGroup,type);
	}
	

}
