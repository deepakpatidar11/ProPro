/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.security.access.prepost.PreAuthorize;

import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;
import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dao.mapper.BonusSITMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.CompensationMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.IncentiveCompensationMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.LongTermPerformanceAwardMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.LumpCompensationMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.NextVestingOptionMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.OptionOutsdngTotalsMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.OptionsOutstandingMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.RestrictedStockOptTotalsMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.RestrictedStockOptionMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.StockOptTotalsMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.StockOptionMapper;
import com.ge.corporate.hr.profile.employee.model.BonusSIT;
import com.ge.corporate.hr.profile.employee.model.Compensation;
import com.ge.corporate.hr.profile.employee.model.IncentiveCompensation;
import com.ge.corporate.hr.profile.employee.model.LongTermPerformanceAward;
import com.ge.corporate.hr.profile.employee.model.LumpCompensation;
import com.ge.corporate.hr.profile.employee.model.RestrictedStockOptionTotals;
import com.ge.corporate.hr.profile.employee.model.StockOption;
import com.ge.corporate.hr.profile.employee.model.StockOptionTotals;
import com.ge.corporate.hr.profile.employee.service.cache.DaoKeyGenerator;

/**
 * Compensation dao implementation
 * @author enrique.romero
 *
 */
public class CompensationDaoImpl extends AbstractBaseDaoSupport implements CompensationDao {	
	private static Log logger = LogFactory.getLog(CompensationDaoImpl.class);	
	
	@Cache(nodeName="/profile/employee/dao/compensation", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'Compensation', read)")
	public Compensation getCurrentCompensationBySso(Long sso) {
		//		
		Compensation compensation = new Compensation();
		String query = this.getSql("getCurrentCompensationBySso");
		try{					
			compensation = getJdbcTemplate().queryForObject(query, new Object[]{sso.intValue()}, new CompensationMapper());
			logger.debug("Compensation data was loaded susscesfully");			
		}catch (EmptyResultDataAccessException eex) {			
			logger.debug("Compensation Not Found");			
		}				
		return compensation;
	}

	@Cache(nodeName="/profile/employee/dao/compensation", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'Compensation', read)")
	public BaseModelCollection<Compensation> getCompensationHistoryBySso(Long sso) {
		
		BaseModelCollection<Compensation> compesationList = null;
		String query = this.getSql("getCompensationHistoryBySso");		
		try{	
			compesationList = new BaseModelCollection<Compensation>();
			compesationList.setList( getJdbcTemplate().query(query, new Object[]{sso.intValue(),sso.intValue()}, new CompensationMapper()) );
			logger.debug("Compensation history data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Compensation data Not found");
		}			
		
		return compesationList;
	}
	
	@Cache(nodeName="/profile/employee/dao/compensation", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'Compensation', read)")
	
	public BaseModelCollection<LumpCompensation> getLumpCompensationHistoryBySso(Long sso) {
		BaseModelCollection<LumpCompensation> lumpCompList = null ;
		String query = this.getSql("getLumpCompensationBySso");
		try{					
			lumpCompList = new BaseModelCollection<LumpCompensation>();
			lumpCompList.setList( getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new LumpCompensationMapper()) );
			
			logger.debug("Restricted Stock Option Totals were loaded susscesfully");			
		}catch (EmptyResultDataAccessException eex) {			
			logger.debug("Restricted Stock Option Totals Not Found");			
		}		
		return lumpCompList;
	}
	

	@Cache(nodeName="/profile/employee/dao/compensation", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'Compensation', read)")
	public BaseModelCollection<IncentiveCompensation> getIncentiveCompensationHistoryBySso(
			Long sso) {
		BaseModelCollection<IncentiveCompensation> icList = null;
		String query = this.getSql("getIncentiveCompensationHistoryBySso");		
		try{
			icList = new BaseModelCollection<IncentiveCompensation>();
			icList.setList( getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new IncentiveCompensationMapper()) );
			logger.debug("Incentive Compensation history data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Incentive Compensation data Not found");
		}
		
		return icList;
	}
	
	@Cache(nodeName="/profile/employee/dao/compensation", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'CompensationBonusSIT', read)")
	public BaseModelCollection<BonusSIT> getBonusSITBySso(
			Long sso) {
		BaseModelCollection<BonusSIT> bonusList = null;
		String query = this.getSql("getBonusSITByStartDateAndSso");
		try{
			bonusList = new BaseModelCollection<BonusSIT>();
			bonusList.setList( getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new BonusSITMapper()) );
			logger.debug("Bonus SIT data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Bonus SIT data not found");
		}
		
		return bonusList;
	}
	
	@Cache(nodeName="/profile/employee/dao/compensation", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'Compensation', read)")
	public BaseModelCollection<StockOption> getStockOptionsBySso(Long sso) {
		
		BaseModelCollection<StockOption> stockOpsList = null;
		String query = this.getSql("getStockOptionsBySso");		
		try{
			stockOpsList = new BaseModelCollection<StockOption>();
			stockOpsList.setList( getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new StockOptionMapper()) );
			logger.debug("Stock options data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Stock options data Not found");
		}		
		return stockOpsList;
	}
	
	@Cache(nodeName="/profile/employee/dao/compensation", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'CompensationRestricted', read)")
	public BaseModelCollection<StockOption> getOptionsOutstandingBySso(Long sso) {
		
		BaseModelCollection<StockOption> stockOpsList = null;
		String query = this.getSql("getStockOptionsBySso");		
		try{
			stockOpsList = new BaseModelCollection<StockOption>();
			stockOpsList.setList( getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new OptionsOutstandingMapper()) );
			logger.debug("Option Oustanding data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Option Oustanding data Not found");
		}
		return stockOpsList;
	}
	
	@Cache(nodeName="/profile/employee/dao/compensation", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'RSUHistory', read)")
	public BaseModelCollection<StockOption> getRestrictedStockOptionsBySso(Long sso) {

		BaseModelCollection<StockOption> stockOpsList = null;
		String query = this.getSql("getRestrictedStockOptionsBySso");		
		try{
			stockOpsList = new BaseModelCollection<StockOption>();
			stockOpsList.setList( getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new RestrictedStockOptionMapper()) );
			logger.debug("Restricted stock options data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Restricted stock options data Not found");
		}
		
		return stockOpsList;
	}
	
	
	@Cache(nodeName="/profile/employee/dao/compensation", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'RSUNextVesting', read)")
	public BaseModelCollection<StockOption> getNextVestingOptionsBySso(Long sso) {

		BaseModelCollection<StockOption> stockOpsList = null;
		String query = this.getSql("getNextVestingDateBySso");		
		try{
			stockOpsList = new BaseModelCollection<StockOption>();
			stockOpsList.setList( getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new NextVestingOptionMapper()) );
			logger.debug("Next Vesting options data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Next Vesting options  data Not found");
		}
		
		return stockOpsList;
	}

	@Cache(nodeName="/profile/employee/dao/compensation", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'LTPA', read)")
	public BaseModelCollection<LongTermPerformanceAward> getLongTermPerformanceAwardsBySso(Long sso) {
		
		BaseModelCollection<LongTermPerformanceAward> ltPerfAward = null;
		String query = this.getSql("getLongTermPerformanceAwardsBySso");		
		try{
			ltPerfAward = new BaseModelCollection<LongTermPerformanceAward>();
			ltPerfAward.setList( getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new LongTermPerformanceAwardMapper()) );
			logger.debug("Long Term Performance Award data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Long Term Performance Award Not found");
		}		
		
		return ltPerfAward;
	}

	
	@Cache(nodeName="/profile/employee/dao/compensation", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'Compensation', read)")
	public Long getCurrentCompensationTotalBySso(Long sso) {
		Long value = 0L;
		String query = this.getSql("getTotalCurrentCompensationBySso");		
		try{			
			value = getJdbcTemplate().queryForLong(query, new Object[]{sso.intValue(),sso.intValue()});			
			logger.debug("Total Curren Compensation was calculated properly");
		}catch (IncorrectResultSizeDataAccessException  eex) {
			logger.debug("Could not calculate Total Curren Compensation");
		}
		return value;
	}
	
	@Cache(nodeName="/profile/employee/dao/compensation", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'CompensationRestricted', read)")
	public StockOptionTotals getOptionOutsdngTotalBySso(Long sso) {
		StockOptionTotals totals = new StockOptionTotals();
		String query = this.getSql("getStockOptionsTotalBySso");
		try{					
			totals = getJdbcTemplate().queryForObject(query, new Object[]{sso.intValue()}, new OptionOutsdngTotalsMapper());
			logger.debug("Option Outstanding Totals were loaded susscesfully");			
		}catch (EmptyResultDataAccessException eex) {			
			logger.debug("Option Outstanding Totals Not Found");			
		}		
		return totals;
	}
	
	
	@Cache(nodeName="/profile/employee/dao/compensation", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'Compensation', read)")
	public StockOptionTotals getStockOptionTotalBySso(Long sso) {
		StockOptionTotals totals = new StockOptionTotals();
		String query = this.getSql("getStockOptionsTotalBySso");
		try{					
			totals = getJdbcTemplate().queryForObject(query, new Object[]{sso.intValue()}, new StockOptTotalsMapper());
			logger.debug("Stock Option Totals were loaded susscesfully");			
		}catch (EmptyResultDataAccessException eex) {			
			logger.debug("Stock Option Totals Not Found");			
		}		
		return totals;
	}
	
	
	@Cache(nodeName="/profile/employee/dao/compensation", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'CompensationRestricted', read)")
	public RestrictedStockOptionTotals getRestrictedStockOptionTotalBySso(Long sso) {
		RestrictedStockOptionTotals totals = new RestrictedStockOptionTotals() ;
		String query = this.getSql("getRestrictedStockOptionTotalBySso");
		try{					
			totals = getJdbcTemplate().queryForObject(query, new Object[]{sso.intValue()}, new RestrictedStockOptTotalsMapper());
			logger.debug("Restricted Stock Option Totals were loaded susscesfully");			
		}catch (EmptyResultDataAccessException eex) {			
			logger.debug("Restricted Stock Option Totals Not Found");			
		}		
		return totals;
	}
	
}
