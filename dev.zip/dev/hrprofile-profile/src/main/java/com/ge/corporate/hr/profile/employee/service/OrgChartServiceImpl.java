package com.ge.corporate.hr.profile.employee.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.EmptyResultDataAccessException;

import com.ge.corporate.hr.profile.common.service.AbstractBaseServiceSupport;
import com.ge.corporate.hr.profile.employee.dao.OrgChartDao;
import com.ge.corporate.hr.profile.employee.dao.PropertyDao;
import com.ge.corporate.hr.profile.employee.dto.DirectReportsDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneSearchCompDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneSearchCompListDto;
import com.ge.corporate.hr.profile.employee.dto.OrgChartDirectReportsDto;
import com.ge.corporate.hr.profile.employee.dto.OrgChartDto;
import com.ge.corporate.hr.profile.employee.service.lucene.SearchLuceneService;

public class OrgChartServiceImpl extends AbstractBaseServiceSupport implements
		OrgChartService {

	@Resource(name = "searchIndexService")
	private SearchLuceneService orgChartSearch;
	
	@Resource(name = "orgChartDao")
	private OrgChartDao orgChartDaoImpl;
	
	@Resource(name = "propertyDao")
	private PropertyDao propertyDao;

	private final Log logger = LogFactory.getLog(OrgChartServiceImpl.class);
	
	public static final List<String> aclList = java.util.Arrays.asList("SUPV","MGR","ORG_MGR","ORG_HRM","HRM","HRM_SPL","SHRM","SHRM_F","SHRM_R","SHRM_GL","MATRIX_HRM","O_S_MANAGER","O_S_MANAGER_CP","O_S_MANAGER_F","O_S_MANAGER_GL","O_S_MANAGER_R","O_TD_MANAGER","O_TD_MANAGER_CP","O_TD_MANAGER_F","O_TD_MANAGER_GL","O_TD_MANAGER_R","HRM_VIEW","HR_BP","O_TD_NO_COMP","ADMIN_STAFF","STAFF_HS_LTD_ACCESS","STAFF_HS_STAFFING_SPL","STAFF_HS_US_LEAD_RCTR","STAFF_REQ_FLDR_OWNR");

	public List<OrgChartDirectReportsDto> getEmployeeDetailsForOrgChart(Long sso) {

		List<OrgChartDirectReportsDto> myOrgChart = new ArrayList<OrgChartDirectReportsDto>();
		if (sso != null) {
			myOrgChart = orgChartDaoImpl.getEmployeeDetailsForOrgChart(sso);
		} else {
			logger.error("SSO :" + sso + "is Invalid");
		}

		return myOrgChart;
	}

	@Override
	public OrgChartDto getOrgChartBySSO(Long sso, boolean showCW, boolean toggleDirectReports) {
		OrgChartDto myOrgChart = new OrgChartDto();
		if (sso != null) {
				myOrgChart = orgChartDaoImpl.getOrgChartBySSO(sso, showCW, toggleDirectReports);
		} else {
			logger.error("SSO :" + sso + "is Invalid");
		}

		return myOrgChart;
	}

	@Override
	public OrgChartDto createOrgChartWithLucene(Long sso, Long loggedSSO, boolean showCW, boolean showLTS, List<String> rolesList, boolean toggleDirectReports, boolean viewSuspends){
		OrgChartDto orgChart = new OrgChartDto();
		LuceneSearchCompListDto luceneSearchDto = new LuceneSearchCompListDto();
		LuceneSearchCompListDto luceneSearchDto1 = new LuceneSearchCompListDto();
		DirectReportsDto manager = new DirectReportsDto();
		List<OrgChartDirectReportsDto> directReportList = new ArrayList<OrgChartDirectReportsDto>();
		List<OrgChartDirectReportsDto> contingentList = new ArrayList<OrgChartDirectReportsDto>();
		List<DirectReportsDto> oneOverOneReports = new ArrayList<DirectReportsDto>();
		List<DirectReportsDto> contingent1o1 = new ArrayList<DirectReportsDto>();
		DirectReportsDto oneOverOne = null;
		OrgChartDirectReportsDto employee = new OrgChartDirectReportsDto();
		String isContingentWorker = "";
		String acl = "";
		String lts = "";
		String query = "";
		boolean hasRoleSA = false;
		boolean hasACLRoles = false;
		if(rolesList!=null && rolesList.size()>0){
			hasRoleSA = rolesList.contains("ROLE_SA");
			acl = "";
			for(int i=0; i<rolesList.size(); i++){
				if(aclList.contains(rolesList.get(i))){
					hasACLRoles = true;
					acl += " OR acl_"+rolesList.get(i)+":*"+loggedSSO+"*";
				}
			}
		}
		acl = acl.replaceFirst(" OR ", "");
		lts +="directoryInclusion:true";


		int count = 0;
		//String query = "sso:"+sso+" OR ohMgrSso:"+sso+" OR ohMgrSso1:"+sso;
		try{
			luceneSearchDto.setSearchQuery("sso:"+sso);
			luceneSearchDto.setSortBy("empLastName");
			luceneSearchDto = orgChartSearch.advancedSearch(luceneSearchDto, 0, Integer.MAX_VALUE/2, false);
			if(luceneSearchDto!=null && luceneSearchDto.getSearchList().size()>0){
				count = count + luceneSearchDto.getSearchList().size();
				orgChart.setSso(luceneSearchDto.getSearchList().get(0).getSso());
				if(luceneSearchDto.getSearchList().get(0).getEmpPreferredName()!=null && !luceneSearchDto.getSearchList().get(0).getEmpPreferredName().equalsIgnoreCase(luceneSearchDto.getSearchList().get(0).getEmpFirstName())){
					orgChart.setFirstName(luceneSearchDto.getSearchList().get(0).getEmpPreferredName());
				}else{
					orgChart.setFirstName(luceneSearchDto.getSearchList().get(0).getEmpFirstName());
				}
				orgChart.setBusiness(luceneSearchDto.getSearchList().get(0).getBusiness());
				orgChart.setIfg(luceneSearchDto.getSearchList().get(0).getIfg());
				orgChart.setLastName(luceneSearchDto.getSearchList().get(0).getEmpLastName());
				orgChart.setTitle(luceneSearchDto.getSearchList().get(0).getTitle());
				orgChart.setIsLongTermSuspend(luceneSearchDto.getSearchList().get(0).getDirectoryIncl().equalsIgnoreCase("true")?"false":"true");
				isContingentWorker = luceneSearchDto.getSearchList().get(0).getSso().toString().startsWith("5")?"Y":"N";
				orgChart.setIsContingentWorker(isContingentWorker);
				//manager
				if(luceneSearchDto.getSearchList().get(0).getEmpManagerSso()!=null && luceneSearchDto.getSearchList().get(0).getEmpManagerSso()!=0){
				manager.setFirstName(luceneSearchDto.getSearchList().get(0).getOhMgrFirstName());
				manager.setLastName(luceneSearchDto.getSearchList().get(0).getOhMgrLastName());
				manager.setManager(Long.parseLong(luceneSearchDto.getSearchList().get(0).getOhMgrSso1()!=null?luceneSearchDto.getSearchList().get(0).getOhMgrSso1():"0"));
				manager.setSso(luceneSearchDto.getSearchList().get(0).getEmpManagerSso());
				manager.setTitle(luceneSearchDto.getSearchList().get(0).getMgrTitle());
				orgChart.setManager(manager);
				// 1o1 manager
				luceneSearchDto.setSearchQuery("sso:"+manager.getSso());
				luceneSearchDto = orgChartSearch.advancedSearch(luceneSearchDto, 0, 1, false);
				if(luceneSearchDto.getSearchList().size()>0 && luceneSearchDto.getSearchList().get(0).getEmpManagerSso() != 0){
					manager = new DirectReportsDto();
					manager.setFirstName(luceneSearchDto.getSearchList().get(0).getOhMgrFirstName());
					manager.setLastName(luceneSearchDto.getSearchList().get(0).getOhMgrLastName());
					manager.setManager(Long.parseLong(luceneSearchDto.getSearchList().get(0).getOhMgrSso1()!=null?luceneSearchDto.getSearchList().get(0).getOhMgrSso1():"0"));
					manager.setSso(luceneSearchDto.getSearchList().get(0).getEmpManagerSso());
					manager.setTitle(luceneSearchDto.getSearchList().get(0).getMgrTitle());
					orgChart.setOneOverOneManager(manager);
					
					// 2o1 manager
					luceneSearchDto.setSearchQuery("sso:"+manager.getSso());
					luceneSearchDto = orgChartSearch.advancedSearch(luceneSearchDto, 0, 1, false);
					if(luceneSearchDto.getSearchList().size()>0 && luceneSearchDto.getSearchList().get(0).getEmpManagerSso() != 0){
						manager = new DirectReportsDto();
						manager.setFirstName(luceneSearchDto.getSearchList().get(0).getOhMgrFirstName());
						manager.setLastName(luceneSearchDto.getSearchList().get(0).getOhMgrLastName());
						manager.setManager(Long.parseLong(luceneSearchDto.getSearchList().get(0).getOhMgrSso1()!=null?luceneSearchDto.getSearchList().get(0).getOhMgrSso1():"0"));
						manager.setSso(luceneSearchDto.getSearchList().get(0).getEmpManagerSso());
						manager.setTitle(luceneSearchDto.getSearchList().get(0).getMgrTitle());
						orgChart.setOrgHeirarchy1(manager);
						
						//3o1 manager
						luceneSearchDto.setSearchQuery("sso:"+manager.getSso());
						luceneSearchDto = orgChartSearch.advancedSearch(luceneSearchDto, 0, 1, false);
						if(luceneSearchDto.getSearchList().size()>0 && luceneSearchDto.getSearchList().get(0).getEmpManagerSso() != 0){
							manager = new DirectReportsDto();
							manager.setFirstName(luceneSearchDto.getSearchList().get(0).getOhMgrFirstName());
							manager.setLastName(luceneSearchDto.getSearchList().get(0).getOhMgrLastName());
							manager.setManager(Long.parseLong(luceneSearchDto.getSearchList().get(0).getOhMgrSso1()!=null?luceneSearchDto.getSearchList().get(0).getOhMgrSso1():"0"));
							manager.setSso(luceneSearchDto.getSearchList().get(0).getEmpManagerSso());
							manager.setTitle(luceneSearchDto.getSearchList().get(0).getMgrTitle());
							orgChart.setOrgHeirarchy2(manager);
						}
					}
				}
				}
			}
			//direct reports
			if(showCW){ 
				if(hasACLRoles && showLTS){
					query += "(empManagerSso:"+sso+" AND ("+acl+")) OR ";
				}
				query += "(empManagerSso:"+sso+" AND "+lts+")";
				if(hasRoleSA){
					query = "empManagerSso:"+sso;
					if(!showLTS){
						query += " AND "+lts;
					}
				}
			}else{
				if(hasACLRoles && showLTS){
					query += "(empManagerSso:"+sso+" AND ("+acl+") AND NOT(sso:5*)) OR ";
				}
				query += "(empManagerSso:"+sso+" AND "+lts+" AND NOT(sso:5*))";
				if(hasRoleSA){
					query = "empManagerSso:"+sso+" AND NOT(sso:5*)";
					if(!showLTS){
						query += " AND "+lts;
					}
				}
			}
			luceneSearchDto.setSearchQuery(query);
			luceneSearchDto.setSortBy("empLastName");
			luceneSearchDto = orgChartSearch.advancedSearch(luceneSearchDto, 0, Integer.MAX_VALUE/2, false);
			if(luceneSearchDto!=null && luceneSearchDto.getSearchList().size()>0){
				//count = count + luceneSearchDto.getSearchList().size();
				for(LuceneSearchCompDto rs : luceneSearchDto.getSearchList()){
											
						employee = new OrgChartDirectReportsDto();
						oneOverOneReports = new ArrayList<DirectReportsDto>();
						contingent1o1 = new ArrayList<DirectReportsDto>();
						employee.setBusiness(rs.getBusiness());
						if(rs.getEmpPreferredName()!=null && !rs.getEmpPreferredName().equalsIgnoreCase(rs.getEmpFirstName())){
							employee.setFirstName(rs.getEmpPreferredName());
						}else{
							employee.setFirstName(rs.getEmpFirstName());
						}
						employee.setIfg(rs.getIfg());							
						isContingentWorker = rs.getSso().toString().startsWith("5")?"Y":"N";
						employee.setIsContingentWorker(isContingentWorker);
						employee.setLastName(rs.getEmpLastName());
						employee.setManagerSso(rs.getEmpManagerSso());
						employee.setSso(rs.getSso());
						employee.setTitle(rs.getTitle());
						employee.setIsLongTermSuspend(rs.getDirectoryIncl().equalsIgnoreCase("true")?"false":"true");
						//1 over 1 reports
						if(!toggleDirectReports){
							query = "";
							if(showCW){ 
								if(hasACLRoles && showLTS){
									query += "(empManagerSso:"+rs.getSso()+" AND ("+acl+")) OR ";
								}
								query += "(empManagerSso:"+rs.getSso()+" AND "+lts+")";
								if(hasRoleSA){
									query = "empManagerSso:"+rs.getSso();
									if(!showLTS){
										query += " AND "+lts;
									}
								}
							}else{
								if(hasACLRoles && showLTS){
									query += "(empManagerSso:"+rs.getSso()+" AND ("+acl+") AND NOT(sso:5*)) OR ";
								}
								query += "(empManagerSso:"+rs.getSso()+" AND "+lts+" AND NOT(sso:5*))";
								if(hasRoleSA){
									query = "empManagerSso:"+rs.getSso()+" AND NOT(sso:5*)";
									if(!showLTS){
										query += " AND "+lts;
									}
								}
							}
							luceneSearchDto1.setSearchQuery(query);
							luceneSearchDto1.setSortBy("empLastName");
							luceneSearchDto1 = orgChartSearch.advancedSearch(luceneSearchDto1, 0, Integer.MAX_VALUE/2, false);
							if(luceneSearchDto1!=null && luceneSearchDto1.getSearchList().size()>0){
								for(LuceneSearchCompDto rs1 : luceneSearchDto1.getSearchList()){
									//if(!ocl.getSso().toString().startsWith("5")){
										oneOverOne = new DirectReportsDto();
										if(rs1.getEmpPreferredName()!=null && !rs1.getEmpPreferredName().equalsIgnoreCase(rs1.getEmpFirstName())){
											oneOverOne.setFirstName(rs1.getEmpPreferredName());
										}else{
											oneOverOne.setFirstName(rs1.getEmpFirstName());
										}
										oneOverOne.setLastName(rs1.getEmpLastName());
										oneOverOne.setManager(rs1.getEmpManagerSso());
										oneOverOne.setSso(rs1.getSso());
										oneOverOne.setTitle(rs1.getTitle());
										isContingentWorker = rs1.getSso().toString().startsWith("5")?"Y":"N";
										oneOverOne.setIsContingentWorker(isContingentWorker);
										oneOverOne.setIsLongTermSuspend(rs1.getDirectoryIncl().equalsIgnoreCase("true")?"false":"true");
										if(oneOverOne.getSso().toString().startsWith("5")){
											contingent1o1.add(oneOverOne);
										}else{
											oneOverOneReports.add(oneOverOne);
										}
									//}
									}
									if(showCW){
										oneOverOneReports.addAll(contingent1o1);
									}
									count = count + oneOverOneReports.size();
									employee.setDirectReports(oneOverOneReports);
								}
							}
						
						if(!employee.getSso().toString().startsWith("5")){
							directReportList.add(employee);
						}else{
							if(showCW){
								contingentList.add(employee);
							}
						}
					
				}	count = count + directReportList.size() + contingentList.size();
				
			}
			orgChart.setDirectReportList(directReportList);
			orgChart.setContingentList(contingentList);
			orgChart.setTotalDirectReports(directReportList.size());
			orgChart.setTotalNodes(count);
		}catch(EmptyResultDataAccessException ex){
			logger.info("Org Heirarchy info not loaded for sso:" + sso);
		}
		return orgChart;
	}

	@Override
	public OrgChartDto getNodeCount(Long sso, Long loggedSSO, boolean showCW, boolean showLTS, List<String> rolesList, boolean toggleDR, boolean viewSuspends) {
		OrgChartDto orgChart = new OrgChartDto();
		LuceneSearchCompListDto luceneSearchDto = new LuceneSearchCompListDto();
		String acl = "";
		String lts = "";
		String query = "";
		boolean hasRoleSA = false;
		boolean hasACLRoles = false;
		if(rolesList!=null && rolesList.size()>0){
			hasRoleSA = rolesList.contains("ROLE_SA");
			acl = "";
			for(int i=0; i<rolesList.size(); i++){
				if(aclList.contains(rolesList.get(i))){
					hasACLRoles = true;
					acl += " OR acl_"+rolesList.get(i)+":*"+loggedSSO+"*";
				}
			}
		}
		acl = acl.replaceFirst(" OR ", "");
		lts +="directoryInclusion:true";
		if(showCW){ 
			if(hasACLRoles && showLTS){
				query += "(empManagerSso:"+sso+" AND ("+acl+")) OR ";
			}
			query += "(empManagerSso:"+sso+" AND "+lts+")";
			if(hasRoleSA){
				query = "empManagerSso:"+sso;
				if(!showLTS){
					query += " AND "+lts;
				}
			}
		}else{
			if(hasACLRoles && showLTS){
				query += "(empManagerSso:"+sso+" AND ("+acl+") AND NOT(sso:5*)) OR ";
			}
			query += "(empManagerSso:"+sso+" AND "+lts+" AND NOT(sso:5*))";
			if(hasRoleSA){
				query = "empManagerSso:"+sso+" AND NOT(sso:5*)";
				if(!showLTS){
					query += " AND "+lts;
				}
			}
		}
		luceneSearchDto.setSearchQuery(query);
		luceneSearchDto = orgChartSearch.getNodeCount(luceneSearchDto, 0, Integer.MAX_VALUE/2, null);
		orgChart.setTotalDirectReports(luceneSearchDto.getTotal());
		
		if(!toggleDR){
			query = "";
			if(showCW){ 
				if(hasACLRoles && showLTS){
					query += "((sso:"+sso+" OR ohMgrSso:"+sso+" OR ohMgrSso1:"+sso + ") AND ("+acl+")) OR ";
				}
				query += "((sso:"+sso+" OR ohMgrSso:"+sso+" OR ohMgrSso1:"+sso + ") AND "+lts+")";
				if(hasRoleSA){
					query = "(sso:"+sso+" OR ohMgrSso:"+sso+" OR ohMgrSso1:"+sso+")";
					if(!showLTS){
						query += " AND "+lts;
					}
				}
			}else{
				if(hasACLRoles && showLTS){
					query += "((sso:"+sso+" OR ohMgrSso:"+sso+" OR ohMgrSso1:"+sso + ") AND ("+acl+") AND NOT(sso:5*)) OR ";
				}
				query += "((sso:"+sso+" OR ohMgrSso:"+sso+" OR ohMgrSso1:"+sso + ") AND "+lts+" AND NOT(sso:5*))";
				if(hasRoleSA){
					query = "(sso:"+sso+" OR ohMgrSso:"+sso+" OR ohMgrSso1:"+sso+") AND NOT(sso:5*)";					
					if(!showLTS){
						query += " AND "+lts;
					}
				}
			}
		}
		luceneSearchDto.setSearchQuery(query);
		luceneSearchDto = orgChartSearch.getNodeCount(luceneSearchDto, 0, Integer.MAX_VALUE/2, null);
		orgChart.setTotalNodes(luceneSearchDto.getTotal());
		return orgChart;
	}	
	
	@Override
	public OrgChartDto createOrgChartWithLuceneMobile(Long sso, Long loggedSSO, List<String> rolesList, boolean viewSuspends){
		OrgChartDto orgChart = new OrgChartDto();
		LuceneSearchCompListDto luceneSearchDto = new LuceneSearchCompListDto();
		DirectReportsDto manager = new DirectReportsDto();
		List<OrgChartDirectReportsDto> directReportList = new ArrayList<OrgChartDirectReportsDto>();
		List<OrgChartDirectReportsDto> peerList = new ArrayList<OrgChartDirectReportsDto>();
		OrgChartDirectReportsDto employee = new OrgChartDirectReportsDto();
		String isContingentWorker = "";
		String acl = "";
		String lts = "";
		String query = "";
		boolean hasRoleSA = false;
		boolean hasACLRoles = false;
		if(rolesList!=null && rolesList.size()>0){
			hasRoleSA = rolesList.contains("ROLE_SA");
			acl = "";
			for(int i=0; i<rolesList.size(); i++){
				if(aclList.contains(rolesList.get(i))){
					hasACLRoles = true;
					acl += " OR acl_"+rolesList.get(i)+":*"+loggedSSO+"*";
				}
			}
		}
		acl = acl.replaceFirst(" OR ", "");
		lts +="directoryInclusion:true";
		int count = 0;
		int peer = 0;
		try{
			luceneSearchDto.setSearchQuery("sso:"+sso);
			luceneSearchDto.setSortBy("empLastName");
			luceneSearchDto = orgChartSearch.advancedSearch(luceneSearchDto, 0, Integer.MAX_VALUE/2, false);
			if(luceneSearchDto!=null && luceneSearchDto.getSearchList().size()>0){
				count = count + luceneSearchDto.getSearchList().size();
				orgChart.setSso(luceneSearchDto.getSearchList().get(0).getSso());
				if(luceneSearchDto.getSearchList().get(0).getEmpPreferredName()!=null && !luceneSearchDto.getSearchList().get(0).getEmpPreferredName().equalsIgnoreCase(luceneSearchDto.getSearchList().get(0).getEmpFirstName())){
					orgChart.setFirstName(luceneSearchDto.getSearchList().get(0).getEmpPreferredName());
				}else{
					orgChart.setFirstName(luceneSearchDto.getSearchList().get(0).getEmpFirstName());
				}
				orgChart.setLastName(luceneSearchDto.getSearchList().get(0).getEmpLastName());
				orgChart.setTitle(luceneSearchDto.getSearchList().get(0).getTitle());
				orgChart.setIfg(luceneSearchDto.getSearchList().get(0).getIfg());
				
				//orgChart.setCity(luceneSearchDto.getSearchList().get(0).getEmpCity());
				orgChart.setState(luceneSearchDto.getSearchList().get(0).getEmpState());
				orgChart.setCountry(luceneSearchDto.getSearchList().get(0).getEmpCountry());
				orgChart.setIsLongTermSuspend(luceneSearchDto.getSearchList().get(0).getDirectoryIncl().equalsIgnoreCase("true")?"false":"true");
				
				isContingentWorker = luceneSearchDto.getSearchList().get(0).getSso().toString().startsWith("5")?"Y":"N";
				orgChart.setIsContingentWorker(isContingentWorker);
				if(luceneSearchDto.getSearchList().get(0).getEmpManagerSso()!=null && luceneSearchDto.getSearchList().get(0).getEmpManagerSso()!=0){
					// manager
					manager.setFirstName(luceneSearchDto.getSearchList().get(0).getOhMgrFirstName());
					manager.setLastName(luceneSearchDto.getSearchList().get(0).getOhMgrLastName());
					manager.setSso(luceneSearchDto.getSearchList().get(0).getEmpManagerSso());
					manager.setTitle(luceneSearchDto.getSearchList().get(0).getMgrTitle());
					orgChart.setManager(manager);
					// peer
					query="";
					if(hasACLRoles){
						query += "(empManagerSso:"+manager.getSso()+" AND ("+acl+") AND NOT(sso:5*)) OR ";
					}
					query += "(empManagerSso:"+manager.getSso()+" AND "+lts+" AND NOT(sso:5*))";
					if(hasRoleSA){
						query = "empManagerSso:"+manager.getSso()+" AND NOT(sso:5*)";
					}
					luceneSearchDto.setSearchQuery(query);
					luceneSearchDto.setSortBy("empLastName");
					luceneSearchDto = orgChartSearch.advancedSearch(luceneSearchDto, 0, Integer.MAX_VALUE/2, false);
					if(luceneSearchDto!=null && luceneSearchDto.getSearchList().size()>0){
						for(LuceneSearchCompDto rs : luceneSearchDto.getSearchList()){					
							employee = new OrgChartDirectReportsDto();
							if(rs.getEmpPreferredName()!=null && !rs.getEmpPreferredName().equalsIgnoreCase(rs.getEmpFirstName())){
								employee.setFirstName(rs.getEmpPreferredName());
							}else{
								employee.setFirstName(rs.getEmpFirstName());
							}
							employee.setLastName(rs.getEmpLastName());
							employee.setSso(rs.getSso());
							peerList.add(employee);
						}
						orgChart.setPeerList(peerList);
						peer = peer + peerList.size();
					}
				}
			}
			//direct reports
			query="";
			if(hasACLRoles){
				query += "(empManagerSso:"+sso+" AND ("+acl+") AND NOT(sso:5*)) OR ";
			}
			query += "(empManagerSso:"+sso+" AND "+lts+" AND NOT(sso:5*))";
			if(hasRoleSA){
				query = "empManagerSso:"+sso+" AND NOT(sso:5*)";
			}
			luceneSearchDto.setSearchQuery(query);
			luceneSearchDto.setSortBy("empLastName");
			luceneSearchDto = orgChartSearch.advancedSearch(luceneSearchDto, 0, Integer.MAX_VALUE/2, false);
			
			int directListLimit = Integer.parseInt(propertyDao.getByKey("orgchart.maxDirectNodes.mobile"));
			
			int directListLength = luceneSearchDto.getSearchList().size() > directListLimit ? directListLimit : luceneSearchDto.getSearchList().size();
			if(luceneSearchDto!=null && luceneSearchDto.getSearchList().size()>0){
				for(int i=0; i < directListLength; i++){
					
						employee = new OrgChartDirectReportsDto();
						if(luceneSearchDto.getSearchList().get(i).getEmpPreferredName()!=null && !luceneSearchDto.getSearchList().get(i).getEmpPreferredName().equalsIgnoreCase(luceneSearchDto.getSearchList().get(i).getEmpFirstName())){
							employee.setFirstName(luceneSearchDto.getSearchList().get(i).getEmpPreferredName());	
						}else{
							employee.setFirstName(luceneSearchDto.getSearchList().get(i).getEmpFirstName());			
						}
						employee.setLastName(luceneSearchDto.getSearchList().get(i).getEmpLastName());
						employee.setSso(luceneSearchDto.getSearchList().get(i).getSso());
						employee.setIsLongTermSuspend(luceneSearchDto.getSearchList().get(i).getDirectoryIncl().equalsIgnoreCase("true")?"false":"true");
						directReportList.add(employee);
					
				}
				count = directReportList.size();
			}
			orgChart.setDirectReportList(directReportList);
			orgChart.setTotalDirectReports(luceneSearchDto.getSearchList().size());
			orgChart.setTotalNodes(count);
			orgChart.setTotalPeers(peer);
		}catch(EmptyResultDataAccessException ex){
			logger.info("Org Heirarchy info not loaded for sso:" + sso);
		}
		return orgChart;
	}

	public PropertyDao getPropertyDao() {
		return propertyDao;
	}
	
}
