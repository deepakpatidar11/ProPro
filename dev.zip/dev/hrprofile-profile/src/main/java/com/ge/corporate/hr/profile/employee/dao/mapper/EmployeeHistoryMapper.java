/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.EmployeeHistory;

public class EmployeeHistoryMapper implements RowMapper<EmployeeHistory> {

	private static final String SSO  = "SSO";
	private static final String EMH_BUSINESS_CARD = "EMH_BUSINESS_CARD";
	private static final String EMH_CORPORATE_BAND = "EMH_CORPORATE_BAND";
	private static final String EMH_BUSINESS_BAND = "EMH_BUSINESS_BAND";
	private static final String EMH_GE_BUSINESS = "EMH_GE_BUSINESS";
	private static final String EMH_LOACATION = "EMH_LOACATION";
	private static final String EMH_FUNCTION_DES = "EMH_FUNCTION_DES";
	private static final String EMH_FROM_DATE = "EMH_FROM_DATE";
	private static final String EMH_TO_DATE = "EMH_TO_DATE";
	private static final String EMH_MANAGER = "EMH_MANAGER";
	private static final String EMH_INSERT_DATE = "EMH_INSERT_DATE";
	private static final String EMH_UPDATE_DATE = "EMH_UPDATE_DATE";
	private static final String EMH_EXP_DESC = "EMH_EXP_DESC";
	private static final String EMH_CURRENT_FLAG = "curr_job_flag";
	private static final String EMH_ALERT_FLAG = "alert_flag";
	
	private boolean isSelf = false;
	private boolean hasDataGroup = false;
	
	public EmployeeHistoryMapper() {		
		isSelf=true;
		hasDataGroup=true;
	}
	
	public EmployeeHistoryMapper(boolean _isSelf, boolean _hasDataGroup) {		
		isSelf=_isSelf;
		hasDataGroup=_hasDataGroup;
	}
	
	public EmployeeHistory mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		EmployeeHistory employeeHistory = new EmployeeHistory();
		
		employeeHistory.setSso(rs.getLong(SSO));
		employeeHistory.setBusinessCard(rs.getString(EMH_BUSINESS_CARD));
		if(hasDataGroup){
			employeeHistory.setCorporateBand(rs.getString(EMH_CORPORATE_BAND));
			employeeHistory.setBusinessBand(rs.getString(EMH_BUSINESS_BAND));
		}
		employeeHistory.setGeBusiness(rs.getString(EMH_GE_BUSINESS));
		employeeHistory.setLocation(rs.getString(EMH_LOACATION));
		employeeHistory.setJobFunction(rs.getString(EMH_FUNCTION_DES));
		employeeHistory.setFromDate(rs.getString(EMH_FROM_DATE));
		employeeHistory.setToDate(rs.getString(EMH_TO_DATE));
		if(isSelf){
			employeeHistory.setManager(rs.getString(EMH_MANAGER));
			employeeHistory.setAlertFlag(rs.getString(EMH_ALERT_FLAG));
		}
		employeeHistory.setDescription(rs.getString(EMH_EXP_DESC));
		//Not used
		employeeHistory.setInsertDate(rs.getString(EMH_INSERT_DATE));
		employeeHistory.setUpdateDate(rs.getString(EMH_UPDATE_DATE));
		employeeHistory.setCurrentFlag(rs.getString(EMH_CURRENT_FLAG));
		
		return employeeHistory;
	}
}
