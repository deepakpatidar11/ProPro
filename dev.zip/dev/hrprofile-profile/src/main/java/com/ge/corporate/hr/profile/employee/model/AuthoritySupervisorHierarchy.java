/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="authoritySupervisorHierarchy")
@XmlAccessorType(XmlAccessType.FIELD)
public class AuthoritySupervisorHierarchy extends AbstractBaseModelSupport{

	private static final long serialVersionUID = 4760712755094392751L;
	
	public AuthoritySupervisorHierarchy() {}	
	@XmlElement(name="sso")
	private long sso;	
	// personal info
	@XmlElement(name="reportsTo")
	private String reportsTo;
	@XmlElement(name="hrManager")
	private String hrManager;

	public long getSso() {
		return sso;
	}
	public void setSso(long sso) {
		this.sso = sso;
	}
	public String getReportsTo() {
		return reportsTo;
	}
	public void setReportsTo(String reportsTo) {
		this.reportsTo = reportsTo;
	}
	public String getHrManager() {
		return hrManager;
	}
	public void setHrManager(String hrManager) {
		this.hrManager = hrManager;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	
	

		
}