/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.PriorPerformance;

/**
 * Prior Performance mapper
 * @author rithesh.shridhar
 *
 */
public class PriorPerformanceMapper implements RowMapper<PriorPerformance>{
	
	public static final String DATA_YEAR = "perf_year";
	public static final String DATA_OVERAL_PERFORMANCE = "perf_overall_performance";
	public static final String DATA_OVERAL_RAITING = "perf_overall_rating";
	public static final String DATA_OVERALL_GROWTH = "perf_overall_growth_value";
	
	public PriorPerformance mapRow(ResultSet rs, int rowNum) throws SQLException {		
		PriorPerformance priorPerformance = new PriorPerformance();		
		priorPerformance.setOverallPerformance(rs.getString(DATA_OVERAL_PERFORMANCE));			
		priorPerformance.setYear(rs.getShort(DATA_YEAR));
		priorPerformance.setOverallRating(rs.getString(DATA_OVERAL_RAITING));
		priorPerformance.setOverallGrowth(rs.getString(DATA_OVERALL_GROWTH));		
		return priorPerformance;		
	}
	
}
