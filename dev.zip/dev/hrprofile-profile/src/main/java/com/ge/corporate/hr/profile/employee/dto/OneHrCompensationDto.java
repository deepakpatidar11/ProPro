package com.ge.corporate.hr.profile.employee.dto;
import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.BonusSIT;
import com.ge.corporate.hr.profile.employee.model.Compensation;
import com.ge.corporate.hr.profile.employee.model.IncentiveCompensation;

public class OneHrCompensationDto extends AbstractBaseDtoSupport{	
	
	private static final long serialVersionUID = -2684896088396513052L;
	
	private Long sso;
	/**
	 * Total Current Compensation
	 */
	Long totalCurrentComp = 0L;
	
	/**
	 * Total Current Compensation Converted to USD
	 */
	Long totalCurrentCompConverted = 0L;
	String Status = "";
	BaseModelCollection<Compensation> compensationList = null;	

	BaseModelCollection<IncentiveCompensation> icList = null;
	BaseModelCollection<BonusSIT> bonusList = null;

	public String minSalary;
	public String maxSalary;
	
	public String getMinSalary() {
		return minSalary;
	}

	public void setMinSalary(String minSalary) {
		this.minSalary = minSalary;
	}

	public String getMaxSalary() {
		return maxSalary;
	}

	public void setMaxSalary(String maxSalary) {
		this.maxSalary = maxSalary;
	}
	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public BaseModelCollection<BonusSIT> getBonusList() {
		return bonusList;
	}

	public void setBonusList(BaseModelCollection<BonusSIT> bonusList) {
		this.bonusList = bonusList;
	}

	public BaseModelCollection<Compensation> getCompensationList() {
		return compensationList;
	}

	public void setCompensationList(
			BaseModelCollection<Compensation> compensationList) {
		this.compensationList = compensationList;
	}

	public BaseModelCollection<IncentiveCompensation> getIcList() {
		return icList;
	}

	public void setIcList(BaseModelCollection<IncentiveCompensation> icList) {
		this.icList = icList;
	}

	public OneHrCompensationDto(Long sso)	{
		this.sso = sso;
	}
	
	public Long getTotalCurrentComp() {
		return totalCurrentComp;
	}
	
	public void setTotalCurrentComp(Long totalCurrentComp) {
		this.totalCurrentComp = totalCurrentComp;
	}
	
	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public Long getTotalCurrentCompConverted() {
		return totalCurrentCompConverted;
	}

	public void setTotalCurrentCompConverted(Long totalCurrentCompConverted) {
		this.totalCurrentCompConverted = totalCurrentCompConverted;
	}

	public String getCurrency(){
		String currency = null;
		//A future dated salary record is any record where the Date is > Sys.Date
		if(compensationList != null && !compensationList.isEmpty()){
			
			for(Compensation comp :compensationList.getList()){
				
				if(!comp.isFutureDate()){
					currency = comp.getCurrency();
					break;
				}
				
			}
			
		}
		return currency;
	}

	@Override
	public long getId() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public OneHrCompensationDto(){
		
	}
	
}
