/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.ProxyHost;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.ge.corporate.hr.profile.employee.dto.CurrencyDto;
import com.ge.corporate.hr.profile.employee.model.CurrencyAPI;

/**
 * Currency Conversion class that uses HTTP service to retrieve currency conversion data on 
 * JSON format.
 * 
 * @author hector.nevarez
 *
 */
public class CurrencyConversionServiceImpl implements CurrencyConversionService {

	private HttpClient httpCon;
	private GetMethod getMethod;
	private ProxyHost proxy;
	
	private String url;
	
	private String charset;
	
	private final Log logger = LogFactory.getLog(CurrencyConversionServiceImpl.class);
	
	private final static String DEFAULT_CURRENCY = "USD";
	private final static Double DEFAULT_CURRENCY_RATE = 1D;
	
	//@Cacheable(cacheName="/profile/employee/service/currency")
	public List<CurrencyDto> getCurrency(){
		
		CurrencyDto convertedCurrency = null;
		List<CurrencyDto> currencyList = new ArrayList<CurrencyDto>();
		Map<String, Double> currMap = new HashMap<String, Double>();
		
		createConnection();
		
		getMethod = new GetMethod(url);
		getMethod.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, charset);
		getMethod.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,	new DefaultHttpMethodRetryHandler(3, false));
		
		try{
			
			if(proxy != null){
				httpCon.getHostConfiguration().setProxyHost( proxy );
			}
			
			if( httpCon.executeMethod(getMethod) == HttpStatus.SC_OK ){						
				
				charset = (charset != null && !charset.equals("")) ? charset : getMethod.getRequestCharSet();		
				
				currMap = unmarshallResponse(new String ( getMethod.getResponseBody(), charset) );
				
				for (String currCode : currMap.keySet()) {
					convertedCurrency = new CurrencyDto();				
					convertedCurrency.setFormerAmmount(DEFAULT_CURRENCY_RATE);
					convertedCurrency.setConvertedAmmount(1/currMap.get(currCode));
					convertedCurrency.setFormerCurrency(currCode);
					convertedCurrency.setConvertedCurrency(DEFAULT_CURRENCY);
					currencyList.add(convertedCurrency);
				}
				
			}else{
				logger.debug("Call Failed with STATUS:" + getMethod.getStatusCode());
			}
		} catch (JsonParseException e) {
			logger.error("Currency Conversion returned invalid JSon response");
		} catch (JsonMappingException e) {	
			logger.error("Currency Conversion Unable to map JSon response to Object");
		} catch (HttpException e) {
			logger.debug("HTTP Currency Service call falied:" + e.getMessage());
	    } catch (IOException e) {
	    	logger.debug("HTTP Currency Service call falied:" + e.getMessage());
	    } finally {
	    	getMethod.releaseConnection();
	    }  
		
		
		return currencyList;
		
	}
	
	public CurrencyDto getCurrency(String currentCurrency, Long ammount, String newCurrency) {
		
		CurrencyDto convertedCurrency = null;
		
		if(currentCurrency.equalsIgnoreCase("COP")){
			System.out.println("Break Point");
		}
		
		if(!currentCurrency.equals(newCurrency)){
			
			createConnection();
			
			getMethod = new GetMethod(getServiceCallUrl(currentCurrency, ammount, newCurrency));
			getMethod.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, charset);
			getMethod.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,	new DefaultHttpMethodRetryHandler(3, false));
			
			try{
				
				if(proxy != null){
					httpCon.getHostConfiguration().setProxyHost( proxy );
				}
				
				if( httpCon.executeMethod(getMethod) == HttpStatus.SC_OK ){
									
					convertedCurrency = new CurrencyDto();
					convertedCurrency.setFormerAmmount((double) ammount);
					convertedCurrency.setConvertedCurrency(newCurrency);
					convertedCurrency.setFormerCurrency(currentCurrency);
					
					charset = (charset != null && !charset.equals("")) ? charset : getMethod.getRequestCharSet();
					
					unmarshallResponse( convertedCurrency, new String ( getMethod.getResponseBody(), charset) );
					
				}else{
					logger.debug("Call Failed with STATUS:" + getMethod.getStatusCode());
				}
			} catch (JsonParseException e) {
				logger.error("Currency Conversion returned invalid JSon response");
			} catch (JsonMappingException e) {	
				logger.error("Currency Conversion Unable to map JSon response to Object");
			} catch (HttpException e) {
				logger.debug("HTTP Currency Service call falied:" + e.getMessage());
		    } catch (IOException e) {
		    	logger.debug("HTTP Currency Service call falied:" + e.getMessage());
		    } finally {
		    	getMethod.releaseConnection();
		    }  
			
			/*
		    try {
		        URL url = new URL(getServiceCallUrl(currentCurrency, ammount, newCurrency));
		        BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
		        String html;
		        while ((html = in.readLine()) != null) {
		            html = in.readLine().toString();	            
		            extractHTMLResponse( convertedCurrency, html );
		        }
		        in.close();
		    } catch (MalformedURLException e) {
		    	logger.debug("HTTP Currency Service call falied:" + e.getMessage());
		    } catch (IOException e) {
		    	logger.debug("HTTP Currency Service call falied:" + e.getMessage());
		    }
		    */
		
		}
		
		return convertedCurrency;
		
	}

	protected String getServiceCallUrl(String currentCurrency, Long ammount, String newCurreny){
		StringBuilder callUrl = new StringBuilder();
		
		callUrl.append(url);
		
		callUrl.append("?a=1&from=");
		callUrl.append(currentCurrency.toUpperCase());	
		callUrl.append("&to=");	
		callUrl.append(newCurreny.toUpperCase());
		
		logger.debug("Remote service call at " + callUrl.toString());
		
		return callUrl.toString();
	}
	
	protected void extractHTMLResponse( CurrencyDto convertedCurrency, String response) throws IOException{
		
		String rate = StringUtils.substringBetween(response, "<span class=\"bld\">", " USD</span>");
		convertedCurrency.setConvertedAmmount(Double.parseDouble(rate));
		
	}
	
	protected Map<String, Double> unmarshallResponse( String response) throws JsonParseException, JsonMappingException, IOException{
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES , true);
		
		CurrencyAPI rawConvertedCurrency = mapper.readValue(response, CurrencyAPI.class);
		
		return rawConvertedCurrency.getRates();
		
	}
	
	protected void unmarshallResponse( CurrencyDto convertedCurrency, String response) throws JsonParseException, JsonMappingException, IOException{
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES , true);
		
		Map<String, Object> rawConvertedCurrency = null;
		
		rawConvertedCurrency = mapper.readValue (response, HashMap.class);
		
		convertedCurrency.setConvertedAmmount(Double.parseDouble((String) rawConvertedCurrency.get("rate")));
		
		//Map raw object to DTO
		//convertedCurrency.setFormerAmmount( fetchNumber(rawConvertedCurrency.get("lhs").toString()) );
		//if(rawConvertedCurrency.get("rate")!=null){
		//	convertedCurrency.setConvertedAmmount( fetchNumber( rawConvertedCurrency.get("rate").toString() ) );
		//}
		
	}
	
	private Double fetchNumber(String rawAmmount) throws IOException{
		Double ammount = null;
		if(rawAmmount != null && !rawAmmount.equals("")){
			try{
				ammount = formatToNumeric(rawAmmount);
			}catch (NumberFormatException e) {
				logger.error("Currency conversion returned a non numeric value:" + rawAmmount);
			}
		}
		return ammount;
		
	}
	
	public Double formatToNumeric (String rawNumber){
		
		rawNumber = rawNumber.replaceAll("[^\\d.]", ""); //Eliminates all NonNumeric Char except for [.]
		rawNumber = rawNumber.replaceAll("[\\.]*$", ""); //Eliminates trailing [.]s
				
		return Double.parseDouble(rawNumber);
	}
	
	public void setCharset(String charset) {
		this.charset = charset;
	}
	
	public void setProxy(ProxyHost proxy) {
		this.proxy = proxy; 
	}
	
	public void setProxy(String host, int port) {
		proxy = new ProxyHost(host, port);
	}

	public void setURL(String url) throws IOException {
		this.url = url;
	}

	protected void createConnection(){
		if(httpCon == null){
			httpCon = new HttpClient();
		}
	}
	
}
