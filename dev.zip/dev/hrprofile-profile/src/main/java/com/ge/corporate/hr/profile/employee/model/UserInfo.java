/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="userInfo")
@XmlAccessorType(XmlAccessType.FIELD)
public class UserInfo extends AbstractBaseModelSupport {

	private static final long serialVersionUID = 4760712755094392751L;
	
	public UserInfo() {}
	
	@XmlElement(name="sso")
	private Long sso;
	
	@XmlElement(name="firstName")
	private String firstName;
	
	@XmlElement(name="lastName")
	private String lastName;
	
	@XmlElement(name="preferedName")
	private String preferedName;	

	@XmlElement(name="industrySegment")
	private String industrySegment;
	
	@XmlElement(name="business")
	private String business;
	
	@XmlElement(name="subBusiness")
	private String subBusiness;
	
	@XmlElement(name="organization")
	private String organization;
	
	@XmlElement(name="function")
	private String function;
	
	@XmlElement(name="jobFamily")
	private String jobFamily;
	
	public Long getSso() {
		return sso;
	}	
	public void setSso(Long sso) {
		this.sso = sso;
	}	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPreferedName() {
		return preferedName;
	}
	public void setPreferedName(String preferedName) {
		this.preferedName = preferedName;
	}
	public String getIndustrySegment() {
		return industrySegment;
	}
	public void setIndustrySegment(String industrySegment) {
		this.industrySegment = industrySegment;
	}
	public String getBusiness() {
		return business;
	}
	public void setBusiness(String business) {
		this.business = business;
	}
	public String getSubBusiness() {
		return subBusiness;
	}
	public void setSubBusiness(String subBusiness) {
		this.subBusiness = subBusiness;
	}
	public String getOrganization() {
		return organization;
	}
	public void setOrganization(String organization) {
		this.organization = organization;
	}
	public String getFunction() {
		return function;
	}
	public void setFunction(String function) {
		this.function = function;
	}
	public String getJobFamily() {
		return jobFamily;
	}
	public void setJobFamily(String jobFamily) {
		this.jobFamily = jobFamily;
	}
	
}