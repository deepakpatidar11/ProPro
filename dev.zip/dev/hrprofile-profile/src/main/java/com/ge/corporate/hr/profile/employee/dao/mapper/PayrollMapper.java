package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.WorkAssignmentRestricted;

public class PayrollMapper implements RowMapper<WorkAssignmentRestricted> {
	
	public static final String DATA_PAYROLL_NAME = "EMP_PAYROLL_NAME";
	public static final String DATA_PAYROLL_PROCESSOR_CODE = "EMP_PAYROLL_PROCESSOR_CODE";
	
	public WorkAssignmentRestricted mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		WorkAssignmentRestricted assignment = new WorkAssignmentRestricted();	
		
		assignment.setPayrollName(rs.getString(DATA_PAYROLL_NAME));		
		assignment.setPayrollProcessorCode(rs.getString(DATA_PAYROLL_PROCESSOR_CODE));
		return assignment;		
	}
}
