package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "profileCompleteness")
public class ProfileCompleteness {

	@XmlElement(name = "sso")
	private Long sso;

	@XmlElement(name = "percentComplete")
	private int percentComplete;

	@XmlElement(name = "profSummary")
	private int profSummary;

	@XmlElement(name = "jobDesc")
	private int jobDesc;

	@XmlElement(name = "workHistory")
	private int workHistory;

	@XmlElement(name = "workHistoryDesc")
	private int workHistoryDesc;

	@XmlElement(name = "career")
	private int career;

	@XmlElement(name = "education")
	private int education;

	@XmlElement(name = "languageProf")
	private int languageProf;

	@XmlElement(name = "profInterests")
	private int profInterests;

	@XmlElement(name = "networks")
	private int networks;

	@XmlElement(name = "expertise")
	private int expertise;

	@XmlElement(name = "workMobility")
	private int workMobility;

	@XmlElement(name = "affGroups")
	private int affGroups;

	@XmlElement(name = "initProjects")
	private int initProjects;

	@XmlElement(name = "custSuppliers")
	private int custSuppliers;

	@XmlElement(name = "profCertification")
	private int profCertification;

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public int getPercentComplete() {
		return percentComplete;
	}

	public void setPercentComplete(int percentComplete) {
		this.percentComplete = percentComplete;
	}

	public int getProfSummary() {
		return profSummary;
	}

	public void setProfSummary(int profSummary) {
		this.profSummary = profSummary;
	}

	public int getJobDesc() {
		return jobDesc;
	}

	public void setJobDesc(int jobDesc) {
		this.jobDesc = jobDesc;
	}

	public int getWorkHistory() {
		return workHistory;
	}

	public void setWorkHistory(int workHistory) {
		this.workHistory = workHistory;
	}

	public int getWorkHistoryDesc() {
		return workHistoryDesc;
	}

	public void setWorkHistoryDesc(int workHistoryDesc) {
		this.workHistoryDesc = workHistoryDesc;
	}

	public int getCareer() {
		return career;
	}

	public void setCareer(int career) {
		this.career = career;
	}

	public int getEducation() {
		return education;
	}

	public void setEducation(int education) {
		this.education = education;
	}

	public int getLanguageProf() {
		return languageProf;
	}

	public void setLanguageProf(int languageProf) {
		this.languageProf = languageProf;
	}

	public int getProfInterests() {
		return profInterests;
	}

	public void setProfInterests(int profInterests) {
		this.profInterests = profInterests;
	}

	public int getExpertise() {
		return expertise;
	}

	public void setExpertise(int expertise) {
		this.expertise = expertise;
	}

	public int getWorkMobility() {
		return workMobility;
	}

	public void setWorkMobility(int workMobility) {
		this.workMobility = workMobility;
	}

	public int getAffGroups() {
		return affGroups;
	}

	public void setAffGroups(int affGroups) {
		this.affGroups = affGroups;
	}

	public int getInitProjects() {
		return initProjects;
	}

	public void setInitProjects(int initProjects) {
		this.initProjects = initProjects;
	}

	public int getCustSuppliers() {
		return custSuppliers;
	}

	public void setCustSuppliers(int custSuppliers) {
		this.custSuppliers = custSuppliers;
	}

	public int getProfCertification() {
		return profCertification;
	}

	public void setProfCertification(int profCertification) {
		this.profCertification = profCertification;
	}

	public int getNetworks() {
		return networks;
	}

	public void setNetworks(int networks) {
		this.networks = networks;
	}

}
