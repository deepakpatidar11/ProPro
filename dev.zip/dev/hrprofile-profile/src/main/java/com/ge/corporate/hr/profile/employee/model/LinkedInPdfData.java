package com.ge.corporate.hr.profile.employee.model;

import java.util.ArrayList;
import java.util.List;

public class LinkedInPdfData {
	private String summary = "";
	private List<LinkedInPdfEmploymentHistory> employmentHistory = new ArrayList<LinkedInPdfEmploymentHistory>();
	private List<LinkedInPdfEducation> education = new ArrayList<LinkedInPdfEducation>();

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public List<LinkedInPdfEmploymentHistory> getEmploymentHistory() {
		return employmentHistory;
	}

	public void setEmploymentHistory(List<LinkedInPdfEmploymentHistory> employmentHistory) {
		this.employmentHistory = employmentHistory;
	}

	public List<LinkedInPdfEducation> getEducation() {
		return education;
	}

	public void setEducation(List<LinkedInPdfEducation> education) {
		this.education = education;
	}
}
