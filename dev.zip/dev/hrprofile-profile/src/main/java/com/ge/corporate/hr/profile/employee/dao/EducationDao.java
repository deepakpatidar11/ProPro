/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import java.util.List;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dto.EducationTrainingDto;
import com.ge.corporate.hr.profile.employee.model.Certification;
import com.ge.corporate.hr.profile.employee.model.Education;
import com.ge.corporate.hr.profile.employee.model.EducationCountry;
import com.ge.corporate.hr.profile.employee.model.EducationUniversity;
/**
 * Education Dao interface
 * @author enrique.romero
 *
 */
public interface EducationDao {
	/**
	 * returns all Education information by sso, this information  belongs to "Education" data group
	 * @param sso Employee sso
	 * @return Education model
	 */
	public BaseModelCollection<Education> getEducationListBySso(Long sso, boolean isSelf);
	public BaseModelCollection<Education> getEducationListOptinBySso(Long sso);
	public BaseModelCollection<Education> getEducationListAllBySso(Long sso);
	public BaseModelCollection<EducationCountry> getCountries();
	public BaseModelCollection<String> getDegrees();
	public BaseModelCollection<String> getMajors();
	public BaseModelCollection<String> getUniversities();
	public BaseModelCollection<String> getDegrees(String country);
	public BaseModelCollection<EducationUniversity> getUniversities(String country, String query);
	public boolean saveEducationDetails(Long sso,
			EducationTrainingDto educationDetails);
	public boolean saveProfessionalCertifications(Long sso,
			List<Certification> certificationList);
	public BaseModelCollection<Certification> getCertificationsBySso(Long sso);
	}
