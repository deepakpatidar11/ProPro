package com.ge.corporate.hr.profile.employee.dao;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.security.access.prepost.PreAuthorize;

import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dao.mapper.BonusSITMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.CompensationMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.IncentiveCompensationMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.LongTermPerformanceAwardMapper;
import com.ge.corporate.hr.profile.employee.model.BonusSIT;
import com.ge.corporate.hr.profile.employee.model.Compensation;
import com.ge.corporate.hr.profile.employee.model.IncentiveCompensation;
import com.ge.corporate.hr.profile.employee.model.LongTermPerformanceAward;
import com.ge.corporate.hr.profile.employee.model.LumpCompensation;

public class OneHrCompensationDaoImpl extends AbstractBaseDaoSupport implements OneHrCompensationDao{
	
	private static Log logger = LogFactory.getLog(OneHrCompensationDaoImpl.class);	
	
	@PreAuthorize("hasPermission(#sso, 'CompensationOneHR', read)")
	public BaseModelCollection<Compensation> getOneHrCompensationHistoryBySso(Long sso) {

		BaseModelCollection<Compensation> compensationList = null;
		String query = this.getSql("getCompensationHistoryBySso");		
		try{	
			
			compensationList = new BaseModelCollection<Compensation>();
			compensationList.setList( getJdbcTemplate().query(query, new Object[]{sso.intValue(),sso.intValue()}, new CompensationMapper()) );
			logger.debug("OnehrCompensation history data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("OnehrCompensation data Not found");
		}			
		
		return compensationList;
	
	}

	@PreAuthorize("hasPermission(#sso, 'CompensationOneHR', read)")
	public BaseModelCollection<IncentiveCompensation> getOneHrIncentiveCompensationHistoryBySso(
			Long sso) {
		BaseModelCollection<IncentiveCompensation> icList = null;
		String query = this.getSql("getIncentiveCompensationHistoryBySso");		
		try{
			icList = new BaseModelCollection<IncentiveCompensation>();
			icList.setList( getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new IncentiveCompensationMapper()) );
			logger.debug("Onehr Incentive Compensation history data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Onehr Incentive Compensation data Not found");
		}
		
		return icList;
	}

	@Override
	public BaseModelCollection<BonusSIT> getOneHrBonusSITBySso(Long sso) {
		BaseModelCollection<BonusSIT> bonus = null;
		String query = this.getSql("getOneHRBonusSITByStartDateAndSso");		
		try{
			bonus = new BaseModelCollection<BonusSIT>();
			bonus.setList( getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new BonusSITMapper()) );
			logger.debug("Onehr Incentive Compensation history data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Onehr Incentive Compensation data Not found");
		}
		return bonus;
	}



	
	
}
