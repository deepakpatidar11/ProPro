/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="performanceGV")
@XmlAccessorType(XmlAccessType.FIELD)
public class PerformanceGV extends AbstractBaseModelSupport{
	/**
	 * 
	 */	
	private static final long serialVersionUID = 5304681939817284326L;
		
	@XmlElement(name="perfId")
	private Long perfId;
	@XmlAttribute(name="id")
	private Long id;	
	@XmlElement(name="name")
	private String name;
	@XmlElement(name="rating")
	private String rating;
	@XmlElement(name="year")
	private Integer year;
	
	public void setId(Long id) {
		this.id = id;
	}	
	public Long getId() {
		return id;
	}		
	public Long getPerfId() {
		return perfId;
	}
	public void setPerfId(Long perfId) {
		this.perfId = perfId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;
	}
	
}
