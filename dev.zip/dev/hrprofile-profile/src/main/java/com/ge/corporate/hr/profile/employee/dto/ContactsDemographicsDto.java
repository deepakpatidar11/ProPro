/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.employee.model.EmergencyContact;
import com.ge.corporate.hr.profile.employee.model.EmployeeRestricted;
import com.ge.corporate.hr.profile.employee.model.HomeAddress;
import com.ge.corporate.hr.profile.employee.model.ServiceDates;

@XmlRootElement(name="contactsDemographics")
@XmlAccessorType(XmlAccessType.FIELD)
public class ContactsDemographicsDto extends AbstractBaseDtoSupport {
	
	/**
	 * default serial id
	 */
	private static final long serialVersionUID = 1L;

	@XmlElement(name="sso")
	private Long sso;
	
	private EmployeeRestricted perInfoRestricted;
	
	private EmployeeRestricted genderCitizenship;
	
	private EmployeeRestricted disabilitySelfId;
	
	private EmployeeRestricted glbtSelfId;
	
	private HomeAddress homeAddress;
	
	private EmergencyContact emergencyContact;
	
	private ServiceDates serviceDates;
	
	public long getId() {
		return (sso==null)?0:sso.longValue();
	}
	
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}

	public void setPerInfoRestricted(EmployeeRestricted perInfoRestricted) {
		this.perInfoRestricted = perInfoRestricted;
	}

	public EmployeeRestricted getPerInfoRestricted() {
		return perInfoRestricted;
	}

	public EmployeeRestricted getGenderCitizenship() {
		return genderCitizenship;
	}

	public void setGenderCitizenship(EmployeeRestricted genderCitizenship) {
		this.genderCitizenship = genderCitizenship;
	}
	
	public EmployeeRestricted getDisabilitySelfId() {
		return disabilitySelfId;
	}

	public void setDisabilitySelfId(EmployeeRestricted disabilitySelfId) {
		this.disabilitySelfId = disabilitySelfId;
	}

	public EmployeeRestricted getGlbtSelfId() {
		return glbtSelfId;
	}

	public void setGlbtSelfId(EmployeeRestricted glbtSelfId) {
		this.glbtSelfId = glbtSelfId;
	}

	public HomeAddress getHomeAddress() {
		return homeAddress;
	}

	public void setHomeAddress(HomeAddress homeAddress) {
		this.homeAddress = homeAddress;
	}

	public EmergencyContact getEmergencyContact() {
		return emergencyContact;
	}

	public void setEmergencyContact(EmergencyContact emergencyContact) {
		this.emergencyContact = emergencyContact;
	}

	public ServiceDates getServiceDates() {
		return serviceDates;
	}

	public void setServiceDates(ServiceDates serviceDates) {
		this.serviceDates = serviceDates;
	}
		
		
}
