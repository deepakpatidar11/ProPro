/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.WorkAssignmentRestricted;


public class HeadCountCostCenterMapper implements RowMapper<WorkAssignmentRestricted> {
	
	public static final String DATA_COST_CENTER = "EMP_COST_CENTER_CODE";
	public static final String DATA_BUC = "WA_BUC";
	public static final String DATA_ADN = "WA_ADN";
	
	public static final String DATA_HEADCOUNT_COST_CENTER_CODE = "EMP_HEADCOUNT_COST_CENTER_CODE";
	
	
	public WorkAssignmentRestricted mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		WorkAssignmentRestricted assignment = new WorkAssignmentRestricted();	
		
		assignment.setHeadcountCostCenterCode(rs.getString(DATA_HEADCOUNT_COST_CENTER_CODE));
		
		return assignment;		
	}
}
