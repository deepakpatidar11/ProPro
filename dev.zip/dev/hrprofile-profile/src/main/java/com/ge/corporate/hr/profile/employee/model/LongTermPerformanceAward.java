/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;
import com.ge.corporate.hr.profile.employee.serializer.CustomDateSerializer;

@XmlRootElement(name="longTermPerformanceAward")
@XmlAccessorType(XmlAccessType.FIELD)
public class LongTermPerformanceAward extends AbstractBaseModelSupport{ 
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 216134679755031104L;
	@XmlElement(name="sso")
	private Long sso;
	@XmlAttribute(name="id")
	private Long id;	
	@XmlElement(name="date")
	private Date date;
	@XmlElement(name="programYear")
	private Short programYear;
	@XmlElement(name="category")
	private String category;
	
	public LongTermPerformanceAward(){
		
	}
	
	public LongTermPerformanceAward(Long sso, Date  date, Short programYear, String category){
		this.sso = sso;
		this.date = date;
		this.programYear = programYear;
		this.category = category;
	}
	
	public void setId(Long id) {
		this.id = id;
	}	
	public Long getId() {
		return id;
	}	
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Short getProgramYear() {
		return programYear;
	}
	public void setProgramYear(Short programYear) {
		this.programYear = programYear;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public static Long getSerialversionuid() {
		return serialVersionUID;
	}
}
