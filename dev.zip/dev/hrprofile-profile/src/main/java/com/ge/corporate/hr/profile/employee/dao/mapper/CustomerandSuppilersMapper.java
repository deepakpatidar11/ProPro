package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.CustomerandSuppliers;


public class CustomerandSuppilersMapper implements RowMapper<CustomerandSuppliers> {
	
	public static final String DATA_SSO ="sso";
	public static final String DATA_TITLE ="name";
	public static final String  DATA_DESCRIPTION ="text";
	public static final String  DATA_LOCATION ="location";
	public static final String  DATA_DATEFROM ="datefrom";
	public static final String  DATA_DATETO ="dateto";
	
	
	public CustomerandSuppliers mapRow(ResultSet rs, int rowNum) throws SQLException {
		CustomerandSuppliers languages = new CustomerandSuppliers();
		
		languages.setSso(rs.getLong(DATA_SSO));
		languages.setTitle(rs.getString(DATA_TITLE));
		languages.setDescription(rs.getString(DATA_DESCRIPTION));
		languages.setLocation(rs.getString(DATA_LOCATION));
		
		languages.setFromDate(rs.getString(DATA_DATEFROM));
		languages.setToDate(rs.getString(DATA_DATETO));
		
		
		//Not to be shown anymore
		//education.setGraduationYear(rs.getShort(DATA_GRAD_YEAR));
		
		return languages;
	}
}