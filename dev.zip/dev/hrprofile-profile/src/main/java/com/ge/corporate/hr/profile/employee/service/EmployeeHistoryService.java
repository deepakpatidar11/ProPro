/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.service;



import java.util.List;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dto.EmployeeHistoryDto;
import com.ge.corporate.hr.profile.employee.model.CareerAspiration;
import com.ge.corporate.hr.profile.employee.model.CustomerandSuppliers;
import com.ge.corporate.hr.profile.employee.model.EmployeeHistory;
import com.ge.corporate.hr.profile.employee.model.IntiativesandProject;
import com.ge.corporate.hr.profile.employee.model.WorkMobility;

public interface EmployeeHistoryService {
	public EmployeeHistoryDto getEmployeeHistory(EmployeeHistoryDto employeeHistory);
	public EmployeeHistoryDto getEmployeeHistoryRoleSelf(EmployeeHistoryDto employeeHistoryDto);
	public EmployeeHistoryDto getEmploymentHistoryAll(EmployeeHistoryDto employeeHistory, boolean isSharing, boolean isSelf, boolean hasDataGroup);
	public EmployeeHistoryDto getEmploymentHistory(EmployeeHistoryDto employeeHistory, boolean isSelf, boolean hasDataGroup);
	public BaseModelCollection<IntiativesandProject>  getIntiativesAndProject(Long sso);
	public BaseModelCollection<CustomerandSuppliers>  getCustomerAndSuppliers(EmployeeHistoryDto employeeHistory);
	public void updateIntiativesAndProject(EmployeeHistoryDto employeeHistory);
	public void updateCustomerSuppliers(EmployeeHistoryDto employeeHistory);
	public boolean setCareerAspiration(Long sso, String goalCombined);
	public boolean setCareerOpportunity(Long sso, String careerOppFlag);
	public String getCareerOpportunity(Long sso);
	public boolean saveEmploymentHistory(List<EmployeeHistory> empHistory, Long sso);
	public boolean saveCurrentJob(EmployeeHistory currentJob, Long sso);
	public CareerAspiration getCareerAspiration(Long sso) ;
	public WorkMobility getWorkMobility(Long sso) ;
	public boolean setWorkMobility(Long sso, WorkMobility workMobility);
	public boolean updateEmpistoryAlertFlagService(Long sso);
	public BaseModelCollection<EmployeeHistory> populateEmploymentHistory(
			Long sso);
}
