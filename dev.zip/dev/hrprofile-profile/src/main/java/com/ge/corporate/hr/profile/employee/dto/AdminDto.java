/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
/**
 * 
 */
package com.ge.corporate.hr.profile.employee.dto;

import java.io.Serializable;
import java.util.List;

import org.springframework.util.AutoPopulatingList;

import com.ge.corporate.hr.profile.auth.model.DataGroup;
import com.ge.corporate.hr.profile.auth.model.ProfileRoles;
import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;


/**
 * @author francisco.blanco
 *
 */
public class AdminDto extends AbstractBaseDtoSupport implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String className = null;
	private List<ProfileRoles> roles;
	private List<DataGroup> dataGroups;
	private List<DataGroup> selectDataGroups;
	private List<DataGroup> internalResume;
	private List<DataGroup> compensation;
	private List<DataGroup> orgChart;
	private List<DataGroup> contactDemo;
	private List<DataGroup> tranSa;
	private List<DataGroup> workCareer;
	private List<DataGroup> education;
	private List<DataGroup> other;
	private List<ExcelReport> excelreport;
	private String type;
	
	private String selectedRole;
	
	
	public AdminDto(){
		roles 				= new AutoPopulatingList<ProfileRoles>(ProfileRoles.class);
		dataGroups 			= new AutoPopulatingList<DataGroup>(DataGroup.class);
		selectDataGroups	= new AutoPopulatingList<DataGroup>(DataGroup.class);	
	}
	
	
	public String getSelectedRole() {
		return selectedRole;
	}


	public void setSelectedRole(String selectedRole) {
		this.selectedRole = selectedRole;
	}


	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public List<ProfileRoles> getRoles() {
		return roles;
	}
	public void setRoles(List<ProfileRoles> roles) {
		this.roles = roles;
	}
	public List<DataGroup> getDataGroups() {
		return dataGroups;
	}
	public void setDataGroups(List<DataGroup> dataGroups) {
		this.dataGroups = dataGroups;
	}

	public List<DataGroup> getSelectDataGroups() {
		return selectDataGroups;
	}

	public void setSelectDataGroups(List<DataGroup> selectDataGroups) {
		this.selectDataGroups = selectDataGroups;
	}

	public long getId() {
		return 0;
	}


	public List<DataGroup> getInternalResume() {
		return internalResume;
	}


	public void setInternalResume(List<DataGroup> internalResume) {
		this.internalResume = internalResume;
	}


	public List<DataGroup> getOrgChart() {
		return orgChart;
	}


	public void setOrgChart(List<DataGroup> orgChart) {
		this.orgChart = orgChart;
	}


	public List<DataGroup> getCompensation() {
		return compensation;
	}


	public void setCompensation(List<DataGroup> compensation) {
		this.compensation = compensation;
	}


	public List<DataGroup> getTranSa() {
		return tranSa;
	}


	public void setTranSa(List<DataGroup> tranSa) {
		this.tranSa = tranSa;
	}


	public List<DataGroup> getContactDemo() {
		return contactDemo;
	}


	public void setContactDemo(List<DataGroup> contactDemo) {
		this.contactDemo = contactDemo;
	}


	public List<DataGroup> getWorkCareer() {
		return workCareer;
	}


	public void setWorkCareer(List<DataGroup> workCareer) {
		this.workCareer = workCareer;
	}


	public List<DataGroup> getEducation() {
		return education;
	}


	public void setEducation(List<DataGroup> education) {
		this.education = education;
	}


	public List<ExcelReport> getExcelreport() {
		return excelreport;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public void setExcelreport(List<ExcelReport> excelreport) {
		this.excelreport = excelreport;
	}


	public List<DataGroup> getOther() {
		return other;
	}


	public void setOther(List<DataGroup> other) {
		this.other = other;
	}
	
	
	
	
	
}
