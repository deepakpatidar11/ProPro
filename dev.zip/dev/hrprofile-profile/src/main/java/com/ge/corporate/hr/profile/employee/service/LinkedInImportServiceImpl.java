package com.ge.corporate.hr.profile.employee.service;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.net.ssl.SSLContext;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpHost;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ge.corporate.hr.profile.common.service.AbstractBaseServiceSupport;

public class LinkedInImportServiceImpl extends AbstractBaseServiceSupport implements LinkedInImportService {

	private static final Logger logger = LoggerFactory.getLogger(LinkedInImportServiceImpl.class);

	@Value("${linkedin.client.id}")
	private String clientId;

	@Value("${linkedin.client.secret}")
	private String clientSecret;

	@Value("${linkedin.url.auth}")
	private String authUrl;

	@Value("${linkedin.url.accesstoken}")
	private String accessTokenUrl;

	@Value("${linkedin.url.redirect}")
	private String redirectUrl;

	@Value("${linkedin.scope}")
	private String scope;

	@Value("${linkedin.url.data}")
	private String dataUrl;
	
	@Value("${linkedin.proxy.host}")
	private String proxyHost;
	
	@Value("${linkedin.proxy.port}")
	private int proxyPort;
	
	@Value("${linkedin.jks.passphrase}")
	private String jksPassphrase;

	@Override
	public String requestAuthCodeUrl(String state) {
		String authCodeUrl = null;
		try {
			authCodeUrl = new URIBuilder(authUrl).addParameter("response_type", "code")
					.addParameter("client_id", clientId).addParameter("redirect_uri", redirectUrl)
					.addParameter("state", state).addParameter("scope", scope).toString();
		} catch (URISyntaxException e) {
			logger.error("Unrecoverable error occured when building auth code url", e);
		}
		return authCodeUrl;
	}

	@Override
	public String recieveAccessToken(String code) {
		CloseableHttpResponse response = null;

		try (CloseableHttpClient client = getClient()) {

			HttpPost post = new HttpPost(accessTokenUrl);
			List<NameValuePair> nvps = new ArrayList<NameValuePair>();
			nvps.add(new BasicNameValuePair("grant_type", "authorization_code"));
			nvps.add(new BasicNameValuePair("code", code));
			nvps.add(new BasicNameValuePair("redirect_uri", redirectUrl));
			nvps.add(new BasicNameValuePair("client_id", clientId));
			nvps.add(new BasicNameValuePair("client_secret", clientSecret));
			post.setEntity(new UrlEncodedFormEntity(nvps));

			response = client.execute(post);
			String accessToken = null;

			accessToken = String.valueOf(
					new ObjectMapper().readValue(response.getEntity().getContent(), Map.class).get("access_token"));

			EntityUtils.consumeQuietly(response.getEntity());

			return accessToken;
		} catch (IOException e) {
			logger.error("Unrecoverable error occured when aquireing access token", e);
			return null;
		} finally {
			IOUtils.closeQuietly(response);
		}

	}

	@Override
	public String importLinkedInData(String token) {
		CloseableHttpResponse response = null;

		try (CloseableHttpClient client = getClient()) {

			HttpGet get = new HttpGet(dataUrl);
			get.addHeader(new BasicHeader("Authorization", "Bearer " + token));

			response = client.execute(get);
			String summary = null;

			Map responseBody = new ObjectMapper().readValue(response.getEntity().getContent(), Map.class);

			summary = Objects.toString(responseBody.getOrDefault("summary", responseBody.get("headline")), "");

			EntityUtils.consumeQuietly(response.getEntity());

			return summary;
		} catch (IOException e) {
			logger.error("Unrecoverable error occured when querying LinkedIn", e);
			return null;
		} finally {
			IOUtils.closeQuietly(response);
		}
	}
	
	private CloseableHttpClient getClient() throws IOException {
		try {
			SSLContext sslcontext = SSLContexts.custom()
					.loadTrustMaterial(LinkedInImportServiceImpl.class.getClassLoader().getResource("geroot.jks"),
							jksPassphrase.toCharArray(), new TrustSelfSignedStrategy())
					.build();
			SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext,
					new String[] { "TLSv1", "TLSv1.1", "TLSv1.2" }, null,
					SSLConnectionSocketFactory.getDefaultHostnameVerifier());

			HttpHost proxy = new HttpHost(proxyHost, proxyPort);

			return HttpClients.custom().setSSLSocketFactory(sslsf).setProxy(proxy).build();
		} catch (IOException | KeyManagementException | NoSuchAlgorithmException | KeyStoreException
				| CertificateException e) {
			logger.error("Unrecoverable error occured when building SSL context", e);
			throw new IOException(e);
		}
	}

}
