package com.ge.corporate.hr.profile.employee.dao;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.BonusSIT;
import com.ge.corporate.hr.profile.employee.model.Compensation;
import com.ge.corporate.hr.profile.employee.model.IncentiveCompensation;
import com.ge.corporate.hr.profile.employee.model.LongTermPerformanceAward;
import com.ge.corporate.hr.profile.employee.model.LumpCompensation;

public interface OneHrCompensationDao {
	
	
	/**
	 * Returns Compensation history data by sso 
	 * @param sso Employee SSO
	 * @return Compensation model
	 */
	public BaseModelCollection<Compensation> getOneHrCompensationHistoryBySso(Long sso);
	
	/**
	 * Returns Incentive compensation history data by sso 
	 * @param sso Employee SSO
	 * @return IncentiveList Model
	 */
	public BaseModelCollection<IncentiveCompensation> getOneHrIncentiveCompensationHistoryBySso(Long sso);
	
	public BaseModelCollection<BonusSIT> getOneHrBonusSITBySso(Long sso);
}
