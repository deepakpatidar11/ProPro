/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.serializer;
import java.io.IOException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;

public class CustomDateSerializer extends JsonSerializer<Date> {
	 private Format formatter;
	 
    @Override
    public void serialize(Date value, JsonGenerator gen, 
                          SerializerProvider arg2)
        throws IOException, JsonProcessingException {
    	
    	if(value.equals(new Date(0))){
    		gen.writeString("");
    	}else{    		
	    	formatter = new SimpleDateFormat("dd-MMM-yyyy");   
	    	gen.writeString(formatter.format(value));	    	
	    }
    }	
}
