/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
/**
 * 
 */
package com.ge.corporate.hr.profile.employee.dao;

import java.util.Date;


/**
 * @author francisco.blanco
 *
 */
public interface ScheduledDao {
	
	/**
	 * Validates that the process has not started yet, if it hasn't 
	 * then the record to register that the process has started is created
	 * @param type
	 * @return
	 */
	public boolean validateScheduledStart(String type);	
	public void removeSchedule(String type);	
	public Date getEndDateByType(String type);
	public void startSchedule(String type);
	
}
