/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import javax.xml.bind.annotation.XmlElement;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;

public class SearchCompDto extends AbstractBaseDtoSupport{
	/**
	 * 
	 */
	private static final long serialVersionUID = -103632232234856348L;
	
	public SearchCompDto() {

	}

	public SearchCompDto(Long sso, String empName, String empManagerName,
	String organization, String business, String subBusiness,
	String band, String func, String region, String country,
	String ifg, String title, String jobFamily,
	String leadershipProgram, Long empManagerSso) {
	super();
	this.sso = sso;
	this.empName = empName;
	this.empManagerName = empManagerName;
	this.organization = organization;
	this.business = business;
	this.subBusiness = subBusiness;
	this.band = band;
	this.func = func;
	this.region = region;
	this.country = country;
	this.ifg = ifg;
	this.title = title;
	this.jobFamily = jobFamily;
	this.leadershipProgram = leadershipProgram;
	this.empManagerSso = empManagerSso;
	}

	@XmlElement(name="sso")
	private Long sso;
	
	@XmlElement(name="empName")
	private String empName;
	
	@XmlElement(name="empManagerName")
	private String empManagerName;
	
	@XmlElement(name="organization")
	private String organization;
	
	@XmlElement(name="business")
	private String business;
	
	@XmlElement(name="subBusiness")
	private String subBusiness;
	
	@XmlElement(name="band")
	private String band;
	
	@XmlElement(name="func")
	private String func;
	
	@XmlElement(name="region")
	private String region;
	
	@XmlElement(name="country")
	private String country;
	
	@XmlElement(name="ifg")
	private String ifg;
	
	@XmlElement(name="title")
	private String title;

	@XmlElement(name="jobFamily")
	private String jobFamily;
	
	@XmlElement(name="leadershipProgram")
	private String leadershipProgram;
	
	@XmlElement(name="leadershipProgramType")
	private String leadershipProgramType;
	
	@XmlElement(name="empManagerSso")
	private Long empManagerSso;
	
	public Long getEmpManagerSso() {
		return empManagerSso;
	}

	public void setEmpManagerSso(Long empManagerSso) {
		this.empManagerSso = empManagerSso;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getIfg() {
		return ifg;
	}

	public void setIfg(String ifg) {
		this.ifg = ifg;
	}

	public long getId() {
		return (sso==null)?0:sso.longValue();		
	}
	
	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpManagerName() {
		return empManagerName;
	}

	public void setEmpManagerName(String empManagerName) {
		this.empManagerName = empManagerName;
	}

	public String getBusiness() {
		return business;
	}

	public void setBusiness(String business) {
		this.business = business;
	}

	public String getSubBusiness() {
		return subBusiness;
	}

	public void setSubBusiness(String subBusiness) {
		this.subBusiness = subBusiness;
	}

	public String getBand() {
		return band;
	}

	public void setBand(String band) {
		this.band = band;
	}

	public String getFunc() {
		return func;
	}

	public void setFunc(String function) {
		this.func = function;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}
	
	public String getJobFamily() {
		return jobFamily;
	}

	public void setJobFamily(String jobFamily) {
		this.jobFamily = jobFamily;
	}
	
	public String getLeadershipProgram() {
		return leadershipProgram;
	}

	public void setLeadershipProgram(String leadershipProgram) {
		this.leadershipProgram = leadershipProgram;
	}
	
	public String getLeadershipProgramType() {
		return leadershipProgramType;
	}

	public void setLeadershipProgramType(String leadershipProgramType) {
		this.leadershipProgramType = leadershipProgramType;
	}

	

}
