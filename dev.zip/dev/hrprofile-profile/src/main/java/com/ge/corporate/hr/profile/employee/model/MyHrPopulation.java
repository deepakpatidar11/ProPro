/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="myHrPopulation")
@XmlAccessorType(XmlAccessType.FIELD)
public class MyHrPopulation extends AbstractBaseModelSupport{
	
	private static final long serialVersionUID = 46981221793287345L;
	
	@XmlAttribute(name="sso")
	private Long sso; //SSO Id
	
	@XmlElement(name="first_name")
	private String first_name;

	@XmlElement(name="last_name")
	private String last_name;
	
	@XmlElement(name="full_name")
	private String full_name;

	@XmlElement(name="title")	
	private String title;
	
	@XmlElement(name="business")
	private String business;
	
	@XmlElement(name="sub_business")
	private String sub_business;
	
	@XmlElement(name="organization")	
	private String organization;

	@XmlElement(name="ffunction")	
	private String ffunction;
	
	@XmlElement(name="job_family")	
	private String job_family;
	
	@XmlElement(name="job_type")	
	private String job_type;
	
	@XmlElement(name="band")	
	private String band;
	
	@XmlElement(name="gender")	
	private String gender;
	
	@XmlElement(name="useeo")	
	private String useeo;
	
	@XmlElement(name="region")	
	private String region;
	
	@XmlElement(name="country")	
	private String country;
	
	@XmlElement(name="city")	
	private String city;
	
	@XmlElement(name="manager_sso")	
	private Long manager_sso;
	
	@XmlElement(name="manager_name")	
	private String manager_name;
	
	@XmlElement(name="hrm_sso")	
	private Long hrm_sso;
	
	@XmlElement(name="hrm_name")	
	private String hrm_name;
	
	@XmlElement(name="adjservicedate")	
	private Date adjservicedate;

	@XmlElement(name="org_start_date")	
	private Date org_start_date;
	
	@XmlElement(name="terminationdate")	
	private Date terminationdate;
	
	@XmlElement(name="currency")	
	private String currency;
	
	@XmlElement(name="legal_entity")	
	private String legal_entity;
	
	@XmlElement(name="headcount_costcenter")	
	private String headcount_costcenter;

	@XmlElement(name="rating")	
	private String rating;
	
	@XmlElement(name="salary")	
	private String salary;

	@XmlElement(name="diversity")
	private String diversity;
	
	@XmlElement(name="headcount_value")	
	private String headcount_value; 
	
	@XmlElement(name="assignment_category")	
	private String assignment_category;
	
	@XmlElement(name="assignment_status")	
	private String assignment_status;
	
	@XmlElement(name="market_type")	
	private String market_type;
	
	
	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getFull_name() {
		return full_name;
	}

	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getBusiness() {
		return business;
	}

	public void setBusiness(String business) {
		this.business = business;
	}

	public String getSub_business() {
		return sub_business;
	}

	public void setSub_business(String sub_business) {
		this.sub_business = sub_business;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getFfunction() {
		return ffunction;
	}

	public void setFfunction(String ffunction) {
		this.ffunction = ffunction;
	}

	public String getJob_family() {
		return job_family;
	}

	public void setJob_family(String job_family) {
		this.job_family = job_family;
	}

	public String getJob_type() {
		return job_type;
	}

	public void setJob_type(String job_type) {
		this.job_type = job_type;
	}

	public String getBand() {
		return band;
	}

	public void setBand(String band) {
		this.band = band;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getUseeo() {
		return useeo;
	}

	public void setUseeo(String useeo) {
		this.useeo = useeo;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Long getManager_sso() {
		return manager_sso;
	}

	public void setManager_sso(Long manager_sso) {
		this.manager_sso = manager_sso;
	}

	public String getManager_name() {
		return manager_name;
	}

	public void setManager_name(String manager_name) {
		this.manager_name = manager_name;
	}

	public Long getHrm_sso() {
		return hrm_sso;
	}

	public void setHrm_sso(Long hrm_sso) {
		this.hrm_sso = hrm_sso;
	}

	public String getHrm_name() {
		return hrm_name;
	}

	public void setHrm_name(String hrm_name) {
		this.hrm_name = hrm_name;
	}

	public Date getAdjservicedate() {
		return adjservicedate;
	}

	public void setAdjservicedate(Date adjservicedate) {
		this.adjservicedate = adjservicedate;
	}
	
	public Date getOrg_start_date() {
		return org_start_date;
	}

	public void setOrg_start_date(Date org_start_date) {
		this.org_start_date = org_start_date;
	}

	public Date getTerminationdate() {
		return terminationdate;
	}

	public void setTerminationdate(Date terminationdate) {
		this.terminationdate = terminationdate;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getLegal_entity() {
		return legal_entity;
	}

	public void setLegal_entity(String legal_entity) {
		this.legal_entity = legal_entity;
	}

	public String getHeadcount_costcenter() {
		return headcount_costcenter;
	}

	public void setHeadcount_costcenter(String headcount_costcenter) {
		this.headcount_costcenter = headcount_costcenter;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public String getDiversity() {
		return diversity;
	}

	public void setDiversity(String diversity) {
		this.diversity = diversity;
	}

	public String getHeadcount_value() {
		return headcount_value;
	}

	public void setHeadcount_value(String headcount_value) {
		this.headcount_value = headcount_value;
	}

	public String getAssignment_category() {
		return assignment_category;
	}

	public void setAssignment_category(String assignment_category) {
		this.assignment_category = assignment_category;
	}

	public String getAssignment_status() {
		return assignment_status;
	}

	public void setAssignment_status(String assignment_status) {
		this.assignment_status = assignment_status;
	}

	public String getMarket_type() {
		return market_type;
	}

	public void setMarket_type(String market_type) {
		this.market_type = market_type;
	}
	
}
