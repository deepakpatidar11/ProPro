package com.ge.corporate.hr.profile.employee.dto;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.Vector;

public class WarmupStatus implements Serializable {

	private static final long serialVersionUID = -2383183682626764384L;
	
	private String id;
	private boolean running;
	private long requestCount;
	private long successCount;
	private long failureCount;
	private Date startTime;
	private Date currentTime;
	private boolean sendDelayMail;
	private boolean readyToSendDelay;
	private boolean sentSuccess;	
	private List<Long> failedSsoList;
	private boolean readyToSendFailure;
	private boolean sentFailureMail;
	private boolean isAllSsoIndexed;
	private boolean isAllExpertiseIndexed;
	private long indexedRecords;
	private long copiedRecords;
	private List<Long> missedSsoList;
	private List<String> bulkLoadedList;
	private List<String> bulkFailedList;
	
	private static final DateFormat format = new SimpleDateFormat();

	public WarmupStatus() {
		this.id = createUniqueId();
		this.running = true;
		this.requestCount = 0;
		this.successCount = 0;
		this.failureCount = 0;
		this.startTime = new Date();
		this.currentTime = new Date();
		this.sendDelayMail = false;
		this.readyToSendDelay = false;
		this.sentSuccess = false;	
		this.sentFailureMail = false;
		this.readyToSendFailure = false;
		this.failedSsoList = new Vector<Long>();
		this.isAllSsoIndexed = false;
		this.isAllExpertiseIndexed = false;
		this.indexedRecords = 0;
		this.copiedRecords = 0;
		this.missedSsoList= new Vector<Long>();
		this.bulkLoadedList = new Vector<String>();
		this.bulkFailedList = new Vector<String>();
		
	}

	public String getId() {
		return id;
	}
	
	public String getStartTime() {
		return format.format(startTime);
	}

	private String createUniqueId() {
		UUID u = UUID.randomUUID();
		String s1 = Long.toHexString(u.getLeastSignificantBits());
		String s2 = Long.toHexString(u.getMostSignificantBits());
		return (s2+s1);
	}

	public long getRequestCount() {
		return requestCount;
	}
	public synchronized void incrementRequestCount() {
		this.currentTime = new Date();
		this.requestCount++;
	}
	public long getSuccessCount() {
		return successCount;
	}
	public synchronized void incrementSuccessCount() {
		this.currentTime = new Date();
		this.successCount++;
	}
	public long getFailureCount() {
		return failureCount;
	}
	public synchronized void incrementFailureCount() {
		this.currentTime = new Date();
		this.failureCount++;
	}
	
	public long getRuntimeSeconds() {
		return (this.currentTime.getTime() - this.startTime.getTime())/1000L;
	}
	
	public long getRequestsPerSecond() {
		
		if(this.getRuntimeSeconds() > 0 ) {
			return (this.getSuccessCount() + this.getFailureCount())/this.getRuntimeSeconds();
		}
		return 0L;
	}
	
	public boolean isRunning() {
		return running;
	}

	public synchronized void setRunning(boolean running) {
		this.running = running;
	}

	public boolean isSendDelayMail() {
		return sendDelayMail;
	}

	public void setSendDelayMail(boolean sendDelayMail) {
		this.sendDelayMail = sendDelayMail;
	}

	public boolean isReadyToSendDelay() {
		return readyToSendDelay;
	}

	public void setReadyToSendDelay(boolean readyToSendDelay) {
		this.readyToSendDelay = readyToSendDelay;
	}

	public boolean isSentSuccess() {
		return sentSuccess;
	}

	public void setSentSuccess(boolean sentSuccess) {
		this.sentSuccess = sentSuccess;
	}

	public List<Long> getFailedSsoList() {
		return failedSsoList;
	}
	
	public boolean add(Long e) {
		return failedSsoList.add(e);
	}

	public void setFailedSsoList(List<Long> failedSsoList) {
		this.failedSsoList = failedSsoList;
	}
	
	public boolean isReadyToSendFailure() {
		return readyToSendFailure;
	}

	public void setReadyToSendFailure(boolean readyToSendFailure) {
		this.readyToSendFailure = readyToSendFailure;
	}

	public boolean isSentFailureMail() {
		return sentFailureMail;
	}

	public void setSentFailureMail(boolean sentFailureMail) {
		this.sentFailureMail = sentFailureMail;
	}

	public long getIndexedRecords() {
		return indexedRecords;
	}

	public void setIndexedRecords(long indexedRecords) {
		this.indexedRecords = indexedRecords;
	}

	public long getCopiedRecords() {
		return copiedRecords;
	}

	public void setCopiedRecords(long copiedRecords) {
		this.copiedRecords = copiedRecords;
	}

	public boolean isAllSsoIndexed() {
		return isAllSsoIndexed;
	}

	public void setAllSsoIndexed(boolean isAllSsoIndexed) {
		this.isAllSsoIndexed = isAllSsoIndexed;
	}

	public boolean isAllExpertiseIndexed() {
		return isAllExpertiseIndexed;
	}
	
	public void setAllExpertiseIndexed(boolean isAllExpertiseIndexed) {
		this.isAllExpertiseIndexed = isAllExpertiseIndexed;
	}
	
	public List<Long> getMissedSsoList() {
		return missedSsoList;
	}

	public void setMissedSsoList(List<Long> missedSsoList) {
		this.missedSsoList = missedSsoList;
	}
	
	public boolean addMissedSso(Long e) {
		return missedSsoList.add(e);
	}

	public List<String> getBulkLoadedList() {
		return bulkLoadedList;
	}

	public void setBulkLoadedList(List<String> bulkLoadedList) {
		this.bulkLoadedList = bulkLoadedList;
	}
	
	public boolean addToBulkLoadedList(String e) {
		return bulkLoadedList.add(e);
	}

	public List<String> getBulkFailedList() {
		return bulkFailedList;
	}

	public void setBulkFailedList(List<String> bulkFailedList) {
		this.bulkFailedList = bulkFailedList;
	}
	
	public boolean addToFailedBulkList(String e) {
		return bulkFailedList.add(e);
	}
}