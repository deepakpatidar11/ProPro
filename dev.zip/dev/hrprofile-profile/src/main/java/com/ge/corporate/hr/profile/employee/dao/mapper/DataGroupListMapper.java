package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.dto.ExcelReport;


public class DataGroupListMapper implements RowMapper<ExcelReport> {
	
	public static final String DATA_ROLE_NAME = "ROLE_NAME";
	public static final String DATA_DATAGROUP = "DATAGROUP";
	
	
	
	
	
	public ExcelReport mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		ExcelReport report = new ExcelReport();	
		
		
		report.setRole(rs.getString(DATA_DATAGROUP));
		report.setDatagroup(rs.getString(DATA_ROLE_NAME));
		return report;		
	}
}