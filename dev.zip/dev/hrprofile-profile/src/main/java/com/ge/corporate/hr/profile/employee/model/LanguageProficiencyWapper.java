package com.ge.corporate.hr.profile.employee.model;

import java.util.List;

public class LanguageProficiencyWapper {

	private List<LanguageProficiency> languageProficiency;

	public List<LanguageProficiency> getLanguageProficiency() {
		return languageProficiency;
	}

	public void setLanguageProficiency(List<LanguageProficiency> languageProficiency) {
		this.languageProficiency = languageProficiency;
	}

}
