package com.ge.corporate.hr.profile.employee.dao;

import java.util.List;

import com.ge.corporate.hr.profile.employee.dto.OrgChartDto;
import com.ge.corporate.hr.profile.employee.dto.OrgChartDirectReportsDto;

public interface OrgChartDao {

	public List<OrgChartDirectReportsDto> getEmployeeDetailsForOrgChart(Long sso);
	public OrgChartDto getOrgChartBySSO(Long sso, boolean showCW, boolean toggleDirectReports);

}
