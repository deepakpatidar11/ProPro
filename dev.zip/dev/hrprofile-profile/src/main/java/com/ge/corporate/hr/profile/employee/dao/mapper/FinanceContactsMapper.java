package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.FinanceContacts;

public class FinanceContactsMapper implements RowMapper<FinanceContacts>{
	
	public static final String DATA_FIN_COST_EXP_SSO = "fin_cost_exp_sso";
	public static final String DATA_FIN_COST_EXP_NAME = "fin_cost_exp_name";
	public static final String DATA_BUC_ENT_STD_FLG ="buc_ent_std_flg";
	public static final String DATA_EMPLOYEE_ID = "employee_id";

	@Override
	public FinanceContacts mapRow(ResultSet rs, int rowNum) throws SQLException {
		FinanceContacts financeContacts = new FinanceContacts();
		financeContacts.setFinCostExpSso(rs.getString(DATA_FIN_COST_EXP_SSO));
		financeContacts.setFinCostExpName(rs.getString(DATA_FIN_COST_EXP_NAME));
		financeContacts.setBucEntStdFlg(rs.getString(DATA_BUC_ENT_STD_FLG));
		financeContacts.setEmployeeId(rs.getInt(DATA_EMPLOYEE_ID));

		return financeContacts;
}
}
