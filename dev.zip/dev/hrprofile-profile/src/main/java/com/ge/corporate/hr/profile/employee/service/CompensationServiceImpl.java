/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.common.service.AbstractBaseServiceSupport;
import com.ge.corporate.hr.profile.employee.dao.CompensationDao;
import com.ge.corporate.hr.profile.employee.dao.CurrencyConversionDao;
import com.ge.corporate.hr.profile.employee.dto.CompensationDto;
import com.ge.corporate.hr.profile.employee.model.BonusSIT;
import com.ge.corporate.hr.profile.employee.model.Compensation;
import com.ge.corporate.hr.profile.employee.model.Currency;
import com.ge.corporate.hr.profile.employee.model.IncentiveCompensation;
import com.ge.corporate.hr.profile.employee.model.LongTermPerformanceAward;
import com.ge.corporate.hr.profile.employee.model.RestrictedStockOptionTotals;
import com.ge.corporate.hr.profile.employee.model.StockOption;
import com.ge.corporate.hr.profile.employee.model.StockOptionTotals;
import com.ge.corporate.hr.profile.employee.service.cache.ServiceKeyGenerator;
import com.ge.corporate.hr.profile.employee.util.DateUtil;
/**
 * Performance Service 
 * @author enrique.romero
 *
 */
public class CompensationServiceImpl extends AbstractBaseServiceSupport implements CompensationService{
	private final Log logger = LogFactory.getLog(CompensationServiceImpl.class);
	
	private static final String IC_EPP = "EPP";
	private static final String IC_AEIP = "AEIP";
	
	@Resource(name = "compensationDao")
	private CompensationDao compensationDao;
	@Resource(name = "currencyDao")
	private CurrencyConversionDao currencyDao;
	
	@Cache(
			nodeName="/profile/employee/service/compensationService",
			keyGeneratorClass= ServiceKeyGenerator.class,
			cacheName=InfinispanCacheFactory.EMPSERVICECACHE
		)	
	public CompensationDto getCompensation(CompensationDto compensationDto) {
		CompensationDto compensationResDto = null;
		BaseModelCollection<Compensation> compensationList = null;
		BaseModelCollection<IncentiveCompensation> icLsit = null;	
		BaseModelCollection<BonusSIT> bonusList=null;
		BaseModelCollection<StockOption> stockOptList = null;
		BaseModelCollection<StockOption> optsOutstdngList = null;
		BaseModelCollection<StockOption> restrictedStockOptList = null;	
		BaseModelCollection<StockOption> nextVestingOptsList = null;
		BaseModelCollection<LongTermPerformanceAward> ltPerfAwardList = null;
		StockOptionTotals stockOptTotals = null;
		StockOptionTotals optsOutstdngTotals = null;
		RestrictedStockOptionTotals restctdStockOptTotals = null;
		double sum = 0;
		if(compensationDto.getSso() > 0){			
			
			compensationResDto  = new CompensationDto();
			compensationResDto.setSso(compensationDto.getSso());
			
			//Get Compensation History						
			compensationList = compensationDao.getCompensationHistoryBySso(compensationDto.getSso());
			if(compensationList == null){				
				compensationList = new BaseModelCollection<Compensation>(); //
			}
			
			//Calculate V% field
			sum = createCalculatedDataToComp((ArrayList<Compensation>)compensationList.getList(),compensationDto.getSso());			
			compensationResDto.setCompensationList(compensationList);
			
			//Get incentive Compensation
			icLsit = compensationDao.getIncentiveCompensationHistoryBySso(compensationDto.getSso());	
			if(icLsit== null){
				icLsit= new BaseModelCollection<IncentiveCompensation>(); 
			}
			
			//Calculate V% field
			sum += createCalculatedDataToIncentiveComp( (ArrayList<IncentiveCompensation>) icLsit.getList(), compensationResDto.getCurrency());			
			compensationResDto.setIcList(icLsit);
			
			//Set Total Current Compensation to DTO
			compensationResDto.setTotalCurrentComp((new Double(sum)).longValue());
			
			//Get Stock Options			
			stockOptList = compensationDao.getStockOptionsBySso(compensationDto.getSso());			
			if(stockOptList== null){
				stockOptList= new BaseModelCollection<StockOption>(); 
			}
			compensationResDto.setStockOptList(stockOptList);
			
			//Get Options Outstanding	
			optsOutstdngList = compensationDao.getOptionsOutstandingBySso(compensationDto.getSso());			
			if(optsOutstdngList== null){
				optsOutstdngList= new BaseModelCollection<StockOption>(); 
			}
			
			compensationResDto.setOptsOutstdngList(optsOutstdngList);
			
			//Get Stock Option totals
			stockOptTotals = CalulateTotalStockOptions(stockOptList);
			if(stockOptTotals== null){
				stockOptTotals= new StockOptionTotals(); 
			}
			compensationResDto.setStockOptionTotals(stockOptTotals);
			
			//Get Stock Option totals
			optsOutstdngTotals = CalulateTotalOutstdng(optsOutstdngList);
			if(optsOutstdngTotals== null){
				optsOutstdngTotals= new StockOptionTotals(); 
			}
			compensationResDto.setOptsOutstdngTotals(optsOutstdngTotals);
			
			//
			bonusList=compensationDao.getBonusSITBySso(compensationDto.getSso());
			compensationResDto.setBonusList(bonusList);
			//Get Restricted Stock Options			
			restrictedStockOptList = compensationDao.getRestrictedStockOptionsBySso(compensationDto.getSso());
			if(restrictedStockOptList== null){
				restrictedStockOptList= new BaseModelCollection<StockOption>(); 
			}			
			compensationResDto.setRestrictedStockOptList(restrictedStockOptList);
			
			//Get Next Vesting Options			
			nextVestingOptsList = compensationDao.getNextVestingOptionsBySso(compensationDto.getSso());
			if(nextVestingOptsList== null){
				nextVestingOptsList= new BaseModelCollection<StockOption>(); 
			}			
			compensationResDto.setNextVestingOptList(nextVestingOptsList);
			
			//Get Restricted Stock Option totals
			restctdStockOptTotals = compensationDao.getRestrictedStockOptionTotalBySso(compensationDto.getSso());
			if(restctdStockOptTotals== null){
				restctdStockOptTotals= new RestrictedStockOptionTotals(); 
			}
			compensationResDto.setRestrctdStockOptTotals(restctdStockOptTotals);
			
			ltPerfAwardList = compensationDao.getLongTermPerformanceAwardsBySso(compensationDto.getSso());
			if(ltPerfAwardList== null){
				ltPerfAwardList= new BaseModelCollection<LongTermPerformanceAward>(); 
			}	
			//Get Long Term Performance Award info
			compensationResDto.setLtPerformanceAwardList(ltPerfAwardList);
			
			//Get Currency Conversion
			compensationResDto.setTotalCurrentCompConverted( getCurrencyConversion(compensationResDto) );
			
		}else{
			logger.error("Invalid SSO, SSO = " + compensationDto.getSso());
		}
		return compensationResDto;		
	}	
	
	/**
	 * Calculate all calculated fields for Compensation, set interval value for each compensation
	 * 	Set Lump value to compensation that belongs to.
	 * 
	 *  Rules for Total Current Cash Comp:
	 *   a) Total Current Cash Comp = most current (not future dated) salary 
     *		+ last IC amout from current or previous 2 years (currently that would be 2012 or 2011 or 2010) 
     *		+ most current (not future dated) lump sum from current or previous year (ignore negative lump sums though)
     *
	 *  Rules for V%
	 *  	a) the V% is based in the previous Compensation that is not Lump
	 *  	b) The V% For lump should be N/A 
	 *    
	 *	Rules for Interval:
	 *		a ) Calculates diference beteewn line and its previous one depending the date 
	 *
	 * @param compeList
	 * @return Lump sum plus Latest salary
	 */
	private double createCalculatedDataToComp(Collection<Compensation> compList, Long sso){		
		double lumpSum = 0;
		double latestSalary = 0;	
		String lumpCurrency = "";
		String salaryCurrency = "";
		
		if(compList != null){			
			//Calculate Interval Field		
			//Interval = #month between current line date and previous line date (rounded)
			Compensation previousComp = null;	
			
			for(Compensation comp:compList ){		
				//if compensation is lump then percentage should be N/A (null)
				if(comp.isLump()){				
					comp.setChangePercent(null);
				}
				
				if(comp.isLump()){
					int currYear = DateUtil.getYear(new Date());
					int lumpYear = DateUtil.getYear(comp.getEfectiveDate());
					// include lump to "Total Cash Comp" :most current (not future dated) lump sum from current or previous year (ignore negative lump sums though)				
					if( comp.getLumpAmmount()>0 
							&& (lumpYear == currYear || lumpYear == (currYear-1))){			
						lumpSum += comp.getLumpAmmount();
						lumpCurrency = comp.getCurrency();
					}
				}
				if(previousComp!=null)
				{	
					try{
						if(latestSalary == 0 && !comp.isFutureDate() && !comp.isLump()){
							latestSalary = comp.getSalary();	
							salaryCurrency = comp.getCurrency();
						}					
						if(previousComp.getEfectiveDate() != null && comp.getEfectiveDate() != null ){
							if(comp.getSalary()!= 0){
								if(previousComp.getCurrency().equals(comp.getCurrency()))
								{
									double value = ((previousComp.getSalary().doubleValue()/ comp.getSalary().doubleValue())-1)*100;							
									previousComp.setChangePercent(value);
								}else{
									//If currency changes ... Don't calculate V% 
									previousComp.setChangePercent(null);
								}
							}						
						}
					}catch(NullPointerException e){
						logger.debug("Null pointer exception has been thrown in 'Calculates V%' process in method createCalculatedDataToComp");
					}
				}else{
					//Set Lastest Salary;
					if(!comp.isFutureDate() && !comp.isLump()){						
						latestSalary = comp.getSalary();
						salaryCurrency = comp.getCurrency();
					}					
				}				
				//if comp is not lump
				if(!comp.isLump()){
					previousComp = comp;
				}
			}	
			List<Compensation> lumpComList = new ArrayList<Compensation>();
			
			////////////////////////////////////////////
			//Calculates Interval And Repeat the previous base salary on the lump line
			///////////////////////////////////////////
			for(Compensation comp:compList ){
				
				//Repeat the previous base salary on the lump line
				if(comp.isLump()){
					lumpComList.add(comp);
				}else{					
					for(Compensation lumpComp:lumpComList){
						lumpComp.setSalary(comp.getSalary());
					}
					lumpComList.clear();
				}
				
				//Calculates Interval
				if(previousComp!=null)
				{			
					try{
						if(previousComp.getEfectiveDate() != null && comp.getEfectiveDate() != null ){					
							Double d;
							Long inteval;
							//Calculates interval
							d = DateUtil.monthsBetween(
									previousComp.getEfectiveDate(), comp.getEfectiveDate());
							inteval = Math.round(d);
							previousComp.setInterval(inteval.shortValue());
						}	
					}catch(NullPointerException e){
						logger.debug("Null pointer exception has been thrown in 'Calculates Interval' process ");
					}
				}				
				previousComp = comp;				
			}			
		}
		
		if(lumpCurrency!=null && salaryCurrency!=null && !lumpCurrency.equalsIgnoreCase("") && !salaryCurrency.equalsIgnoreCase("") && !lumpCurrency.equalsIgnoreCase(salaryCurrency)){
			lumpSum = (lumpSum * currencyDao.getCurrency(lumpCurrency, "USD").getAmmountConverted().doubleValue())/currencyDao.getCurrency(salaryCurrency, "USD").getAmmountConverted().doubleValue();
		}
		
		return lumpSum + latestSalary;
	}
	
	/**
	 * Create Calculated data to Incentive Compensation
	 * 
	 * 	Rules For Calculate V%
	 * 		a)	If type = EPP the V% = N/A
	 * 		b)	If IC is the last then V% = N/A
	 * 		c)  the IC V% ... calcuate that based on the previous IC amount ... 
	 *		��� 	so compare 2010 IC to 2009 IC ...�� 370000 vs. 330000 
	 * 
	 * 	Rules for Return the IC value that will be added to Total Current Compensation Sum:
	 * 		a)   The value should be the most current compensation that year date is current or last year (Current Year - 1):
	 * 		b)   IC type should not be  EPP
	 * 		c)	 IC should not be future date. 
	 *  
	 *  Rules for incentive compensation type = EPP
	 * 			a) always have IC be above EPP in the same year 
	 *			b) never use EPP when calculating "Total Current Cash Comp" ...
	 *			��� Total Current Cash Comp shows 475000 right now ... but it should show 770000 (400000 + 370000) 
	 *			c) for EPP lines ... don't show V% ... show "N/A" instead
	 *
	 *	
	 * @param incentCompList
	 * @return latest IC
	 */
	private double createCalculatedDataToIncentiveComp(Collection<IncentiveCompensation> incentCompList, String salaryCurrency){
		
		IncentiveCompensation beforeIncentComp = null;
		double latestICAmount = 0;
		String icCurrency = "";
		if(incentCompList != null){
			
			for(IncentiveCompensation comp:incentCompList ){				
				//Calculating IC Total Current Compensation Value
				if(latestICAmount == 0 && !comp.isFutureDate()){
					if(comp.getType() == null || !comp.getType().equals(IC_EPP)){
						int currYear = DateUtil.getYear(new Date());
						int icYear = comp.getPerfYear();						
						if(icYear == currYear || icYear == (currYear-1) || icYear == (currYear-2)){					
							latestICAmount = comp.getAmount();
							icCurrency = comp.getCurrency();
						}
					}
				}				
				
				if(beforeIncentComp!=null)
				{	
					try{
						//Calculates V% field
						//V% = ((current year value / previous year value) - 1 ) * 100		
						if(comp.getAmount()!= null && comp.getAmount() != 0){
							if(beforeIncentComp.getCurrency() != null && beforeIncentComp.getCurrency().equals(comp.getCurrency())){
								double value = ((beforeIncentComp.getAmount().doubleValue()/ comp.getAmount().doubleValue())-1)*100;					
								beforeIncentComp.setChangePercent(value);
							}else{
								//If currency changes ... Don't calculate V% 
								beforeIncentComp.setChangePercent(null);
							}						
						}					
					}catch(NullPointerException e){
						logger.debug("Null pointer exception has been thrown in 'Calculating V% field' ");
					}					
				}
								 
				if(comp.getType() == null || !comp.getType().equals(IC_EPP)){	
					// this help to calculate V% 
					// the IC V% ... calcuate that based on the previous IC amount
					beforeIncentComp = comp; 
				}else{
					//Show "N/A" for Lines with Type = EPP					
					comp.setChangePercent(null);					
				}				
			}
		}
		
		if(icCurrency!=null && salaryCurrency!=null && !icCurrency.equalsIgnoreCase("") && !salaryCurrency.equalsIgnoreCase("") && !icCurrency.equalsIgnoreCase(salaryCurrency)){
			latestICAmount = (latestICAmount * currencyDao.getCurrency(icCurrency, "USD").getAmmountConverted().doubleValue())/currencyDao.getCurrency(salaryCurrency, "USD").getAmmountConverted().doubleValue();
		}

		return latestICAmount;
	}
	
	/**
	 * Calculates Total Stock options
	 * @param stockOptList
	 * @return
	 */
	private StockOptionTotals CalulateTotalStockOptions(BaseModelCollection<StockOption> stockOptList){
		StockOptionTotals stockOptTotals = null;
		
		if(stockOptList != null){
			stockOptTotals = new StockOptionTotals();			
			for(StockOption so : stockOptList.getList()){
				stockOptTotals.setNumShares((so.getNumShares()==null?0:so.getNumShares())
								+ (stockOptTotals.getNumShares()==null?0:stockOptTotals.getNumShares()));				
			}				
		}
		return stockOptTotals;
	}
	
	/**
	 * Calculates Total Outstanding 
	 * @param optsOutstdngList
	 * @return
	 */
	private StockOptionTotals CalulateTotalOutstdng(BaseModelCollection<StockOption> optsOutstdngList){
		StockOptionTotals stockOptTotals = null;
	
		if(optsOutstdngList!= null){
			stockOptTotals = new StockOptionTotals();		
	
			for(StockOption ol : optsOutstdngList.getList()){
				stockOptTotals.setExercided((ol.getExercised()==null?0:ol.getExercised())  
								+ (stockOptTotals.getExercided()==null?0:stockOptTotals.getExercided()));
				stockOptTotals.setTotal((ol.getTotal()==null?0:ol.getTotal())
								+ (stockOptTotals.getTotal()==null?0:stockOptTotals.getTotal()));
				stockOptTotals.setSharedVested((ol.getSharedVested()==null?0:ol.getSharedVested())
								+ (stockOptTotals.getSharedVested()==null?0:stockOptTotals.getSharedVested()));
				stockOptTotals.setSharedUnvested((ol.getSharedUnvested()==null?0:ol.getSharedUnvested())
						+ (stockOptTotals.getSharedUnvested()==null?0:stockOptTotals.getSharedUnvested()));
			}				
		}			
		return stockOptTotals;
	}
	/**
	 * Get Conversion Rate and calculate total
	 * @param compensationDto
	 */
	private Long getCurrencyConversion(CompensationDto compensationDto){
		
		Long totalConvertedAmmount = null;
		
		if(compensationDto != null && compensationDto.getCurrency() != null && !compensationDto.getCurrency().equals("USD")){
			Currency currency = currencyDao.getCurrency(compensationDto.getCurrency(), "USD");
			
			if(currency != null){
				totalConvertedAmmount = (new Double(compensationDto.getTotalCurrentComp() * currency.getAmmountConverted())).longValue();
			}
		}		
		return totalConvertedAmmount;
	}
}
