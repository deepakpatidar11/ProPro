/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import java.util.List;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dto.CountryRegionDto;
import com.ge.corporate.hr.profile.employee.dto.EmployeeHistoryDto;
import com.ge.corporate.hr.profile.employee.model.CareerAspiration;
import com.ge.corporate.hr.profile.employee.model.CustomerandSuppliers;
import com.ge.corporate.hr.profile.employee.model.EmployeeHistory;
import com.ge.corporate.hr.profile.employee.model.IntiativesandProject;
import com.ge.corporate.hr.profile.employee.model.WorkMobility;

public interface EmployeeHistoryDao {

	public BaseModelCollection<EmployeeHistory> getEmployeeHistoryBySso(Long sso);
	public BaseModelCollection<EmployeeHistory> getEmployeeHistoryForRoleSelf(Long sso);
	public BaseModelCollection<EmployeeHistory> getEmployeeHistoryOptinBySso(Long sso, boolean isSelf, boolean hasDataGroup);
	public BaseModelCollection<EmployeeHistory> getEmployeeHistoryAllBySso(Long sso, boolean isSelf, boolean hasDataGroup);
	public BaseModelCollection<IntiativesandProject> getIntiativesAndProject(Long sso);
	public BaseModelCollection<CustomerandSuppliers> getCustomerAndSuppiler(Long sso);
	public void updateIntiativesAndProject(Long sso, EmployeeHistoryDto employeeHistory);
	public void updateCustomerSuppliers(Long sso, EmployeeHistoryDto employeeHistory);
	public boolean setCareerAspiration(Long sso, String goalCombined);
	public CareerAspiration getCareerAspiration(Long sso);
	public boolean saveEmploymentHistory(Long sso, List<EmployeeHistory> empHistory);
	public boolean saveCurrentJob(Long sso, EmployeeHistory currentJob);
	public WorkMobility getWorkMobility(Long sso);
	public List<String> getSelectedCountries(Long sso);
	public boolean setWorkMobility(Long sso, WorkMobility workMobility);
	public boolean updateEmpistoryAlertFlagBySSO(Long sso);
	public boolean setCareerOpportunity(Long sso, String careerOppFlag);
	public String getCareerOpportunity(Long sso);
}
