/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.service;

import java.io.IOException;
import java.util.List;

import org.apache.commons.httpclient.ProxyHost;

import com.ge.corporate.hr.profile.employee.dto.CurrencyDto;

public interface CurrencyConversionService {
	
	public void setURL(String url) throws IOException;
	
	public void setCharset(String charset);
	
	public void setProxy(ProxyHost proxy);
	
	public void setProxy(String host, int port);
	
	/**
	 * Converts a currency to a specified one.
	 *  
	 * @param currentCurrency
	 * @param ammount
	 * @param newCurreny
	 * @return
	 */
	public CurrencyDto getCurrency(String currentCurrency, Long ammount, String newCurreny);
	
	public List<CurrencyDto> getCurrency();
	
}
