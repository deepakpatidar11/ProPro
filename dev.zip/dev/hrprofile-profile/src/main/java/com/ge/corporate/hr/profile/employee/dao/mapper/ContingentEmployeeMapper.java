package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.ContingentEmployee;


public class ContingentEmployeeMapper implements RowMapper<ContingentEmployee> {

	
	public static final String DATA_SSO = "sso";
	public static final String DATA_FIRST_NAME = "emp_first_name";
	public static final String DATA_LAST_NAME = "emp_last_name";
	public static final String DATA_FULL_NAME = "emp_full_name";
	public static final String DATA_KNOWNS_AS = "emp_known_as";
	public static final String DATA_ADDRESS = "emp_address";
	public static final String DATA_CITY = "emp_city";
	public static final String DATA_STATE = "emp_state";
	public static final String DATA_COUNTRY = "emp_country";
	public static final String DATA_ZIP = "emp_zip";
	public static final String DATA_FAX = "emp_fax";
	public static final String DATA_EMAIL = "emp_email";
	public static final String DATA_WORK_PHONE = "emp_work_phone";
	public static final String DATA_MOBILE = "emp_mobile";
	public static final String DATA_DCOMM = "emp_dcomm";
	public static final String DATA_MAILSTOP = "emp_mailstop";
	public static final String DATA_INTERNAL_LOCATION = "emp_internal_location";

	
	
	public ContingentEmployee mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		
		ContingentEmployee contingentEmployee = new ContingentEmployee();
		
		contingentEmployee.setSso(rs.getLong(DATA_SSO));
		contingentEmployee.setAddress(rs.getString(DATA_ADDRESS));	
		contingentEmployee.setCity(rs.getString(DATA_CITY));
		contingentEmployee.setState(rs.getString(DATA_STATE));
		contingentEmployee.setCountry(rs.getString(DATA_COUNTRY));
		contingentEmployee.setZip(rs.getString(DATA_ZIP));
		contingentEmployee.setDcomm(rs.getString(DATA_DCOMM));		
		contingentEmployee.setEmail(rs.getString(DATA_EMAIL));
		contingentEmployee.setFax(rs.getString(DATA_FAX));
		contingentEmployee.setFirstName(rs.getString(DATA_FIRST_NAME));
		contingentEmployee.setFullName(rs.getString(DATA_FULL_NAME));
		contingentEmployee.setKnownAs(rs.getString(DATA_KNOWNS_AS));
		contingentEmployee.setLastName(rs.getString(DATA_LAST_NAME));
		contingentEmployee.setMobile(rs.getString(DATA_MOBILE));		
		contingentEmployee.setPhone(rs.getString(DATA_WORK_PHONE));
		contingentEmployee.setMailstop(rs.getString(DATA_MAILSTOP));
		contingentEmployee.setInternalLocation(rs.getString(DATA_INTERNAL_LOCATION));

			
		return contingentEmployee;
	}

}
