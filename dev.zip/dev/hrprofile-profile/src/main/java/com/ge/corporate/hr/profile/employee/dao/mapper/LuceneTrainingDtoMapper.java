package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.dto.LuceneTrainingDto;

public class LuceneTrainingDtoMapper implements RowMapper<LuceneTrainingDto> {

	public static final String DATA_SSO ="sso";
	public static final String DATA_ID = "trn_id";
	public static final String DATA_DESC = "trcat_description";
	public static final String DATA_SHARED ="shared";
	@Override
	public LuceneTrainingDto mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		LuceneTrainingDto trng = new LuceneTrainingDto();
		trng.setSharedFlag(rs.getString(DATA_SHARED));
		trng.setSso(rs.getLong(DATA_SSO));
		trng.setTrngDescriptiom(rs.getString(DATA_DESC));
		trng.setTrngID(rs.getString(DATA_ID));
		return trng;
	}

	

}
