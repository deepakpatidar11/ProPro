package com.ge.corporate.hr.profile.employee.model;


import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="myOrgMgrClientsFlexiGrid")
@XmlAccessorType(XmlAccessType.FIELD)
public class MyOrgMgrClientFlexiGrid extends AbstractBaseModelSupport{
	
	private static final long serialVersionUID = 46981221793287345L;
	
	@XmlAttribute(name="sso")
	private Long sso; //SSO Id
	
	@XmlElement(name="total")
	private int total;
	
	@XmlElement(name="page")
	private int page;
	
	@XmlElement(name="role")
	private String role;

	@XmlElement(name="relType")
	private List<String> relType;
	
	@XmlElement(name="selectedRelType")
	private List<String> selectedRelType;
	
	@XmlElement(name="headcount")
	private double headcount;
	
	@XmlElement(name="pagesize")
	private int pagesize;
	
	@XmlElement(name="records")
	private int records;

	@XmlElement(name="locale")
	private Locale locale;
	
	@XmlElement(name="format")
	private String format;

	@XmlElement(name="rows")
	private ArrayList<HrPopulationFlexiGridColModel> rows;
	
	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public List<String> getRelType() {
		return relType;
	}

	public void setRelType(List<String> relType) {
		this.relType = relType;
	}

	public List<String> getSelectedRelType() {
		return selectedRelType;
	}

	public void setSelectedRelType(List<String> selectedRelType) {
		this.selectedRelType = selectedRelType;
	}

	public double getHeadcount() {
		return headcount;
	}

	public void setHeadcount(double headcount) {
		this.headcount = headcount;
	}

	public int getPagesize() {
		return pagesize;
	}

	public void setPagesize(int pagesize) {
		this.pagesize = pagesize;
	}

	public int getRecords() {
		return records;
	}

	public void setRecords(int records) {
		this.records = records;
	}

	public Locale getLocale() {
		return locale;
	}

	public void setLocale(Locale locale) {
		this.locale = locale;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public ArrayList<HrPopulationFlexiGridColModel> getRows() {
		return rows;
	}

	public void setRows(ArrayList<HrPopulationFlexiGridColModel> rows) {
		this.rows = rows;
	}

	
}
