package com.ge.corporate.hr.profile.employee.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class OrgChartDirectReportsDto {

	@XmlElement(name = "sso")
	private Long sso;

	@XmlElement(name = "firstName")
	private String firstName;

	@XmlElement(name = "lastName")
	private String lastName;

	@XmlElement(name = "title")
	private String title;

	@XmlElement(name = "managerSso")
	private Long managerSso;

	@XmlElement(name = "isContingentWorker")
	private String isContingentWorker;

	@XmlElement(name = "ifg")
	private String ifg;

	@XmlElement(name = "business")
	private String business;
	
	@XmlElement(name = "isLongTermSuspend")
	private String isLongTermSuspend;

	private Integer orgLevel;

	private List<DirectReportsDto> directReports;

	public OrgChartDirectReportsDto(Long sso, String firstName,
			String lastName, String title, Long managerSso,
			List<DirectReportsDto> directReports, Integer orgLevel,
			String isContingentWorker, String ifg, String business, String isLongTermSuspend) {
		super();
		this.sso = sso;
		this.firstName = firstName;
		this.lastName = lastName;
		this.title = title;
		this.managerSso = managerSso;
		this.directReports = directReports;
		this.orgLevel = orgLevel;
		this.isContingentWorker = isContingentWorker;
		this.ifg = ifg;
		this.business = business;
		this.isLongTermSuspend = isLongTermSuspend;
	}

	public String getIsContingentWorker() {
		return isContingentWorker;
	}

	public void setIsContingentWorker(String isContingentWorker) {
		this.isContingentWorker = isContingentWorker;
	}

	public Integer getOrgLevel() {
		return orgLevel;
	}

	public void setOrgLevel(Integer orgLevel) {
		this.orgLevel = orgLevel;
	}

	public OrgChartDirectReportsDto() {
		// TODO Auto-generated constructor stub
	}

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Long getManagerSso() {
		return managerSso;
	}

	public void setManagerSso(Long managerSso) {
		this.managerSso = managerSso;
	}

	public List<DirectReportsDto> getDirectReports() {
		return directReports;
	}

	public void setDirectReports(List<DirectReportsDto> directReports) {
		this.directReports = directReports;
	}

	public String getIfg() {
		return ifg;
	}

	public void setIfg(String ifg) {
		this.ifg = ifg;
	}

	public String getBusiness() {
		return business;
	}

	public void setBusiness(String business) {
		this.business = business;
	}

	public String getIsLongTermSuspend() {
		return isLongTermSuspend;
	}

	public void setIsLongTermSuspend(String isLongTermSuspend) {
		this.isLongTermSuspend = isLongTermSuspend;
	}


	
}
