package com.ge.corporate.hr.profile.employee.model;

public class EducationUniversity {

	private String id;
	
	private String university;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUniversity() {
		return university;
	}

	public void setUniversity(String university) {
		this.university = university;
	}
	
}
