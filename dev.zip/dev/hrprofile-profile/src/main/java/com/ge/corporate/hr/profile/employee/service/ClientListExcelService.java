package com.ge.corporate.hr.profile.employee.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ge.corporate.hr.profile.employee.dto.AssignmentDto;
import com.ge.corporate.hr.profile.employee.dto.ExcelReport;
import com.ge.corporate.hr.profile.employee.dto.MyCWPopulationDto;
import com.ge.corporate.hr.profile.employee.dto.MyHrPopulationDto;
import com.ge.corporate.hr.profile.employee.dto.MyReportsDto;

public interface ClientListExcelService 
{
	public MyHrPopulationDto getMyHrPopulation(MyHrPopulationDto myHrPopulationDtoPar,List<String> roles, String param, int start, int limit, String sortName, String sortOrder, boolean isSuspended);
	public List<String> getMyHrPopulationRoles(Long sso);
	public MyHrPopulationDto getMyHrPopulationOthers(MyHrPopulationDto myHrPopulationDtoPar,String roles, String param, int start, int limit, String sortName, String sortOrder, String type);
	public String getFullName(Long sso);
	public MyHrPopulationDto getMyHrPopulationExcel(MyHrPopulationDto myHrPopulationDtoPar,List<String> roles, String param, int start, int limit, String sortName, String sortOrder, boolean isSuspended);
	public MyHrPopulationDto getMyOrgMgrClientListService(MyHrPopulationDto myHrPopulationDto, List<String> rel_types, String param, int start, int limit, String sortName, String sortOrder, boolean isSuspended);
	public MyHrPopulationDto getMyOrgMgrClientListExcelService(MyHrPopulationDto myHrPopulationDto, List<String> rel_types, String param, int start, int limit, String sortName, String sortOrder, boolean isSuspended);
	public MyCWPopulationDto getMyCWPopulation(MyCWPopulationDto myCWPopulationDtoPar, List<String> roles, List<String> rel_types, String param, int start, int limit, String sortName, String sortOrder, List<String> subpersontype);
	public List<ExcelReport>  getDataGroupReport(List<ExcelReport>  dataGroup,String type);
	
}

