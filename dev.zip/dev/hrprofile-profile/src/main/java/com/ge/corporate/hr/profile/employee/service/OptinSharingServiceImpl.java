/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.service;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ge.corporate.hr.profile.common.service.AbstractBaseServiceSupport;
import com.ge.corporate.hr.profile.employee.dao.OptinSharingDao;
import com.ge.corporate.hr.profile.employee.model.OptinSharing;
import com.ge.corporate.hr.profile.employee.model.Property;
import com.itextpdf.text.pdf.PdfStructTreeController.returnType;

/**
 * Performance Service
 * 
 * @author enrique.romero
 * 
 */
public class OptinSharingServiceImpl extends AbstractBaseServiceSupport
		implements OptinSharingService {
	private final Log logger = LogFactory.getLog(OptinSharingServiceImpl.class);

	@Resource(name = "optinSharingDao")
	private OptinSharingDao optinSharingDao;

	public boolean setOptinSharing(Long principal, String type,
			String value) {
		return optinSharingDao.setOptinSharingDao(principal, type, value);
	}
	
	public boolean hasOptinServiceAcess(Long sso, String column){
		return optinSharingDao.hasOptinServiceAcess(sso, column);
	}
	
	public List<String> optinTrainingListBySSO(Long sso){
		return optinSharingDao.optinTrainingListBySSO(sso);
	}
	
	public List<String> allTrainingListBySSO(Long sso){
		return optinSharingDao.allTrainingListBySSO(sso);
	}
	
	public boolean setTrainingListBySSO(Long principal, String training, boolean delete){
		return optinSharingDao.setTrainingListBySSO(principal, training, delete);
	}
	
	public OptinSharing getOptinSharing(Long sso) {
		return optinSharingDao.getOptinSharingDao(sso);
	}

	public OptinSharingDao getOptinSharingDao() {
		return optinSharingDao;
	}

	public void setOptinSharingDao(OptinSharingDao optinSharingDao) {
		this.optinSharingDao = optinSharingDao;
	}

	@Override
	public List<Property> getSharedTrainingList(Long sso) {
		return optinSharingDao.getSharedTrainingList(sso);
	}

	@Override
	public boolean updateOptinSharing(OptinSharing optinSharing) {
		boolean status = false;
		if (optinSharing!=null) {
			status = optinSharingDao.updateOptinSharing(optinSharing);
			status = status && optinSharingDao.delOptinSharingTrnListBySso(optinSharing.getSso());
			status = status && optinSharingDao.insertOptinSharing(optinSharing);
		}		
		return status;
	}
	
}
