/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.security.access.prepost.PreAuthorize;

import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;
import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dao.mapper.PerformanceMapper;
import com.ge.corporate.hr.profile.employee.model.Performance;
import com.ge.corporate.hr.profile.employee.service.cache.DaoKeyGenerator;

/**
 * Performance Dao implementation
 * @author enrique.romero
 *
 */
public class PerformanceDaoImpl extends AbstractBaseDaoSupport  implements PerformanceDao {
	private static Log logger = LogFactory.getLog(PerformanceDaoImpl.class);
	
	@Cache(nodeName="/profile/employee/dao/performance", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'Performance', read)")
	public BaseModelCollection<Performance> getPerformanceBySso(Long sso) {
		//		
		final BaseModelCollection<Performance> performance = new BaseModelCollection<Performance>();
		String query = this.getSql("getPerformanceBySso");		
		try{
			performance.getList().addAll(getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new PerformanceMapper()));			
			logger.debug("Performance data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Performance Not found");
		}				
		return performance;
	}
}
