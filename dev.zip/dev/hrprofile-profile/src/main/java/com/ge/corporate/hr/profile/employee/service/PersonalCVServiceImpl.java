/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.service;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.common.service.AbstractBaseServiceSupport;
import com.ge.corporate.hr.profile.employee.dao.EducationDao;
import com.ge.corporate.hr.profile.employee.dao.EmergencyContactDao;
import com.ge.corporate.hr.profile.employee.dao.EmployeeDao;
import com.ge.corporate.hr.profile.employee.dao.LanguageDao;
import com.ge.corporate.hr.profile.employee.dao.ProgramDao;
import com.ge.corporate.hr.profile.employee.dao.TrainingDao;
import com.ge.corporate.hr.profile.employee.dao.WorkAssignmentDao;
import com.ge.corporate.hr.profile.employee.dto.ContactsDemographicsDto;
import com.ge.corporate.hr.profile.employee.dto.EducationCatalogs;
import com.ge.corporate.hr.profile.employee.dto.EducationDto;
import com.ge.corporate.hr.profile.employee.dto.EducationTrainingDto;
import com.ge.corporate.hr.profile.employee.dto.PersonalCVDto;
import com.ge.corporate.hr.profile.employee.dto.TrainingDto;
import com.ge.corporate.hr.profile.employee.model.CAS;
import com.ge.corporate.hr.profile.employee.model.Certification;
import com.ge.corporate.hr.profile.employee.model.Education;
import com.ge.corporate.hr.profile.employee.model.EducationCountry;
import com.ge.corporate.hr.profile.employee.model.EducationUniversity;
import com.ge.corporate.hr.profile.employee.model.EmergencyContact;
import com.ge.corporate.hr.profile.employee.model.EmployeeRestricted;
import com.ge.corporate.hr.profile.employee.model.HomeAddress;
import com.ge.corporate.hr.profile.employee.model.LanguageProficiency;
import com.ge.corporate.hr.profile.employee.model.OptinSharing;
import com.ge.corporate.hr.profile.employee.model.Program;
import com.ge.corporate.hr.profile.employee.model.ProgramHeader;
import com.ge.corporate.hr.profile.employee.model.ServiceDates;
import com.ge.corporate.hr.profile.employee.model.SixSigma;
import com.ge.corporate.hr.profile.employee.model.Training;
import com.ge.corporate.hr.profile.employee.model.TrainingHeader;
import com.ge.corporate.hr.profile.employee.service.cache.ServiceKeyGenerator;

public class PersonalCVServiceImpl extends AbstractBaseServiceSupport implements PersonalCVService{
	private final Log logger = LogFactory.getLog(WorkAssignmentServiceImpl.class);
	
	@Resource(name = "employeeDao")
	private EmployeeDao employeeDao;
	
	@Resource(name = "emergencyContactDao")
	private EmergencyContactDao emergencyContactDao;
	
	@Resource(name = "educationDao")
	private EducationDao educationDao;
	
	@Resource(name = "programDao")
	private ProgramDao programDao;
	
	@Resource(name = "trainingDao")
	private TrainingDao trainingDao;
		
	@Resource(name = "languageDao")
	private LanguageDao languageDao;

	@Resource(name = "workAssignmentDao")
	private WorkAssignmentDao assignmentDao;
		
	@Cache(
			nodeName="/profile/employee/service/personalCVService",
			keyGeneratorClass=ServiceKeyGenerator.class,
			cacheName=InfinispanCacheFactory.EMPSERVICECACHE	
	)	
	public PersonalCVDto getDemographics(PersonalCVDto personalCVDto) {
		PersonalCVDto workPersonalCVDto = null;
		
		//Set employee information to PersonalCVDto
		if(personalCVDto.getSso() > 0){
			EmployeeRestricted empRestricted = null;
			EmployeeRestricted genderCitizenship = null;			
			EmployeeRestricted disabilitySelfId = null;
			EmployeeRestricted glbtSelfId = null;
			
			workPersonalCVDto = new PersonalCVDto();					
			workPersonalCVDto.setSso(personalCVDto.getSso());
						
			empRestricted = employeeDao.getEmployeeRestrictedBySso(personalCVDto.getSso());
			if(empRestricted == null){
				empRestricted = new EmployeeRestricted();
			}
			genderCitizenship = employeeDao.getGenderCitizenshipBySso(personalCVDto.getSso());
			if(genderCitizenship == null){
				genderCitizenship = new EmployeeRestricted();
			}
			
			disabilitySelfId = employeeDao.getDisabilityIdBySso(personalCVDto.getSso());
			if(disabilitySelfId == null){
				disabilitySelfId = new EmployeeRestricted();
			}
			
			glbtSelfId = employeeDao.getGLBTSelfIdBySso(personalCVDto.getSso());
			if(glbtSelfId == null){
				glbtSelfId = new EmployeeRestricted();
			}
				
			workPersonalCVDto.setPerInfoRestricted(empRestricted);
			workPersonalCVDto.setGenderCitizenship(genderCitizenship);
			workPersonalCVDto.setDisabilitySelfId(disabilitySelfId);
			workPersonalCVDto.setGlbtSelfId(glbtSelfId);
			
		}else{
			logger.error("Invalid SSO, SSO = " + personalCVDto.getSso());
		}		
		return workPersonalCVDto;
	}
	
	@Cache(
			nodeName="/profile/employee/service/personalCVService",
			keyGeneratorClass=ServiceKeyGenerator.class,
			cacheName=InfinispanCacheFactory.EMPSERVICECACHE	
	)
	public ContactsDemographicsDto getContactsDemographics(ContactsDemographicsDto contactsDemographicsDto){
		ContactsDemographicsDto workContactsDemographics = null;
		
		//Set employee information to PersonalCVDto
		if(contactsDemographicsDto.getSso() > 0){
			EmployeeRestricted empRestricted = null;
			EmployeeRestricted genderCitizenship = null;
			EmployeeRestricted disabilitySelfId = null;
			EmployeeRestricted glbtSelfId = null;
			
			HomeAddress homeAddress = null;
			
			EmergencyContact emergContact = null;
			
			ServiceDates servDates = null;

			workContactsDemographics = new ContactsDemographicsDto();					
			workContactsDemographics.setSso(contactsDemographicsDto.getSso());
						
			empRestricted = employeeDao.getEmployeeRestrictedBySso(contactsDemographicsDto.getSso());
			if(empRestricted == null){
				empRestricted = new EmployeeRestricted();
			}
			genderCitizenship = employeeDao.getGenderCitizenshipBySso(contactsDemographicsDto.getSso());
			if(genderCitizenship == null){
				genderCitizenship = new EmployeeRestricted();
			}
			
			disabilitySelfId = employeeDao.getDisabilityIdBySso(contactsDemographicsDto.getSso());
			if(disabilitySelfId == null){
				disabilitySelfId = new EmployeeRestricted();
			}
			
			glbtSelfId = employeeDao.getGLBTSelfIdBySso(contactsDemographicsDto.getSso());
			if(glbtSelfId == null){
				glbtSelfId = new EmployeeRestricted();
			}
						
			homeAddress = employeeDao.getHomeAdressBySso(contactsDemographicsDto.getSso());
			if(homeAddress == null){
				homeAddress = new HomeAddress();
			}
			
			emergContact = emergencyContactDao.getEmergencyContactBySso(contactsDemographicsDto.getSso());	
			if(emergContact == null){
				emergContact = new EmergencyContact();
			}
			
			servDates = assignmentDao.getServiceDatesBySso(contactsDemographicsDto.getSso());
			if(servDates == null){
				servDates = new ServiceDates();
			}
			
			workContactsDemographics.setPerInfoRestricted(empRestricted);
			workContactsDemographics.setGenderCitizenship(genderCitizenship);
			workContactsDemographics.setDisabilitySelfId(disabilitySelfId);
			workContactsDemographics.setGlbtSelfId(glbtSelfId);
			workContactsDemographics.setHomeAddress(homeAddress);
			workContactsDemographics.setEmergencyContact(emergContact);
			workContactsDemographics.setServiceDates(servDates);
			
		}else{
			logger.error("Invalid SSO, SSO = " + contactsDemographicsDto.getSso());
		}		
		return workContactsDemographics;
	}
	
	/*@Cache(
			nodeName="/profile/employee/service/personalCVService",
			keyGeneratorClass=ServiceKeyGenerator.class,
			cacheName=InfinispanCacheFactory.EMPSERVICECACHE	
		)		*/
	public EducationTrainingDto getEducationAndTraining(EducationTrainingDto educationDto){
		EducationTrainingDto eduDto = new EducationTrainingDto();
				
		if(educationDto.getSso() > 0){			
			BaseModelCollection<TrainingHeader> tHeaderList = new BaseModelCollection<TrainingHeader>();
			
			Map<String,TrainingHeader> mapAux = new HashMap<String, TrainingHeader>();
			BaseModelCollection<Education> educationList;
			//Get education Information
			educationList = educationDao.getEducationListBySso(educationDto.getSso(), educationDto.isSelf());
			if(educationList == null){
				//if null, an empty collection must be inserted
				educationList = new BaseModelCollection<Education>();
			}
			eduDto.setEducationList(educationList);			
			
			//Get Training Information
			BaseModelCollection<Training> trainingList = trainingDao.getEmployeeTrainingBySso(educationDto.getSso());
			
			if(trainingList == null){
				eduDto.setTrainingHederList(tHeaderList);				
			}else{
				tHeaderList.setGranted(trainingList.isGranted());
				
				if(trainingList.getList() != null){
					for(Training training : trainingList.getList()){				
						TrainingHeader th = mapAux.get(training.getDisplayHeading());				
						if(th == null){
							//Create the Header
							TrainingHeader thNew = new TrainingHeader();
							List<Training> tList = new  ArrayList<Training>();
							thNew.setUiDisplayHeading(training.getDisplayHeading());
							thNew.setTrainingList(tList);
							tHeaderList.add(thNew);
							th = thNew;					
							mapAux.put(training.getDisplayHeading(), thNew);					
						}				
						//Add Training to Header
						th.getTrainingList().add(training);									
					}
				}
				eduDto.setTrainingHederList(tHeaderList);				
			}
			
			// Get Program Information
			BaseModelCollection<Program> programList =  programDao.getProgramListBySso(educationDto.getSso());
			if(programList == null){
				//if null an empty collection must be inserted
				programList = 	new BaseModelCollection<Program>();					
			}		
			eduDto.setProgramList(programList);	
			
			// Get Professional Certifications
			BaseModelCollection<Certification> certifications = educationDao.getCertificationsBySso(educationDto.getSso());
			if(certifications == null){
				certifications = 	new BaseModelCollection<Certification>();					
			}
			eduDto.setCertifications(certifications);
			
			// Get Six Sigma Data
			BaseModelCollection<SixSigma> sixSigmaList = trainingDao.getSixSigmaBySso(educationDto.getSso());
			if(sixSigmaList == null){
				sixSigmaList = 	new BaseModelCollection<SixSigma>();					
			}
			eduDto.setSixSigmaList(sixSigmaList);
						
			// Get Corporate Audit Staff Data
			BaseModelCollection<CAS> casList = trainingDao.getCASDataBySso(educationDto.getSso());
			if(casList == null){
				casList = 	new BaseModelCollection<CAS>();					
			}
			eduDto.setCASList(casList);
			
		}else{
			logger.error("Invalid SSO, SSO = " + educationDto.getSso());
		}		
		return eduDto;
	}
	
	public EducationTrainingDto getEducationAndTrainingOptin(EducationTrainingDto educationDto, OptinSharing optinSharing){
		EducationTrainingDto eduDto = new EducationTrainingDto();
		
		if(educationDto.getSso() > 0){			
			BaseModelCollection<TrainingHeader> tHeaderList = new BaseModelCollection<TrainingHeader>();
			
			Map<String,TrainingHeader> mapAux = new HashMap<String, TrainingHeader>();
			BaseModelCollection<Education> educationList = null;
			//Get education Information
			if(optinSharing.getEducation().equalsIgnoreCase("Y")){
				educationList = educationDao.getEducationListOptinBySso(educationDto.getSso());
			}
			/*else{
				educationList = educationDao.getEducationListBySso(educationDto.getSso());
			}*/
			if(educationList == null){
				//if null, an empty collection must be inserted
				educationList = new BaseModelCollection<Education>();
			}
			eduDto.setEducationList(educationList);			
			
			//Get Training Information
			BaseModelCollection<Training> trainingList = null;
			if(optinSharing.getTraining().equalsIgnoreCase("Y")){
				trainingList = trainingDao.getEmployeeTrainingOptinBySso(educationDto.getSso());
			}
			/*else{
				trainingList = trainingDao.getEmployeeTrainingBySso(educationDto.getSso());
			}*/
			
			if(trainingList == null){
				eduDto.setTrainingHederList(tHeaderList);				
			}else{
				tHeaderList.setGranted(trainingList.isGranted());
				
				if(trainingList.getList() != null){
					for(Training training : trainingList.getList()){				
						TrainingHeader th = mapAux.get(training.getDisplayHeading());				
						if(th == null){
							//Create the Header
							TrainingHeader thNew = new TrainingHeader();
							List<Training> tList = new  ArrayList<Training>();
							thNew.setUiDisplayHeading(training.getDisplayHeading());
							thNew.setTrainingList(tList);
							tHeaderList.add(thNew);
							th = thNew;					
							mapAux.put(training.getDisplayHeading(), thNew);					
						}				
						//Add Training to Header
						th.getTrainingList().add(training);									
					}
				}
				eduDto.setTrainingHederList(tHeaderList);				
			}
			
			if(optinSharing.getTraining().equalsIgnoreCase("Y")){
				// Get Program Information
				BaseModelCollection<Program> programList = new BaseModelCollection<Program>();	
				if(optinSharing.getTrainingList().contains("Leadership Programs")){
					programList =  programDao.getProgramListOptinBySso(educationDto.getSso());
				}	
				eduDto.setProgramList(programList);	
				
				// Get Professional Certifications
				BaseModelCollection<Certification> certifications = new BaseModelCollection<Certification>();	
				if(optinSharing.getTrainingList().contains("Professional Certifications")){
					certifications = educationDao.getCertificationsBySso(educationDto.getSso());					
				}
				eduDto.setCertifications(certifications);
				
				// Get Six Sigma Data
				BaseModelCollection<SixSigma> sixSigmaList = new BaseModelCollection<SixSigma>();
				if(optinSharing.getTrainingList().contains("Six Sigma")){
					sixSigmaList = 	trainingDao.getSixSigmaBySso(educationDto.getSso());					
				}
				eduDto.setSixSigmaList(sixSigmaList);
							
				// Get Corporate Audit Staff Data
				BaseModelCollection<CAS> casList = new BaseModelCollection<CAS>();	
				if(optinSharing.getTrainingList().contains("Corporate Audit Staff")){
					casList = trainingDao.getCASDataBySso(educationDto.getSso());					
				}
				eduDto.setCASList(casList);
			}
			
			
		}else{
			logger.error("Invalid SSO, SSO = " + educationDto.getSso());
		}		
		return eduDto;
	}
	
	public EducationDto getEducation(EducationDto educationDto){
		EducationDto eduDto = new EducationDto();
		
		if(educationDto.getSso() > 0){
			BaseModelCollection<Education> educationList;
			//Get education Information
			educationList = educationDao.getEducationListOptinBySso(educationDto.getSso());
			if(educationList == null){
				//if null, an empty collection must be inserted
				educationList = new BaseModelCollection<Education>();
			}
			eduDto.setEducationList(educationList);	
		}else{
			logger.error("Invalid SSO, SSO = " + educationDto.getSso());
		}		
		return eduDto;
	}
	
	public EducationDto getEducationAll(EducationDto educationDto, boolean isSharing){
		EducationDto eduDto = new EducationDto();
		
		if(educationDto.getSso() > 0){
			BaseModelCollection<Education> educationList;
			//Get education Information
			educationList = educationDao.getEducationListAllBySso(educationDto.getSso());
			if(educationList == null){
				//if null, an empty collection must be inserted
				educationList = new BaseModelCollection<Education>();
			}
			eduDto.setShared(isSharing);
			eduDto.setEducationList(educationList);	
		}else{
			logger.error("Invalid SSO, SSO = " + educationDto.getSso());
		}		
		return eduDto;
	}
	
	public TrainingDto getTraining(TrainingDto trainingDto, List<String> allTraining, List<String> optinTraining){
		TrainingDto trnDto = new TrainingDto();
		
		if(trainingDto.getSso() > 0){			
			BaseModelCollection<TrainingHeader> tHeaderList = new BaseModelCollection<TrainingHeader>();
			
			Map<String,TrainingHeader> mapAux = new HashMap<String, TrainingHeader>();
			BaseModelCollection<Training>trainingList = trainingDao.getEmployeeTrainingOptinBySso(trainingDto.getSso());
			
			//Get Training Information		
			if(trainingList == null){
				trnDto.setTrainingHederList(tHeaderList);				
			}else{
				tHeaderList.setGranted(trainingList.isGranted());
				
				if(trainingList.getList() != null){
					for(Training training : trainingList.getList()){				
						TrainingHeader th = mapAux.get(training.getDisplayHeading());				
						if(th == null){
							//Create the Header
							TrainingHeader thNew = new TrainingHeader();
							List<Training> tList = new  ArrayList<Training>();
							thNew.setUiDisplayHeading(training.getDisplayHeading());
							thNew.setTrainingList(tList);
							tHeaderList.add(thNew);
							thNew.setShared(true);
							thNew.setGranted(true);
							th = thNew;					
							mapAux.put(training.getDisplayHeading(), thNew);					
						}				
						//Add Training to Header
						th.getTrainingList().add(training);									
					}
				}
				
				for(int i=0; i < allTraining.size(); i++){
					if(!optinTraining.contains(allTraining.get(i))){
						TrainingHeader thNew = new TrainingHeader();
						List<Training> tList = new  ArrayList<Training>();
						thNew.setUiDisplayHeading(allTraining.get(i));
						thNew.setTrainingList(null);
						thNew.setShared(false);
						tHeaderList.add(thNew);
					}
				}
				
				trnDto.setTrainingHederList(tHeaderList);				
			}
			
			// Get Program Information
			ProgramHeader leadershipProgramList =  new ProgramHeader();
			BaseModelCollection<Program>programList =  programDao.getProgramListOptinBySso(trainingDto.getSso());
			
			leadershipProgramList.setShared(true);
			leadershipProgramList.setGranted(true);
			
			if(!optinTraining.contains("Leadership Programs")){
				leadershipProgramList.setShared(false);
				leadershipProgramList.setGranted(false);
				programList = null;
			}else if(programList == null){
				//if null an empty collection must be inserted
				programList = 	new BaseModelCollection<Program>();	
			}		
			leadershipProgramList.setProgramList(programList);
			leadershipProgramList.setUiDisplayHeading("Leadership Programs");
			
			trnDto.setLeadershipProgramList(leadershipProgramList);		
			
		}else{
			logger.error("Invalid SSO, SSO = " + trainingDto.getSso());
		}		
		return trnDto;
	}
	
	public TrainingDto getTrainingAll(TrainingDto trainingDto, boolean isSharing, List<String> optinTraining){
		TrainingDto trnDto = new TrainingDto();
		
		if(trainingDto.getSso() > 0){			
			BaseModelCollection<TrainingHeader> tHeaderList = new BaseModelCollection<TrainingHeader>();
			
			Map<String,TrainingHeader> mapAux = new HashMap<String, TrainingHeader>();

			//Get Training Information
			BaseModelCollection<Training> trainingList = trainingDao.getEmployeeTrainingAllBySso(trainingDto.getSso());
			
			if(trainingList == null){
				trnDto.setTrainingHederList(tHeaderList);				
			}else{
				tHeaderList.setGranted(trainingList.isGranted());
				
				if(trainingList.getList() != null){
					for(Training training : trainingList.getList()){				
						TrainingHeader th = mapAux.get(training.getDisplayHeading());				
						if(th == null){
							//Create the Header
							TrainingHeader thNew = new TrainingHeader();
							List<Training> tList = new  ArrayList<Training>();
							if(optinTraining.contains(training.getDisplayHeading())){
								thNew.setShared(true);
							}else{
								thNew.setShared(false);
							}
							thNew.setGranted(true);
							thNew.setUiDisplayHeading(training.getDisplayHeading());
							thNew.setTrainingList(tList);
							tHeaderList.add(thNew);
							th = thNew;					
							mapAux.put(training.getDisplayHeading(), thNew);					
						}				
						//Add Training to Header
						th.getTrainingList().add(training);									
					}
				}
				trnDto.setTrainingHederList(tHeaderList);				
			}
			
			// Get Program Information
			ProgramHeader leadershipProgramList =  new ProgramHeader();
			BaseModelCollection<Program>programList =  programDao.getProgramListAllBySso(trainingDto.getSso());
			if(programList == null){
				//if null an empty collection must be inserted
				programList = 	new BaseModelCollection<Program>();
			}
			leadershipProgramList.setGranted(programList.isGranted());
			leadershipProgramList.setProgramList(programList);
			leadershipProgramList.setShared(true);
			if(optinTraining.contains("Leadership Programs")){
				leadershipProgramList.setShared(true);
			}else{
				leadershipProgramList.setShared(false);
			}
			leadershipProgramList.setUiDisplayHeading("Leadership Programs");
			
			trnDto.setLeadershipProgramList(leadershipProgramList);
			trnDto.setShared(isSharing);
				
		}else{
			logger.error("Invalid SSO, SSO = " + trainingDto.getSso());
		}		
		return trnDto;
	}
	
	public List<String> getLanguageList() {
		return languageDao.getLanguageList();
	}
	
	public boolean addLanguages(Long sso, ArrayList<Map<String, String>> langProfList) {
		return languageDao.addLanguages(sso, langProfList);
	}

	public boolean deleteLanguages(Long sso, ArrayList<Map<String, String>> langProfList) {
		return languageDao.deleteLanguages(sso, langProfList);
	}

	public boolean updateLanguages(Long sso, ArrayList<Map<String, String>> langProfList) {
		return languageDao.updateLanguages(sso, langProfList);
	}
	
	public boolean setLanguageProficieny(Long sso, ArrayList<Map<String, String>> langProfList){
		return languageDao.setLanguageProficieny(sso, langProfList);
	}

	public EducationTrainingDto getLanguageProficieny(EducationTrainingDto educationDto) {
		if(educationDto.getSso() > 0){
			BaseModelCollection<LanguageProficiency> languageProficiencyList = languageDao.getlanguageProficiencyList(educationDto.getSso());
			educationDto.setLanguageProficiencyList(languageProficiencyList);		
			//List<String> languageList =  languageDao.getLanguageList();
			//educationDto.setLanguageList(languageList);
		}else{
			logger.error("Invalid SSO, SSO = " + educationDto.getSso());
		}
		return educationDto;
	}
	
	@Override
	public boolean saveEducationDetails(Long sso,
			EducationTrainingDto educationDetails) {
		// TODO Auto-generated method stub
		return educationDao.saveEducationDetails(sso, educationDetails);
	}

	public ProgramDao getProgramDao() {
		return programDao;
	}

	public void setProgramDao(ProgramDao programDao) {
		this.programDao = programDao;
	}

	public TrainingDao getTrainingDao() {
		return trainingDao;
	}

	public void setTrainingDao(TrainingDao trainingDao) {
		this.trainingDao = trainingDao;
	}
	
	public EmployeeDao getEmployeeDao() {
		return employeeDao;
	}

	public void setEmployeeDao(EmployeeDao employeeDao) {
		this.employeeDao = employeeDao;
	}

	public EducationDao getPersonalCVDao() {
		return educationDao;
	}


	public void seeducationDaoo(EducationDao educationDao) {
		this.educationDao = educationDao;
	}
	public EmergencyContactDao getEmergencyContactDao() {
		return emergencyContactDao;
	}

	public void setEmergencyContactDao(EmergencyContactDao emergencyContactDao) {
		this.emergencyContactDao = emergencyContactDao;
	}

	public EducationDao getEducationDao() {
		return educationDao;
	}

	public void setEducationDao(EducationDao educationDao) {
		this.educationDao = educationDao;
	}

	@Override
	public EducationCatalogs loadEducationCatalogs(String country, String query) {
		EducationCatalogs catalogs = new EducationCatalogs();
		BaseModelCollection<String> degreeList = new BaseModelCollection<String>();
		BaseModelCollection<EducationCountry> countryList = new BaseModelCollection<EducationCountry>();
		countryList = educationDao.getCountries();
		catalogs.setCountryList(countryList);
		BaseModelCollection<String> majorList = new BaseModelCollection<String>();
		majorList = educationDao.getMajors();
		catalogs.setMajorList(majorList);
		if (country != null || query !=null) {
			BaseModelCollection<EducationUniversity> universityList = new BaseModelCollection<EducationUniversity>();
			universityList = educationDao.getUniversities(country,query);
			catalogs.setUniversityList(universityList);
			if (country != null){
				degreeList = educationDao.getDegrees(country);
				catalogs.setDegreeList(degreeList);
			}
		}else{
			degreeList = educationDao.getDegrees();
			catalogs.setDegreeList(degreeList);
		}
		BaseModelCollection<EducationCountry> statusList = new BaseModelCollection<EducationCountry>();
		EducationCountry graduated = new EducationCountry();
		graduated.setCountryCode("Y");
		graduated.setCountryName("Graduated");
		EducationCountry inProgress = new EducationCountry();
		inProgress.setCountryCode("N");
		inProgress.setCountryName("In Progress");
		statusList.add(graduated);
		statusList.add(inProgress);
		catalogs.setStatusList(statusList);
		return catalogs;
	}

	@Override
	public boolean saveProfessionalCertifications(Long sso,
			List<Certification> certificationList) {
		// TODO Auto-generated method stub
		return educationDao.saveProfessionalCertifications(sso,certificationList);
	}

	public WorkAssignmentDao getAssignmentDao() {
		return assignmentDao;
	}

	public void setAssignmentDao(WorkAssignmentDao assignmentDao) {
		this.assignmentDao = assignmentDao;
	}

	@Override
	public EducationTrainingDto getEducationBySso(
			EducationTrainingDto educationDto) {
		EducationTrainingDto eduDto = new EducationTrainingDto();
		if(educationDto.getSso() > 0){
			BaseModelCollection<Education> educationList;
		//Get education Information
		educationList = educationDao.getEducationListBySso(educationDto.getSso(), educationDto.isSelf());
		if(educationList == null){
			//if null, an empty collection must be inserted
			educationList = new BaseModelCollection<Education>();
		}
		eduDto.setEducationList(educationList);
		eduDto.setSso(educationDto.getSso());
		eduDto.setSelf(educationDto.isSelf());
		}else{
			logger.error("Invalid SSO, SSO = " + educationDto.getSso());
		}
		return eduDto;					
	}

	@Override
	public EducationTrainingDto getTrainingBySso(
			EducationTrainingDto educationDto, boolean datagroupAccess, OptinSharing optinSharing) {
		if(educationDto.getSso() > 0){
			BaseModelCollection<Training> trainingList = null;
			if(datagroupAccess){
				 trainingList = trainingDao.getEmployeeTrainingBySso(educationDto.getSso());
			}else{
				trainingList = trainingDao.getEmployeeTrainingOptinBySso(educationDto.getSso());
			}
			BaseModelCollection<TrainingHeader> tHeaderList = new BaseModelCollection<TrainingHeader>();
			Map<String,TrainingHeader> mapAux = new HashMap<String, TrainingHeader>();
			
			if(trainingList == null){
				educationDto.setTrainingHederList(tHeaderList);				
			}else{
				tHeaderList.setGranted(trainingList.isGranted());
				
				if(trainingList.getList() != null){
					for(Training training : trainingList.getList()){				
						TrainingHeader th = mapAux.get(training.getDisplayHeading());				
						if(th == null){
							//Create the Header
							TrainingHeader thNew = new TrainingHeader();
							List<Training> tList = new  ArrayList<Training>();
							thNew.setUiDisplayHeading(training.getDisplayHeading());
							thNew.setTrainingList(tList);
							tHeaderList.add(thNew);
							th = thNew;					
							mapAux.put(training.getDisplayHeading(), thNew);					
						}				
						//Add Training to Header
						th.getTrainingList().add(training);									
					}
				}
				educationDto.setTrainingHederList(tHeaderList);				
			}
			
			// Get Program Information
			BaseModelCollection<Program> programList = new BaseModelCollection<Program>();
			if(optinSharing.getTrainingList().contains("Leadership Programs")||datagroupAccess){
				programList = programDao.getProgramListBySso(educationDto.getSso());
			}	
			educationDto.setProgramList(programList);	
			
			// Get Six Sigma Data
			BaseModelCollection<SixSigma> sixSigmaList = new BaseModelCollection<SixSigma>();
			if(optinSharing.getTrainingList().contains("Six Sigma")||datagroupAccess){
				sixSigmaList = trainingDao.getSixSigmaBySso(educationDto.getSso());
			}
			educationDto.setSixSigmaList(sixSigmaList);		
						
			// Get Corporate Audit Staff Data
			BaseModelCollection<CAS> casList = new BaseModelCollection<CAS>();	
			if(optinSharing.getTrainingList().contains("Corporate Audit Staff")||datagroupAccess){
				casList = trainingDao.getCASDataBySso(educationDto.getSso());
			}
			educationDto.setCASList(casList);
			
			educationDto.setSso(educationDto.getSso());
			educationDto.setSelf(educationDto.isSelf());
		}else{
			logger.error("Invalid SSO, SSO = " + educationDto.getSso());
		}
		return educationDto;					
	}

	@Override
	public EducationTrainingDto getCertificationsBySso(
			EducationTrainingDto educationDto) {
		//EducationTrainingDto eduDto = new EducationTrainingDto();
		if(educationDto.getSso() > 0){
			// Get Professional Certifications
			BaseModelCollection<Certification> certifications = educationDao.getCertificationsBySso(educationDto.getSso());
			if(certifications == null){
				certifications = 	new BaseModelCollection<Certification>();					
			}
			educationDto.setCertifications(certifications);
			educationDto.setSso(educationDto.getSso());
			educationDto.setSelf(educationDto.isSelf());
		}else{
			logger.error("Invalid SSO, SSO = " + educationDto.getSso());
		}
		return educationDto;					
	}

	@Override
	public boolean hasEducation(Long sso) {
		boolean hasEducation = false;
		BaseModelCollection<Education> educationList = educationDao.getEducationListBySso(sso, true);
		if(educationList!=null && !educationList.isEmpty()){
			if(educationList.getList()!=null && educationList.getList().size()>0){
				hasEducation = true;
			}
		}else{
			hasEducation = false;
		}
		return hasEducation;
	}

}
