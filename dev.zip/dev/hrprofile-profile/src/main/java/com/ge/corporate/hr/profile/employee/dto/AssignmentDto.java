/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonWriteNullProperties;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.DottedLineManager;
import com.ge.corporate.hr.profile.employee.model.FinanceContacts;
import com.ge.corporate.hr.profile.employee.model.LeadershipProgramAssignment;
import com.ge.corporate.hr.profile.employee.model.Person;
import com.ge.corporate.hr.profile.employee.model.PersonLevel;
import com.ge.corporate.hr.profile.employee.model.Reports;
import com.ge.corporate.hr.profile.employee.model.WorkAssignment;
import com.ge.corporate.hr.profile.employee.model.WorkAssignmentHistortyInt;
import com.ge.corporate.hr.profile.employee.model.WorkAssignmentRestricted;


@XmlRootElement(name="assignment")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonWriteNullProperties(value=false)
public class AssignmentDto extends AbstractBaseDtoSupport{
	/**
	 * serial ID
	 */
	private static final long serialVersionUID = 1L;
	
	@XmlElement(name="sso")
	private Long sso;
	
	@XmlElement(name="viewSuspendedEmployees")
	private boolean viewSuspendedEmployees;
	
	@XmlElement(name="isAlstomEmployee")
	private boolean isAlstomEmployee;

	@XmlElement(name="workAssignment")
	WorkAssignment workAssignment;
	
	@XmlElement(name="workAssignmentRestrd")
	WorkAssignmentRestricted workAssignmentRestrd;
	
	@XmlElement(name="historyList")
	private List<AssignmentDto> historyList;
	
	@XmlElement(name="superHierarchyPerInfoList")
	private BaseModelCollection<PersonLevel> superHierarchyPerInfoList;

	@XmlElement(name="directReptsPerInfoList")
	private BaseModelCollection<Person> directReptsPerInfoList;
	
	@XmlElement(name="directReptsAssignmtList")
	private BaseModelCollection<Person> directReptsAssignmtList;
	
	@XmlElement(name="dottedLineDirectReptsList")
	private BaseModelCollection<Person> dottedLineDirectReptsList;
	
	@XmlElement(name="contingentWorkerReptsList")
	private BaseModelCollection<Person> contingentWorkerReptsList;
	
	@XmlElement(name="directReptList")
	private BaseModelCollection<Person> directReptList;
	@XmlElement(name="dottedLineReptList")
	private BaseModelCollection<Person> dottedLineReptList;
	@XmlElement(name="contingentLineReptList")
	private BaseModelCollection<Person> contingentLineReptList;
	@XmlElement(name="dottedLineManager")
	private DottedLineManager dottedLineManager;

	@XmlElement(name="financeContacts")
	private BaseModelCollection<FinanceContacts> financeContacts;
	
	@XmlElement(name="workAssignmentHistInt")
	private WorkAssignmentHistortyInt workAssignmentHistInt;	
	
	@XmlElement(name="lpList")
	private BaseModelCollection<Reports> lpList;
	@XmlElement(name="localBand")
	WorkAssignmentRestricted localBand;
	
	@XmlElement(name="corporateBand")
	WorkAssignmentRestricted corporateBand;
	
	@XmlElement(name="CostCenter")
	WorkAssignmentRestricted costCenter;
	
	@XmlElement(name="headCountCostCenter")
	WorkAssignmentRestricted headCountCostCenter;
	
	@XmlElement(name="reportingOrgs")
	WorkAssignmentRestricted reportingOrgs;

	@XmlElement(name="workRegion")
	WorkAssignmentRestricted workRegion;

	@XmlElement(name="headCount")
	WorkAssignmentRestricted headCount;
	
	@XmlElement(name="leader")
	WorkAssignmentRestricted leader;
	

	@XmlElement(name="profesionalSummary")
	WorkAssignmentRestricted profesionalSummary;

	@XmlElement(name="payroll")
	WorkAssignmentRestricted payroll;
	
	@XmlElement(name="leadershipProgramAssignment")
	private LeadershipProgramAssignment lpAssignment;
	
	
	public BaseModelCollection<Reports> getLpList() {
		return lpList;
	}

	public WorkAssignmentRestricted getLeader() {
		return leader;
	}

	public void setLeader(WorkAssignmentRestricted leader) {
		this.leader = leader;
	}

	public void setLpList(BaseModelCollection<Reports> lpList) {
		this.lpList = lpList;
	}

	public long getId() {
		return (sso==null)?0:sso.longValue();		
	}
	
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	
	public boolean isAlstomEmployee() {
		return isAlstomEmployee;
	}

	public void setAlstomEmployee(boolean isAlstomEmployee) {
		this.isAlstomEmployee = isAlstomEmployee;
	}
	
	public boolean isViewSuspendedEmployees() {
		return viewSuspendedEmployees;
	}

	public void setViewSuspendedEmployees(boolean viewSuspendedEmployees) {
		this.viewSuspendedEmployees = viewSuspendedEmployees;
	}
	
	public List<AssignmentDto> getHistoryList() {
		return historyList;
	}
	public void setHistoryList(List<AssignmentDto> historyList) {
		this.historyList = historyList;
	}
	
	public WorkAssignment getWorkAssignment() {
		return workAssignment;
	}

	public void setWorkAssignment(WorkAssignment workAssignment) {
		this.workAssignment = workAssignment;
	}

	public WorkAssignmentRestricted getWorkAssignmentRestrd() {
		return workAssignmentRestrd;
	}

	public void setWorkAssignmentRestrd(
			WorkAssignmentRestricted workAssignmentRestrd) {
		this.workAssignmentRestrd = workAssignmentRestrd;
	}
	
	public BaseModelCollection<PersonLevel> getSuperHierarchyPerInfoList() {
		return superHierarchyPerInfoList;
	}

	public void setSuperHierarchyPerInfoList(
			BaseModelCollection<PersonLevel> superHierarchyPerInfoList) {
		this.superHierarchyPerInfoList = superHierarchyPerInfoList;
	}
	
	public BaseModelCollection<Person> getDirectReptsPerInfoList() {
		return directReptsPerInfoList;
	}

	public void setDirectReptsPerInfoList(
			BaseModelCollection<Person> directReptsPerInfoList) {
		this.directReptsPerInfoList = directReptsPerInfoList;
	}

	public BaseModelCollection<Person> getDirectReptsAssignmtList() {
		return directReptsAssignmtList;
	}

	public void setDirectReptsAssignmtList(
			BaseModelCollection<Person> directReptsAssignmtList) {
		this.directReptsAssignmtList = directReptsAssignmtList;
	}

	public BaseModelCollection<Person> getDottedLineDirectReptsList() {
		return dottedLineDirectReptsList;
	}

	public void setDottedLineDirectReptsList(
			BaseModelCollection<Person> dottedLineDirectReptsList) {
		this.dottedLineDirectReptsList = dottedLineDirectReptsList;
	}
	
	public void setWorkAssignmentHistInt(WorkAssignmentHistortyInt workAssignmentHistInt) {
		this.workAssignmentHistInt = workAssignmentHistInt;
	}

	public WorkAssignmentHistortyInt getWorkAssignmentHistInt() {
		return workAssignmentHistInt;
	}

	public WorkAssignmentRestricted getLocalBand() {
		return localBand;
	}

	public void setLocalBand(WorkAssignmentRestricted localBand) {
		this.localBand = localBand;
	}
	
	public WorkAssignmentRestricted getCorporateBand() {
		return corporateBand;
	}

	public void setCorporateBand(WorkAssignmentRestricted corporateBand) {
		this.corporateBand = corporateBand;
	}

	public WorkAssignmentRestricted getCostCenter() {
		return costCenter;
	}

	public void setCostCenter(WorkAssignmentRestricted costCenter) {
		this.costCenter = costCenter;
	}

	public DottedLineManager getDottedLineManager() {
		return dottedLineManager;
	}

	public void setDottedLineManager(DottedLineManager dottedLineManager) {
		this.dottedLineManager = dottedLineManager;
	}

	public BaseModelCollection<Person> getContingentWorkerReptsList() {
		return contingentWorkerReptsList;
	}

	public void setContingentWorkerReptsList(
			BaseModelCollection<Person> contingentWorkerReptsList) {
		this.contingentWorkerReptsList = contingentWorkerReptsList;
	}
	
	public WorkAssignmentRestricted getHeadCountCostCenter() {
		return headCountCostCenter;
	}

	public void setHeadCountCostCenter(WorkAssignmentRestricted headCountCostCenter) {
		this.headCountCostCenter = headCountCostCenter;
	}
	
	public BaseModelCollection<Person> getDirectReptList() {
		return directReptList;
	}

	public void setDirectReptList(BaseModelCollection<Person> directReptList) {
		this.directReptList = directReptList;
	}

	public BaseModelCollection<Person> getDottedLineReptList() {
		return dottedLineReptList;
	}

	public void setDottedLineReptList(BaseModelCollection<Person> dottedLineReptList) {
		this.dottedLineReptList = dottedLineReptList;
	}


	public BaseModelCollection<Person> getContingentLineReptList() {
		return contingentLineReptList;
	}

	public void setContingentLineReptList(
			BaseModelCollection<Person> contingentLineReptList) {
		this.contingentLineReptList = contingentLineReptList;
	}

	public WorkAssignmentRestricted getReportingOrgs() {
		return reportingOrgs;
	}

	public void setReportingOrgs(WorkAssignmentRestricted reportingOrgs) {
		this.reportingOrgs = reportingOrgs;
	}

	public WorkAssignmentRestricted getWorkRegion() {
		return workRegion;
	}

	public void setWorkRegion(WorkAssignmentRestricted workRegion) {
		this.workRegion = workRegion;
	}

	public WorkAssignmentRestricted getHeadCount() {
		return headCount;
	}

	public void setHeadCount(WorkAssignmentRestricted headCount) {
		this.headCount = headCount;
	}

	public WorkAssignmentRestricted getProfesionalSummary() {
		return profesionalSummary;
	}

	public void setProfesionalSummary(WorkAssignmentRestricted profesionalSummary) {
		this.profesionalSummary = profesionalSummary;
	}

	public LeadershipProgramAssignment getLpAssignment() {
		return lpAssignment;
	}

	public void setLpAssignment(LeadershipProgramAssignment lpAssignment) {
		this.lpAssignment = lpAssignment;
	}

	public WorkAssignmentRestricted getPayroll() {
		return payroll;
	}

	public void setPayroll(WorkAssignmentRestricted payroll) {
		this.payroll = payroll;
	}

	public BaseModelCollection<FinanceContacts> getFinanceContacts() {
		return financeContacts;
	}

	public void setFinanceContacts(
			BaseModelCollection<FinanceContacts> financeContacts) {
		this.financeContacts = financeContacts;
	}
}
