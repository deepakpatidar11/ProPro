/*package com.ge.corporate.hr.profile.employee.service.mail;

import java.util.List;

public interface SensitiveDataPopupMail {	
	public boolean sendMail(Long principal, Long sso, List<String> roles,
			List<String> rolesForContext);
}*/
