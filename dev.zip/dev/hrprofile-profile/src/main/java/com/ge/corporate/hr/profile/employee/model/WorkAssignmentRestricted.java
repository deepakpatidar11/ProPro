/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonWriteNullProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;
import com.ge.corporate.hr.profile.employee.serializer.CustomDateSerializer;

@XmlRootElement(name="workAssignment")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonWriteNullProperties(value=false)
public class WorkAssignmentRestricted extends AbstractBaseModelSupport{

	private static final long serialVersionUID = 46981221793287345L;
	
	@XmlElement(name="sso")
	private Long id; //SSO Id
	
	@XmlAttribute(name="id")
	private Long waId;
	
	@XmlElement(name="monthsInJob")
	private Integer monthsInJob;	
	@XmlElement(name="monthsInPosition")
	private Integer monthsInPosition;	
	@XmlElement(name="monthsInBusiness")
	private Integer monthsInBusiness;	
	@XmlElement(name="jobType")
	private String jobType;
	@XmlElement(name="band")	
	private String band;	
	@XmlElement(name="bandDate")	
	@Deprecated
	private Date bandDate; // Field is never loaded on the data loads
	@XmlElement(name="localBand")
	private String localBand;	
	
	@XmlElement(name="dateFirstHired")
	private Date dateFirstHired;
	@XmlElement(name="aquiredServiceDate")
	private Date aquiredServiceDate;
	@XmlElement(name="adjustedServiceDate")
	private Date adjustedServiceDate;
	@XmlElement(name="gmeInfoHomeCountry")	
	private String gmeInfoHomeCountry ;
	@XmlElement(name="costCenter")
	private String costCenter;
	@XmlElement(name="buc")
	private String buc;
	@XmlElement(name="adn")
	private String adn;	
	@XmlElement(name="serciveDates")
	private ServiceDates serciveDates;
	@XmlElement(name="headcountCostCenterCode")
	private String headcountCostCenterCode;
	@XmlElement(name="payrollName")
	private String payrollName;
	@XmlElement(name="payrollProcessorCode")
	private String payrollProcessorCode;
	@XmlElement(name="reportingIFG")
	private String reportingIFG;
	@XmlElement(name="reportingBusiness")
	private String reportingBusiness;
	@XmlElement(name="workRegion")
	private String workRegion;
	@XmlElement(name="headCount")
	private String headCount;
	@XmlElement(name="professionalSummary")
	private String professionalSummary;
	@XmlElement(name="ldgrCostCenter")
	private String ldgrCostCenter;
	@XmlElement(name="ldgrBuc")
	private String ldgrBuc;
	@XmlElement(name="ldgrCompanyLine")
	private String ldgrCompanyLine;
	@XmlElement(name="ldgrProductLine")
	private String ldgrProductLine;
	@XmlElement(name="ldgrProjectCode")
	private String ldgrProjectCode;
	@XmlElement(name="ldgrRefId")
	private String ldgrRefId;
	@XmlElement(name="enterpriseStandard")
	private String enterpriseStandard;

	@XmlElement(name="leader")
	private String leader;
	
	public String getLeader() {
		return leader;
	}
	public void setLeader(String leader) {
		this.leader = leader;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getWaId() {
		return waId;
	}
	public void setWaId(Long waId) {
		this.waId = waId;
	}
	
	public String getBand() {
		return band;
	}
	public void setBand(String band) {
		this.band = band;
	}
	@Deprecated
	public Date getBandDate() {
		return bandDate;
	}
	@Deprecated
	public void setBandDate(Date bandDate) {
		this.bandDate = bandDate;
	}
	
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	
	public String getLocalBand() {
		return localBand;
	}
	public void setLocalBand(String localBand) {
		this.localBand = localBand;
	}
	
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getDateFirstHired() {
		return dateFirstHired;
	}
	public void setDateFirstHired(Date dateFirstHired) {
		this.dateFirstHired = dateFirstHired;
	}
	
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getAquiredServiceDate() {
		return aquiredServiceDate;
	}
	public void setAquiredServiceDate(Date aquiredServiceDate) {
		this.aquiredServiceDate = aquiredServiceDate;
	}
	
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getAdjustedServiceDate() {
		return adjustedServiceDate;
	}
	public void setAdjustedServiceDate(Date adjustedServiceDate) {
		this.adjustedServiceDate = adjustedServiceDate;
	}
	public String getGmeInfoHomeCountry() {
		return gmeInfoHomeCountry;
	}
	public void setGmeInfoHomeCountry(String gmeInfoHomeCountry) {
		this.gmeInfoHomeCountry = gmeInfoHomeCountry;
	}
	public String getCostCenter() {
		return costCenter;
	}
	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}
	public String getAdn() {
		return adn;
	}
	public void setAdn(String adn) {
		this.adn = adn;
	}
	
	public String getBuc() {
		return buc;
	}
	public void setBuc(String buc) {
		this.buc = buc;
	}
	public void setSerciveDates(ServiceDates serciveDates) {
		this.serciveDates = serciveDates;
	}
	public ServiceDates getSerciveDates() {
		return serciveDates;
	}
	public Integer getMonthsInPosition() {
		return monthsInPosition;
	}
	public void setMonthsInPosition(Integer monthsInPosition) {
		this.monthsInPosition = monthsInPosition;
	}	
	public String getHeadcountCostCenterCode() {
		return headcountCostCenterCode;
	}
	public void setHeadcountCostCenterCode(String headcountCostCenterCode) {
		this.headcountCostCenterCode = headcountCostCenterCode;
	}
	public String getPayrollName() {
		return payrollName;
	}
	public void setPayrollName(String payrollName) {
		this.payrollName = payrollName;
	}
	public String getPayrollProcessorCode() {
		return payrollProcessorCode;
	}
	public void setPayrollProcessorCode(String payrollProcessorCode) {
		this.payrollProcessorCode = payrollProcessorCode;
	}
	public Integer getMonthsInBusiness() {
		return monthsInBusiness;
	}
	public void setMonthsInBusiness(Integer monthsInBusiness) {
		this.monthsInBusiness = monthsInBusiness;
	}
	public void setMonthsInJob(Integer monthsInJob) {
		this.monthsInJob = monthsInJob;
	}
	public Integer getMonthsInJob() {
		return monthsInJob;
	}
	public String getReportingIFG() {
		return reportingIFG;
	}
	public void setReportingIFG(String reportingIFG) {
		this.reportingIFG = reportingIFG;
	}
	public String getReportingBusiness() {
		return reportingBusiness;
	}
	public void setReportingBusiness(String reportingBusiness) {
		this.reportingBusiness = reportingBusiness;
	}
	public String getWorkRegion() {
		return workRegion;
	}
	public void setWorkRegion(String workRegion) {
		this.workRegion = workRegion;
	}
	public String getHeadCount() {
		return headCount;
	}
	public void setHeadCount(String headCount) {
		this.headCount = headCount;
	}
	public String getProfessionalSummary() {
		return professionalSummary;
	}
	public void setProfessionalSummary(String professionalSummary) {
		this.professionalSummary = professionalSummary;
	}
	public String getLdgrCostCenter() {
		return ldgrCostCenter;
	}
	public void setLdgrCostCenter(String ldgrCostCenter) {
		this.ldgrCostCenter = ldgrCostCenter;
	}
	public String getLdgrBuc() {
		return ldgrBuc;
	}
	public void setLdgrBuc(String ldgrBuc) {
		this.ldgrBuc = ldgrBuc;
	}
	public String getLdgrCompanyLine() {
		return ldgrCompanyLine;
	}
	public void setLdgrCompanyLine(String ldgrCompanyLine) {
		this.ldgrCompanyLine = ldgrCompanyLine;
	}
	public String getLdgrProductLine() {
		return ldgrProductLine;
	}
	public void setLdgrProductLine(String ldgrProductLine) {
		this.ldgrProductLine = ldgrProductLine;
	}
	public String getLdgrProjectCode() {
		return ldgrProjectCode;
	}
	public void setLdgrProjectCode(String ldgrProjectCode) {
		this.ldgrProjectCode = ldgrProjectCode;
	}
	public String getLdgrRefId() {
		return ldgrRefId;
	}
	public void setLdgrRefId(String ldgrRefId) {
		this.ldgrRefId = ldgrRefId;
	}
	public String getEnterpriseStandard() {
		return enterpriseStandard;
	}
	public void setEnterpriseStandard(String enterpriseStandard) {
		this.enterpriseStandard = enterpriseStandard;
	}
	
}
