/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.FinanceContacts;
import com.ge.corporate.hr.profile.employee.model.LeadershipProgramAssignment;
import com.ge.corporate.hr.profile.employee.model.MyClient;
import com.ge.corporate.hr.profile.employee.model.Person;
import com.ge.corporate.hr.profile.employee.model.Reports;
import com.ge.corporate.hr.profile.employee.model.ServiceDates;
import com.ge.corporate.hr.profile.employee.model.WorkAssignment;
import com.ge.corporate.hr.profile.employee.model.WorkAssignmentHistortyInt;
import com.ge.corporate.hr.profile.employee.model.WorkAssignmentRestricted;

/**
 * Work Assignment Dao Interface
 * 
 * @author enrique.romero
 * 
 */

public interface WorkAssignmentDao {

	/**
	 * Returns current Work assignment information by sso, this information
	 * belongs to "Work Assignment" data group
	 * 
	 * @param sso
	 *            Employee SSO
	 * @return WorkAssignment model
	 */
	public WorkAssignment getCurrentWorkAssignmentBySso(Long sso);
	
	public WorkAssignment getCurrentWorkAssignmentAlstomBySso(Long sso);

	/**
	 * Returns current work assignment Information by sso, this information
	 * belongs to "Work Assignment - Restricted" Data Group
	 * 
	 * @param sso
	 *            Employee SSO
	 * @return WorkAssignment model
	 */
	public WorkAssignmentRestricted getCurrentWorkAssignmentRestrictedBySso(
			Long sso);

	/**
	 * Returns Current Local band, this info belongs to LocalBand DG
	 * 
	 * @param sso
	 * @return
	 */
	public WorkAssignmentRestricted getCurrentLocalBandBySso(Long sso);
	
	public WorkAssignmentRestricted getCurrentCorpBandBySso(Long sso);

	/**
	 * Returns Current CostCenter, this info belongs to CostCenter DG
	 * 
	 * @param sso
	 * @return
	 */
	public WorkAssignmentRestricted getCurrentCostCenterBySso(Long sso);

	/**
	 * Returns Historical Work Assignment information by sso, this information
	 * belongs to WorkAssignment Data Group
	 * 
	 * @param sso
	 *            Employee SSO
	 * @return Work assignment model list
	 */
	public BaseModelCollection<WorkAssignmentHistortyInt> getWorkAssignmentListBySso(
			Long sso);

	/**
	 * Returns Historical Work Assignment information by sso, this information
	 * belongs to WorkAssignment Restricted Data Group
	 * 
	 * @param sso
	 *            Employee SSO
	 * @return Work assignment model list
	 */
	public BaseModelCollection<WorkAssignmentRestricted> getWorkAssignmentRestrictedListBySso(
			Long sso);

	/**
	 * Returns Service Dates information by sso, this information belongs to
	 * Work Service Dates Data Group
	 * 
	 * @param sso
	 *            Employee SSO
	 * @return service dates model
	 */
	public ServiceDates getServiceDatesBySso(Long sso);

	/**
	 * Returns months in business that belongs to Work Assignment - Restricted
	 * Data Group
	 * 
	 * @param sso
	 *            Employee SSO
	 * @return WorkAssignmentRestricted model
	 */
	public WorkAssignmentRestricted getMonthInBusinessBySso(Long sso);

	/**
	 * Returns Direct Reports information by, this information belongs to
	 * WorkAssignmentHistroyInternal Data Group
	 * 
	 * @param sso
	 * @return employee list model by sso, this information belongs to
	 *         WorkAssignment Data Group
	 */
	public BaseModelCollection<Person> getDirectReportsListByManger(
			Long sso);

	public BaseModelCollection<Person> getDirectoryDirectReportsListByManger(Long sso);
	public BaseModelCollection<Reports> getLpList(Long sso);
	/**
	 * Returns Dotted Line Direct Reports information by, this information
	 * belongs to DottedLineDirectReports Data Group
	 * 
	 * @param sso
	 * @return employee list model by sso, this information belongs to
	 *         WorkAssignment Data Group
	 */
	public BaseModelCollection<Person> getDirectReportsListByDottedLineManger(
			Long sso);

	/**
	 * Returns Months in position
	 * 
	 * @param sso
	 * @return
	 */
	public WorkAssignmentHistortyInt getMonthsInPositionBySso(Long sso);

	/**
	 * Returns My Clients information by sso
	 * 
	 * @param sso
	 *            Employee SSO
	 * @return
	 */
	public BaseModelCollection<MyClient> getMyClientsListBySso(Long sso);

	public BaseModelCollection<Person> getContingentReportsListBySupervisor(
			Long sso);

	public WorkAssignmentRestricted getHeadCountCostCenterBySso(Long sso);
	
	public BaseModelCollection<Reports> getDirectReportsList(Long sso);
	public BaseModelCollection<Reports> getDottedLineReportsList(Long sso);
	public BaseModelCollection<Reports> getDirectoryDirectReportsList(Long sso);
	public BaseModelCollection<Reports> getDirectoryDottedLineReportsList(Long sso);
	public BaseModelCollection<Reports> getContingentReportsList(Long sso);
	
	public String getFullNameDao(Long sso);
	public WorkAssignmentRestricted getReportingOrgsBySso(Long sso);
	public WorkAssignmentRestricted getWorkRegionBySso(Long sso);
	public WorkAssignmentRestricted getHeadcountValueBySso(Long sso);
	public WorkAssignmentRestricted getProgramList(Long sso);

	public String getProfessionalSummary(Long sso);
	public boolean setProfessionalSummary(Long sso, String text);

	public LeadershipProgramAssignment getProgramAssignment(Long sso);
	
	public WorkAssignmentRestricted getCurrentPayrollBySso(Long sso);
	public BaseModelCollection<FinanceContacts> getFinanceContactsListBySso(Long sso);

}

