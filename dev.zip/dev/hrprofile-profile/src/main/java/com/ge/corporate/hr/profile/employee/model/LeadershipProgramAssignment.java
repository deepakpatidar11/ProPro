package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonWriteNullProperties;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name = "leadershipProgramAssignment")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonWriteNullProperties(value=false)
public class LeadershipProgramAssignment extends AbstractBaseModelSupport{

	private static final long serialVersionUID = 1L;

	private Long leaderSso;

	private String programShortName;

	private String leaderFullName;

	private String rotationTitle;

	private Short rotationNumber;

	private String rotationSubbusiness;

	private String subFunction;

	public Long getLeaderSso() {
		return leaderSso;
	}

	public void setLeaderSso(Long leaderSso) {
		this.leaderSso = leaderSso;
	}

	public String getProgramShortName() {
		return programShortName;
	}

	public void setProgramShortName(String programShortName) {
		this.programShortName = programShortName;
	}

	public String getLeaderFullName() {
		return leaderFullName;
	}

	public void setLeaderFullName(String leaderFullName) {
		this.leaderFullName = leaderFullName;
	}

	public String getRotationTitle() {
		return rotationTitle;
	}

	public void setRotationTitle(String rotationTitle) {
		this.rotationTitle = rotationTitle;
	}

	public Short getRotationNumber() {
		return rotationNumber;
	}

	public void setRotationNumber(Short rotationNumber) {
		this.rotationNumber = rotationNumber;
	}

	public String getRotationSubbusiness() {
		return rotationSubbusiness;
	}

	public void setRotationSubbusiness(String rotationSubbusiness) {
		this.rotationSubbusiness = rotationSubbusiness;
	}

	public String getSubFunction() {
		return subFunction;
	}

	public void setSubFunction(String subFunction) {
		this.subFunction = subFunction;
	}

}
