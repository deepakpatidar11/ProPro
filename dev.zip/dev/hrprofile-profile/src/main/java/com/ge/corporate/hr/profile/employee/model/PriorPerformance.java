/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="priorPerformance")
@XmlAccessorType(XmlAccessType.FIELD)
public class PriorPerformance extends AbstractBaseModelSupport{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 120570252065628774L;

	@XmlElement(name="sso")
	private Long sso;
	@XmlAttribute(name="id")
	private Long id;	
	@XmlElement(name="year")
	private Short year;
	@XmlElement(name="overallPerformance")
	private String overallPerformance;
	@XmlElement(name="overallGrowth")
	private String overallGrowth;
	@XmlElement(name="overallRating")
	private String overallRating;
	
	public void setId(Long id) {
		this.id = id;
	}	
	public Long getId() {
		return id;
	}	
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	public Short getYear() {
		return year;
	}
	public void setYear(Short year) {
		this.year = year;
	}
	public String getOverallPerformance() {
		return overallPerformance;
	}
	public void setOverallPerformance(String overallPerformance) {
		this.overallPerformance = overallPerformance;
	}
	public String getOverallGrowth() {
		return overallGrowth;
	}
	public void setOverallGrowth(String overallGrowth) {
		this.overallGrowth = overallGrowth;
	}
	public String getOverallRating() {
		return overallRating;
	}
	public void setOverallRating(String overallRating) {
		this.overallRating = overallRating;
	}
	
}
