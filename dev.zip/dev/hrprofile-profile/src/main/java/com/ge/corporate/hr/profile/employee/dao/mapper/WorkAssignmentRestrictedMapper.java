/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.WorkAssignmentRestricted;


public class WorkAssignmentRestrictedMapper implements RowMapper<WorkAssignmentRestricted> {
	
	public static final String DATA_BAND = "WA_BAND";
	public static final String DATA_GME_INFO_HOME_COUNTRY = "WA_GME_INFO_HOME_COUNTRY";
	public static final String DATA_POSITION_TYPE = "WA_POSITION_TYPE";	
	public static final String DATA_PAYROLL_NAME = "EMP_PAYROLL_NAME";
	public static final String DATA_PAYROLL_PROCESSOR_CODE = "EMP_PAYROLL_PROCESSOR_CODE";
	public static final String DATA_MONTHS_IN_JOB = "EMP_MONTHS_IN_JOB";	
	
	
	public WorkAssignmentRestricted mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		WorkAssignmentRestricted assignment = new WorkAssignmentRestricted();	
		
		//assignment.setBand(rs.getString(DATA_BAND));
		assignment.setJobType(rs.getString(DATA_POSITION_TYPE));
		assignment.setGmeInfoHomeCountry(rs.getString(DATA_GME_INFO_HOME_COUNTRY));
		assignment.setPayrollName(rs.getString(DATA_PAYROLL_NAME));
		assignment.setPayrollProcessorCode(rs.getString(DATA_PAYROLL_PROCESSOR_CODE));		
		assignment.setMonthsInJob(rs.getInt(DATA_MONTHS_IN_JOB));
		
		return assignment;		
	}
}
