package com.ge.corporate.hr.profile.employee.dto;

import org.apache.log4j.Logger;

public class WarmupMonitor {

	private static Logger LOG = Logger.getLogger(WarmupMonitor.class);
		
	private String mailFrom;
	private String mailTo;
	private String delaySubject;
	private String delayBody;
	private String failureSubject;
	private String failureBody;
	private int delayAlertTimeLimit; 
	private int failAlertTimeLimit;
	private int expectedReqPerSec;
	
	public String getMailFrom() {
		return mailFrom;
	}

	public void setMailFrom(String mailFrom) {
		this.mailFrom = mailFrom;
	}

	public String getMailTo() {
		return mailTo;
	}

	public void setMailTo(String mailTo) {
		this.mailTo = mailTo;
	}

	public String getDelaySubject() {
		return delaySubject;
	}

	public void setDelaySubject(String delaySubject) {
		this.delaySubject = delaySubject;
	}

	public String getDelayBody() {
		return delayBody;
	}

	public void setDelayBody(String delayBody) {
		this.delayBody = delayBody;
	}

	public String getFailureSubject() {
		return failureSubject;
	}

	public void setFailureSubject(String failureSubject) {
		this.failureSubject = failureSubject;
	}

	public String getFailureBody() {
		return failureBody;
	}

	public void setFailureBody(String failureBody) {
		this.failureBody = failureBody;
	}

	public int getDelayAlertTimeLimit() {
		return delayAlertTimeLimit;
	}

	public void setDelayAlertTimeLimit(int delayAlertTimeLimit) {
		this.delayAlertTimeLimit = delayAlertTimeLimit;
	}

	public int getFailAlertTimeLimit() {
		return failAlertTimeLimit;
	}

	public void setFailAlertTimeLimit(int failAlertTimeLimit) {
		this.failAlertTimeLimit = failAlertTimeLimit;
	}

	public int getExpectedReqPerSec() {
		return expectedReqPerSec;
	}

	public void setExpectedReqPerSec(int expectedReqPerSec) {
		this.expectedReqPerSec = expectedReqPerSec;
	}

	public void checkMonitor(WarmupStatus status, String job){
					
		if(status.getFailedSsoList()!=null & !status.getFailedSsoList().isEmpty() & 
			   status.getRuntimeSeconds() > failAlertTimeLimit & 
			   status.isSentFailureMail()==false & status.isReadyToSendFailure()==false) {
				
				status.setReadyToSendFailure(true);
				this.setFailureBody("Hi All,\n\n This is to inform you that below List of SSO have been failed " +
						"during "+job+"Warmup Process.\n\n"+
						status.getFailedSsoList().toString());
			 
				/*boolean sentFailureMail=mailService.sendMail(mailFrom, new String[]{mailTo}, 
						failureSubject,this.getFailureBody());
				
				if(sentFailureMail==true) {
					LOG.info("Failure Mail has been sent. As there are "+
							status.getFailedSsoList().size()+" SSO got failed");
						status.setSentFailureMail(true);
				}*/
		}

		if(status.getRuntimeSeconds() > delayAlertTimeLimit & 
		   status.getRequestsPerSecond()< expectedReqPerSec & 
		   status.isSendDelayMail()==false & status.isReadyToSendDelay()==false) {	
				
						status.setReadyToSendDelay(true);
						
						this.setDelayBody("Hi All,\n This is to inform you that "+job+"Warmup Process is getting executed " +
								"slowly with the rate of less than "+expectedReqPerSec+" requests per second. Currently it runs "+
								status.getRequestsPerSecond()+" requests per second.");						
						
						/*boolean sentSuccess=mailService.sendMail(mailFrom, new String[]{mailTo}, 
								delaySubject,delayBody);
						
						if(sentSuccess==true) {
							LOG.info("Delay Mail has been sent. As Requests Per Second is:"+
																status.getRequestsPerSecond());
								status.setSendDelayMail(true); 
						}*/
		}
	}
	
	public void checkBulkLoad(WarmupStatus status, String job){
		
		if(status.getBulkFailedList()!=null & !status.getBulkFailedList().isEmpty()) {
										
					this.setFailureBody("Hi All,\n\n This is to inform you that below List of Bulk load have been failed " +
							"during "+job+"Warmup Process.\n\n"+
							status.getBulkFailedList().toString());
				 
			/*		boolean sentFailureMail=mailService.sendMail(mailFrom, new String[]{mailTo}, 
							failureSubject,this.getFailureBody());
					
					if(sentFailureMail==true) {
						LOG.info("Failure Mail has been sent. As there are "+
								status.getBulkFailedList().size()+" bulk load got failed");							
					}*/
			}
	}
	

	



	public void warmUpJobFailOverAlert(WarmupStatus status, double deviation, String job){
		status.setReadyToSendFailure(true);
		String mailBody = String.format("%s WarmUp job: %s has not copied the indexes to the filesystem as the deviation of the new index from the DB is more than %.2f percent", job,status.getId(),deviation);		
		/*boolean sentSuccess = mailService.sendMail(mailFrom, new String[]{mailTo}, failureSubject, mailBody);
		if(sentSuccess==true) {
			LOG.info("Failure Mail has been sent due to "+job+" WarmUp Job Failure for DB Connection issue");
			status.setSentFailureMail(true);
		}*/
	}
}
