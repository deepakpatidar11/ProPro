/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
/**
 * 
 */
package com.ge.corporate.hr.profile.employee.dto;

import java.io.Serializable;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;


/**
 * @author francisco.blanco
 *
 */
public class AdminCacheWarmUpDto extends AbstractBaseDtoSupport implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String className = null;
	private Integer subLevels;
	private String cronExpression;
	private boolean enabled;
	
	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public Integer getSubLevels() {
		return subLevels;
	}

	public void setSubLevels(Integer subLevels) {
		this.subLevels = subLevels;
	}

	public String getCronExpression() {
		return cronExpression;
	}
	
	public void setCronExpression(String cronExpression) {
		this.cronExpression = cronExpression;
	}
	

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}


	public long getId() {
		return 0;
	}
	
	
	
	
	
}
