/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonWriteNullProperties;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="workAssignment")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonWriteNullProperties(value=false)
public class WorkAssignment extends AbstractBaseModelSupport{
	
	private static final long serialVersionUID = 46981221793287345L;
	
	@XmlElement(name="sso")
	private Long id; //SSO Id	
	@XmlAttribute(name="id")
	private Long waId;	
	@XmlElement(name="ifg")
	private String ifg;	
	
	@XmlElement(name="ifgId")
	private Long ifgId;
	
	@XmlElement(name="businessSegment")
	private String businessSegment;
	
	@XmlElement(name="businessSegmentId")
	private Long businessSegmentId;
	
	@XmlElement(name="subBusiness")
	private String subBusiness;		
	
	@XmlElement(name="subBusinessId")
	private Long subBusinessId;
	
	@XmlElement(name="org")	
	private String org;
	@XmlElement(name="orgId")	
	private Long orgId;
	@XmlElement(name="manager")	
	private Long manager;//SSO Manager
	@XmlElement(name="hrManager")
	private Long hrManager; //SSO HR MANAGER
	@XmlElement(name="localHrManager")
	private Long localHrManager;//SSO LOCAL HR MANAGER		
	@XmlElement(name="employeeType")	
	private String employeeType;
	@XmlElement(name="jobFunction")	
	private String jobFunction;
	@XmlElement(name="jobType")	
	private String jobType;
	@XmlElement(name="jobFamily")	
	private String jobFamily;
	@XmlElement(name="positionType")
	private String positionType;	
	@XmlElement(name="mobile")	
	private String mobile;	
	@XmlElement(name="dcomm")	
	private String dcomm;
	@XmlElement(name="phone")	
	private String phone;
	@XmlElement(name="email")
	private String email;		
	@XmlElement(name="address1")
	private String address1;
	@XmlElement(name="address2")	
	private String address2;
	@XmlElement(name="address3")	
	private String address3;	
	@XmlElement(name="city")	
	private String city;
	@XmlElement(name="state")
	private String state;
	@XmlElement(name="zip")	
	private String zip;
	@XmlElement(name="country")	
	private String country;
	@XmlElement(name="region")
	private String region;
	@XmlElement(name="positionTitle")	
	private String positionTitle;
	@XmlElement(name="managerName")
	private String managerName;	
	@XmlElement(name="hrManagerName")
	private String hrManagerName;
	@XmlElement(name="hrManagerName")
	private String localHrManagerName;	
	@XmlElement(name="hrManagerEmail")
	private String hrManagerEmail;
	@XmlElement(name="legalEntity")
	private String legalEntity;
	@XmlElement(name="mailstop")
	private String mailstop;
	
	@XmlElement(name="internalLocation")
	private String internalLocation;
	
	@XmlElement(name="technicalDiscipline")	
	private String technicalDiscipline;
	
	@XmlElement(name="assignmentStatus")
	private String assignmentStatus;
	
	@XmlElement(name="headcountValue")
	private String headcountValue;

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getWaId() {
		return waId;
	}
	public void setWaId(Long waId) {
		this.waId = waId;
	}
	public String getIfg() {
		return ifg;
	}				
	public void setIfg(String ifg) {
		this.ifg = ifg;
	}
	
	public String getBusinessSegment() {
		return businessSegment;
	}
	public void setBusinessSegment(String businessSegment) {
		this.businessSegment = businessSegment;
	}

	public String getPositionTitle() {
		return positionTitle;
	}
	public void setPositionTitle(String positionTitle) {
		this.positionTitle = positionTitle;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getEmployeeType() {
		return employeeType;
	}
	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}
	public String getJobFunction() {
		return jobFunction;
	}
	public void setJobFunction(String jobFunction) {
		this.jobFunction = jobFunction;
	}
	
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getJobFamily() {
		return jobFamily;
	}
	public void setJobFamily(String jobFamily) {
		this.jobFamily = jobFamily;
	}
	public String getPositionType() {
		return positionType;
	}
	public void setPositionType(String positionType) {
		this.positionType = positionType;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getDcomm() {
		return dcomm;
	}
	public void setDcomm(String dcomm) {
		this.dcomm = dcomm;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public String getSubBusiness() {
		return subBusiness;
	}
	public void setSubBusiness(String subBusiness) {
		this.subBusiness = subBusiness;
	}
	public String getOrg() {
		return org;
	}
	public void setOrg(String org) {
		this.org = org;
	}
	public Long getManager() {
		return manager;
	}
	public void setManager(Long manager) {
		this.manager = manager;
	}
	public Long getHrManager() {
		return hrManager;
	}
	public void setHrManager(Long hrManager) {
		this.hrManager = hrManager;
	}
	public Long getLocalHrManager() {
		return localHrManager;
	}
	public void setLocalHrManager(Long localHrManager) {
		this.localHrManager = localHrManager;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getAddress3() {
		return address3;
	}
	public void setAddress3(String address3) {
		this.address3 = address3;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}

	public void setHrManagerName(String hrManagerName) {
		this.hrManagerName = hrManagerName;
	}
	public String getHrManagerName() {
		return hrManagerName;
	}
	public void setLocalHrManagerName(String localHrManagerName) {
		this.localHrManagerName = localHrManagerName;
	}
	public String getLocalHrManagerName() {
		return localHrManagerName;
	}
	public void setIfgId(Long ifgId) {
		this.ifgId = ifgId;
	}
	public Long getIfgId() {
		return ifgId;
	}
	public void setBusinessSegmentId(Long businessSegmentId) {
		this.businessSegmentId = businessSegmentId;
	}
	public Long getBusinessSegmentId() {
		return businessSegmentId;
	}
	public void setSubBusinessId(Long subBusinessId) {
		this.subBusinessId = subBusinessId;
	}
	public Long getSubBusinessId() {
		return subBusinessId;
	}
	public String getLegalEntity() {
		return legalEntity;
	}
	public void setLegalEntity(String legalEntity) {
		this.legalEntity = legalEntity;
	}
	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}
	public Long getOrgId() {
		return orgId;
	}
	public String getMailstop() {
		return mailstop;
	}
	public void setMailstop(String mailstop) {
		this.mailstop = mailstop;
	}
	public String getInternalLocation() {
		return internalLocation;
	}
	public void setInternalLocation(String internalLocation) {
		this.internalLocation = internalLocation;
	}
	public String getTechnicalDiscipline() {
		return technicalDiscipline;
	}
	public void setTechnicalDiscipline(String technicalDiscipline) {
		this.technicalDiscipline = technicalDiscipline;
	}
	public String getAssignmentStatus() {
		return assignmentStatus;
	}
	public void setAssignmentStatus(String assignmentStatus) {
		this.assignmentStatus = assignmentStatus;
	}
	public String getHeadcountValue() {
		return headcountValue;
	}
	public void setHeadcountValue(String headcountValue) {
		this.headcountValue = headcountValue;
	}
	public String getHrManagerEmail() {
		return hrManagerEmail;
	}
	public void setHrManagerEmail(String hrManagerEmail) {
		this.hrManagerEmail = hrManagerEmail;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	
}
