package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.SixSigma;

public class SixSigmaMapper implements RowMapper<SixSigma> {

	public static final String DATA_SSO = "sso";
	public static final String DATA_YEAR = "year";
	public static final String DATA_NAME = "sixsigma_name";

	@Override
	public SixSigma mapRow(ResultSet rs, int rowNum) throws SQLException {
		SixSigma sixSigma = new SixSigma();
		sixSigma.setSso(rs.getLong(DATA_SSO));
		sixSigma.setYear(rs.getShort(DATA_YEAR));
		sixSigma.setName(rs.getString(DATA_NAME));

		return sixSigma;
	}

}
