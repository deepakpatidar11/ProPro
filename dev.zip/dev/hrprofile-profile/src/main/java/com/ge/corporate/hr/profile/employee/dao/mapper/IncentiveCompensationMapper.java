/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.IncentiveCompensation;
/**
 * Incentive Compensation mapper
 * @author enrique.romero
 *
 */
public class IncentiveCompensationMapper implements RowMapper<IncentiveCompensation>{
	
	public static final String DATA_PERF_YEAR = "ic_date";
	public static final String DATA_TYPE = "ic_type";
	public static final String DATA_AMMOUNT = "ic_ammount";
	public static final String DATA_CHANGE_PERCENT = "ic_change_percent";
	public static final String DATA_CURERNCY = "ic_currency";
	public static final String DATA_IS_FUTURE_DATE = "is_future_date";
	
	public IncentiveCompensation mapRow(ResultSet rs, int rowNum) throws SQLException {		
		IncentiveCompensation ic = new IncentiveCompensation();
		
		ic.setPerfYear(rs.getShort(DATA_PERF_YEAR));
		ic.setType(rs.getString(DATA_TYPE));
		ic.setAmount(rs.getLong(DATA_AMMOUNT));
		ic.setChangePercent(rs.getDouble(DATA_CHANGE_PERCENT));
		ic.setCurrency(rs.getString(DATA_CURERNCY));
		ic.setFutureDate(rs.getBoolean(DATA_IS_FUTURE_DATE));
		
		return ic;		
	}
	

}
