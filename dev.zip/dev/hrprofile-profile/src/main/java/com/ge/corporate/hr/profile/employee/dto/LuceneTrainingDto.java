package com.ge.corporate.hr.profile.employee.dto;

import java.util.Date;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;

public class LuceneTrainingDto extends AbstractBaseDtoSupport {

	private long sso;
	private String trngID;
	private String trngDescriptiom;
	private String sharedFlag;

	public long getSso() {
		return sso;
	}

	public void setSso(long sso) {
		this.sso = sso;
	}

	public String getTrngID() {
		return trngID;
	}

	public void setTrngID(String trngID) {
		this.trngID = trngID;
	}

	public String getTrngDescriptiom() {
		return trngDescriptiom;
	}

	public void setTrngDescriptiom(String trngDescriptiom) {
		this.trngDescriptiom = trngDescriptiom;
	}

	public String getSharedFlag() {
		return sharedFlag;
	}

	public void setSharedFlag(String sharedFlag) {
		this.sharedFlag = sharedFlag;
	}

	public LuceneTrainingDto(long sso, String trngID,
			String trngDescriptiom, String sharedFlag) {
		super();
		this.sso = sso;
		this.trngID = trngID;
		this.trngDescriptiom = trngDescriptiom;
		this.sharedFlag = sharedFlag;
	}

	public LuceneTrainingDto() {
		super();
	}

	@Override
	public long getId() {
		// TODO Auto-generated method stub
		return 0;
	}

}
