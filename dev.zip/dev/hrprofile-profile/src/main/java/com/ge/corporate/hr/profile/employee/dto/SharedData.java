package com.ge.corporate.hr.profile.employee.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.Education;

public class SharedData {
private Long sso;
	
	private BaseModelCollection<Education> educationList;

	@XmlElement(name="professionalSummary")
	private String professionalSummary;
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	public BaseModelCollection<Education> getEducationList() {
		return educationList;
	}
	public void setEducationList(BaseModelCollection<Education> educationList) {
		this.educationList = educationList;
	}
	
	public String getProfessionalSummary() {
		return professionalSummary;
	}
	public void setProfessionalSummary(String professionalSummary) {
		this.professionalSummary = professionalSummary;
	}

}
