/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.CareerAspiration;
import com.ge.corporate.hr.profile.employee.model.CustomerandSuppliers;
import com.ge.corporate.hr.profile.employee.model.EmployeeHistory;
import com.ge.corporate.hr.profile.employee.model.IntiativesandProject;
import com.ge.corporate.hr.profile.employee.model.ServiceDates;
import com.ge.corporate.hr.profile.employee.model.WorkAssignmentRestricted;
import com.ge.corporate.hr.profile.employee.model.WorkMobility;

@XmlRootElement(name = "employeeHistory")
@XmlAccessorType(XmlAccessType.FIELD)
public class EmployeeHistoryDto extends AbstractBaseDtoSupport {

	private static final long serialVersionUID = -3600530242896336312L;
	@XmlElement(name = "sso")
	private Long sso;
	@XmlElement(name = "shared")
	private boolean shared;
	@XmlElement(name = "serviceDates")
	private ServiceDates serviceDates;
	@XmlElement(name = "workAssignmentRestrd")
	private WorkAssignmentRestricted workAssignmentRestrd;
	@XmlElement(name = "workAssignmentHistoryInternal")
	private BaseModelCollection<EmployeeHistory> workAssignmentHistoryInternal;
	@XmlElement(name = "intiativesandProject")
	private BaseModelCollection<IntiativesandProject> intiativesandProject;
	@XmlElement(name = "newIntiativesandProject")
	private List<IntiativesandProject> newIntiativesandProject;
	@XmlElement(name = "deleteIntiativesandProject")
	private List<IntiativesandProject> deleteIntiativesandProject;
	@XmlElement(name = "customerSupplier")
	private BaseModelCollection<CustomerandSuppliers> customerSupplier;
	@XmlElement(name = "newcustomerSupplier")
	private List<CustomerandSuppliers> newcustomerSupplier;
	@XmlElement(name = "deleteCustomerSupplier")
	private List<CustomerandSuppliers> deleteCustomerSupplier;
	@XmlElement(name = "careerAspiration")
	private CareerAspiration careerAspiration;
	@XmlElement(name = "employmentHistory")
	private List<EmployeeHistory> employmentHistory;
	@XmlElement(name = "workHistoryEdit")
	private boolean workHistoryEdit;
	@XmlElement(name = "workmobility")
	private WorkMobility workMobility;
	@XmlElement(name = "careerOpportunity")
	private String careerOpportunity;

	public BaseModelCollection<CustomerandSuppliers> getCustomerSupplier() {
		return customerSupplier;
	}

	public void setCustomerSupplier(BaseModelCollection<CustomerandSuppliers> customerSupplier) {
		this.customerSupplier = customerSupplier;
	}

	public List<CustomerandSuppliers> getNewcustomerSupplier() {
		return newcustomerSupplier;
	}

	public void setNewcustomerSupplier(List<CustomerandSuppliers> newcustomerSupplier) {
		this.newcustomerSupplier = newcustomerSupplier;
	}

	public List<CustomerandSuppliers> getDeleteCustomerSupplier() {
		return deleteCustomerSupplier;
	}

	public void setDeleteCustomerSupplier(List<CustomerandSuppliers> deleteCustomerSupplier) {
		this.deleteCustomerSupplier = deleteCustomerSupplier;
	}

	public List<IntiativesandProject> getNewIntiativesandProject() {
		return newIntiativesandProject;
	}

	public void setNewIntiativesandProject(List<IntiativesandProject> newIntiativesandProject) {
		this.newIntiativesandProject = newIntiativesandProject;
	}

	public List<IntiativesandProject> getDeleteIntiativesandProject() {
		return deleteIntiativesandProject;
	}

	public void setDeleteIntiativesandProject(List<IntiativesandProject> deleteIntiativesandProject) {
		this.deleteIntiativesandProject = deleteIntiativesandProject;
	}

	public BaseModelCollection<IntiativesandProject> getIntiativesandProject() {
		return intiativesandProject;
	}

	public void setIntiativesandProject(BaseModelCollection<IntiativesandProject> intiativesandProject) {
		this.intiativesandProject = intiativesandProject;
	}

	public EmployeeHistoryDto() {
	}

	public EmployeeHistoryDto(Long sso) {
		this.sso = sso;
	}

	public long getId() {
		return sso != null ? sso.longValue() : 0;
	}

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public BaseModelCollection<EmployeeHistory> getWorkAssignmentHistoryInternal() {
		return workAssignmentHistoryInternal;
	}

	public void setWorkAssignmentHistoryInternal(BaseModelCollection<EmployeeHistory> workAssignmentHistoryInternal) {
		this.workAssignmentHistoryInternal = workAssignmentHistoryInternal;
	}

	public ServiceDates getServiceDates() {
		return serviceDates;
	}

	public void setServiceDates(ServiceDates serviceDates) {
		this.serviceDates = serviceDates;
	}

	public WorkAssignmentRestricted getWorkAssignmentRestrd() {
		return workAssignmentRestrd;
	}

	public void setWorkAssignmentRestrd(WorkAssignmentRestricted workAssignmentRestrd) {
		this.workAssignmentRestrd = workAssignmentRestrd;
	}

	public boolean getShared() {
		return shared;
	}

	public void setShared(boolean shared) {
		this.shared = shared;
	}

	public WorkMobility getWorkMobility() {
		return workMobility;
	}

	public void setWorkMobility(WorkMobility workMobility) {
		this.workMobility = workMobility;
	}

	public CareerAspiration getCareerAspiration() {
		return careerAspiration;
	}

	public void setCareerAspiration(CareerAspiration careerAspiration) {
		this.careerAspiration = careerAspiration;
	}

	public List<EmployeeHistory> getEmploymentHistory() {
		return employmentHistory;
	}

	public void setEmploymentHistory(List<EmployeeHistory> employmentHistory) {
		this.employmentHistory = employmentHistory;
	}

	public boolean isWorkHistoryEdit() {
		return workHistoryEdit;
	}

	public void setWorkHistoryEdit(boolean workHistoryEdit) {
		this.workHistoryEdit = workHistoryEdit;
	}

	public String getCareerOpportunity() {
		return careerOpportunity;
	}

	public void setCareerOpportunity(String careerOpportunity) {
		this.careerOpportunity = careerOpportunity;
	}

}
