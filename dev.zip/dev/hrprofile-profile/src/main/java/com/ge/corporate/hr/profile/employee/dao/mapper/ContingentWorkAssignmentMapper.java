package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.ContingentEmployee;

public class ContingentWorkAssignmentMapper implements RowMapper<ContingentEmployee>{

	public static final String DATA_SSO = "sso";
	public static final String DATA_PERSON_TYPE = "emp_person_type";
	public static final String DATA_TITLE = "emp_title";
	public static final String DATA_IFG = "emp_ifg";
	public static final String DATA_BS = "emp_bs";
	public static final String DATA_SB = "emp_sb";
	public static final String DATA_DEPT = "emp_dept";
	public static final String DATA_JOB_FN = "emp_job_fn";
	public static final String DATA_JOB_FMLY = "emp_job_fmly";
	public static final String DATA_SPONSOR_SSO = "emp_sponsor_sso";
	public static final String DATA_SPONSOR_NAME = "emp_sponsor_name";
	public static final String DATA_SPONSOR_FIRSTNAME = "emp_sponsor_firstname";
	public static final String DATA_SPONSOR_LASTNAME = "emp_sponsor_lastname";
	public static final String DATA_START_DATE = "emp_sso_start_date";
	public static final String DATA_END_DATE = "emp_sso_end_date";
	
	public ContingentEmployee mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		
		ContingentEmployee contingentEmployee = new ContingentEmployee();

		contingentEmployee.setSso(rs.getLong(DATA_SSO));
		contingentEmployee.setBusinessSegment(rs.getString(DATA_BS));		
		contingentEmployee.setDepartment(rs.getString(DATA_DEPT));
		contingentEmployee.setIfgName(rs.getString(DATA_IFG));
		contingentEmployee.setJobFamily(rs.getString(DATA_JOB_FMLY));
		contingentEmployee.setJobFunction(rs.getString(DATA_JOB_FN));
		contingentEmployee.setPersonType(rs.getString(DATA_PERSON_TYPE));
		contingentEmployee.setSubBusiness(rs.getString(DATA_SB));
		contingentEmployee.setTitle(rs.getString(DATA_TITLE));
		contingentEmployee.setSponsorName(rs.getString(DATA_SPONSOR_NAME));
		contingentEmployee.setSponsorFirstName(rs.getString(DATA_SPONSOR_FIRSTNAME));
		contingentEmployee.setSponsorLastName(rs.getString(DATA_SPONSOR_LASTNAME));
		contingentEmployee.setSponsorSSO(rs.getLong(DATA_SPONSOR_SSO));
		contingentEmployee.setSsoEndDate(rs.getDate(DATA_END_DATE));
		contingentEmployee.setSsoStartDate(rs.getDate(DATA_START_DATE));
		
		return contingentEmployee;
	}

}
