package com.ge.corporate.hr.profile.employee.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name="expertiseDto")
@XmlAccessorType(XmlAccessType.FIELD)
public class ExpertiseDto {
	
	@XmlElement(name = "label")
	private String label;
	
	@XmlElement(name = "id")
	private int id;
	
	@XmlElement(name = "text")
	private String text;
	
	@XmlElement(name = "tooltip")
	private String tooltip;
	
	@XmlElement(name = "children")
	private List<ExpertiseDto> children;
	
	public ExpertiseDto() {
	}

	public String getLabel() {
		return label;
	}


	public void setLabel(String label) {
		this.label = label;
	}


	public String getTooltip() {
		return tooltip;
	}


	public void setTooltip(String tooltip) {
		this.tooltip = tooltip;
	}


	public List<ExpertiseDto> getChildren() {
		return children;
	}


	public void setChildren(List<ExpertiseDto> children) {
		this.children = children;
	}


	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}
	
	public String getText() {
		return text;
	}
	
	public void setText(String text) {
		this.text = text;
	}
}
