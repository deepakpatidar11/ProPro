package com.ge.corporate.hr.profile.employee.model;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name="mentoring")
@XmlAccessorType(XmlAccessType.FIELD)
public class Mentoring {

	private Long sso;
	
	@XmlElement(name="mentor")
	private String mentor;
	
	@XmlElement(name="mentee")
	private String mentee;

	@XmlElement(name="description")
	private String description;

	@XmlElement(name="connectFlag")
	private boolean connectFlag;

	@XmlElement(name="mentorInterest")
	private List<Integer> mentorInterest;
	
	@XmlElement(name="menteeInterest")
	private List<Integer> menteeInterest;
	
	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	
	public String getMentor() {
		return mentor;
	}

	public void setMentor(String mentor) {
		this.mentor = mentor;
	}

	
	public String getMentee() {
		return mentee;
	}

	public void setMentee(String mentee) {
		this.mentee = mentee;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	public boolean getConnectFlag() {
		return connectFlag;
	}
	public void setConnectFlag(boolean connectFlag) {
		this.connectFlag = connectFlag;
	}
	public List<Integer> getMentorInterest() {
		return mentorInterest;
	}
	public void setMentorInterest(List<Integer> mentorInterest) {
		this.mentorInterest = mentorInterest;
	}
	public List<Integer> getMenteeInterest() {
		return menteeInterest;
	}
	public void setMenteeInterest(List<Integer> menteeInterest) {
		this.menteeInterest = menteeInterest;
	}
}
