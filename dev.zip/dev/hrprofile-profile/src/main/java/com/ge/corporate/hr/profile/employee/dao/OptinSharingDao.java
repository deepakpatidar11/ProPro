/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import java.util.List;

import com.ge.corporate.hr.profile.employee.model.OptinSharing;
import com.ge.corporate.hr.profile.employee.model.Property;

public interface OptinSharingDao {
	public boolean setOptinSharingDao(Long principal, String type, String value);
	public OptinSharing getOptinSharingDao(Long sso);
	public boolean hasOptinServiceAcess(Long sso, String column);
	public List<String> optinTrainingListBySSO(Long sso);
	public List<String> allTrainingListBySSO(Long sso);
	public boolean setTrainingListBySSO(Long principal, String training, boolean delete);
	public List<Property> getSharedTrainingList(Long sso);
	public boolean delOptinSharingTrnListBySso(Long sso);
	public boolean updateOptinSharing(OptinSharing optinSharing);
	public boolean insertOptinSharing(OptinSharing optinSharing);
}
