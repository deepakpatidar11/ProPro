package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;
@XmlRootElement(name="employeeExpertises")
@XmlAccessorType(XmlAccessType.FIELD)
public class EmployeeExpertise extends AbstractBaseModelSupport{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1773539267619895473L;

	@XmlElement(name="sso")
	private Long sso;
	
	@XmlElement(name="expertise")
	private Expertise expertise;
	
	@XmlElement(name="order")
	private int order;
	
	@XmlElement(name="flag")
	private String flag;
	
	@XmlElement(name="addedFrom")
	private String addedFrom;
	
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	public Expertise getExpertise() {
		return expertise;
	}
	public void setExpertise(Expertise expertise) {
		this.expertise = expertise;
	}
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getAddedFrom() {
		return addedFrom;
	}
	public void setAddedFrom(String addedFrom) {
		this.addedFrom = addedFrom;
	}
}
