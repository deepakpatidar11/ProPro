/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

// jaxb
@XmlRootElement(name="profile")
@XmlAccessorType(XmlAccessType.FIELD)
@Deprecated
public class Profile extends AbstractBaseModelSupport{

	private static final long serialVersionUID = 4760712755094392751L;
	
	public Profile() {}
	
	@XmlElement(name="sso")
	private long sso;	
	// personal info
	@XmlElement(name="firstName")
	private String firstName;
	@XmlElement(name="lastName")
	private String lastName;
	@XmlElement(name="preferedName")
	private String preferedName;	
	@XmlElement(name="birthDate")
	private Date birthDate;
	@XmlElement(name="citizenShip")
	private String citizenShip;	
	@XmlElement(name="gender")
	private String gender;
	@XmlElement(name="usEeoCategory")
	private String usEeoCategory;
	@XmlElement(name="veteranStatus")
	private String veteranStatus;	
	@XmlElement(name="mobile")
	private String mobile;	
	@XmlElement(name="dcomm")
	private String dcomm;
	@XmlElement(name="phone")
	private String phone;
	@XmlElement(name="email")
	private String email;
	
	@XmlElement(name="emergencyContact")	
	private EmergencyContact emergencyContact;
	
	// org info
	@XmlElement(name="title")
	private String title;
	@XmlElement(name="org")
	private String org;
	
	@XmlElement(name="managerSso")
	private long managerSso;
	@XmlElement(name="hrManager")
	private long hrManager;
	@XmlElement(name="localHrManager")
	private long localHrManager;
	@XmlElement(name="dottedLineManager")
	private long dottedLineManager;	
		
	@XmlElement(name="performance")
	private Performance performance;
	
	@XmlTransient
	private Profile manager;
	
	@XmlElement(name="currentEducation")	
	private Education education; // Current Education
	
	@XmlElement(name="education")	
	private List<Education> educationList = new ArrayList<Education>();
	
	@XmlElement(name="assignment")	
	private List<WorkAssignment> assignmentList = new ArrayList<WorkAssignment>();
	
	@XmlElement(name="training")
	private List<Training> trainingList = new ArrayList<Training>();
	
	@XmlElement(name="performanceAward")
	private List<LongTermPerformanceAward> longTermPerfAwardList = new ArrayList<LongTermPerformanceAward>();
	
	@XmlElement(name="compensationList")
	private List<Compensation> compensationList = new ArrayList<Compensation>();
	
	@XmlElement(name="incentiveComp")
	private List<IncentiveCompensation> incentiveCompList = new ArrayList<IncentiveCompensation>();
	
	@XmlElement(name="lumpComp")
	private List<LumpCompensation> lumpCompList = new ArrayList<LumpCompensation>();
	
	@XmlElement(name="stockOption")
	private List<StockOption> stockOptionList = new ArrayList<StockOption>();
	
	@XmlElement(name="program")
	private List<Program> programList = new ArrayList<Program>();
	
	
	public long getSso() {
		return sso;
	}	
	public void setSso(long sso) {
		this.sso = sso;
	}	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPreferedName() {
		return preferedName;
	}
	public void setPreferedName(String preferedName) {
		this.preferedName = preferedName;
	}
	public Date getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}
	public String getCitizenShip() {
		return citizenShip;
	}
	public void setCitizenShip(String citizenShip) {
		this.citizenShip = citizenShip;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getUsEeoCategory() {
		return usEeoCategory;
	}
	public void setUsEeoCategory(String usEeoCategory) {
		this.usEeoCategory = usEeoCategory;
	}
	public String getVeteranStatus() {
		return veteranStatus;
	}
	public void setVeteranStatus(String veteranStatus) {
		this.veteranStatus = veteranStatus;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getDcomm() {
		return dcomm;
	}
	public void setDcomm(String dcomm) {
		this.dcomm = dcomm;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public EmergencyContact getEmergencyContact() {
		return emergencyContact;
	}
	public void setEmergencyContact(EmergencyContact emergencyContact) {
		this.emergencyContact = emergencyContact;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getOrg() {
		return org;
	}
	public void setOrg(String org) {
		this.org = org;
	}	
	public long getManagerSso() {
		return managerSso;
	}
	public void setManagerSso(long managerSso) {
		this.managerSso = managerSso;	
	}	
	public long getHrManager() {
		return hrManager;
	}
	public void setHrManager(long hrManager) {
		this.hrManager = hrManager;
	}
	public long getLocalHrManager() {
		return localHrManager;
	}
	public void setLocalHrManager(long localHrManager) {
		this.localHrManager = localHrManager;
	}
	public long getDottedLineManager() {
		return dottedLineManager;
	}
	public void setDottedLineManager(long dottedLineManager) {
		this.dottedLineManager = dottedLineManager;
	}
	public Performance getPerformance() {
		return performance;
	}
	public void setPerformance(Performance performance) {
		this.performance = performance;
	}
	public Profile getManager() {
		return manager;
	}
	public void setManager(Profile manager) {
		this.manager = manager;
	}
	public List<Education> getEducationList() {
		return educationList;
	}
	public void setEducationList(List<Education> educationList) {
		this.educationList = educationList;
	}
	public List<WorkAssignment> getAssignmentList() {
		return assignmentList;
	}
	public void setAssignmentList(List<WorkAssignment> assignmentList) {
		this.assignmentList = assignmentList;
	}
	public List<Training> getTrainingList() {
		return trainingList;
	}
	public void setTrainingList(List<Training> trainingList) {
		this.trainingList = trainingList;
	}
	public List<LongTermPerformanceAward> getLongTermPerfAwardList() {
		return longTermPerfAwardList;
	}
	public void setLongTermPerfAwardList(
			List<LongTermPerformanceAward> longTermPerfAwardList) {
		this.longTermPerfAwardList = longTermPerfAwardList;
	}
	public List<Compensation> getCompensationList() {
		return compensationList;
	}
	public void setCompensationList(List<Compensation> compensationList) {
		this.compensationList = compensationList;
	}
	public List<IncentiveCompensation> getIncentiveCompList() {
		return incentiveCompList;
	}
	public void setIncentiveCompList(List<IncentiveCompensation> incentiveCompList) {
		this.incentiveCompList = incentiveCompList;
	}
	public List<LumpCompensation> getLumpCompList() {
		return lumpCompList;
	}
	public void setLumpCompList(List<LumpCompensation> lumpCompList) {
		this.lumpCompList = lumpCompList;
	}
	public List<StockOption> getStockOptionList() {
		return stockOptionList;
	}
	public void setStockOptionList(List<StockOption> stockOptionList) {
		this.stockOptionList = stockOptionList;
	}
	public List<Program> getProgramList() {
		return programList;
	}
	public void setProgramList(List<Program> programList) {
		this.programList = programList;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public void setEducation(Education education) {
		this.education = education;
	}
	public Education getEducation() {
		return education;
	}
	
	
	public void addEducation( Education education ) {
		this.educationList.add(education);
	}	
	public void addAssignment( WorkAssignment assignment ) {
		this.assignmentList.add(assignment);
	}
	public void addPerformanceAward( LongTermPerformanceAward performanceAward ) {
		this.longTermPerfAwardList.add(performanceAward);
	}	
	public void addTraining( Training training ) {
		this.trainingList.add(training);
	}	
	public void addCompenmsation( Compensation compensation ) {
		this.compensationList.add(compensation);
	}	
	public void addIncentiveCompenmsation( IncentiveCompensation compensation ) {
		this.incentiveCompList.add(compensation);
	}	
	public void addLumpCompensation( LumpCompensation compensation ) {
		this.lumpCompList.add(compensation);
	}
	public void addStockOption( StockOption stockOption ) {
		this.stockOptionList.add(stockOption);
	}	
	public void addProgram( Program program ) {
		this.programList.add(program);
	}
		
}
