package com.ge.corporate.hr.profile.employee.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dto.ExcelReport;
import com.ge.corporate.hr.profile.employee.model.MyCWPopulation;
import com.ge.corporate.hr.profile.employee.model.MyHrPopulation;
import com.ge.corporate.hr.profile.employee.model.WorkAssignmentRestricted;

public interface ClientListExcelDao {
	
	public BaseModelCollection<MyHrPopulation> getMyHrPopulationListBySso(
			Long sso, List<String> roles, String param, int start, int limit,
			String sortName, String sortOrder, Locale locale, String format, boolean isSuspended);

	public List<String> getMyHrPopulationRolesBySso(Long sso);

	public int getMyHrPopulationCountBySso(Long sso, List<String> roles,
			String param, boolean isSuspended);

	public double getMyHrPopulationHeadCountBySso(Long sso, List<String> roles,
			String param, boolean isSuspended);

	public BaseModelCollection<MyHrPopulation> getMyHrPopulationOthersListBySso(
			Long sso, String roles, String param, int start, int limit,
			String sortName, String sortOrder, String type, Locale locale, String format);

	public int getMyHrPopulationOthersCountBySso(Long sso, String roles,
			String param, String type);

	public double getMyHrPopulationOthersHeadCountBySso(Long sso, String roles,
			String param, String type);

	public BaseModelCollection<MyHrPopulation> getMyHrPopulationListBySsoExcel(
			Long sso, List<String> roles, String param, int start, int limit,
			String sortName, String sortOrder, Locale locale, String format, boolean isSuspended);

	public String getFullNameDao(Long sso);

	public BaseModelCollection<MyHrPopulation> getMyOrgMgrClientListBySso(
			Long sso, List<String> rel_types, String param, int start,
			int limit, String sortName, String sortOrder, Locale locale,
			String format, boolean isSuspended);
	
	public BaseModelCollection<MyHrPopulation> getMyOrgMgrClientListBySsoExcel(
			Long sso, List<String> rel_types, String param, int start,
			int limit, String sortName, String sortOrder, Locale locale,
			String format, boolean isSuspended);
	
	public int getMyOrgMgrClientListCountBySso(Long sso,
			List<String> rel_types, String param, boolean isSuspended);

	public int getMyOrgMgrClientListHeadCountBySso(Long sso,
			List<String> rel_types, String param, boolean isSuspended);

	public List<String> getMymyOrgMgrRelTypesBySso(Long sso);
	
	public BaseModelCollection<MyCWPopulation> getMyCWPopulationListBySso(
			Long sso, List<String> roles, String param, int start, int limit,
			String sortName, String sortOrder, List<String> subpersontype, String format);

	public int getMyCWPopulationCountBySso(Long sso, List<String> roles, String param, List<String> subpersontype);
	
	public BaseModelCollection<MyCWPopulation> getMyCWMgrPopulationListBySso(
			Long sso, List<String> rel_types, String param, int start, int limit,
			String sortName, String sortOrder, List<String> subpersontype, String format);

	public int getMyCWMgrPopulationCountBySso(Long sso, List<String> rel_types, String param, List<String> subpersontype);
	public List<ExcelReport> getDatagroupReport(List<ExcelReport> dataGroup,String type);

}
