/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.EmergencyContact;

/**
 * Emergency Contact Mapper
 * @author enrique.romero
 *
 */
public class EmergencyContactMapper implements RowMapper<EmergencyContact>{

	public static final String DATA_FULLNAME = "ec_full_name";
	public static final String DATA_TYPE_DESC = "ec_type_description";
	public static final String DATA_PRI_PHONE = "ec_pri_phone";
	public static final String DATA_SEC_PHONE = "ec_sec_phone";
	public static final String DATA_EMAIL = "ec_email";
	public static final String DATA_ADDRESS1 = "ec_address1";	
	public static final String DATA_ADDRESS2 = "ec_address2";
	public static final String DATA_ADDRESS3 = "ec_address3";
	public static final String DATA_CITY = "ec_city";
	public static final String DATA_STATE = "ec_state";
	public static final String DATA_COUNTRY = "ec_country";
	public static final String DATA_ZIP = "ec_zip";
	public static final String DATA_RELATIONSHIP = "ec_relationship";
	
	public static final String DATA_OWN_FULLNAME = "ec_own_cont_full_nm"; 
	public static final String DATA_OWN_TYPE_DESC = "ec_own_type_desc"; 
	public static final String DATA_OWN_PRI_PHONE = "ec_own_pri_phone";
	public static final String DATA_OWN_SEC_PHONE = "ec_own_sec_phone";
	public static final String DATA_OWN_ADDRESS1 = "ec_own_address1"; 
	public static final String DATA_OWN_ADDRESS2 = "ec_own_address2"; 
	public static final String DATA_OWN_ADDRESS3 = "ec_own_address3"; 
	public static final String DATA_OWN_CITY = "ec_own_city"; 
	public static final String DATA_OWN_STATE = "ec_own_state"; 
	public static final String DATA_OWN_COUNTRY = "ec_own_country";
	public static final String DATA_OWN_ZIP = "ec_own_zip";
	
	public EmergencyContact mapRow(ResultSet rs, int rowNum) throws SQLException {
		EmergencyContact emergencyContact = new EmergencyContact();
		
		
		emergencyContact.setFullName(rs.getString(DATA_FULLNAME));
		emergencyContact.setTypeDescription(rs.getString(DATA_TYPE_DESC));
		emergencyContact.setPrimaryPhone(rs.getString(DATA_PRI_PHONE));
		emergencyContact.setSecondaryPhone(rs.getString(DATA_SEC_PHONE));
		emergencyContact.setEmail(rs.getString(DATA_EMAIL));
		emergencyContact.setAddress1(rs.getString(DATA_ADDRESS1));
		emergencyContact.setAddress2(rs.getString(DATA_ADDRESS2));
		emergencyContact.setAddress3(rs.getString(DATA_ADDRESS3));
		emergencyContact.setCity(rs.getString(DATA_CITY));		
		emergencyContact.setState(rs.getString(DATA_STATE));
		emergencyContact.setCountry(rs.getString(DATA_COUNTRY));
		emergencyContact.setZip(rs.getString(DATA_ZIP));		
		emergencyContact.setRelationship(rs.getString(DATA_RELATIONSHIP));
				
		emergencyContact.setOwnFullName(rs.getString(DATA_OWN_FULLNAME));
		emergencyContact.setOwnTypeDescription(rs.getString(DATA_OWN_TYPE_DESC));
		emergencyContact.setOwnPrimaryPhone(rs.getString(DATA_OWN_PRI_PHONE));
		emergencyContact.setOwnSecondaryPhone(rs.getString(DATA_OWN_SEC_PHONE));
		emergencyContact.setOwnAddress1(rs.getString(DATA_OWN_ADDRESS1));
		emergencyContact.setOwnAddress2(rs.getString(DATA_OWN_ADDRESS2));
		emergencyContact.setOwnAddress3(rs.getString(DATA_OWN_ADDRESS3));
		emergencyContact.setOwnCity(rs.getString(DATA_OWN_CITY));		
		emergencyContact.setOwnState(rs.getString(DATA_OWN_STATE));
		emergencyContact.setOwnCountry(rs.getString(DATA_OWN_COUNTRY));
		emergencyContact.setOwnZip(rs.getString(DATA_OWN_ZIP));
			
		return emergencyContact;		
	}
	
}
