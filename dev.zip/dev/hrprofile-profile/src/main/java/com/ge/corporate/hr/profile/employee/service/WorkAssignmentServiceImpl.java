/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.service;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.common.service.AbstractBaseServiceSupport;
import com.ge.corporate.hr.profile.employee.dao.EmployeeDao;
import com.ge.corporate.hr.profile.employee.dao.WorkAssignmentDao;
import com.ge.corporate.hr.profile.employee.dto.AssignmentDto;
import com.ge.corporate.hr.profile.employee.dto.AssignmentHistoryDto;
import com.ge.corporate.hr.profile.employee.dto.DirectReportsDto;
import com.ge.corporate.hr.profile.employee.dto.MyClientsDto;
import com.ge.corporate.hr.profile.employee.dto.MyReportsDto;
import com.ge.corporate.hr.profile.employee.model.DottedLineManager;
import com.ge.corporate.hr.profile.employee.model.Employee;
import com.ge.corporate.hr.profile.employee.model.FinanceContacts;
import com.ge.corporate.hr.profile.employee.model.LeadershipProgramAssignment;
import com.ge.corporate.hr.profile.employee.model.MyClient;
import com.ge.corporate.hr.profile.employee.model.Person;
import com.ge.corporate.hr.profile.employee.model.PersonLevel;
import com.ge.corporate.hr.profile.employee.model.Reports;
import com.ge.corporate.hr.profile.employee.model.ServiceDates;
import com.ge.corporate.hr.profile.employee.model.WorkAssignment;
import com.ge.corporate.hr.profile.employee.model.WorkAssignmentHistortyInt;
import com.ge.corporate.hr.profile.employee.model.WorkAssignmentRestricted;
import com.ge.corporate.hr.profile.employee.service.cache.ServiceKeyGenerator;

public class WorkAssignmentServiceImpl extends AbstractBaseServiceSupport
		implements WorkAssignmentService {

	private final Log logger = LogFactory
			.getLog(WorkAssignmentServiceImpl.class);

	@Resource(name = "workAssignmentDao")
	private WorkAssignmentDao assignmentDao;

	@Resource(name = "employeeDao")
	private EmployeeDao employeeDao;

	@Cache(nodeName = "/profile/employee/service/workAssignmentService", keyGeneratorClass = ServiceKeyGenerator.class, cacheName = InfinispanCacheFactory.EMPSERVICECACHE)
	public AssignmentDto getCurrentInformation(AssignmentDto assignmentDto) {
		AssignmentDto workAssignmentDto = null;

		// Set employee information to PersonalInfoDto
		if (assignmentDto.getSso() > 0) {
			WorkAssignment workAsgnmt = null;
			WorkAssignmentRestricted workAsgnmtRestrd = null;
			WorkAssignmentRestricted localBand = null;
			WorkAssignmentRestricted leader = null;
			WorkAssignmentRestricted corpBand = null;
			WorkAssignmentRestricted costCenter = null;
			WorkAssignmentRestricted headCountCostCenter = null;
			WorkAssignmentRestricted reportingOrgs = null;
			WorkAssignmentRestricted workRegion = null;
			WorkAssignmentRestricted headCount = null;
			WorkAssignmentRestricted payroll = null;
			//WorkAssignmentRestricted profesionalSummary = null;
			DottedLineManager dottedLineMgr = null;
			
			BaseModelCollection<Person> dirRepsAsgnd = null;
			BaseModelCollection<Reports> lpList = null;
			// BaseModelCollection<Person> dirRepsEmp = null;
			BaseModelCollection<PersonLevel> dirSuperHier = null;
			BaseModelCollection<Person> dottedLine = null;
			BaseModelCollection<Person> contingentReport = null;
			BaseModelCollection<FinanceContacts> financeContacts = null;

			// WorkAssignmentHistortyInt monthsInPosition = null;
			workAssignmentDto = new AssignmentDto();
			workAssignmentDto.setSso(assignmentDto.getSso());

			// Set Work Assignment data
			if (assignmentDto.isAlstomEmployee()) {
				workAsgnmt = assignmentDao
						.getCurrentWorkAssignmentAlstomBySso(assignmentDto
								.getSso());
			} else {
				workAsgnmt = assignmentDao
						.getCurrentWorkAssignmentBySso(assignmentDto.getSso());
			}
			if (workAsgnmt == null) {
				workAsgnmt = new WorkAssignment();
			}
			workAssignmentDto.setWorkAssignment(workAsgnmt);

			// Set Dotted Line Manager
			dottedLineMgr = employeeDao.getDottedLineManagerBySso(assignmentDto
					.getSso());
			if (dottedLineMgr == null) {
				dottedLineMgr = new DottedLineManager();
			}
			workAssignmentDto.setDottedLineManager(dottedLineMgr);

			// Set Work Assignment Restricted Data
			workAsgnmtRestrd = assignmentDao
					.getCurrentWorkAssignmentRestrictedBySso(assignmentDto
							.getSso());
			if (workAsgnmtRestrd == null) {
				workAsgnmtRestrd = new WorkAssignmentRestricted();
			}
			/*
			 * monthsInPosition = assignmentDao
			 * .getMonthsInPositionBySso(assignmentDto.getSso()); if
			 * (monthsInPosition != null) {
			 * workAsgnmtRestrd.setMonthsInPosition(monthsInPosition
			 * .getMonthsInPosition()); }
			 */

			workAssignmentDto.setWorkAssignmentRestrd(workAsgnmtRestrd);

			// Set payroll
			payroll = assignmentDao.getCurrentPayrollBySso(assignmentDto
					.getSso());
			if (payroll == null) {
				payroll = new WorkAssignmentRestricted();
			}
			workAssignmentDto.setPayroll(payroll);

			// Set local band
			localBand = assignmentDao.getCurrentLocalBandBySso(assignmentDto
					.getSso());
			if (localBand == null) {
				localBand = new WorkAssignmentRestricted();
			}
			workAssignmentDto.setLocalBand(localBand);

			// Set corp band
			corpBand = assignmentDao.getCurrentCorpBandBySso(assignmentDto
					.getSso());
			if (corpBand == null) {
				corpBand = new WorkAssignmentRestricted();
			}
			workAssignmentDto.setCorporateBand(corpBand);

			// Set CostCenter
			costCenter = assignmentDao.getCurrentCostCenterBySso(assignmentDto
					.getSso());
			if (costCenter == null) {
				costCenter = new WorkAssignmentRestricted();
			}
			workAssignmentDto.setCostCenter(costCenter);

			// Set HeadCountCostCenter
			headCountCostCenter = assignmentDao
					.getHeadCountCostCenterBySso(assignmentDto.getSso());
			if (headCountCostCenter == null) {
				headCountCostCenter = new WorkAssignmentRestricted();
			}
			workAssignmentDto.setHeadCountCostCenter(headCountCostCenter);

			// Supervisor Hierarchy
			dirSuperHier = employeeDao.getSupervisorHierarchyList(assignmentDto
					.getSso());
			if (dirSuperHier == null) {
				dirSuperHier = new BaseModelCollection<PersonLevel>();
			}
			workAssignmentDto.setSuperHierarchyPerInfoList(dirSuperHier);

			// Direct reports
			if (assignmentDto.isViewSuspendedEmployees()) {
				dirRepsAsgnd = assignmentDao
						.getDirectReportsListByManger(assignmentDto.getSso());
			} else {
				dirRepsAsgnd = assignmentDao
						.getDirectoryDirectReportsListByManger(assignmentDto
								.getSso());
			}
			if (dirRepsAsgnd == null) {
				dirRepsAsgnd = new BaseModelCollection<Person>();
			}
			workAssignmentDto.setDirectReptsAssignmtList(dirRepsAsgnd);
			if (assignmentDto.isViewSuspendedEmployees()) {
				lpList = assignmentDao
						.getLpList(assignmentDto.getSso());
			} else {
				lpList = assignmentDao
						.getLpList(assignmentDto
								.getSso());
			}
			if (lpList == null) {
				lpList = new BaseModelCollection<Reports>();
			}
			workAssignmentDto.setLpList(lpList);
			
			leader = assignmentDao.getProgramList(assignmentDto
					.getSso());
			if (leader == null) {
				leader = new WorkAssignmentRestricted();
			}
			
			financeContacts=assignmentDao.getFinanceContactsListBySso(assignmentDto.getSso());
			
			if(financeContacts == null)	{
				financeContacts = new BaseModelCollection<FinanceContacts>();
			}

			workAssignmentDto.setFinanceContacts(financeContacts);		
			
			
			workAssignmentDto.setLeader(leader);
			/*
			 * if (assignmentDto.isViewSuspendedEmployees()){ dirRepsEmp =
			 * employeeDao.getDirectReportsListByManger(assignmentDto
			 * .getSso()); }else{ dirRepsEmp =
			 * employeeDao.getDirectoryDirectReportsListByManger(assignmentDto
			 * .getSso()); } if (dirRepsEmp == null) { dirRepsEmp = new
			 * BaseModelCollection<Person>(); }
			 * workAssignmentDto.setDirectReptsPerInfoList(dirRepsEmp);
			 */
			dottedLine = assignmentDao
					.getDirectReportsListByDottedLineManger(assignmentDto
							.getSso());
			if (dottedLine == null) {
				dottedLine = new BaseModelCollection<Person>();
			}
			workAssignmentDto.setDottedLineDirectReptsList(dottedLine);

			contingentReport = assignmentDao
					.getContingentReportsListBySupervisor(assignmentDto
							.getSso());
			if (contingentReport == null) {
				contingentReport = new BaseModelCollection<Person>();
			}
			workAssignmentDto.setContingentWorkerReptsList(contingentReport);

			// workAssignmentDto.setWorkAssignmentHistInt(monthsInPosition);
			
			// Set Reporting Organization
			reportingOrgs = assignmentDao
					.getReportingOrgsBySso(assignmentDto.getSso());
			if (reportingOrgs == null) {
				reportingOrgs = new WorkAssignmentRestricted();
			}
			workAssignmentDto.setReportingOrgs(reportingOrgs);
						
			// Set Work Region 
			workRegion = assignmentDao
					.getWorkRegionBySso(assignmentDto.getSso());
			if (workRegion == null) {
				workRegion = new WorkAssignmentRestricted();
			}
			workAssignmentDto.setWorkRegion(workRegion);
			
			// Set HeadCount Value
			headCount = assignmentDao
					.getHeadcountValueBySso(assignmentDto.getSso());
			if (headCount == null) {
				headCount = new WorkAssignmentRestricted();
			}
			workAssignmentDto.setHeadCount(headCount);
		} else {
			logger.error("Invalid SSO, SSO = " + assignmentDto.getSso());
		}
		return workAssignmentDto;
	}

	public AssignmentDto getConnectParams(AssignmentDto assignmentDto) {
		AssignmentDto workAssignmentDto = null;

		if (assignmentDto.getSso() > 0) {
			WorkAssignment workAsgnmt = null;
			WorkAssignmentRestricted localBand = null;
			WorkAssignmentRestricted corpBand = null;
			
			BaseModelCollection<PersonLevel> dirSuperHier = null;

			workAssignmentDto = new AssignmentDto();
			workAssignmentDto.setSso(assignmentDto.getSso());

			// Set Work Assignment data
			workAsgnmt = assignmentDao.getCurrentWorkAssignmentBySso(assignmentDto.getSso());
			if (workAsgnmt == null) {
				workAsgnmt = new WorkAssignment();
			}
			workAssignmentDto.setWorkAssignment(workAsgnmt);

			// Set local band
			localBand = assignmentDao.getCurrentLocalBandBySso(assignmentDto.getSso());
			if (localBand == null) {
				localBand = new WorkAssignmentRestricted();
			}
			workAssignmentDto.setLocalBand(localBand);

			// Set corp band
			corpBand = assignmentDao.getCurrentCorpBandBySso(assignmentDto.getSso());
			if (corpBand == null) {
				corpBand = new WorkAssignmentRestricted();
			}
			workAssignmentDto.setCorporateBand(corpBand);

			// Supervisor Hierarchy
			dirSuperHier = employeeDao.getSupervisorHierarchyList(assignmentDto.getSso());
			if (dirSuperHier == null) {
				dirSuperHier = new BaseModelCollection<PersonLevel>();
			}
			workAssignmentDto.setSuperHierarchyPerInfoList(dirSuperHier);

		} else {
			logger.error("Invalid SSO, SSO = " + assignmentDto.getSso());
		}
		return workAssignmentDto;
	}
	
	@Cache(nodeName = "/profile/employee/service/workAssignmentService", keyGeneratorClass = ServiceKeyGenerator.class, cacheName = InfinispanCacheFactory.EMPSERVICECACHE)
	public AssignmentHistoryDto getJobHistoryInformation(
			AssignmentHistoryDto assignmentDto) {
		AssignmentHistoryDto workAssigHistDto = null;

		if (assignmentDto.getSso() > 0) {
			WorkAssignmentRestricted workAssgnRestd = null;
			ServiceDates servDates = null;
			BaseModelCollection<WorkAssignmentHistortyInt> workAsgmntList = null;
			BaseModelCollection<WorkAssignmentRestricted> workAsgmntRestList = null;

			workAssigHistDto = new AssignmentHistoryDto();
			workAssigHistDto.setSso(assignmentDto.getSso());
			// Get Service Dates
			servDates = assignmentDao.getServiceDatesBySso(assignmentDto
					.getSso());
			if (servDates == null) {
				servDates = new ServiceDates();
			}
			workAssigHistDto.setServiceDates(servDates);

			// Get Month in business
			workAssgnRestd = assignmentDao
					.getMonthInBusinessBySso(assignmentDto.getSso());
			if (workAssgnRestd == null) {
				workAssgnRestd = new WorkAssignmentRestricted();
			}
			workAssigHistDto.setWorkAssignmentRestrd(workAssgnRestd);

			// Get GE Assignment History List

			// Get Work Assignment Interior List
			workAsgmntList = assignmentDao
					.getWorkAssignmentListBySso(assignmentDto.getSso());
			if (workAsgmntList == null) {
				workAsgmntList = new BaseModelCollection<WorkAssignmentHistortyInt>();
			}
			workAssigHistDto.setWorkAssigIntList(workAsgmntList);

			// Get Work Assignment Restricted List -- this list only contains
			// BAND value filled
			workAsgmntRestList = assignmentDao
					.getWorkAssignmentRestrictedListBySso(assignmentDto
							.getSso());
			if (workAsgmntRestList == null) {
				workAsgmntRestList = new BaseModelCollection<WorkAssignmentRestricted>();
			}
			workAssigHistDto.setWorkAssigRestrictdList(workAsgmntRestList);

		} else {
			logger.error("Invalid SSO, SSO = " + assignmentDto.getSso());
		}

		return workAssigHistDto;
	}

	@Cache(nodeName = "/profile/employee/service/workAssignmentService", keyGeneratorClass = ServiceKeyGenerator.class, cacheName = InfinispanCacheFactory.EMPSERVICECACHE)
	public MyClientsDto getMyClients(MyClientsDto myClientsDtoPar) {
		MyClientsDto myClientsDto = null;

		if (myClientsDtoPar.getSso() > 0) {

			BaseModelCollection<MyClient> myClientsList = null;

			myClientsDto = new MyClientsDto();
			myClientsDto.setSso(myClientsDtoPar.getSso());
			// Get Service Dates
			myClientsList = assignmentDao.getMyClientsListBySso(myClientsDto
					.getSso());
			if (myClientsList == null) {
				myClientsList = new BaseModelCollection<MyClient>();
			}
			myClientsDto.setMyClientsList(myClientsList);

		} else {
			logger.error("Invalid SSO, SSO = " + myClientsDtoPar.getSso());
		}

		return myClientsDto;
	}

	public MyReportsDto getMyReport(MyReportsDto myReportsDto) {
		MyReportsDto myReportsDtovar = null;
		if (myReportsDto.getSso() > 0) {
			BaseModelCollection<Reports> direct = null;
			BaseModelCollection<Reports> contingent = null;
			BaseModelCollection<Reports> dotted = null;
			BaseModelCollection<Reports> lpList = null;
			
			myReportsDtovar = new MyReportsDto();
			myReportsDtovar.setSso(myReportsDto.getSso());
			myReportsDtovar.setFormat(myReportsDto.getFormat());
			myReportsDtovar.setViewSuspendedEmployees(myReportsDto
					.isViewSuspendedEmployees());
			if (myReportsDtovar.isViewSuspendedEmployees()) {
				direct = assignmentDao.getDirectReportsList(myReportsDto
						.getSso());
				dotted = assignmentDao.getDottedLineReportsList(myReportsDto
						.getSso());
			} else {
				direct = assignmentDao
						.getDirectoryDirectReportsList(myReportsDto.getSso());
				dotted = assignmentDao
						.getDirectoryDottedLineReportsList(myReportsDto
								.getSso());
			}
			myReportsDtovar.setDirectReportList(direct);
			myReportsDtovar.setDottedReportList(dotted);
			contingent = assignmentDao.getContingentReportsList(myReportsDto
					.getSso());
			lpList = assignmentDao.getLpList(myReportsDto
					.getSso());
			myReportsDtovar.setContingentReportList(contingent);
			myReportsDtovar.setLpList(lpList);
		} else {
			logger.error("Invalid SSO, SSO = " + myReportsDto.getSso());
		}
		return myReportsDtovar;
	}

	public String getFullName(Long sso) {
		return assignmentDao.getFullNameDao(sso);
	}

	public void setWorkAssignmentDGDataForRepList(
			DirectReportsDto directRepsDto, Employee employee) {
		if (employee != null) {
			directRepsDto.setTitle(employee.getTitle());
		}
	}

	public void setPersonalInfoDGDataForRepList(DirectReportsDto directRepsDto,
			Employee employee) {
		if (employee != null) {
			directRepsDto.setSso(employee.getSso());
			directRepsDto.setFirstName(employee.getFirstName());
			directRepsDto.setLastName(employee.getLastName());
		}
	}



	public WorkAssignmentDao getAssignmentDao() {
		return assignmentDao;
	}

	public void setAssignmentDao(WorkAssignmentDao assignmentDao) {
		this.assignmentDao = assignmentDao;
	}

	public EmployeeDao getEmployeeDao() {
		return employeeDao;
	}

	public void setEmployeeDao(EmployeeDao employeeDao) {
		this.employeeDao = employeeDao;
	}

	@Override
	public boolean setProfessionalSummary(Long sso, String professionalSummary) {
		return assignmentDao.setProfessionalSummary(sso, professionalSummary);
	}

	public String getProfessionalSummary(Long sso) {
		String profesionalSummary = "";
		if (sso > 0) {	
			profesionalSummary=	assignmentDao.getProfessionalSummary(sso);
			if (profesionalSummary == null) {
				profesionalSummary = "";
			}
		} else {
			logger.error("Invalid SSO, SSO = " + sso);
		}
		return profesionalSummary;
	}

	@Override
	public LeadershipProgramAssignment getLeadershipAssignment(Long sso) {
		return assignmentDao.getProgramAssignment(sso);
	}

}
