/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="workAssignment")
@XmlAccessorType(XmlAccessType.FIELD)
public class WorkAssignmentHistortyInt extends AbstractBaseModelSupport{
	
	private static final long serialVersionUID = 46981221793287345L;
	
	@XmlElement(name="sso")
	private Long id; //SSO Id	
	@XmlAttribute(name="id")
	private Long waId;	
	@XmlElement(name="ifg")
	private String ifg;	
	@XmlElement(name="businessSegment")
	private String businessSegment;	
	@XmlElement(name="manager")	
	private Long manager;//SSO Manager	
	@XmlElement(name="jobFunction")	
	private String jobFunction;	
	@XmlElement(name="address1")
	private String address1;		
	@XmlElement(name="city")	
	private String city;
	@XmlElement(name="state")
	private String state;
	@XmlElement(name="zip")	
	private String zip;
	@XmlElement(name="country")	
	private String country;
	@XmlElement(name="positionTitle")	
	private String positionTitle;
	@XmlElement(name="managerName")
	private String managerName;
	
	@XmlElement(name="managerName")
	private Integer monthsInPosition;	
	
	@XmlElement(name="startDate")
	private Date startDate;
	@XmlElement(name="startDate")
	private Date endDate;
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getWaId() {
		return waId;
	}
	public void setWaId(Long waId) {
		this.waId = waId;
	}
	public String getIfg() {
		return ifg;
	}
	public void setIfg(String ifg) {
		this.ifg = ifg;
	}
	
	public String getBusinessSegment() {
		return businessSegment;
	}
	public void setBusinessSegment(String businessSegment) {
		this.businessSegment = businessSegment;
	}

	public String getPositionTitle() {
		return positionTitle;
	}
	public void setPositionTitle(String positionTitle) {
		this.positionTitle = positionTitle;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	public String getJobFunction() {
		return jobFunction;
	}
	public void setJobFunction(String jobFunction) {
		this.jobFunction = jobFunction;
	}
	
	public Long getManager() {
		return manager;
	}
	public void setManager(Long manager) {
		this.manager = manager;
	}	
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public void setMonthsInPosition(Integer monthsInPosition) {
		this.monthsInPosition = monthsInPosition;
	}
	public Integer getMonthsInPosition() {
		return monthsInPosition;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	
}
