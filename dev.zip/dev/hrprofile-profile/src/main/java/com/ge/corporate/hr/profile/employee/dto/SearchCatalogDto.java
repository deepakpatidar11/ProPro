/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;

public class SearchCatalogDto extends AbstractBaseDtoSupport {

	private static final long serialVersionUID = -4094765911965791990L;

	private StringCatalogDto ifg;

	private StringCatalogDto business;

	private StringCatalogDto function;

	private StringCatalogDto region;

	private StringCatalogDto country;

	private StringCatalogDto leadershipProgram;

	private StringCatalogDto technicalDiscipline;

	private StringCatalogDto reportingIFG;

	private StringCatalogDto reportingBusiness;

	private StringCatalogDto languages;

	private StringCatalogDto band;

	private StringCatalogDto assignmentSubBusiness;

	private StringCatalogDto assignmentLeaderFor;

	public StringCatalogDto getIfg() {
		return ifg;
	}

	public void setIfg(StringCatalogDto ifg) {
		this.ifg = ifg;
	}

	public StringCatalogDto getBusiness() {
		return business;
	}

	public void setBusiness(StringCatalogDto business) {
		this.business = business;
	}

	public StringCatalogDto getFunction() {
		return function;
	}

	public void setFunction(StringCatalogDto function) {
		this.function = function;
	}

	public StringCatalogDto getRegion() {
		return region;
	}

	public void setRegion(StringCatalogDto region) {
		this.region = region;
	}

	public StringCatalogDto getCountry() {
		return country;
	}

	public void setCountry(StringCatalogDto country) {
		this.country = country;
	}

	public StringCatalogDto getLeadershipProgram() {
		return leadershipProgram;
	}

	public void setLeadershipProgram(StringCatalogDto leadershipProgram) {
		this.leadershipProgram = leadershipProgram;
	}

	public StringCatalogDto getTechnicalDiscipline() {
		return technicalDiscipline;
	}

	public void setTechnicalDiscipline(StringCatalogDto technicalDiscipline) {
		this.technicalDiscipline = technicalDiscipline;
	}

	public StringCatalogDto getReportingIFG() {
		return reportingIFG;
	}

	public void setReportingIFG(StringCatalogDto reportingIFG) {
		this.reportingIFG = reportingIFG;
	}

	public StringCatalogDto getReportingBusiness() {
		return reportingBusiness;
	}

	public void setReportingBusiness(StringCatalogDto reportingBusiness) {
		this.reportingBusiness = reportingBusiness;
	}

	public StringCatalogDto getLanguages() {
		return languages;
	}

	public void setLanguages(StringCatalogDto languages) {
		this.languages = languages;
	}

	public StringCatalogDto getBand() {
		return band;
	}

	public void setBand(StringCatalogDto band) {
		this.band = band;
	}

	public StringCatalogDto getAssignmentSubBusiness() {
		return assignmentSubBusiness;
	}

	public void setAssignmentSubBusiness(StringCatalogDto assignmentSubBusiness) {
		this.assignmentSubBusiness = assignmentSubBusiness;
	}

	public StringCatalogDto getAssignmentLeaderFor() {
		return assignmentLeaderFor;
	}

	public void setAssignmentLeaderFor(StringCatalogDto assignmentLeaderFor) {
		this.assignmentLeaderFor = assignmentLeaderFor;
	}

	@Override
	public long getId() {
		// TODO Auto-generated method stub
		return 0;
	}

}
