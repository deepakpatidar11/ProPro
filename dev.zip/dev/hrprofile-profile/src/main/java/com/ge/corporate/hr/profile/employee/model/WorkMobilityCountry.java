package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "mobilityCountry")
@XmlAccessorType(XmlAccessType.FIELD)
public class WorkMobilityCountry {

	private Long sso;

	private String mobilityCountry;

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public String getMobilityCountry() {
		return mobilityCountry;
	}

	public void setMobilityCountry(String mobilityCountry) {
		this.mobilityCountry = mobilityCountry;
	}

}
