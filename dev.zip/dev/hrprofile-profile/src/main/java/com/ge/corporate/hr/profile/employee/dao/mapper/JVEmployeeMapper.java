package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.JVEmployee;


public class JVEmployeeMapper implements RowMapper<JVEmployee> {

	
	public static final String DATA_SSO = "sso";
	public static final String DATA_FIRST_NAME = "emp_first_name";
	public static final String DATA_LAST_NAME = "emp_last_name";
	public static final String DATA_FULL_NAME = "emp_full_name";
	public static final String DATA_ADDRESS = "emp_address";
	public static final String DATA_CITY = "emp_city";
	public static final String DATA_STATE = "emp_state";
	public static final String DATA_COUNTRY = "emp_country";
	public static final String DATA_ZIP = "emp_zip";
	public static final String DATA_EMAIL = "emp_email";
	public static final String DATA_WORK_PHONE = "emp_work_phone";
	public static final String DATA_MOBILE = "emp_mobile";
		
	
	public JVEmployee mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		
		JVEmployee jvEmployee = new JVEmployee();
		
		jvEmployee.setSso(rs.getLong(DATA_SSO));
		jvEmployee.setAddress(rs.getString(DATA_ADDRESS));	
		jvEmployee.setCity(rs.getString(DATA_CITY));
		jvEmployee.setState(rs.getString(DATA_STATE));
		jvEmployee.setCountry(rs.getString(DATA_COUNTRY));
		jvEmployee.setZip(rs.getString(DATA_ZIP));
		jvEmployee.setEmail(rs.getString(DATA_EMAIL));
		jvEmployee.setFirstName(rs.getString(DATA_FIRST_NAME));
		jvEmployee.setFullName(rs.getString(DATA_FULL_NAME));
		jvEmployee.setLastName(rs.getString(DATA_LAST_NAME));
		jvEmployee.setMobile(rs.getString(DATA_MOBILE));		
		jvEmployee.setPhone(rs.getString(DATA_WORK_PHONE));
					
		return jvEmployee;
	}

}
