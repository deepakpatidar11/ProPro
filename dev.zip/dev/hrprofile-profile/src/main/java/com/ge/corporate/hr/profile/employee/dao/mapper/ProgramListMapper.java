package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.WorkAssignmentRestricted;

public class ProgramListMapper implements RowMapper<WorkAssignmentRestricted> {
	
	public static final String DATA_PROGRAM_NAME = "PROGRAMLIST";
	public static final String DATA_SSO = "leadersso";
	
	public WorkAssignmentRestricted mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		WorkAssignmentRestricted assignment = new WorkAssignmentRestricted();	
		
		assignment.setLeader(rs.getString(DATA_PROGRAM_NAME));		
		
		return assignment;		
	}
}
