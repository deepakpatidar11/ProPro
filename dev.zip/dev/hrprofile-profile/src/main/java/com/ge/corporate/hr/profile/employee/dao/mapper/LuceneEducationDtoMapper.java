package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.dto.LuceneEducationDto;

public class LuceneEducationDtoMapper implements RowMapper<LuceneEducationDto> {

	public static final String DATA_COUNTRY = "edu_country";
	public static final String DATA_DEGREE = "edu_degree";
	public static final String DATA_MAJOR = "edu_major";
	public static final String DATA_UNIV = "edu_university";
	public static final String DATA_SSO = "sso";
	
	@Override
	public LuceneEducationDto mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		LuceneEducationDto edu = new LuceneEducationDto();
		edu.setEduCountry(rs.getString(DATA_COUNTRY));
		edu.setEduDegree(rs.getString(DATA_DEGREE));
		edu.setEduMajor(rs.getString(DATA_MAJOR));
		edu.setEduUniversity(rs.getString(DATA_UNIV));
		edu.setSso(rs.getLong(DATA_SSO));
		return edu;
	}

	
}
