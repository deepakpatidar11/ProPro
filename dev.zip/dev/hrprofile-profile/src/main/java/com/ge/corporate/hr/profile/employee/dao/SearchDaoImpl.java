/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
/**
 * 
 */
package com.ge.corporate.hr.profile.employee.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.ge.corporate.hr.profile.auth.dao.RolesAuthorityDao;
import com.ge.corporate.hr.profile.auth.util.PersonAuthUtil;
import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;
import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dao.mapper.ShortProfileListMapper;
import com.ge.corporate.hr.profile.employee.dto.EmployeeExpertiseDto;
import com.ge.corporate.hr.profile.employee.model.Expertise;
import com.ge.corporate.hr.profile.employee.model.MentoringInterest;
import com.ge.corporate.hr.profile.employee.model.ProfileUserMetrics;
import com.ge.corporate.hr.profile.employee.model.ShortProfileList;
import com.ge.corporate.hr.profile.employee.service.cache.DaoKeyGenerator;
import com.ge.corporate.hr.profile.employee.service.cache.SearchKeyGenerator;


/**
 * @author francisco.blanco
 *
 */
public class SearchDaoImpl extends AbstractBaseDaoSupport  implements SearchDao {
	@Resource(name = "rolesDao")
	RolesAuthorityDao rolesDao;
	private final String SEPARATOR_AND ="AND";
	private final String PARENTHESIS_OPEN ="(";
	private final String PARENTHESIS_CLOSE =")";
	private final String SEPARATOR_OR ="OR";
	private final String SEPARATOR_UNION ="UNION";
	public static final String ROLE_SA 	= "ROLE_SA";
	public static final String ROLE_ORGANIZATION_MANAGER = "ORG_MGR";
	public static final String ROLE_MANAGER = "MGR";
	public static final String ROLE_SUPERVISOR 	= "SUPV";
	public static final String ROLE_HRM_RECORDS 	= "HRM";
	
	
	

	@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public BaseModelCollection<String> getBusinessList() {
		BaseModelCollection<String> list = new BaseModelCollection<String>();		
		String query = this.getSql("getBusinessList");		
		try{			
			list.setList(getJdbcTemplate().queryForList(query, String.class));
			logger.debug("Business List was loaded properly in search");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("none Business was found" );
		}
		return list;		
	}
	
	@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public BaseModelCollection<String> getSubBusinessList(String bussines) {
		BaseModelCollection<String> list = new BaseModelCollection<String>();
		String query = this.getSql("getSubBusinessList");		
		try{			
			list.setList(getJdbcTemplate().queryForList(query, String.class, new Object[]{bussines}));
			logger.debug("SubBusiness List was loaded properly in search");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("none SubBusiness was found" );
		}
		return list;		
	}
	
	@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public BaseModelCollection<String> getBandList() {
		BaseModelCollection<String> list = new BaseModelCollection<String>();
		String query = this.getSql("getBandList");		
		try{			
			list.setList(getJdbcTemplate().queryForList(query, String.class));
			logger.debug("Band List was loaded properly in search");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("none Band was found" );
		}
		return list;		
	}
	
	@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public BaseModelCollection<String> getFunctionList() {
		BaseModelCollection<String> list = new BaseModelCollection<String>();
		String query = this.getSql("getFunctionList");		
		try{			
			list.setList(getJdbcTemplate().queryForList(query, String.class));
			logger.debug("Function List was loaded properly in search");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("none Function was found" );
		}
		return list;		
	}
	
	@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public BaseModelCollection<String> getJobFamilyList(String function) {
		BaseModelCollection<String> list = new BaseModelCollection<String>();
		String query = this.getSql("getJobFamilyList");		
		try{			
			list.setList(getJdbcTemplate().queryForList(query, String.class, new Object[]{function}));
			logger.debug("Job Family List was loaded properly in search");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("none Job Family was found" );
		}
		return list;		
	}
	
	@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public BaseModelCollection<String> getRegionList() {
		BaseModelCollection<String> list = new BaseModelCollection<String>();
		String query = this.getSql("getRegionList");		
		try{			
			list.setList(getJdbcTemplate().queryForList(query, String.class));
			logger.debug("Region List was loaded properly in search");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("none Region was found" );
		}
		return list;		
	}
	
	@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public BaseModelCollection<String> getCountryList() {
		BaseModelCollection<String> list = new BaseModelCollection<String>();
		String query = this.getSql("getCountryList");		
		try{			
			list.setList(getJdbcTemplate().queryForList(query, String.class));
			logger.debug("Country List was loaded properly in search");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("none Country was found" );
		}
		return list;		
	}
	
	@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public Map<String, String> getCountryCodeMap() {
		Map<String, String> countrycodemap = new HashMap<>();
		String query = this.getSql("getCountryCodeMap");		
		try{			
			SqlRowSet rowSet = null;
			
			rowSet = getJdbcTemplate().queryForRowSet(query , new Object[]{});
			while(rowSet.next()){
				countrycodemap.put(rowSet.getString("country_code"), rowSet.getString("country_label"));
			}
			
			logger.debug("Country Code Map was loaded properly in search");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("none Country Code Map was found" );
		}
		return countrycodemap;		
	}
	
	@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
    public BaseModelCollection<String> getCountryRegionList(String region) {
           BaseModelCollection<String> list = new BaseModelCollection<String>();
           String query = this.getSql("getCountryRegionList");          
           try{                 
                  list.setList(getJdbcTemplate().queryForList(query, String.class, new Object[]{region}));
                  logger.debug("Country List was loaded properly in search");                
           }catch (EmptyResultDataAccessException eex) {
                  logger.debug("none Country was found" );
           }
           return list;         
    }

	
	@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public BaseModelCollection<String> getLeadershipProgramList() {
		BaseModelCollection<String> list = new BaseModelCollection<String>();
		String query = this.getSql("getLeadershipProgramList");		
		try{			
			list.setList(getJdbcTemplate().queryForList(query, String.class));
			logger.debug("Leadership Program List was loaded properly in search");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("none Leadership Program was found" );
		}
		return list;		
	}
	
	@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public BaseModelCollection<String> getIfgList() {
		BaseModelCollection<String> list = new BaseModelCollection<String>();
		String query = this.getSql("getIfgList");		
		try{			
			list.setList(getJdbcTemplate().queryForList(query, String.class));
			logger.debug("IFG List was loaded properly in search");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("No IFG was found" );
		}
		return list;		
	}
	
	@Override
	public BaseModelCollection<Expertise> getAllExpertise() {
		BaseModelCollection<Expertise> list = new BaseModelCollection<>();
		String query = this.getSql("getAllExpertise");		
		try{			
			list.setList(getJdbcTemplate().query(query, new RowMapper<Expertise>(){
				@Override
				public Expertise mapRow(ResultSet rs, int rowNum) throws SQLException {
					Expertise expertise = new Expertise();
					expertise.setId(rs.getInt("exp_id"));
					expertise.setName(rs.getString("exp_name"));
					expertise.setParentId(rs.getInt("exp_parent"));
					return expertise;
				}}));
			logger.debug("Expertise List was loaded properly for indexing");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("No Expertise was found for indexing" );
		}
		return list;		
	}
	
	@Override
	public EmployeeExpertiseDto getExpertiseByParams(int offset, String status, String date, String expName, boolean isExcelDownload) {
		EmployeeExpertiseDto expertiseDto = new EmployeeExpertiseDto();
		String query = this.getSql("getAllExpertiseByParams");
		String countQuery = this.getSql("getCountOfExpertiseByParams");
		if(!"A".equals(status)) {
			query += "where exp_approved = '"+status+"'";
			countQuery += "where exp_approved = '"+status+"'";
			if(date != null) {
				query += " and trunc(DATE_ADDED) = to_date('"+date+"', 'DD/MM/YYYY')";
				countQuery += " and trunc(DATE_ADDED) = to_date('"+date+"', 'DD/MM/YYYY')";
			}
			if(expName != null && !expName.isEmpty()) {
				query += " and upper(EXP_NAME) like upper('%"+expName+"%')";
				countQuery += " and upper(EXP_NAME) like upper('%"+expName+"%')";
			}
		} else {
			if(date != null) {
				query += " where trunc(DATE_ADDED) = to_date('"+date+"', 'DD/MM/YYYY')";
				countQuery += " where trunc(DATE_ADDED) = to_date('"+date+"', 'DD/MM/YYYY')";
			}
			if(expName != null && !expName.isEmpty()) {
				if(date == null) {
					query += " where";
					countQuery += " where";
				} else {
					query += " and";
					countQuery += " and";
				}
				query += " upper(EXP_NAME) like upper('%"+expName+"%')";
				countQuery += " upper(EXP_NAME) like upper('%"+expName+"%')";
			}
		}
		query += " group by te.exp_id, te.exp_name, te.date_added, te.added_by, exp_approved, te.exp_parent";
		query += " order by date_added";
		if(isExcelDownload){
			String startWrapper = "select RESULTS.exp_id, RESULTS.exp_name, RESULTS.date_added, RESULTS.added_by, RESULTS.exp_approved, RESULTS.\"usedBy\", RESULTS.exp_parent, ep.EXP_NAME \"Parent_Name\" from (";
			String endWrapper = ") RESULTS left join HRPDBA01.T_EXPERTISE ep on RESULTS.exp_parent = ep.exp_id";
			query = startWrapper + query + endWrapper;
		} else {
			query += " OFFSET "+offset+" ROWS FETCH NEXT 10 ROWS ONLY";
		}
		try{
			expertiseDto.setTotalCount(getJdbcTemplate().queryForInt(countQuery));
			expertiseDto.setExpertise(getJdbcTemplate().query(query, new RowMapper<Expertise>(){
				@Override
				public Expertise mapRow(ResultSet rs, int rowNum) throws SQLException {
					Expertise expertise = new Expertise();
					expertise.setId(rs.getInt("exp_id"));
					expertise.setName(rs.getString("exp_name"));
					expertise.setAddedBy(rs.getLong("added_by"));
					expertise.setDateAdded(rs.getDate("date_added"));
					expertise.setApprovedFlag(rs.getString("exp_approved"));
					expertise.setParentId(rs.getInt("exp_parent"));
					expertise.setUsedBy(rs.getInt("usedBy"));
					if(isExcelDownload){
						expertise.setParentName(rs.getString("Parent_Name"));
					}
					return expertise;
				}}));
			logger.debug("getExpertiseByParams List was loaded properly");			
		}catch (Exception eex) {
			logger.debug("Exception in getExpertiseByParams" );
		}
		return expertiseDto;		
	}
	
	@Override
	public boolean updateExpertiseTaxo(List<Expertise> expertise) {
		String updateExp = this.getSql("updateExpertiseTaxonomy");
		String delEmpExp = this.getSql("deleteEmpExpertiseById");
		List<Expertise> deleteList = new ArrayList<>();
		int[] rowsupdated;
		
		for(Expertise exp : expertise) {
			if("R".equals(exp.getApprovedFlag())) {
				deleteList.add(exp);
			} 
		}
		
		if(expertise.size() > 0) {
			try{
				long approvedBy = PersonAuthUtil.getLoggedSSO();
				rowsupdated = getJdbcTemplate().batchUpdate(updateExp, new BatchPreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement ps, int index) throws SQLException {
					ps.setString(1, expertise.get(index).getApprovedFlag());
					ps.setInt(2, expertise.get(index).getParentId());
					ps.setLong(3, approvedBy);
					ps.setString(4, expertise.get(index).getName());
					ps.setInt(5, expertise.get(index).getId());
					
				}
				
				@Override
				public int getBatchSize() {
					return expertise.size();
				}
			});
			} catch (Exception e) {
				logger.debug("Exception in updateExpertiseTaxo" );
			}
		}
		
		if(deleteList.size() > 0) {
			try{
				rowsupdated = getJdbcTemplate().batchUpdate(delEmpExp, new BatchPreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement ps, int index) throws SQLException {
					ps.setInt(1, deleteList.get(index).getId());
				}
				
				@Override
				public int getBatchSize() {
					return deleteList.size();
				}
			});
			} catch (Exception e) {
				logger.debug("Exception in updateExpertiseTaxo while deleting" );
			}
		}
		
		return true;
	}
	
	@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public BaseModelCollection<MentoringInterest> getMentoringInterest() {
		BaseModelCollection<MentoringInterest> list = new BaseModelCollection<>();
		String query = this.getSql("getMentoringInterest");		
		try{			
			list.setList(getJdbcTemplate().query(query, new RowMapper<MentoringInterest>(){
				@Override
				public MentoringInterest mapRow(ResultSet rs, int rowNum) throws SQLException {
					MentoringInterest interest = new MentoringInterest(rs.getInt("id"), 
							rs.getString("interest_name"), rs.getString("interest_tooltip"));
					return interest;
				}}));
			logger.debug("Mentoring Interest List was loaded properly");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("No Mentoring Interest found" );
		}
		return list;		
	}
	
	@Cache(nodeName="/profile/search/acl", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public List<String> getRolesWithClientSearchAccess() {
		List<String> roleList = null;
		String query = this.getSql("getRoleListByDataGroup");	
		try{			
			roleList = getJdbcTemplate().queryForList(query, String.class, new Object[]{"WorkAssignmentRestrictedSearch"});
			logger.debug("Client Search Roles were loaded properly");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("No roles with Client Search access found" );
		}
		return roleList;
	}
	
	@Cache(nodeName="/profile/search/acl", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public List<String> getWorkAssignmentRestrictedSearchLRoles(Long sso) {
		List<String> roleList = null;
		String query = this.getSql("getRoleListByDataGroupAndSSO");	
		try{			
			roleList = getJdbcTemplate().queryForList(query, String.class, new Object[]{"WorkAssignmentRestrictedSearch",sso});
			logger.debug("Client Search Roles were loaded properly for "+sso);			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("No roles with Client Search access found for " + sso );
		}
		return roleList;
	}
	
	@Cache(nodeName="/profile/search/excel", keyGeneratorClass=DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public List<String> getRolesWithSearchExcelAccess(Long sso) {
		List<String> roleList = null;
		String query = this.getSql("getRoleListByDataGroupAndSSO");	
		try{			
			roleList = getJdbcTemplate().queryForList(query, String.class, new Object[]{"ExportSearchExcel", sso});
			logger.debug("Export Search Roles were loaded properly for "+sso);			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("No roles with Export Search access found for "+sso );
		}
		return roleList;
	}
	
	public BaseModelCollection<ShortProfileList> searchEmployeeAdvanced(Long LoggedSso,
			Long sso, String lastName, String firstName, Long managerSso, List<String> business,
			List<String> subBusiness, List<String> band, List<String> function, List<String> region,
			List<String> country, List<String> jobFamily, List<String> leadershipProgram, String leadershipProgramType) {
		
		BaseModelCollection<ShortProfileList> employeeList = new BaseModelCollection<ShortProfileList>();
		StringBuilder query = new StringBuilder( this.getSql("advancedSearchMain") );
		StringBuilder querySearchCriteria = new StringBuilder();
		
		List<Object> param = new ArrayList<Object>();		
		
		try{
			
			//Employee Name
			if( lastName != null && !lastName.equalsIgnoreCase("")){
				querySearchCriteria.append(this.getSql("advancedSearchFullName"));
				param.add(lastName + WILDCARD);
			}
			
			if( firstName != null && !firstName.equalsIgnoreCase("")){
				querySearchCriteria.append(this.getSql("advancedSearchFullName"));
				param.add(WILDCARD +" " + firstName + WILDCARD);
			}
			
			//SSO
			if(sso != null ){
				querySearchCriteria.append( this.getSql("advancedSearchSso") );
				param.add(sso.toString() + WILDCARD);
			}
			// Manager SSO
			if(managerSso != null ){
				querySearchCriteria.append( this.getSql("advancedSearchManagerSso") );
				param.add(managerSso.toString() + WILDCARD);
			}
			//Business
			if(business != null && business.size() > 0){
				querySearchCriteria.append( dynamicPlaceHolderSet(this.getSql("advancedSearchBus"), business) );
				param.addAll( business );
			}
			//Sub business
			if(subBusiness != null && subBusiness.size() > 0){
				querySearchCriteria.append( dynamicPlaceHolderSetForTuple( this.getSql("advancedSearchSubBus"), subBusiness ) );
				param.addAll(subBusiness);
			}
			//Band
			if(band != null && band.size() > 0){
				querySearchCriteria.append( dynamicPlaceHolderSet(this.getSql("advancedSearchBand"), band) );
				param.addAll(band);
			}
			//Function
			if(function != null && function.size() > 0){
				querySearchCriteria.append( dynamicPlaceHolderSet(this.getSql("advancedSearchFunction"), function) );
				param.addAll(function);
			}
			//Region
			if(region != null && region.size() > 0){
				querySearchCriteria.append( dynamicPlaceHolderSet(this.getSql("advancedSearchRegion"), region) );
				param.addAll(region);
			}
			//Country
			if(country != null && country.size() > 0){
				querySearchCriteria.append( dynamicPlaceHolderSet(this.getSql("advancedSearchCountry"), country) );
				param.addAll(country);
			}
			
			//Job Family
			if(jobFamily != null && jobFamily.size() > 0){
				querySearchCriteria.append( dynamicPlaceHolderSet(this.getSql("advancedSearchJobFamily"), jobFamily) );
				param.addAll(jobFamily);
			}
			
			//Leadership Program
			if(leadershipProgram != null && leadershipProgram.size() > 0){
				
				if(leadershipProgramType.equalsIgnoreCase("CURRENT")){
					querySearchCriteria.append( dynamicPlaceHolderSet(this.getSql("advancedSearchCurLeadershipProgram"), replaceHyphenWithComma(leadershipProgram)) );
				}else if(leadershipProgramType.equalsIgnoreCase("GRADUATED")){
					querySearchCriteria.append( dynamicPlaceHolderSet(this.getSql("advancedSearchGrdLeadershipProgram"), replaceHyphenWithComma(leadershipProgram)) );
				}else{				
					querySearchCriteria.append( dynamicPlaceHolderSet(this.getSql("advancedSearchLeadershipProgram"), replaceHyphenWithComma(leadershipProgram)) );
				}
				param.addAll(leadershipProgram);
			}
			
			//Selecting "Band" will limit the search results to only those employees that you have security model access to.
			if(band != null && band.size() > 0){
				//
				StringBuilder securitySql = new StringBuilder();
				if(!PersonAuthUtil.hasRole(ROLE_SA)){
					Map<String,Long>  rolesTypeCount = rolesDao.getRolesFilterTypeCount(LoggedSso, "WorkAssignmentRestricted");
					
					if(	rolesTypeCount.size()>0){
						for(Entry<String, Long> roleTypeCount:rolesTypeCount.entrySet()){		
							if(securitySql.length()>0){							
								securitySql.append(" "+SEPARATOR_UNION + " ");						
							}
							securitySql.append(PARENTHESIS_OPEN);							
							securitySql.append(this.getSql("getUsersByDataGroup"));
							securitySql.append(PARENTHESIS_CLOSE);
							param.add(LoggedSso);
							param.add(roleTypeCount.getKey());
							param.add(roleTypeCount.getValue());
						}
					}
					//Add Supervisor Hierarchy validation
					if(rolesTypeCount.get(ROLE_SUPERVISOR)!= null || rolesTypeCount.get(ROLE_MANAGER)!= null)
					{			
						if(securitySql.length()>0){							
							securitySql.append(" "+SEPARATOR_UNION + " ");						
						}
						securitySql.append(PARENTHESIS_OPEN);
						securitySql.append(this.getSql("getSsosReportsTo"));
						securitySql.append(PARENTHESIS_CLOSE);
						param.add(LoggedSso);							
					}
					
					if(rolesTypeCount.get(ROLE_HRM_RECORDS)!= null)
					{			
						if(securitySql.length()>0){							
							securitySql.append(" "+SEPARATOR_UNION + " ");						
						}
						securitySql.append(PARENTHESIS_OPEN);
						securitySql.append(this.getSql("getSsosHRMReportsTo"));
						securitySql.append(PARENTHESIS_CLOSE);
						param.add(LoggedSso);							
					}
					
					//Add condition query
					if(securitySql.length() > 0){
						querySearchCriteria.append(this.getSql("advancedSearchSsoSecured"));
						querySearchCriteria.append(PARENTHESIS_OPEN);
						querySearchCriteria.append(securitySql);					
						querySearchCriteria.append(PARENTHESIS_CLOSE);						
					}
					
					//applies filter for ROLE_SELF, this filter is temporal
					querySearchCriteria.append(this.getSql("advancedSearchValidateSelf"));
					param.add(LoggedSso);
					
				}else{
					logger.debug("logged user is admin");
				}
			}
			
			//Append Where Clause and search criteria
			if(querySearchCriteria.length() > 0){
				query.append(this.getSql("advancedSearchWhere"));
				query.append(querySearchCriteria.toString());
			}
			
			query.append( this.getSql("advancedSearchClosure") );
			employeeList.setList( getJdbcTemplate().query( query.toString(), param.toArray(), new ShortProfileListMapper() ));
			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("No employee was found" );
		}
		
		
		return employeeList;
	}

	@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public BaseModelCollection<String> getDisciplineList() {
		BaseModelCollection<String> list = new BaseModelCollection<String>();
		String query = this.getSql("getDisciplineList");		
		try{			
			list.setList(getJdbcTemplate().queryForList(query, String.class));
			logger.debug("Technical Discpline List was loaded properly in search");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("No Technical Discpline was found" );
		}
		return list;		
	}

	@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public BaseModelCollection<String> getReportingIfgCatalog() {
		BaseModelCollection<String> list = new BaseModelCollection<String>();
		String query = this.getSql("getReportingIFGList");		
		try{			
			list.setList(getJdbcTemplate().queryForList(query, String.class));
			logger.debug("Reporting IFG List was loaded properly in search");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("No Reporting IFG was found" );
		}
		return list;		
	}

	@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public BaseModelCollection<String> getReportingBusinessCatalog() {
		BaseModelCollection<String> list = new BaseModelCollection<String>();
		String query = this.getSql("getReportingBusinessList");		
		try{			
			list.setList(getJdbcTemplate().queryForList(query, String.class));
			logger.debug("Reporting Business List was loaded properly in search");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("No Reporting Business was found" );
		}
		return list;		
	}

	@Override
	public BaseModelCollection<String> getAssignmentLeaderFor() {
		BaseModelCollection<String> list = new BaseModelCollection<String>();
		String query = this.getSql("getAssignmentList");		
		try{			
			list.setList(getJdbcTemplate().queryForList(query, String.class));
			logger.debug("Assignment List was loaded properly in search");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Assignment was not found" );
		}
		return list;		
	}

	@Override
	public BaseModelCollection<String> getAssignmentSubBusiness() {
		BaseModelCollection<String> list = new BaseModelCollection<String>();
		String query = this.getSql("getAssignmentSubBusinessList");		
		try{			
			list.setList(getJdbcTemplate().queryForList(query, String.class));
			logger.debug("Assignment SubBusiness List was loaded properly in search");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Assignment SubBusiness not found" );
		}
		return list;		
	}
	
	@Override
	public BaseModelCollection<Long> getAllConnections(Long sso) {
		BaseModelCollection<Long> list = new BaseModelCollection<>();
		logger.debug("Fetching all Connection List");
		String query = this.getSql("getAllConnections");		
		try{			
			list.setList(getJdbcTemplate().queryForList(query, new Object[]{sso, sso}, Long.class));
			logger.debug("Connection List loaded properly");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Connection List not found" );
		}
		return list;
	}
	
	@Override
	public void addSearchMetrics(ProfileUserMetrics metrics, Map<String, Map<String, String>> search_cat_map) {
		String valueQuery = "";
		List<String> labelValueList = new ArrayList<>();

		String timeStamp = new SimpleDateFormat("dd-MMM-yy hh.mm.ss.SSS a")
				.format(new Timestamp(System.currentTimeMillis()));
		timeStamp = "to_timestamp('" + timeStamp + "', 'DD-MON-RR HH.MI.SSXFF AM')";

		for (String category : search_cat_map.keySet()) {
			String query = "insert into t_search_metrics(sso, search_date, search_category, client_search, user_business, user_function, user_region";
			valueQuery = " values(" + metrics.getSso() + ", " + timeStamp + ", '" + category + "', '" + metrics.getClientSearch() + "'";
			valueQuery += ", '" + metrics.getBusiness() + "', '" + metrics.getFunction() + "', '" + metrics.getRegion()	+ "'";

			Map<String, String> labelValueMap = search_cat_map.get(category);
			int i = 1;
			labelValueList.clear();
			for (Map.Entry<String, String> labVal : labelValueMap.entrySet()) {
				query += ", label" + i + ", value" + i;
				valueQuery += ", ?, ?";
				labelValueList.add(labVal.getKey());
				labelValueList.add(labVal.getValue());
				i++;
			}
			query = query + ") " + valueQuery + ")";

			try {
				getJdbcTemplate().update(query, labelValueList.toArray());
			} catch (Exception e) {
				logger.debug("Exception in addSearchMetrics - " + e.getMessage());
				logger.debug("Exception for Search metrics query >> " + query);
			}
		}
		metrics = null;
		search_cat_map = null;
	}
}
