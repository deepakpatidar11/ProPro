/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.service.task;

import java.net.InetAddress;
import java.util.Date;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ge.corporate.hr.profile.employee.dao.ScheduledDao;
import com.ge.corporate.hr.profile.employee.dto.WarmupStatus;
import com.ge.corporate.hr.profile.employee.service.lucene.LuceneWarmUpService;


public class LuceneIndexTaskImpl implements LuceneIndexTask{
	private static Log logger = LogFactory.getLog(LuceneIndexTaskImpl.class);
	
	private static final String LUCENE_INDEX_TYPE = "LUIX";
	private static final String CACHE_WARMUP_TYPE = "CWUP";
	
	@Resource(name="luceneWarmUpService")
	private LuceneWarmUpService luceneWarmUpService;
	
	@Resource(name="scheduledDao")
	private ScheduledDao scheduledDao;
	
	private Date lastEndDate = null;
	
	private boolean enabled = true;

	public void executeLuceneIndex() {
		if(isEnabled()){	
			logger.info("Validating Lucene Index Job " + new Date(System.currentTimeMillis()));		
			//Get date of last batch job run, and batch job should have finished.
			try {
				Date dateEnd = scheduledDao.getEndDateByType(LUCENE_INDEX_TYPE);
			
				if( (dateEnd!= null && lastEndDate == null ) || (dateEnd!= null && lastEndDate!= null && lastEndDate.compareTo(dateEnd) < 0)  ){		
					//Record Last end date
					lastEndDate = dateEnd;
					WarmupStatus ws = new WarmupStatus();
					ws = luceneWarmUpService.startLuceneWarmupJob();
					scheduledDao.startSchedule(CACHE_WARMUP_TYPE);
				}else{
					logger.info("Lucene Index Job was not be executed "  + new Date(System.currentTimeMillis()));
				}
			} catch (Exception e) {
				e.getMessage();
			}
		}
	}

	public LuceneWarmUpService getLuceneWarmUpService() {
		return luceneWarmUpService;
	}

	public void setLuceneWarmUpService(LuceneWarmUpService luceneWarmUpService) {
		this.luceneWarmUpService = luceneWarmUpService;
	}

	public ScheduledDao getScheduledDao() {
		return scheduledDao;
	}

	public void setScheduledDao(ScheduledDao scheduledDao) {
		this.scheduledDao = scheduledDao;
	}
	
	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
}
