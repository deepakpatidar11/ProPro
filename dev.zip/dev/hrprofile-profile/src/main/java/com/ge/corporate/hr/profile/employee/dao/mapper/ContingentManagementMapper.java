package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


import com.ge.corporate.hr.profile.employee.model.ContingentManagement;

public class ContingentManagementMapper implements RowMapper<ContingentManagement> {
	
	
	public static final String DATA_ACTL_RCRS= "cont_actl_rcrs";
	public static final String DATA_APRVD_RCRS = "cont_aprvd_rcrs";
	public static final String DATA_REQ_START_DT = "cont_req_start_dt";
	public static final String DATA_REQ_END_DT = "cont_req_end_dt";
	public static final String DATA_SUPPLIER = "cont_supplier";
	public static final String DATA_WRKR_TYPE = "cont_wrkr_type";
	public static final String DATA_REQ_ID = "cont_req_id";
	public static final String DATA_REQ_NAME = "cont_req_name";
	public static final String DATA_REQ_STATUS = "cont_req_status";


	public ContingentManagement mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		// TODO Auto-generated method stub
		
		ContingentManagement contingentManagement = new ContingentManagement();
		
		contingentManagement.setActlResources(rs.getString(DATA_ACTL_RCRS));
		contingentManagement.setApprvdResources(rs.getString(DATA_APRVD_RCRS));
		contingentManagement.setSupplier(rs.getString(DATA_SUPPLIER));
		contingentManagement.setWorkerType(rs.getString(DATA_WRKR_TYPE));
		contingentManagement.setWorkReqEndDate(rs.getDate(DATA_REQ_END_DT));
		contingentManagement.setWorkReqId(rs.getLong(DATA_REQ_ID));
		contingentManagement.setWorkReqName(rs.getString(DATA_REQ_NAME));
		contingentManagement.setWorkReqStartDate(rs.getDate(DATA_REQ_START_DT));
		contingentManagement.setWorkReqStatus(rs.getString(DATA_REQ_STATUS));
		return contingentManagement;
	}

}
