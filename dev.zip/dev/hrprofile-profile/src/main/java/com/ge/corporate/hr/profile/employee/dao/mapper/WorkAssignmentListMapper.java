/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.WorkAssignmentHistortyInt;

/**
 * Work assignment history mapper
 * @author enrique.romero
 *
 */

public class WorkAssignmentListMapper implements RowMapper<WorkAssignmentHistortyInt> {
	
	public static final String DATA_POSITION_TITLE = "WA_POSITION_TITLE";	
	public static final String DATA_BUSINESS_SEG = "WA_BUSINESS_SEGMENT_NAME";	
	public static final String DATA_MANAGER = "WA_MANAGER";
	public static final String DATA_MANAGER_NAME = "WA_MANAGER_NAME";
	public static final String DATA_JOB_FUNCTION = "AFUNC_LABEL";	
	public static final String DATA_ADRESS1 = "WA_ADDRESS1";
	public static final String DATA_CITY = "WA_CITY";
	public static final String DATA_STATE = "WA_STATE";
	public static final String DATA_ZIP = "WA_ZIP";
	public static final String DATA_COUNTRY = "WA_COUNTRY";
	public static final String DATA_START_DATE = "WA_START_DATE";
	
	
	public WorkAssignmentHistortyInt mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		WorkAssignmentHistortyInt assignment = new WorkAssignmentHistortyInt();		
		assignment.setPositionTitle(rs.getString(DATA_POSITION_TITLE));		
		assignment.setBusinessSegment(rs.getString(DATA_BUSINESS_SEG));			
		assignment.setManager(rs.getLong(DATA_MANAGER));
		assignment.setManagerName(rs.getString(DATA_MANAGER_NAME));		
		assignment.setJobFunction(rs.getString(DATA_JOB_FUNCTION));			
		assignment.setAddress1(rs.getString(DATA_ADRESS1));
		assignment.setCity(rs.getString(DATA_CITY));
		assignment.setState(rs.getString(DATA_STATE));
		assignment.setZip(rs.getString(DATA_ZIP));
		assignment.setCountry(rs.getString(DATA_COUNTRY));
		assignment.setStartDate(rs.getDate(DATA_START_DATE));
		
		return assignment;		
	}
}
