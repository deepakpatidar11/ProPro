/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
/**
 * 
 */
package com.ge.corporate.hr.profile.employee.dao;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;


/**
 * @author francisco.blanco
 *
 */
public class ScheduledDaoImpl extends AbstractBaseDaoSupport  implements ScheduledDao {
	
	private static final String CURRENCY_CONVERSION_RATE_LOAD_TYPE = "CUCR";
	private static final String CACHE_WARMUP_TYPE = "CWUP";
	private static final String LUCENE_INDEX_TYPE = "LUIX";
	
	/* (non-Javadoc)
	 * @see com.ge.corporate.hr.profile.employee.dao.ScheduledDAO#validateScheduledStart()
	 */
	public boolean validateScheduledStart(String type) {
		SqlRowSet row = null;
		
		final Object[] param = new Object[]{ type };
		
		try{
			String query = null;
			
			if(type.equals(CURRENCY_CONVERSION_RATE_LOAD_TYPE)){
				query = getSql("getRunningScheduled");
			}else if(type.equals(CACHE_WARMUP_TYPE)){
				query = getSql("getEndedScheduled");
			}else if(type.equals(LUCENE_INDEX_TYPE)){
				query = getSql("getEndedScheduled");
			}
			
			row = getJdbcTemplate().queryForRowSet(query, param);
			
			if(row.next()){
				logger.debug( "Scheduled Process already Started:" + type );
				return false;//return i==1 ? true:false;
			}else{
				logger.debug( "No scheduled process started for " + type + " - Starting process" );
				
				return addRunningSchedule(type) == 1 ? true:false;
			}
		}catch(EmptyResultDataAccessException eex){
			logger.debug( "Unable to load Schedule records for " + type );
		}		
		return false;
	}
	
	/**
	 * getEndDateByType 
	 * 
	 * @param type
	 *  
	 */	
	public Date getEndDateByType(String type){
		Date date = null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		String sDate;
			
		String query = getSql("getEndDateByType");
		SqlRowSet row = null;
		row  = getJdbcTemplate().queryForRowSet(query,new Object[]{ type });		
		if(row.next()){	
			sDate = row.getString("sch_end");
			
			try {
				date = (Date)dateFormat.parse(sDate);
			} catch (ParseException e) {				
				e.printStackTrace();
				return null;
			}			
			return date;
		}
		return null;	
	}
	
	private int addRunningSchedule(String type){
		
		int result = 0;
		
		final Object[] param = new Object[]{ type };
		
		try{
			String query = null;
			
			if(type.equals(CURRENCY_CONVERSION_RATE_LOAD_TYPE)){
				query = getSql("insertScheduleAsRunning");
			}else if(type.equals(CACHE_WARMUP_TYPE)){
				query = getSql("markScheduleAsStarted");
			}else if(type.equals(LUCENE_INDEX_TYPE)){
				query = getSql("markScheduleAsStarted");
			}
			
			result = getJdbcTemplate().update(query, param);
			 
		}catch (DataAccessException e) {
			logger.debug( "Could not add Schedule Data for " + type );
		}
		
		return result;
	}
	
	public void removeSchedule(String type){
		
		final Object[] param = new Object[]{ type };
		
		try{
			getJdbcTemplate().update(getSql("markScheduleAsEnded"), param);
			
		}catch (DataAccessException e) {
			logger.debug( "No Schedule Data to remove" );
		}
		
	}
	
	public void startSchedule(String type){
		
		final Object[] param = new Object[]{ type };
		
		try{
			getJdbcTemplate().update(getSql("markStartSchedule"), param);
			
		}catch (DataAccessException e) {
			logger.debug( "Task Scheduled for " +type );
		}
		
	}
	
}
