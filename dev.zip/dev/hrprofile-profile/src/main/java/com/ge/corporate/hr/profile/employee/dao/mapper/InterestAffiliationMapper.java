package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.dto.InterestAffiliationDto;

public class InterestAffiliationMapper implements RowMapper<InterestAffiliationDto>{

	public static final String DATA_SSO = "sso";
	public static final String DATA_SHARED = "shared";
	public static final String DATA_INTERESTS= "employee_interests";
	
	@Override
	public InterestAffiliationDto mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		InterestAffiliationDto interests = new InterestAffiliationDto();
		interests.setSso(rs.getLong(DATA_SSO));
		interests.setEmployeeInterests(rs.getString(DATA_INTERESTS));
		return interests;
	}

}
