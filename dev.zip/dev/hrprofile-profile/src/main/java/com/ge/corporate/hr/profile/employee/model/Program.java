/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="program")
@XmlAccessorType(XmlAccessType.FIELD)
public class Program extends AbstractBaseModelSupport{
	
	private static final long serialVersionUID = -2718913064990559594L;

	@XmlElement(name="sso")
	private Long sso;
	@XmlAttribute(name="id")
	private Long id;	
	@XmlElement(name="name")
	private String name;
	@XmlElement(name="shortName")
	private String shortName;
	@XmlElement(name="graduationYear")
	private Short graduationYear;	
	@XmlElement(name="status")
	private String status;	
	@XmlElement(name="trainingList")
	private List<Training> trainingList;
	
	public Program(){
		
	}
	public Program(Long id, String name, String shortName, String status){
		this.sso = id;
		this.name = name;
		this.shortName = shortName;
		this.status = status;
	}
	
	public void setId(Long id) {
		this.id = id;
	}	
	public Long getId() {
		return id;
	}	
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setGraduationYear(Short graduationYear) {
		this.graduationYear = graduationYear;
	}
	public Short getGraduationYear() {
		return graduationYear;
	}
	public void setTrainingList(List<Training> trainingList) {
		this.trainingList = trainingList;
	}
	public List<Training> getTrainingList() {
		return trainingList;
	}

}
