package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.Person;
import com.ge.corporate.hr.profile.employee.model.Reports;

public class LpListMapper implements RowMapper<Reports>{
	
	public static final String DATA_SSO = "sso";
	public static final String DATA_FIRST_NAME = "emp_name";
	public static final String DATA_EMAIL_ID = "EMP_EMAIL";	
	public static final String DATA_PROGRAM_NAME = "PROGRAMSHORTNAME";
	public static final String DATA_POSITION_TITLE = "ROTATIONTITLE";
	public static final String DATA_FUNCTION = "FUNCTION";
	public static final String DATA_BUSINESS = "ROTATIONBUSINESSNAME";
	public static final String DATA_SUB_BUSINESS = "ROTATIONSUBBUSINESSNAME";
	
	
	
	public Reports mapRow(ResultSet rs, int rowNum) throws SQLException {
		Reports reports = new Reports();
		
		reports.setSso(rs.getLong(DATA_SSO));
		reports.setFirstName(rs.getString(DATA_FIRST_NAME));
		reports.setEmail(rs.getString(DATA_EMAIL_ID));
		reports.setProgram(rs.getString(DATA_PROGRAM_NAME));
		reports.setPositionTitle(rs.getString(DATA_POSITION_TITLE));
		reports.setFnction(rs.getString(DATA_FUNCTION));
		reports.setBusiness(rs.getString(DATA_BUSINESS));	
		reports.setSubBusiness(rs.getString(DATA_SUB_BUSINESS));	
		return 	reports;		
	}	
}
