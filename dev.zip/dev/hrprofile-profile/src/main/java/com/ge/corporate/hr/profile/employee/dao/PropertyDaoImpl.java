/*******************************************************************************
 *
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.EmptyResultDataAccessException;

import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;
import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;
import com.ge.corporate.hr.profile.employee.dao.mapper.PropertyMapper;
import com.ge.corporate.hr.profile.employee.model.Property;
import com.ge.corporate.hr.profile.employee.service.cache.PropertyKeyGenerator;

/**
 * Performance Dao implementation
 * @author enrique.romero
 *
 */
public class PropertyDaoImpl extends AbstractBaseDaoSupport implements PropertyDao {
	private static Log logger = LogFactory.getLog(PropertyDaoImpl.class);
	
	@Cache(nodeName="/profile/properties", keyGeneratorClass=PropertyKeyGenerator.class, cacheName=InfinispanCacheFactory.PROPERTYCACHE)
	public String getByKey(String key) {
		//		
		String value = null;
		String query = this.getSql("getPropertyByKey");		
		try{
			value = getJdbcTemplate().queryForObject(query,new Object[]{key} , String.class); 
			logger.debug("Property was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Property Not found");
		}				
		return value;
	}
	
	@Cache(nodeName="/profile/properties", keyGeneratorClass=PropertyKeyGenerator.class, cacheName=InfinispanCacheFactory.PROPERTYCACHE)
	public List<Property> getList() {
		//
		List<Property> properties = null;		
		String query = this.getSql("getPropertyList");
		try{
			properties = getJdbcTemplate().query(query, new PropertyMapper());
			logger.debug("Property Map was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Property Map Not found");
		}				
		return properties;
	}
}
