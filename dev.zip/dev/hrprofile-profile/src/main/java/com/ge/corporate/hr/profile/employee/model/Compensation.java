/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;
import com.ge.corporate.hr.profile.employee.serializer.CustomDateSerializer;

/**
 * Compensation model
 * 
 * @author enrique.romero
 *
 */
@XmlRootElement(name = "compensation")
@XmlAccessorType(XmlAccessType.FIELD)
public class Compensation extends AbstractBaseModelSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4735935723290563121L;

	@XmlElement(name = "sso")
	private Long sso;
	@XmlAttribute(name = "id")
	private Long id;
	@XmlElement(name = "salary")
	private Long salary;
	@XmlElement(name = "efectiveDate")
	private Date efectiveDate;
	@XmlElement(name = "changeAmount")
	private Double changeAmount;
	@XmlElement(name = "changePercent")
	private Double changePercent;
	@XmlElement(name = "currency")
	private String currency;
	@XmlElement(name = "lumpAmount")
	private Double lumpAmmount;
	@XmlElement(name = "interval")
	private Short interval;
	@XmlElement(name = "futureDate")
	private Boolean futureDate;
	@XmlElement(name = "lump")
	private Boolean lump;
	@XmlElement(name = "salaryReasonCode")
	private String salaryReasonCode;
	public String minSalary;
	public String maxSalary;

	public String getMinSalary() {
		return minSalary;
	}

	public void setMinSalary(String minSalary) {
		this.minSalary = minSalary;
	}

	public String getMaxSalary() {
		return maxSalary;
	}

	public void setMaxSalary(String maxSalary) {
		this.maxSalary = maxSalary;
	}

	public Compensation() {
	}

	public Compensation(Long sso, Long salary, Date efectiveDate, Double changeAmount, Double changePercent,
			String currency) {
		this.sso = sso;
		this.salary = salary;
		this.efectiveDate = efectiveDate;
		this.changeAmount = changeAmount;
		this.changePercent = changePercent;
		this.currency = currency;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getId() {
		return id;
	}

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public Long getSalary() {
		return salary;
	}

	public void setSalary(Long salary) {
		this.salary = salary;
	}

	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getEfectiveDate() {
		return efectiveDate;
	}

	public void setEfectiveDate(Date efectiveDate) {
		this.efectiveDate = efectiveDate;
	}

	public Double getChangeAmount() {
		return changeAmount;
	}

	public void setChangeAmount(Double changeAmount) {
		this.changeAmount = changeAmount;
	}

	public Double getChangePercent() {
		return changePercent;
	}

	public void setChangePercent(Double changePercent) {
		this.changePercent = changePercent;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		if (currency != null) {
			this.currency = currency.trim().toUpperCase();
		}

	}

	public static Long getSerialversionuid() {
		return serialVersionUID;
	}

	public void setLumpAmmount(Double lumpAmmount) {
		this.lumpAmmount = lumpAmmount;
	}

	public Double getLumpAmmount() {
		return lumpAmmount;
	}

	public void setInterval(Short interval) {
		this.interval = interval;
	}

	public Short getInterval() {
		return interval;
	}

	public void setFutureDate(Boolean futureDate) {
		this.futureDate = futureDate;
	}

	public Boolean isFutureDate() {
		return futureDate;
	}

	public void setLump(Boolean lump) {
		this.lump = lump;
	}

	public Boolean isLump() {
		return lump;
	}

	public String getSalaryReasonCode() {
		return salaryReasonCode;
	}

	public void setSalaryReasonCode(String salaryReasonCode) {
		this.salaryReasonCode = salaryReasonCode;
	}

}
