package com.ge.corporate.hr.profile.employee.model;


import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="myClientsFlexiGrid")
@XmlAccessorType(XmlAccessType.FIELD)
public class MyClientFlexiGrid extends AbstractBaseModelSupport{
	
	private static final long serialVersionUID = 46981221793287345L;
	
	@XmlAttribute(name="sso")
	private Long sso; //SSO Id
	
	@XmlElement(name="total")
	private int total;
	
	@XmlElement(name="page")
	private int page;


	@XmlElement(name="rows")
	private ArrayList<HrClientsFlexiGridColModel> rows;
	
	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}


	
	public ArrayList<HrClientsFlexiGridColModel> getRows() {
		return rows;
	}

	public void setRows(ArrayList<HrClientsFlexiGridColModel> rows) {
		this.rows = rows;
	}


	
}
