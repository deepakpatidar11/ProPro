package com.ge.corporate.hr.profile.employee.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.AffinityGroups;
import com.ge.corporate.hr.profile.employee.model.Mentoring;
import com.ge.corporate.hr.profile.employee.model.OnlineNetwork;
@XmlRootElement(name="interestAffiliation")
@XmlAccessorType(XmlAccessType.FIELD)
public class InterestAffiliationDto extends AbstractBaseDtoSupport {

	@XmlElement(name = "sso")
	private Long sso;
	@XmlElement(name = "interestShared")
	private String interestShared;

	@XmlElement(name = "networkShared")
	private String networkShared;
	@XmlElement(name = "affiliationsShared")
	private String affiliationsShared;
	@XmlElement(name = "employeeInterests")
	private String employeeInterests;
	private BaseModelCollection<OnlineNetwork> networks;
	@XmlElement(name="onlineNetwork")
	private List<OnlineNetwork> networkList;
	private BaseModelCollection<AffinityGroups> externalGroupAffiliations;
	@XmlElement(name="affinityGroups")
	private List<AffinityGroups> externalAffiliationsList;
	@XmlElement(name="mentoring")
	private Mentoring mentoring;
	@Override
	public long getId() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public String getInterestShared() {
		return interestShared;
	}

	public void setInterestShared(String interestShared) {
		this.interestShared = interestShared;
	}

	public String getNetworkShared() {
		return networkShared;
	}

	public void setNetworkShared(String networkShared) {
		this.networkShared = networkShared;
	}

	public String getEmployeeInterests() {
		return employeeInterests;
	}

	public void setEmployeeInterests(String employeeInterests) {
		this.employeeInterests = employeeInterests;
	}

	public BaseModelCollection<OnlineNetwork> getNetworks() {
		return networks;
	}

	public void setNetworks(BaseModelCollection<OnlineNetwork> networks) {
		this.networks = networks;
	}

	public List<OnlineNetwork> getNetworkList() {
		return networkList;
	}

	public void setNetworkList(List<OnlineNetwork> networkList) {
		this.networkList = networkList;
	}

	public String getAffiliationsShared() {
		return affiliationsShared;
	}

	public void setAffiliationsShared(String affiliationsShared) {
		this.affiliationsShared = affiliationsShared;
	}

	public BaseModelCollection<AffinityGroups> getExternalGroupAffiliations() {
		return externalGroupAffiliations;
	}

	public void setExternalGroupAffiliations(
			BaseModelCollection<AffinityGroups> externalGroupAffiliations) {
		this.externalGroupAffiliations = externalGroupAffiliations;
	}

	public List<AffinityGroups> getExternalAffiliationsList() {
		return externalAffiliationsList;
	}

	public void setExternalAffiliationsList(
			List<AffinityGroups> externalAffiliationsList) {
		this.externalAffiliationsList = externalAffiliationsList;
	}

	public Mentoring getMentoring() {
		return mentoring;
	}

	public void setMentoring(Mentoring mentoring) {
		this.mentoring = mentoring;
	}
	
}
