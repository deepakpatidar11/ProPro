package com.ge.corporate.hr.profile.employee.service;

import java.util.List;

import com.ge.corporate.hr.profile.employee.dto.OrgChartDto;
import com.ge.corporate.hr.profile.employee.dto.OrgChartDirectReportsDto;

public interface OrgChartService {
	
	public List<OrgChartDirectReportsDto> getEmployeeDetailsForOrgChart(Long sso) ;
	public OrgChartDto getOrgChartBySSO(Long sso, boolean showCW, boolean toggleDirectReports);
	public OrgChartDto createOrgChartWithLucene(Long sso, Long loggedSSO, boolean showCW, boolean showLTS, List<String> rolesList, boolean toggleDirectReports, boolean viewSuspends);
	public OrgChartDto getNodeCount(Long sso, Long loggedSSO, boolean showCW, boolean showLTS, List<String> rolesList, boolean toggleDR, boolean viewSuspends);
	public OrgChartDto createOrgChartWithLuceneMobile(Long sso, Long loggedSSO, List<String> rolesList, boolean viewSuspends);

}
