/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.security.access.prepost.PreAuthorize;

import com.ge.corporate.hr.profile.auth.dao.AuthorizationDao;
import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;
import com.ge.corporate.hr.profile.common.exception.EmployeeNotFoundException;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dao.mapper.AffinityGroupsMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.AuthSupervisorHierarchyMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.ContingentEmployeeMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.ContingentManagementMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.ContingentWorkAssignmentMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.CustomerandSuppilersMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.DirectReportPerInfoMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.DisabilityIDMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.DottedLineManagerMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.EmployeeAssignmentMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.EmployeeBasicInfoMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.EmployeeExpertiseMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.EmployeeMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.EmployeeRestrictedMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.GLBTSelfIDMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.GenderCitizenshipMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.HomeAddressMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.IntiativesandProjectMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.JVEmployeeMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.JVWorkAssignmentMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.LPBridgeAssignmentMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.LanguageProficicencyMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.LuceneEducationDtoMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.LuceneEmpHistoryMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.LuceneLeadershipDtoMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.LuceneSearchCompListMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.LuceneTrainingDtoMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.ProfileCompletenessMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.SearchCompListMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.ShortProfileListMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.ShortProfileMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.SuperHierarchyPerInfoMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.UserInfoMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.WorkMobilityCountryMapper;
import com.ge.corporate.hr.profile.employee.dto.LuceneEducationDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneEmpHistoryDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneLeadershipDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneSearchCompDto;
import com.ge.corporate.hr.profile.employee.dto.LuceneTrainingDto;
import com.ge.corporate.hr.profile.employee.dto.ProfessionalSummaryDto;
import com.ge.corporate.hr.profile.employee.dto.SearchCompDto;
import com.ge.corporate.hr.profile.employee.model.AffinityGroups;
import com.ge.corporate.hr.profile.employee.model.AuthoritySupervisorHierarchy;
import com.ge.corporate.hr.profile.employee.model.ContingentEmployee;
import com.ge.corporate.hr.profile.employee.model.ContingentManagement;
import com.ge.corporate.hr.profile.employee.model.CustomerandSuppliers;
import com.ge.corporate.hr.profile.employee.model.DottedLineManager;
import com.ge.corporate.hr.profile.employee.model.Employee;
import com.ge.corporate.hr.profile.employee.model.EmployeeAssignment;
import com.ge.corporate.hr.profile.employee.model.EmployeeExpertise;
import com.ge.corporate.hr.profile.employee.model.EmployeeRestricted;
import com.ge.corporate.hr.profile.employee.model.Expertise;
import com.ge.corporate.hr.profile.employee.model.HomeAddress;
import com.ge.corporate.hr.profile.employee.model.IntiativesandProject;
import com.ge.corporate.hr.profile.employee.model.JVEmployee;
import com.ge.corporate.hr.profile.employee.model.LPBridgeAssignment;
import com.ge.corporate.hr.profile.employee.model.LanguageProficiency;
import com.ge.corporate.hr.profile.employee.model.Mentoring;
import com.ge.corporate.hr.profile.employee.model.Person;
import com.ge.corporate.hr.profile.employee.model.PersonLevel;
import com.ge.corporate.hr.profile.employee.model.ProfileCompleteness;
import com.ge.corporate.hr.profile.employee.model.ProfileUserMetrics;
import com.ge.corporate.hr.profile.employee.model.ShortProfile;
import com.ge.corporate.hr.profile.employee.model.ShortProfileList;
import com.ge.corporate.hr.profile.employee.model.UserInfo;
import com.ge.corporate.hr.profile.employee.model.WorkMobilityCountry;
import com.ge.corporate.hr.profile.employee.service.cache.DaoKeyGenerator;
import com.ge.corporate.hr.profile.employee.service.cache.SearchKeyGenerator;


/**
 * Employee Dao Implementation, 
 * @author enrique.romero
 *
 */
public class EmployeeDaoImpl extends AbstractBaseDaoSupport  implements EmployeeDao {
	private static Log logger = LogFactory.getLog(EmployeeDaoImpl.class);
	
	@Resource(name = "authDao")
	private AuthorizationDao authDao;
		
	@Cache(nodeName="/profile/employee/dao/employee", keyGeneratorClass = DaoKeyGenerator.class, cacheName="profile-employee-dao")
	@PreAuthorize("hasPermission(#sso, 'PersonalIdentification', read)")
	public Employee getEmployeeBySso(Long sso) {
		
		Employee employee = new Employee();
		String query = this.getSql("loadEmloyeeBySso");		
		try{			
			//Get Employee 
			employee = getJdbcTemplate().queryForObject(query, new Object[]{sso}, new EmployeeMapper());
			logger.debug("Employee data was loaded susscesfully");			
		}catch (EmptyResultDataAccessException eex) {
			throw new EmployeeNotFoundException("Employee data not found for "+sso);
		}				
		return employee;		
	}
	
	@Cache(nodeName="/profile/employee/dao/contingentworker", keyGeneratorClass = DaoKeyGenerator.class, cacheName="profile-employee-dao")
	public ContingentEmployee getContEmployeeBySso(Long sso) {
		
		ContingentEmployee employee = new ContingentEmployee();
		String query = this.getSql("loadContEmloyeeBySso");		
		try{			
			//Get Employee 
			employee = getJdbcTemplate().queryForObject(query, new Object[]{sso}, new ContingentEmployeeMapper());
			logger.debug("Employee data was loaded susscesfully");			
		}catch (EmptyResultDataAccessException eex) {
			throw new EmployeeNotFoundException("Employee data not found for "+sso);
		}				
		return employee;		
	}
	
	@Cache(nodeName="/profile/employee/dao/contingentworker", keyGeneratorClass = DaoKeyGenerator.class, cacheName="profile-employee-dao")
	public ContingentEmployee getContWorkAssgnmtbySso(Long sso) {
		
		ContingentEmployee employee = new ContingentEmployee();
		String query = this.getSql("loadContWorkAssgnmtbySso");		
		try{			
			//Get Employee 
			employee = getJdbcTemplate().queryForObject(query, new Object[]{sso}, new ContingentWorkAssignmentMapper());
			logger.debug("Work Assignment data was loaded susscesfully");			
		}catch (EmptyResultDataAccessException eex) {
			throw new EmployeeNotFoundException("Work Assignment data not found for "+sso);
		}				
		return employee;		
	}
	
	@Cache(nodeName="/profile/employee/dao/contingentworker", keyGeneratorClass = DaoKeyGenerator.class, cacheName="profile-employee-dao")
	@PreAuthorize("hasPermission(#sso, 'CWManagement', read)")
	public ContingentManagement getContManagement(Long sso) {
		
		BaseModelCollection<ContingentManagement> contingentList = new BaseModelCollection<ContingentManagement>();
		ContingentManagement contingentManagement = new ContingentManagement();
		String query = getSql("loadContManagementbySso");		
		try{			
			//Get Employee 
			//if(authDao.hasWorkRequest(sso)){
			contingentList.setList(getJdbcTemplate().query(query, new Object[]{sso}, new ContingentManagementMapper()));
			if (contingentList.isEmpty()) {
				contingentManagement= null;
		    } else {
		    	contingentManagement= contingentList.get(0);
		    }
			logger.debug("Contingent Management data was loaded susscesfully");	
			//}
		}catch (EmptyResultDataAccessException eex) {
			throw new EmployeeNotFoundException("Contingent Management data not found for "+sso);
		}				
		return contingentManagement;		
	}
	
	@Cache(nodeName="/profile/employee/dao/employee", keyGeneratorClass = DaoKeyGenerator.class, cacheName="profile-employee-dao")
	@PreAuthorize("hasPermission(#sso, 'PersonalIdentificationRestricted', read)")
	public EmployeeRestricted getEmployeeRestrictedBySso(Long sso) {
		
		EmployeeRestricted employeeRestd = new EmployeeRestricted() ;
		String query = this.getSql("getEmployeeRestrictedBySso");		
		try{			
			//Get Employee 
			employeeRestd = getJdbcTemplate().queryForObject(query, new Object[]{sso}, new EmployeeRestrictedMapper());
			logger.debug("Employee Restricted data was loaded susscesfully");			
		}catch (EmptyResultDataAccessException eex) {			
			throw new EmptyResultDataAccessException("Employee Data not found " + sso, 1);
		}				
		return employeeRestd;		
	}
	
	@Cache(nodeName="/profile/employee/dao/employee", keyGeneratorClass = DaoKeyGenerator.class, cacheName="profile-employee-dao")
	@PreAuthorize("hasPermission(#sso, 'GenderCitizenship', read)")
	public EmployeeRestricted getGenderCitizenshipBySso(Long sso) {
		
		EmployeeRestricted genderCitizen = new EmployeeRestricted() ;
		String query = this.getSql("getEmployeeRestrictedBySso");		
		try{			
			//Get Employee 
			genderCitizen = getJdbcTemplate().queryForObject(query, new Object[]{sso}, new GenderCitizenshipMapper());
			logger.debug("Employee Restricted data was loaded susscesfully");			
		}catch (EmptyResultDataAccessException eex) {			
			throw new EmptyResultDataAccessException("Employee Data not found " + sso, 1);
		}				
		return genderCitizen;		
	}
	
	@Cache(nodeName="/profile/employee/dao/employee", keyGeneratorClass = DaoKeyGenerator.class, cacheName="profile-employee-dao")
	@PreAuthorize("hasPermission(#sso, 'DisabilitySelfID', read)")
	public EmployeeRestricted getDisabilityIdBySso(Long sso) {
		
		EmployeeRestricted genderCitizen = new EmployeeRestricted() ;
		String query = this.getSql("getDisabilityIdBySso");		
		try{			
			//Get Employee 
			genderCitizen = getJdbcTemplate().queryForObject(query, new Object[]{sso}, new DisabilityIDMapper());
			logger.debug("Employee Restricted data was loaded susscesfully");			
		}catch (EmptyResultDataAccessException eex) {			
			throw new EmptyResultDataAccessException("Employee Data not found " + sso, 1);
		}				
		return genderCitizen;		
	}
	
	@Cache(nodeName="/profile/employee/dao/employee", keyGeneratorClass = DaoKeyGenerator.class, cacheName="profile-employee-dao")
	@PreAuthorize("hasPermission(#sso, 'GLBTSelfIdentification', read)")
	public EmployeeRestricted getGLBTSelfIdBySso(Long sso) {
		
		EmployeeRestricted genderCitizen = new EmployeeRestricted() ;
		String query = this.getSql("getGLBTSelfIdBySso");		
		try{			
			//Get Employee 
			genderCitizen = getJdbcTemplate().queryForObject(query, new Object[]{sso}, new GLBTSelfIDMapper());
			logger.debug("Employee Restricted data was loaded susscesfully");			
		}catch (EmptyResultDataAccessException eex) {			
			throw new EmptyResultDataAccessException("Employee Data not found " + sso, 1);
		}				
		return genderCitizen;		
	}
	
	@Cache(nodeName="/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName="profile-employee-dao")
	@PreAuthorize("hasPermission(#sso, 'PersonalIdentification', read)")
	public BaseModelCollection<PersonLevel> getSupervisorHierarchyList(Long sso) {
		
		BaseModelCollection<PersonLevel> employeeList = new BaseModelCollection<PersonLevel>();
		String query = this.getSql("getSupervisorHierarchyBySso");		
		try{
			//get direct reports
 			employeeList.setList(getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new SuperHierarchyPerInfoMapper()));
			logger.debug("Supervisor Hierarchy data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Supervisor Hierarchy data Not found");
		}
		
		return employeeList;					
	}
	
	@Cache(nodeName="/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName="profile-employee-dao")
	@PreAuthorize("hasPermission(#sso, 'PersonalIdentification', read)")
	public BaseModelCollection<Person> getDirectReportsListByManger(Long sso) {
		
		BaseModelCollection<Person> employeeList = new BaseModelCollection<Person>();
		String query = this.getSql("getDirectReportsListByManger");		
		try{
			//get direct reports
 			employeeList.setList(getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new DirectReportPerInfoMapper()));
			logger.debug("Direct reports data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Direct reports data Not found");
		}
		
		return employeeList;					
	}
	
	@Cache(nodeName="/profile/employee/dao/workAssignment", keyGeneratorClass = DaoKeyGenerator.class, cacheName="profile-employee-dao")
	@PreAuthorize("hasPermission(#sso, 'PersonalIdentification', read)")
	public BaseModelCollection<Person> getDirectoryDirectReportsListByManger(Long sso) {
		
		BaseModelCollection<Person> employeeList = new BaseModelCollection<Person>();
		String query = this.getSql("getDirectoryDirectReportsListByManger");		
		try{
			//get direct reports
 			employeeList.setList(getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new DirectReportPerInfoMapper()));
			logger.debug("Direct reports data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Direct reports data Not found");
		}
		
		return employeeList;					
	}
	
	
	@Cache(nodeName="/profile/employee/dao/search", keyGeneratorClass = SearchKeyGenerator.class, cacheName="profile-employee-dao")
	public BaseModelCollection<ShortProfile> searchEmployeeByParam(String param) {
		BaseModelCollection<ShortProfile> employeeList = new BaseModelCollection<ShortProfile>();
		String query = this.getSql("searchEmloyeeByParam");		
		try{			
			employeeList.setList(getJdbcTemplate().query(query, new Object[]{param + "%",param + "%",param + "%",param + "%"}, new ShortProfileMapper()));
			logger.debug("Search data was loaded susscesfully");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Search data not found: " + param);			
		}				
		return employeeList;		
	}
	
	@Cache(nodeName="/profile/employee/dao/search", keyGeneratorClass = DaoKeyGenerator.class, cacheName="profile-employee-dao")
	public BaseModelCollection<ShortProfile> searchEmployeeByParam(Long param) {
		return searchEmployeeByParam(param.toString());
	}
	
	@Cache(nodeName="/profile/employee/dao/search", keyGeneratorClass = SearchKeyGenerator.class, cacheName="profile-employee-dao")
	public BaseModelCollection<ShortProfile> searchEmployeeByParamOrderBySso(String param) {
		BaseModelCollection<ShortProfile> employeeList = new BaseModelCollection<ShortProfile>();
		String query = this.getSql("searchEmployeeByParamOrderBySso");
		try{
			if(param.length()>=9){
				query=query.replace("es.sso >= ? and es.sso <= ?", "es.sso = ?");
				employeeList.setList(getJdbcTemplate().query(query, new Object[]{param}, new ShortProfileMapper()));
			}else{
				String param1, param2;
				param1 = StringUtils.rightPad(param, 9, "0");
				param2 = StringUtils.rightPad(param, 9, "9");
				employeeList.setList(getJdbcTemplate().query(query, new Object[]{param1, param2}, new ShortProfileMapper()));
			}
			logger.debug("Search data was loaded susscesfully");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Search data not found: " + param);			
		}				
		return employeeList;		
	}
	
	@Cache(nodeName="/profile/employee/dao/search", keyGeneratorClass = SearchKeyGenerator.class, cacheName="profile-employee-dao")
	public BaseModelCollection<ShortProfileList> searchEmployeeListByParam(String param) {
		BaseModelCollection<ShortProfileList> employeeList = new BaseModelCollection<ShortProfileList>();
		String query = this.getSql("searchEmloyeeListByParam");		
		try{			
			employeeList.setList(getJdbcTemplate().query(query, new Object[]{param + "%",param + "%",param + "%",param + "%"}, new ShortProfileListMapper()));
			logger.debug("Search data was loaded susscesfully");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Search data not found: " + param);			
		}				
		return employeeList;		
	}
	
	@Cache(nodeName="/profile/employee/dao/search", keyGeneratorClass = DaoKeyGenerator.class, cacheName="profile-employee-dao")
	public BaseModelCollection<ShortProfileList> searchEmployeeListByParam(Long param) {
		BaseModelCollection<ShortProfileList> employeeList = new BaseModelCollection<ShortProfileList>();
		String query = this.getSql("searchEmloyeeListBySSO");
		try{
			if(param.toString().length()>=9){
				query=query.replace("es.sso >= ? and es.sso <= ?", "es.sso = ?");
				employeeList.setList(getJdbcTemplate().query(query, new Object[]{param}, new ShortProfileListMapper()));
			}else{
				String param1, param2;
				param1 = StringUtils.rightPad(param.toString(), 9, "0");
				param2 = StringUtils.rightPad(param.toString(), 9, "9");
				employeeList.setList(getJdbcTemplate().query(query, new Object[]{param1, param2}, new ShortProfileListMapper()));
			}
			logger.debug("Search data was loaded susscesfully");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Search data not found: " + param);			
		}				
		return employeeList;		
	}
	
	

	@Cache(nodeName="/profile/employee/dao/employee", keyGeneratorClass = DaoKeyGenerator.class, cacheName="profile-employee-dao")
	@PreAuthorize("hasPermission(#sso, 'DottedLineManager', read)")
	public DottedLineManager getDottedLineManagerBySso(Long sso) {
		
		DottedLineManager dottedLineMngr = new DottedLineManager() ;
		String query = this.getSql("getDottedLineManagerBySso");		
		try{			
			//Get Dotted Line Manager
			dottedLineMngr =  getJdbcTemplate().queryForObject(query, new Object[]{sso}, new DottedLineManagerMapper());				
			logger.debug("Dotted Line Manager was loaded susscesfully");			
		}catch (EmptyResultDataAccessException eex) {			
			logger.debug("Dotted Line Manager was loaded susscesfully");
		}				
		return dottedLineMngr;
	}

	
	@Cache(nodeName="/profile/employee/dao/employee", keyGeneratorClass = DaoKeyGenerator.class, cacheName="profile-employee-dao")
	@PreAuthorize("hasPermission(#sso, 'HomeAddress', read)")
	public HomeAddress getHomeAdressBySso(Long sso) {
		
		HomeAddress homeAddress = new HomeAddress();
		String query = this.getSql("getHomeAdressBySso");		
		try{			
			//Get Employee 
			homeAddress = getJdbcTemplate().queryForObject(query, new Object[]{sso}, new HomeAddressMapper());
			logger.debug("Home Address was loaded susscesfully");			
		}catch (EmptyResultDataAccessException eex) {
			throw new EmployeeNotFoundException("Employee data not found for "+sso);
		}				
		return homeAddress;		
	}
	
	
	/////////
	public AuthoritySupervisorHierarchy getHighAutoritySupervisorHierarchy(){
		AuthoritySupervisorHierarchy authoritySupervisor = new AuthoritySupervisorHierarchy();
		String query 										= this.getSql("getHighSupervisorHierarchy");		
		try{
			authoritySupervisor 							= (getJdbcTemplate().queryForObject
																		(query,new AuthSupervisorHierarchyMapper()));
			logger.debug("Direct reports data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Direct reports data not found");
		}
		
		return authoritySupervisor;
	}
	
	public BaseModelCollection<Employee> getBasicEmployeeListBySsoList(List<Long> ssoList) {
		BaseModelCollection<Employee> employeeList = new BaseModelCollection<Employee>();
		String query = this.getSql("getBasicEmployeeListBySsoList");		
		try{			
			query = dynamicPlaceHolderSet(query,ssoList);
			employeeList.setList(getJdbcTemplate().query( query, ssoList.toArray(), new EmployeeBasicInfoMapper()));
			logger.debug("Employee List was loaded properly");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("No employee was found" );
		}
		
		return employeeList;		
	}
	
	
	public BaseModelCollection<EmployeeAssignment> getEmployeeListBySsoList(List<Long> ssoList) {
		BaseModelCollection<EmployeeAssignment> employeeList = new BaseModelCollection<EmployeeAssignment>();
		String query = this.getSql("getEmployeeAssignmentListBySsoList");		
		try{			
			query = dynamicPlaceHolderSet(query,ssoList);
			employeeList.setList(getJdbcTemplate().query( query, ssoList.toArray(), new EmployeeAssignmentMapper()));
			logger.debug("Employee List was loaded properly");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("No employee was found" );
		}
		
		return employeeList;		
	}
	
	public List<Long> getEmployeeListByHRManager(Long sso) {
		List<Long> employeeList = null;
		String query = this.getSql("getEmployeeListByHRManager");		
		try{			
			employeeList = getJdbcTemplate().queryForList(query, Long.class, new Object[]{sso});
			logger.debug("Employee List was loaded properly");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("none employee was found" );
		}
		return employeeList;		
	}
	
	/*public void sensitiveDataPopupDao(Long sso, String flag) {
		String query = this.getSql("sensitiveDataPopup");		
		try{			
			getJdbcTemplate().update(query, sso, flag);
			//getJdbcTemplate().queryForLong(query, sso);
			logger.debug("Sensitive Data Popup updated successfully");			
		}catch (Exception eex) {
			logger.debug("Sensitive Data Popup update failed" );
		}		
	}
	
	public void sensitiveDataPopupDeleteRolesDao(Long sso) {
		String query = this.getSql("sensitiveDataPopupDeleteRoles");		
		try{			
			getJdbcTemplate().update(query, sso);
			logger.info("Roles deleted for" + sso);			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Error in deleting Roles for" + sso );
		}		
	}
	
	public boolean isValidSensitiveDataPopupDao(Long sso) {
		String query1 = this.getSql("isValidSensitiveDataPopup1");
		String query2 = this.getSql("isValidSensitiveDataPopup2");
		int employeeId1=0,employeeId2=0;
		boolean isValid=false;
		try{			
			employeeId1= getJdbcTemplate().queryForInt(query1,sso);
			employeeId2= getJdbcTemplate().queryForInt(query2,sso);
			logger.debug("Sensitive Data Check Valid");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Sensitive Data Check Not Valid" );
		}catch(Exception e){
			
		}
		if(employeeId1>0 || employeeId2==0){
			isValid = true;
		}
		return isValid;
	}*/
	
	@Override
	public void insertExpertiseEmptyPopupBySSO(Long sso, String flag) {
		String query = this.getSql("expertiseEmptyPopupInsert");		
		try{			
			getJdbcTemplate().update(query, sso, flag);
			logger.debug("Expertise Empty Popup updated sucessfully");			
		}catch (Exception eex) {
			logger.debug("Expertise Empty Popup update failed");	
		}		
	}
	
	@Override
	public boolean showExpertiseEmptyPopupBySSO(Long sso) {
		String query1 = this.getSql("isValidExpertiseEmptyPopup1");
		String query2 = this.getSql("isValidExpertiseEmptyPopup2");
		int employeeId1 = 0, employeeId2 = 0;
		boolean isValid = false;
		try {
			employeeId1 = getJdbcTemplate().queryForInt(query1, sso);
			if(employeeId1 == 0) {
				isValid = true;
			}
			if(!isValid) {
				employeeId2 = getJdbcTemplate().queryForInt(query2, sso);
				if (employeeId2 > 0) {
					isValid = true;
				}
			}
			logger.debug("Expertise Popup Check Valid");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("Expertise Popup Check Not Valid");
		} catch (Exception e) {

		}
		return isValid;
	}
	
	public boolean showInfoPopupStatusBySSODao(Long sso){
		String query1 = this.getSql("showInformationPopup1");
		String query2 = this.getSql("showInformationPopup2");
		int employeeId1=0,employeeId2=0;
		boolean isValid=false;
		try{			
			employeeId1= getJdbcTemplate().queryForInt(query1,sso);
			employeeId2= getJdbcTemplate().queryForInt(query2,sso);
			logger.debug("Info Popup Check Valid");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Info Popup Check Not Valid" );
		}catch(Exception e){

		}
		if(employeeId1>0 || employeeId2==0){
			isValid = true;
		}
		return isValid;
	}
	
	public boolean showWhatsNewPopupBySSODao(Long sso){
		String query = this.getSql("showWhatsNewPopupBySSO");
		int employeeId=0;
		boolean isValid=false;
		try{			
			employeeId= getJdbcTemplate().queryForInt(query,sso);
			logger.debug("Dont show Whats New Popup");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Show Whats New Popup" );
		}catch(Exception e){

		}
		if(employeeId==0){
			isValid = true;
		}
		return isValid;
	}
	
	public void infoPopupInsertBySSODao(Long sso, String flag) {
		String query = this.getSql("informationPopupInsert");		
		try{			
			getJdbcTemplate().update(query, sso, flag);
			//getJdbcTemplate().queryForLong(query, sso);
			logger.debug("Inforamtion Popup updated sucessfully");			
		}catch (Exception eex) {
			logger.debug("Inforamtion Popup update failed");	
		}		
	}
	
	public void whatsnewInsertBySSODao(Long sso, String flag) {
		String query = this.getSql("whatsnewPopupInsert");		
		try{			
			getJdbcTemplate().update(query, sso, flag);
			//getJdbcTemplate().queryForLong(query, sso);
			logger.debug("whats new Popup updated sucessfully");			
		}catch (Exception eex) {
			logger.debug("whats new Popup update failed");	
		}		
	}
	
	public boolean isValidSSO (Long sso){
		boolean isValid = false;
		Long empId = null;
		try{
			empId = getJdbcTemplate().queryForLong(getSql("isValidSSO"),new Object[]{sso});
		}catch(EmptyResultDataAccessException eex){
			logger.debug( sso + " is inValid" );
		}	
		if(empId!=null){
			isValid = true;
		}
		return isValid;
	}
	
	public UserInfo loggedUserInfo(Long sso) {
		String query = this.getSql("loggedUserInfo");		
		UserInfo employee = new UserInfo();
		try{			
			//Get User data 
			employee = getJdbcTemplate().queryForObject(query, new Object[]{sso}, new UserInfoMapper());
			logger.debug("Logged User data was loaded susscesfully");			
		}catch (EmptyResultDataAccessException eex) {
			employee.setSso(sso);
			employee.setFirstName(sso.toString());
			logger.debug("Logged User data not found for "+sso);	
			//throw new EmployeeNotFoundException("Logged User data not found for "+sso);

		}				
		return employee;	
	}
	
	public List<LuceneSearchCompDto> getEmployeeListDao() {
		List<LuceneSearchCompDto> employeeList = new ArrayList<LuceneSearchCompDto>();
		String query = this.getSql("getEmployeeList");
		try {
			employeeList = getJdbcTemplate().query(query, new LuceneSearchCompListMapper());
			//employeeList = getJdbcTemplate().query(dynamicPlaceHolderSet(query,sso ),sso.toArray(), new LuceneSearchCompListMapper());
			//logger.debug("Search data was loaded susscesfully for :" + sso);
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("Search data load failed");
		}
		return employeeList;
	}

	public BaseModelCollection<SearchCompDto> getAllEmployeeListDao() {
		BaseModelCollection<SearchCompDto> employeeList = new BaseModelCollection<SearchCompDto>();
		String query = this.getSql("getAllEmployeeList");
		try {
			employeeList.setList(getJdbcTemplate().query(query,
					new SearchCompListMapper()));
			logger.debug("Search data was loaded susscesfully");
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("Search data not failed");
		}
		return employeeList;
	}

	public List<Long> getAllSso() {
		String query1 = this.getSql("getAllSsoList");
		List<Long> ssoList = null;
		try {
			getJdbcTemplate().setFetchSize(2000);
			ssoList = getJdbcTemplate().queryForList(query1, Long.class);
			logger.info("Total Employee Count:" + ssoList.size());
		} catch (EmptyResultDataAccessException eex) {
			logger.debug("Count for employees Not Valid");
		} catch (Exception e) {
			logger.debug("Exception occured during fetching sso List!");
		}
		return ssoList;
	}

	@Override
	public List<LuceneEducationDto> getEducationData() {
		String query = this.getSql("getEducationDetails");
		List<LuceneEducationDto> eList = new ArrayList<LuceneEducationDto>();
		eList = getJdbcTemplate().query(query, new LuceneEducationDtoMapper());
		//getJdbcTemplate().query(dynamicPlaceHolderSet(query,sso ),sso.toArray(), new LuceneEducationDtoMapper());
		//getJdbcTemplate().query(query, new Object[] { sso },new LuceneEducationDtoMapper());
		return eList;
	}

	@Override
	public List<LuceneEmpHistoryDto> getWorkHistoryData() {
		String query = this.getSql("getEmpHistoryDetails");
		List<LuceneEmpHistoryDto> emhList = new ArrayList<LuceneEmpHistoryDto>();
		emhList = getJdbcTemplate().query(query, new LuceneEmpHistoryMapper());
		//getJdbcTemplate().query(dynamicPlaceHolderSet(query,sso ),sso.toArray(), new LuceneEmpHistoryMapper());
		//getJdbcTemplate().query(query, new Object[] { sso }, new LuceneEmpHistoryMapper());
		return emhList;

	}

	@Override
	public List<LuceneTrainingDto> getTrainingData() {
		String query = this.getSql("getTrainingDetails");
		List<LuceneTrainingDto> tList = new ArrayList<LuceneTrainingDto>();
		tList = getJdbcTemplate().query(query, new LuceneTrainingDtoMapper());
		//getJdbcTemplate().query(dynamicPlaceHolderSet(query,sso ),sso.toArray(), new LuceneTrainingDtoMapper());
		//getJdbcTemplate().query(query, new Object[] { sso }, new LuceneTrainingDtoMapper());
		return tList;

	}

	@Override
	public List<LuceneLeadershipDto> getLeadershipData() {
		String query = this.getSql("getLeadershipDetails");
		List<LuceneLeadershipDto> lpList = new ArrayList<LuceneLeadershipDto>();
		lpList = getJdbcTemplate().query(query, new LuceneLeadershipDtoMapper());
		//getJdbcTemplate().query(dynamicPlaceHolderSet(query,sso ),sso.toArray(), new LuceneLeadershipDtoMapper());
		//getJdbcTemplate().query(query, new Object[] { sso }, new LuceneLeadershipDtoMapper());
		return lpList;

	}
	
	@PreAuthorize("hasPermission(#sso, 'ResumeProfessionalSummaryEdit', read)")
	public int  setProfessionalSummary(Long sso,String profSummary) {
		String query = "";
		int val = 0;
		ProfessionalSummaryDto summary = new ProfessionalSummaryDto();
		try{
			//summary = getSummary(sso);
			if(sso!=null){
				query = this.getSql("updateSummaryInfo");	
			}else{
				query = this.getSql("setSummaryInfo");	
			}
			 val=getJdbcTemplate().update(query, profSummary, sso );
			
			logger.debug("Logged User Prof. summary data was updated susscesfully");		
		}catch (EmptyResultDataAccessException eex) {
			query = this.getSql("setSummaryInfo");	
			val=getJdbcTemplate().update(query, profSummary, sso );
			
			logger.debug("Logged User Prof. summary data was inserted susscesfully");		
		}catch(Exception e){
			logger.debug("Prof. summary data insert/update failed");
		}
		return val;

	}

	@Override
	public ProfileCompleteness getProfileCompleteness(Long sso, Boolean expertiseFlag) {
		int percentComplete = 0;
		String query = this.getSql("profileCompletenessBySso");
		if(!expertiseFlag) {
			query = this.getSql("profileCompletenessBySsoWithNetworks");
		}
		String query1 = this.getSql("getProfileBreakdown");
		ProfileCompleteness percentCompleteness = new ProfileCompleteness();
		try{
			percentComplete = getJdbcTemplate().queryForInt(query, new Object[]{sso});
			percentCompleteness = getJdbcTemplate().queryForObject(query1, new Object[]{sso}, new ProfileCompletenessMapper());
			percentCompleteness.setPercentComplete(percentComplete*10);
			percentCompleteness.setSso(sso);
		}catch(Exception e){
			logger.debug("Exception occured during fetching Profile Completeness Data for sso" + sso);
		}
		return percentCompleteness;
	}
	
	public ProfileCompleteness getProfileBreakdown(Long sso) {
		String query = this.getSql("getProfileBreakdown");
		ProfileCompleteness profileBreakdown = new ProfileCompleteness();
		try{
			profileBreakdown = getJdbcTemplate().queryForObject(query, new Object[]{sso}, new ProfileCompletenessMapper());
		}catch(Exception e){
			logger.debug("Exception occured during fetching Profile Breakdown Data for sso" + sso);
		} 
		return profileBreakdown;
	}

	@Override
	public List<IntiativesandProject> getInitiativeProjectData() {
		String query = this.getSql("getAllInitiativesAndProjects");
		List<IntiativesandProject> projectList = new ArrayList<IntiativesandProject>();
		projectList = getJdbcTemplate().query(query, new IntiativesandProjectMapper());
		return projectList;
}

	@Override
	public List<CustomerandSuppliers> getCustomersAndSuppliersData() {
		String query = this.getSql("getAllCustomersAndSuppliers");
		List<CustomerandSuppliers> projectList = new ArrayList<CustomerandSuppliers>();
		projectList = getJdbcTemplate().query(query, new CustomerandSuppilersMapper());
		return projectList;
	}

	@Override
	public List<LanguageProficiency> getLanguagesData() {
		String query = this.getSql("getAllKnownLanguages");
		List<LanguageProficiency> projectList = new ArrayList<LanguageProficiency>();
		projectList = getJdbcTemplate().query(query, new LanguageProficicencyMapper());
		return projectList;
	}

	@Override
	public List<AffinityGroups> getExternalAffiliationsData() {
		String query = this.getSql("getAllExternalAffiliations");
		List<AffinityGroups> projectList = new ArrayList<AffinityGroups>();
		projectList = getJdbcTemplate().query(query, new AffinityGroupsMapper());
		return projectList;
	}
	
	@Override
	public List<WorkMobilityCountry> getWorkMobilityData() {

		List<WorkMobilityCountry> workMobilityCountries = new ArrayList<WorkMobilityCountry>();
		String query = this.getSql("getAllWorkMobilityCountries");
		workMobilityCountries = getJdbcTemplate().query(query, new WorkMobilityCountryMapper());
		return workMobilityCountries;

	}

	@Override
	public List<LPBridgeAssignment> getLPBridgeData() {
		List<LPBridgeAssignment> lpBridgeAssigments = new ArrayList<LPBridgeAssignment>();
		String query = this.getSql("getLPAssignments");
		lpBridgeAssigments = getJdbcTemplate().query(query, new LPBridgeAssignmentMapper());
		return lpBridgeAssigments;
	}
	
	@Override
	public List<EmployeeExpertise> getEmpExpertiseData() {
		List<EmployeeExpertise> expertises;
		String query = this.getSql("getEmpExpertiseData");
		expertises = getJdbcTemplate().query(query, new EmployeeExpertiseMapper());
		logger.debug("All Employee Expertise List loaded properly");
		return expertises;
	}
	
	@Override
	public List<Mentoring> getEmpMentoringInterestData() {
		List<Mentoring> empMentoringInterest;
		String query = this.getSql("getEmpMentoringInterestAll");
		empMentoringInterest = getJdbcTemplate().query(query, new RowMapper<Mentoring>(){
			@Override
			public Mentoring mapRow(ResultSet rs, int arg1) throws SQLException {
				Mentoring mentoring = new Mentoring();
				mentoring.setSso((long) rs.getInt("sso"));
				String flag = rs.getString("flag");
				if("ME".equalsIgnoreCase(flag)) {
					mentoring.setConnectFlag(true);
				} else {
					mentoring.setConnectFlag(false);
				}
				mentoring.setDescription(rs.getString("interest"));
				return mentoring;
			}
		});
		logger.debug("Employee Mentoring List loaded properly");
		return empMentoringInterest;
	}
	
	@Override
	public boolean addConnection(Long sso, Long connectSSO, int connectionType) {
		String checkQuery = this.getSql("checkConnection");
		String query;
		int row;
		try{
			Long recipientSSO = getJdbcTemplate().queryForObject(checkQuery, new Object[]{sso, connectSSO, connectionType}, Long.class);
			logger.debug("updating existing entry for connection of "+ sso + " and "+connectSSO);
			query = this.getSql("updateConnection");
			row = getJdbcTemplate().update(query, new Object[]{"A", sso, connectSSO, connectionType});
		}catch(Exception e){
			try {
				Long recipientSSO = getJdbcTemplate().queryForObject(checkQuery, new Object[]{connectSSO, sso, connectionType}, Long.class);
				logger.debug("updating existing entry for connection of "+ connectSSO + " and "+sso);
				query = this.getSql("updateConnection");
				row = getJdbcTemplate().update(query, new Object[]{"A", connectSSO, sso, connectionType});
			}catch (Exception ee) {
				logger.debug("creating entry for connection of "+ sso + " and "+connectSSO);
				query = this.getSql("addConnection");
				row = getJdbcTemplate().update(query, new Object[]{sso, connectSSO, connectionType, "A"});
			}
		}
		
		if(row == 1) {
			return true;
		}
		return false;
	}
	
	@Override
	public boolean deleteConnection(Long sso, Long connectSSO, int connectionType) {
		String query = this.getSql("deleteConnection");
		int row = getJdbcTemplate().update(query, new Object[]{"D", sso, connectSSO, connectionType});
		if(row == 0) {
			row = getJdbcTemplate().update(query, new Object[]{"D", connectSSO, sso, connectionType});
		}
		if(row == 1) {
			return true;
		}
		return false;
	}
	
	@Override
	public BaseModelCollection<EmployeeExpertise> getExpertiseListBySSO(Long sso) {
		BaseModelCollection<EmployeeExpertise> expertiseList = new BaseModelCollection<>();
		List<EmployeeExpertise> list;
		String query = this.getSql("getExpertiseListBySSO");
		try {
			list = getJdbcTemplate().query(query, new Object[]{sso}, new RowMapper<EmployeeExpertise>(){

				@Override
				public EmployeeExpertise mapRow(ResultSet rs, int rowNum) throws SQLException {
					EmployeeExpertise employeeExpertise = new  EmployeeExpertise();
					
					Expertise expertise = new Expertise();
					expertise.setId(rs.getInt("exp_id"));
					expertise.setName(rs.getString("exp_name"));
					expertise.setApprovedFlag(rs.getString("exp_approved"));
					
					employeeExpertise.setSso(rs.getLong("sso"));
					employeeExpertise.setOrder(rs.getInt("EXP_ORDER"));
					employeeExpertise.setExpertise(expertise);
					
					return employeeExpertise;
				}});
			expertiseList.setList(list);
			logger.debug("Employee Expertise List loaded properly");
		} catch (Exception e) {
			logger.debug("Issue while loading Employee Expertise List");
		}
		
		return expertiseList;
	}
	
	@Override
	public BaseModelCollection<EmployeeExpertise> updateEmpExpertise(Long sso, List<EmployeeExpertise> expertises) {
		String addEmpExp = this.getSql("addEmpExpertise");
		String deleteEmpExp = this.getSql("deleteEmpExpertise");
		String addExp = this.getSql("addExpertise");
		String checkExp = this.getSql("queryExpertise");
		List<EmployeeExpertise> newList = new ArrayList<>();
		List<EmployeeExpertise> addList = new ArrayList<>();
		List<EmployeeExpertise> deleteList = new ArrayList<>();
		int[] rowsAdded;
		int[] rowsDeleted;
		
		for(EmployeeExpertise exp : expertises) {
			if("N".equals(exp.getFlag())) {
				newList.add(exp);
			} else if("A".equals(exp.getFlag())) {
				addList.add(exp);
			} else if("D".equals(exp.getFlag())) {
				deleteList.add(exp);
			}
		}
		
		if(newList.size() > 0) {
				for(EmployeeExpertise expertise : newList){
					int expId;
					try {
						Expertise existingExp = getJdbcTemplate().queryForObject(checkExp, new Object[] {expertise.getExpertise().getName()}, new RowMapper<Expertise>() {
							@Override
							public Expertise mapRow(ResultSet rs, int index) throws SQLException {
								Expertise dbExp = new Expertise();
								dbExp.setId(rs.getInt("exp_id"));
								dbExp.setApprovedFlag(rs.getString("exp_approved"));
								return dbExp;
							}
						});
					if (existingExp != null && existingExp.getId() > 0) {
						expertise.getExpertise().setId(existingExp.getId());
						addList.add(expertise);
						if ("R".equalsIgnoreCase(existingExp.getApprovedFlag())) {
							try {
								int row = getJdbcTemplate().update(this.getSql("updateExpertiseStatus"),
										new Object[] { expertise.getFlag(), existingExp.getId() });
							} catch (Exception e) {}
						}
					}
					} catch (Exception e) {
						KeyHolder keyHolder = new GeneratedKeyHolder();
						int status = getJdbcTemplate().update(
					    	    new PreparedStatementCreator() {
					    	        public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
					    	            PreparedStatement pst = con.prepareStatement(addExp, new String[] {"EXP_ID"});
					    	            pst.setString(1, expertise.getExpertise().getName());
					    	            pst.setLong(2, sso);
					    	            return pst;
					    	        }
					    	    },
					    	    keyHolder);
			              expId = keyHolder.getKey().intValue();
			              expertise.getExpertise().setId(expId);
			              addList.add(expertise);
			              logger.debug("Added new expertise to the table with id: "+expId);
					}
				}
		}
		
		if(addList.size() > 0) {
			try{
				rowsAdded = getJdbcTemplate().batchUpdate(addEmpExp, new BatchPreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement ps, int index) throws SQLException {
					ps.setLong(1, sso);
					ps.setInt(2, addList.get(index).getExpertise().getId());
					ps.setInt(3, addList.get(index).getOrder());
					ps.setString(4, addList.get(index).getAddedFrom());
				}
				
				@Override
				public int getBatchSize() {
					return addList.size();
				}
			});
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(deleteList.size() > 0) {
			try{
				rowsDeleted = getJdbcTemplate().batchUpdate(deleteEmpExp, new BatchPreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement ps, int index) throws SQLException {
					ps.setLong(1, sso);
					ps.setInt(2, deleteList.get(index).getExpertise().getId());
				}
				
				@Override
				public int getBatchSize() {
					return deleteList.size();
				}
			});
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return getExpertiseListBySSO(sso);
	}

	@Override
	public BaseModelCollection<Long> getAllMentors(Long sso) {
		BaseModelCollection<Long> list = new BaseModelCollection<>();
		String query = this.getSql("getAllMentorsBySSO");		
		try{			
			list.setList(getJdbcTemplate().queryForList(query, new Object[]{sso}, Long.class));
		}catch (EmptyResultDataAccessException eex) {
		}
		return list;
	}

	@Override
	public BaseModelCollection<Long> getAllMentees(Long sso) {
		BaseModelCollection<Long> list = new BaseModelCollection<>();
		String query = this.getSql("getAllMenteesBySSO");		
		try{			
			list.setList(getJdbcTemplate().queryForList(query, new Object[]{sso}, Long.class));
		}catch (EmptyResultDataAccessException eex) {
		}
		return list;
	}
	
	@Override
	public Map<String, List<Integer>> getEmpMentoringInterest(Long sso) {
		Map<String, List<Integer>> empMentoInterest = new HashMap<>();
		String query = this.getSql("getEmpMentoringInterestBySSO");		
		try{			
			SqlRowSet rowSet = null;
			
			rowSet = getJdbcTemplate().queryForRowSet(query , new Object[]{sso});
			while(rowSet.next()){
				String key = rowSet.getString("mentor_mentee_flag");
				if(empMentoInterest.containsKey(key)) {
					List<Integer> list = empMentoInterest.get(key);
					list.add(rowSet.getInt("interest_id"));
				} else {
					List<Integer> list = new ArrayList<>();
					list.add(rowSet.getInt("interest_id"));
					empMentoInterest.put(key, list);
				}
			}
			logger.debug("Emp Mentoring interest loaded properly");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Emp Mentoring interest not found" );
		}
		return empMentoInterest;		
	}
	
	@Override
	public BaseModelCollection<String> getEmpMenteeInterests(Long sso) {
		BaseModelCollection<String> empMenteeInterests = new BaseModelCollection<>();
		String query = this.getSql("getMenteeInterestsBySSO");		
		try{
			empMenteeInterests.setList(getJdbcTemplate().queryForList(query, new Object[]{sso}, String.class));
			logger.debug("Employee Mentee interest loaded properly");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Emp Mentee interest not found" );
		}
		return empMenteeInterests;		
	}
	
	@Cache(nodeName="/profile/employee/dao/jvemployee", keyGeneratorClass = DaoKeyGenerator.class, cacheName="profile-employee-dao")
	public JVEmployee getJVEmployeeBySso(Long sso) {
		
		JVEmployee employee = new JVEmployee();
		String query = this.getSql("loadJVEmployeeBySso");		
		try{			
			//Get Employee 
			employee = getJdbcTemplate().queryForObject(query, new Object[]{sso}, new JVEmployeeMapper());
			logger.debug("Employee data was loaded susscesfully");			
		}catch (EmptyResultDataAccessException eex) {
			throw new EmployeeNotFoundException("Employee data not found for "+sso);
		}				
		return employee;		
	}

	@Override
	public JVEmployee getJVWorkAssgnmtbySso(Long sso) {
		
		JVEmployee employee = new JVEmployee();
		String query = this.getSql("loadJVWorkAssgnmtbySso");		
		try{			
			//Get Employee 
			employee = getJdbcTemplate().queryForObject(query, new Object[]{sso}, new JVWorkAssignmentMapper());
			logger.debug("Work Assignment data was loaded susscesfully");			
		}catch (EmptyResultDataAccessException eex) {
			throw new EmployeeNotFoundException("Work Assignment data not found for "+sso);
		}				
		return employee;		
	}

	@Override
	public void insertLoginMetrics(ProfileUserMetrics metrics) {
		String query = this.getSql("addLoginMetrics");
		
		try {
			getJdbcTemplate().update(query, new Object[] {metrics.getSso(), metrics.getPageVisited(), 
					metrics.getViewedSso(), metrics.getViewType(), metrics.getRolesForContext(), 
					metrics.getBusiness(), metrics.getFunction(), metrics.getRegion(), metrics.getLoginType(), 
					metrics.getOperatingSystem(), metrics.getBrowser(), metrics.getDevice()});
		} catch (Exception e) {
			logger.debug("Exception in insertLoginMetrics - "+e.getMessage());
			logger.debug("Exception for metrics query >> "+query);
		}
		metrics = null;
	}
}
