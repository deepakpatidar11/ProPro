package com.ge.corporate.hr.profile.employee.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class LinkedInPdfEducation {
	private String schoolName;
	private List<String> majors = new ArrayList<>();
	private String degree;
	private Date graduationDate;

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public List<String> getMajors() {
		return majors;
	}

	public void setMajors(List<String> majors) {
		this.majors = majors;
	}
	
	public void addMajor(String major) {
		this.majors.add(major);
	}

	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public Date getGraduationDate() {
		return graduationDate;
	}

	public void setGraduationDate(Date graduationDate) {
		this.graduationDate = graduationDate;
	}

}
