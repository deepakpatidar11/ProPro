package com.ge.corporate.hr.profile.employee.model;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name = "financeContacts")
@XmlAccessorType(XmlAccessType.FIELD)
public class FinanceContacts extends AbstractBaseModelSupport{

	private static final long serialVersionUID = 46981221793287345L;
	private String finCostExpSso;
	private String finCostExpName;
	private int employeeId;
	private String bucEntStdFlg;

	public String getFinCostExpSso() {
		return finCostExpSso;
	}
	public void setFinCostExpSso(String finCostExpSso) {
		this.finCostExpSso = finCostExpSso;
	}
	public String getFinCostExpName() {
		return finCostExpName;
	}
	public void setFinCostExpName(String finCostExpName) {
		this.finCostExpName = finCostExpName;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getBucEntStdFlg() {
		return bucEntStdFlg;
	}
	public void setBucEntStdFlg(String bucEntStdFlg) {
		this.bucEntStdFlg = bucEntStdFlg;
	}

}
