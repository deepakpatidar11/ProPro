/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.ServiceDates;
import com.ge.corporate.hr.profile.employee.model.WorkAssignmentHistortyInt;
import com.ge.corporate.hr.profile.employee.model.WorkAssignmentRestricted;


@XmlRootElement(name="assignment")
@XmlAccessorType(XmlAccessType.FIELD)

public class AssignmentHistoryDto extends AbstractBaseDtoSupport{

	private static final long serialVersionUID = 3835701876509448286L;

	
	@XmlElement(name="sso")
	private Long sso;
	
	
	@XmlElement(name="serviceDates")
	ServiceDates serviceDates;
	
	@XmlElement(name="workAssignmentRestrd")
	WorkAssignmentRestricted workAssignmentRestrd;

	@XmlElement(name="workAssignmtHistoryList")
	private BaseModelCollection<WorkAssignmentHistortyInt> workAssigIntList;
	
	@XmlElement(name="workAssigRestrictdList")
	private BaseModelCollection<WorkAssignmentRestricted> workAssigRestrictdList;
	
	
	public long getId() {
		return (sso==null)?0:sso.longValue();
	}
	
	
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}


	public ServiceDates getServiceDates() {
		return serviceDates;
	}

	public void setServiceDates(ServiceDates serviceDates) {
		this.serviceDates = serviceDates;
	}

	public BaseModelCollection<WorkAssignmentHistortyInt> getWorkAssigIntList() {
		return workAssigIntList;
	}

	public void setWorkAssigIntList(BaseModelCollection<WorkAssignmentHistortyInt> workAssigIntList) {
		this.workAssigIntList = workAssigIntList;
	}

	public BaseModelCollection<WorkAssignmentRestricted> getWorkAssigRestrictdList() {
		return workAssigRestrictdList;
	}
	
	public void setWorkAssigRestrictdList(
			BaseModelCollection<WorkAssignmentRestricted> workAssigRestrictdList) {
		this.workAssigRestrictdList = workAssigRestrictdList;
	}
	
	public WorkAssignmentRestricted getWorkAssignmentRestrd() {
		return workAssignmentRestrd;
	}
	
	public void setWorkAssignmentRestrd(WorkAssignmentRestricted  workAssignmentRestrd){			
		this.workAssignmentRestrd = workAssignmentRestrd;
	}
}
