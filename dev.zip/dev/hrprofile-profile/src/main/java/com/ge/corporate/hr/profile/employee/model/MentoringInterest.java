package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;
@XmlRootElement(name="mentoringInterest")
@XmlAccessorType(XmlAccessType.FIELD)
public class MentoringInterest extends AbstractBaseModelSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4633773023633931568L;

	public MentoringInterest() {
	}
	
	public MentoringInterest(int id, String text, String tooltip) {
		super();
		this.id = id;
		this.text = text;
		this.tooltip = tooltip;
	}
	
	@XmlElement(name="id")
	private int id;
	
	@XmlElement(name="text")
	private String text;
	
	@XmlElement(name="tooltip")
	private String tooltip;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getTooltip() {
		return tooltip;
	}
	public void setTooltip(String tooltip) {
		this.tooltip = tooltip;
	}
}
