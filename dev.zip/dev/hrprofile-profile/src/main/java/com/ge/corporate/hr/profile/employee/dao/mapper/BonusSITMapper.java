/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.BonusSIT;
/**
 * Incentive Compensation mapper
 * @author enrique.romero
 *
 */
public class BonusSITMapper implements RowMapper<BonusSIT>{

	public static final String DATA_SSO = "sso";
	public static final String DATA_START_YEAR = "from_year";
	public static final String DATA_END_YEAR = "to_year";
	public static final String DATA_START_DATE = "from_date";
	public static final String DATA_END_DATE = "to_date";
	public static final String DATA_PLAN_TYPE = "bonus_type";
	public static final String DATA_PLAN_NAME = "plan_name";
	public static final String DATA_DIS_TYPE = "distribution_type";
	public static final String DATA_TARGET = "target_value";
	public static final String DATA_FREQUENCY = "payment_frequency";
	public static final String DATA_DESC = "description";
	public static final String DATA_CURR = "target_currency";
	
	public BonusSIT mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		BonusSIT bonus = new BonusSIT();
		bonus.setStartYear(rs.getString(DATA_START_YEAR));
		bonus.setEndYear(rs.getString(DATA_END_YEAR));
		bonus.setStartDate(rs.getDate(DATA_START_DATE));
		bonus.setEndDate(rs.getDate(DATA_END_DATE));
		bonus.setPlanName(rs.getString(DATA_PLAN_NAME));
		bonus.setPlanType(rs.getString(DATA_PLAN_TYPE));
		bonus.setDisType(rs.getString(DATA_DIS_TYPE));
		bonus.setTarget(rs.getDouble(DATA_TARGET));
		bonus.setPaymentFrequency(rs.getString(DATA_FREQUENCY));
		bonus.setDescription(rs.getString(DATA_DESC));
		bonus.setCurrency(rs.getString(DATA_CURR));
		
		return bonus;
	}
	

}
