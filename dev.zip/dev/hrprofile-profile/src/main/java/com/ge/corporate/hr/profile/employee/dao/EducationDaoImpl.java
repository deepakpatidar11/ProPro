/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.security.access.prepost.PreAuthorize;

import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;
import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dao.mapper.CertificationMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.EducationCountryMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.EducationMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.EducationUniversityMapper;
import com.ge.corporate.hr.profile.employee.dto.EducationTrainingDto;
import com.ge.corporate.hr.profile.employee.model.Certification;
import com.ge.corporate.hr.profile.employee.model.Education;
import com.ge.corporate.hr.profile.employee.model.EducationCountry;
import com.ge.corporate.hr.profile.employee.model.EducationUniversity;
import com.ge.corporate.hr.profile.employee.model.EmployeeHistory;
import com.ge.corporate.hr.profile.employee.service.EmployeeProfileService;
import com.ge.corporate.hr.profile.employee.service.cache.DaoKeyGenerator;
import com.ge.corporate.hr.profile.employee.service.cache.SearchKeyGenerator;
/**
 * Education Dao Implementation
 * @author enrique.romero
 */
public class EducationDaoImpl extends AbstractBaseDaoSupport  implements EducationDao{

	@Resource(name = "employeeProfileService")
	private EmployeeProfileService personalInfoService;
	
	//@Cache(nodeName="/profile/employee/dao/personalCV", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	//@PreAuthorize("hasPermission(#sso, 'ResumeEducationView', read)")
	public BaseModelCollection<Education> getEducationListBySso(Long sso, boolean isSelf){
		BaseModelCollection<Education> educationList = new BaseModelCollection<Education>();
		String query = this.getSql("getEducationListBySso");		
		try{
			educationList.setList(getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new EducationMapper(isSelf)));
			logger.debug("Education data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Education data was not found");
		}catch (Exception ex) {
			logger.debug("Education data was not found" );
		}
		
		return educationList;
	}
	
	public BaseModelCollection<Education> getEducationListAllBySso(Long sso){
		BaseModelCollection<Education> educationList = new BaseModelCollection<Education>();
		String query = this.getSql("getEducationListBySso");		
		try{
			educationList.setList(getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new EducationMapper()));
			logger.debug("Education data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Education data Not found");
		}catch (Exception ex) {
			logger.debug("Education data was not found" );
		}
		
		return educationList;
	}
	
	public BaseModelCollection<Education> getEducationListOptinBySso(Long sso){
		BaseModelCollection<Education> educationList = new BaseModelCollection<Education>();
		String query = this.getSql("getEducationListOptinBySso");		
		try{
			educationList.setList(getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new EducationMapper()));
			logger.debug("Education data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Education data Not found");
		}catch (Exception ex) {
			logger.debug("Education data was not found" );
		}
		
		return educationList;
	}

	@PreAuthorize("hasPermission(#sso, 'ResumeEducationEdit', read)")
	public boolean saveEducationDetails(Long sso,
			EducationTrainingDto educationDetails) {
		String addUnivQuery = this.getSql("addUniversityBySso");
		String addSchoolQuery = this.getSql("addOtherEducationBySso");
		String deleteQuery = this.getSql("deleteEducationBySso");
		try{
			getJdbcTemplate().update(deleteQuery, new Object[]{sso});
			for(Education edu : educationDetails.getEducationDetailsList()){
				if(edu.getEduType().equalsIgnoreCase("University")){
					getJdbcTemplate().update(addUnivQuery, new Object[]{sso, personalInfoService.escapeSpecialCharacters(edu.getEduType()), edu.getDegree(), edu.getCountry(),  personalInfoService.escapeSpecialCharacters(edu.getUniversity()), edu.getMajor(), edu.getMajor2(), edu.getGraduationYear(), edu.getStatus()});
				}else{
					getJdbcTemplate().update(addSchoolQuery, new Object[]{sso, personalInfoService.escapeSpecialCharacters(edu.getEduType()), personalInfoService.escapeSpecialCharacters(edu.getSchool()), personalInfoService.escapeSpecialCharacters(edu.getDiplomaCertificate()), personalInfoService.escapeSpecialCharacters(edu.getLocation()), edu.getStatus()});
				}				
			}
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Education data updated sucessfully");
			return false;
		}catch(Exception e){
			logger.debug("Education data could not be updated");
			return false;
		}
		return true;
		}

	@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public BaseModelCollection<EducationCountry> getCountries() {
		BaseModelCollection<EducationCountry> countryList = new BaseModelCollection<EducationCountry>();
		String query = this.getSql("getEduCountryList");		
		try{
			countryList.setList(getJdbcTemplate().query(query, new EducationCountryMapper()));
			logger.debug("Education country data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Education country data Not found");
		}catch (Exception ex) {
			logger.debug("Education data was not found" );
		}
		
		return countryList;
	}

	@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public BaseModelCollection<String> getDegrees() {
		BaseModelCollection<String> list = new BaseModelCollection<String>();
		String query = this.getSql("getDegreeList");		
		try{			
			list.setList(getJdbcTemplate().queryForList(query, String.class));
			logger.debug("Degree List was loaded properly");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Degree data was not found" );
		}catch (Exception ex) {
			logger.debug("Degree data was not found" );
		}
		return list;		
	}

	@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public BaseModelCollection<String> getMajors() {
		BaseModelCollection<String> list = new BaseModelCollection<String>();
		String query = this.getSql("getMajorList");		
		try{			
			list.setList(getJdbcTemplate().queryForList(query, String.class));
			logger.debug("Major List was loaded properly");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Major data was not found" );
		}catch (Exception ex) {
			logger.debug("Major data was not found" );
		}
		return list;		
	}

	@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public BaseModelCollection<String> getUniversities() {
		BaseModelCollection<String> list = new BaseModelCollection<String>();
		String query = this.getSql("getUniversityList");		
		try{			
			list.setList(getJdbcTemplate().queryForList(query, String.class));
			logger.debug("University List was loaded properly");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("University data was not found" );
		}catch (Exception ex) {
			logger.debug("University data was not found" );
		}
		return list;		
	}

	@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)
	public BaseModelCollection<String> getDegrees(String country) {
		BaseModelCollection<String> list = new BaseModelCollection<String>();
		String query = this.getSql("getDegreeByCountry");		
		try{			
			list.setList(getJdbcTemplate().queryForList(query, String.class, new Object[]{country}));
			logger.debug("Degree List was loaded properly for " + country);			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Degree data was not found" );
		}catch (Exception ex) {
			logger.debug("Degree data was not found" );
		}
		return list;		
	}

	//@Cache(nodeName="/profile/search/catalog", keyGeneratorClass=SearchKeyGenerator.class, cacheName=InfinispanCacheFactory.SEARCHCACHE)	
	public BaseModelCollection<EducationUniversity> getUniversities(String country, String university) {
		BaseModelCollection<EducationUniversity> list = new BaseModelCollection<EducationUniversity>();
		String query = this.getSql("getUniversityByCountry");	
		String query1 = this.getSql("searchUniversity");
		try{
			if(country != null && !country.equalsIgnoreCase("COUNTRY")){
				if(university!=null && !university.equalsIgnoreCase("")){
					university = "%"+university+ "%";
					list.setList(getJdbcTemplate().query(query1,new EducationUniversityMapper(), new Object[]{country,university}));
				}else{
					list.setList(getJdbcTemplate().query(query, new EducationUniversityMapper(), new Object[]{country}));
				}				
			}
			logger.debug("University List was loaded properly for " +country );			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("University data was not found" );
		}catch (Exception ex) {
			logger.debug("University data was not found" );
		}
		return list;		
	}

	@PreAuthorize("hasPermission(#sso, 'ResumeProfessionalCertificationEdit', read)")
	public boolean saveProfessionalCertifications(Long sso,
			List<Certification> certificationList) {
		String addQuery = this.getSql("addCertification");
		String deleteQuery = this.getSql("deleteCertificationBySso");
		try{
			getJdbcTemplate().update(deleteQuery, new Object[]{sso});
			for(Certification cert : certificationList){
				getJdbcTemplate().update(addQuery, new Object[]{sso, personalInfoService.escapeSpecialCharacters(cert.getTrainingName()), cert.getCertificationYear()});			
			}
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Certification data updated sucessfully");
			return false;
		}catch(Exception e){
			logger.debug("Certification data could not be updated");
			return false;
		}
		return true;
	}

	@Override
	public BaseModelCollection<Certification> getCertificationsBySso(Long sso) {
		BaseModelCollection<Certification> certifications = new BaseModelCollection<Certification>();
		String query = this.getSql("getCertificationBySso");		
		try{
			certifications.setList(getJdbcTemplate().query(query, new Object[]{sso.intValue()}, new CertificationMapper()));
			logger.debug("Professional Certification data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Professional Certification data was not found");
		}catch (Exception ex) {
			logger.debug("Professional Certification data was not found" );
		}
		
		return certifications;
	}
}
