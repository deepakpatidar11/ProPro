package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.LPBridgeAssignment;

public class LPBridgeAssignmentMapper implements RowMapper<LPBridgeAssignment> {

	public static final String DATA_SSO = "sso";
	public static final String DATA_PROGRAMSHORTNAME = "programshortname";
	public static final String DATA_LEADERNAME = "leader_full_name";
	public static final String DATA_SUBBUSINESS = "rotationsubbusinessname";
	public static final String DATA_ROTATION_TITLE = "rotationtitle";
	public static final String DATA_ROTATION_NUMBER = "rotationnumber";
	
	@Override
	public LPBridgeAssignment mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		LPBridgeAssignment lpBridgeAssignment = new LPBridgeAssignment();
		lpBridgeAssignment.setSso(rs.getLong(DATA_SSO));
		lpBridgeAssignment.setAssignmentLeaderFor(rs.getString(DATA_PROGRAMSHORTNAME));
		lpBridgeAssignment.setAssignmentLeaderName(rs.getString(DATA_LEADERNAME));
		lpBridgeAssignment.setAssignmentSubBusiness(rs.getString(DATA_SUBBUSINESS));
		lpBridgeAssignment.setAssignmentTitle(DATA_ROTATION_TITLE);
		lpBridgeAssignment.setRotationNumber(rs.getString(DATA_ROTATION_NUMBER));
		return lpBridgeAssignment;
	}


}
