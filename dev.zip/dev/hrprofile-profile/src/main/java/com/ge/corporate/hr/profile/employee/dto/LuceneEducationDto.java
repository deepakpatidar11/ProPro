package com.ge.corporate.hr.profile.employee.dto;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;


public class LuceneEducationDto extends AbstractBaseDtoSupport {

	private long sso;
	private String eduDegree;
	private String eduMajor;
	private String eduUniversity;
	private String eduCountry;

	public LuceneEducationDto(long sso, String eduDegree, String eduMajor,
			String eduUniversity, String eduCountry) {
		super();
		this.sso = sso;
		this.eduDegree = eduDegree;
		this.eduMajor = eduMajor;
		this.eduUniversity = eduUniversity;
		this.eduCountry = eduCountry;
	}

	public LuceneEducationDto() {
		super();
	}

	public long getSso() {
		return sso;
	}

	public void setSso(long sso) {
		this.sso = sso;
	}

	public String getEduDegree() {
		return eduDegree;
	}

	public void setEduDegree(String eduDegree) {
		this.eduDegree = eduDegree;
	}

	public String getEduMajor() {
		return eduMajor;
	}

	public void setEduMajor(String eduMajor) {
		this.eduMajor = eduMajor;
	}

	public String getEduUniversity() {
		return eduUniversity;
	}

	public void setEduUniversity(String eduUniversity) {
		this.eduUniversity = eduUniversity;
	}

	public String getEduCountry() {
		return eduCountry;
	}

	public void setEduCountry(String eduCountry) {
		this.eduCountry = eduCountry;
	}

	@Override
	public long getId() {
		// TODO Auto-generated method stub
		return 0;
	}

}
