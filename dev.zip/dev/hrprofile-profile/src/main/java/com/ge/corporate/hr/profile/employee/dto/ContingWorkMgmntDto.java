/*******************************************************************************
 * Copyright � 2013 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename	:	ContingWorkMgmnt.java
 *  Created on 06/19/2013
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/

package com.ge.corporate.hr.profile.employee.dto;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.dto.BaseDtoSupport;


@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name="ContingWorkMgmnt")
public class ContingWorkMgmntDto implements BaseDtoSupport,Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 6426795134313470526L;

	/**
	 * 
	 */
	


	@XmlElement(name="workReqId")
	private Long workReqId;
	
	@XmlElement(name="workRedStartDate")
	private Date workReqStartDate;
	
	@XmlElement(name="workReqEndDate")
	private Date workReqEndDate;
	
	@XmlElement(name="workReqName")
	private String workReqName;
	
	@XmlElement(name="workReqStatus")
	private String workReqStatus;
	
	@XmlElement(name="supplier")
	private String supplier;
	
	@XmlElement(name="workerType")
	private String workerType;
	
	@XmlElement(name="apprvdResources")
	private String apprvdResources;
	
	@XmlElement(name="actlResources")
	private String actlResources;
	
	@XmlElement(name="sso")
	private String sso;
	
	@XmlElement(name="ssoStartDate")
	private Date ssoStartDate;
	
	@XmlElement(name="ssoEndDate")
	private Date ssoEndDate;
	
	public Long getWorkReqId() {
		return workReqId;
	}

	public void setWorkReqId(Long workReqId) {
		this.workReqId = workReqId;
	}

	public Date getWorkReqStartDate() {
		return workReqStartDate;
	}

	public void setWorkReqStartDate(Date workReqStartDate) {
		this.workReqStartDate = workReqStartDate;
	}

	public Date getWorkReqEndDate() {
		return workReqEndDate;
	}

	public void setWorkReqEndDate(Date workReqEndDate) {
		this.workReqEndDate = workReqEndDate;
	}

	public String getWorkReqName() {
		return workReqName;
	}

	public void setWorkReqName(String workReqName) {
		this.workReqName = workReqName;
	}

	public String getWorkReqStatus() {
		return workReqStatus;
	}

	public void setWorkReqStatus(String workReqStatus) {
		this.workReqStatus = workReqStatus;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public String getWorkerType() {
		return workerType;
	}

	public void setWorkerType(String workerType) {
		this.workerType = workerType;
	}

	public String getApprvdResources() {
		return apprvdResources;
	}

	public void setApprvdResources(String apprvdResources) {
		this.apprvdResources = apprvdResources;
	}

	public String getActlResources() {
		return actlResources;
	}

	public void setActlResources(String actlResources) {
		this.actlResources = actlResources;
	}

	public String getSso() {
		return sso;
	}

	public void setSso(String sso) {
		this.sso = sso;
	}

	public Date getSsoStartDate() {
		return ssoStartDate;
	}

	public void setSsoStartDate(Date ssoStartDate) {
		this.ssoStartDate = ssoStartDate;
	}

	public Date getSsoEndDate() {
		return ssoEndDate;
	}

	public void setSsoEndDate(Date ssoEndDate) {
		this.ssoEndDate = ssoEndDate;
	}

	public long getId() {
		// TODO Auto-generated method stub
		return 0;
	}

	
	
}
