/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="incentiveCompensation")
@XmlAccessorType(XmlAccessType.FIELD)
public class IncentiveCompensation extends AbstractBaseModelSupport{

	private static final long serialVersionUID = -5674032496525136670L;
	
	
	@XmlElement(name="sso")
	private Long sso;
	@XmlAttribute(name="id")
	private Long id;	
	@XmlElement(name="amount")
	private Long amount;
	@XmlElement(name="currency")
	private String currency;
	@XmlElement(name="perfYear")
	private Short perfYear;
	@XmlElement(name="changePercent")
	private Double changePercent;
	@XmlElement(name="type")
	private String type;
	@XmlElement(name="futureDate")
	private Boolean futureDate;
	
	
	public IncentiveCompensation(){
		
	}
	
	public IncentiveCompensation(Long sso, Long amount, String currency, 
									Short perfYear, Double changePercent, String type){
		this.sso = sso;
		this.amount = amount;
		this.currency = currency;	
		this.perfYear = perfYear;
		this.changePercent = changePercent;
		this.type = type;
	}
	
	
	public void setId(Long id) {
		this.id = id;
	}	
	public Long getId() {
		return id;
	}	
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	public Long getAmount() {
		return amount;
	}
	public void setAmount(Long amount) {
		this.amount = amount;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}	
	public Double getChangePercent() {
		return changePercent;
	}
	public void setChangePercent(Double changePercent) {
		this.changePercent = changePercent;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public static Long getSerialversionuid() {
		return serialVersionUID;
	}

	public void setPerfYear(Short perfYear) {
		this.perfYear = perfYear;
	}

	public Short getPerfYear() {
		return perfYear;
	}
	
	public void setFutureDate(Boolean futureDate) {
		this.futureDate = futureDate;
	}

	public Boolean isFutureDate() {
		return futureDate;
	}
	
}
