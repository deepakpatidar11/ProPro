/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.security.access.prepost.PreAuthorize;

import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;
import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;
import com.ge.corporate.hr.profile.employee.dao.mapper.EmergencyContactMapper;
import com.ge.corporate.hr.profile.employee.model.EmergencyContact;
import com.ge.corporate.hr.profile.employee.service.cache.DaoKeyGenerator;

/**
 * Emergency Contact dao implementation
 * @author enrique.romero
 *
 */
public class EmergencyContactDaoImpl extends AbstractBaseDaoSupport implements EmergencyContactDao{

	private static Log logger = LogFactory.getLog(EmergencyContactDaoImpl.class);
	
	@Cache(nodeName="/profile/employee/dao/emergencyContact", keyGeneratorClass = DaoKeyGenerator.class, cacheName=InfinispanCacheFactory.EMPDAOCACHE)
	@PreAuthorize("hasPermission(#sso, 'EmergencyContact', read)")
	public EmergencyContact getEmergencyContactBySso(Long sso) {
		// 
		EmergencyContact emergencyContact = new EmergencyContact();
		try{
			String query = this.getSql("getEmergencyContactBySso");		
			emergencyContact = getJdbcTemplate().queryForObject(query, new Object[]{sso.intValue()}, new EmergencyContactMapper());
			logger.debug("EmergencyContact data was loaded susscesfully");
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("EmergencyContact Not found");
		}			
			
		return emergencyContact;
	}
	
}
