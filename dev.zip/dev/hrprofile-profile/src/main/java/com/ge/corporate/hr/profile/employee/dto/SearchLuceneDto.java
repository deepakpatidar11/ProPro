/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class SearchLuceneDto implements Serializable {

	private static final long serialVersionUID = -5065551171795908003L;

	public void copy(SearchLuceneDto searchDto) {
		if (searchDto.getSsoName() != null) {
			this.setSsoName(new String(searchDto.getSsoName()));
		}
		if (searchDto.getTitle() != null) {
			this.setTitle(new String(searchDto.getTitle()));
		}
		if (searchDto.getEmailPhone() != null) {
			this.setEmailPhone(new String(searchDto.getEmailPhone()));
		}
		if (searchDto.getManagerDetails() != null) {
			this.setManagerDetails(new String(searchDto.getManagerDetails()));
		}
		if (searchDto.getWorkHistory() != null) {
			this.setWorkHistory(new String(searchDto.getWorkHistory()));
		}
		if (searchDto.getEduTrng() != null) {
			this.setEduTrng(new String(searchDto.getEduTrng()));
		}
		if (searchDto.getOrganization() != null) {
			this.setOrganization(new String(searchDto.getOrganization()));
		}
		if (searchDto.getLocation() != null) {
			this.setLocation(new String(searchDto.getLocation()));
		}
		if (searchDto.getIfg() != null) {
			this.setIfg(new ArrayList<String>(searchDto.getIfg()));
		}
		if (searchDto.getBusiness() != null) {
			this.setBusiness(new ArrayList<String>(searchDto.getBusiness()));
		}
		if (searchDto.getSubBusiness() != null) {
			this.setSubBusiness(new ArrayList<String>(searchDto
					.getSubBusiness()));
		}
		if (searchDto.getBand() != null) {
			this.setBand(new ArrayList<String>(searchDto.getBand()));
		}
		if (searchDto.getCountry() != null) {
			this.setCountry(new ArrayList<String>(searchDto.getCountry()));
		}
		if (searchDto.getFunction() != null) {
			this.setFunction(new ArrayList<String>(searchDto.getFunction()));
		}
		if (searchDto.getRegion() != null) {
			this.setRegion(new ArrayList<String>(searchDto.getRegion()));
		}
		if (searchDto.getJobFamily() != null) {
			this.setJobFamily(new ArrayList<String>(searchDto.getJobFamily()));
		}
		if (searchDto.getLeadershipProgram() != null) {
			this.setLeadershipProgram(new ArrayList<String>(searchDto
					.getLeadershipProgram()));
		}
		if (searchDto.getLeadershipProgramType() != null) {
			this.setLeadershipProgramType(new String(searchDto
					.getLeadershipProgramType()));
		}
		if (searchDto.getPrsnType() != null) {
			this.setPrsnType(new String(searchDto
					.getPrsnType()));
		}
		if (searchDto.getDirectoryIncl() != null) {
			this.setDirectoryIncl(new String(searchDto
					.getDirectoryIncl()));
		}
		if (searchDto.getTechDisciplineKW()!= null) {
			this.setTechDisciplineKW(new ArrayList<String>(searchDto
					.getTechDisciplineKW()));
		}
		if (searchDto.getTechDisciplineSTD() != null) {
			this.setTechDisciplineSTD(new ArrayList<String>(searchDto
					.getTechDisciplineSTD()));
		}
		if (searchDto.getReportingBusiness()!= null) {
			this.setReportingBusiness(new ArrayList<String>(searchDto.getReportingBusiness()));
		}
		if (searchDto.getReportingIFG()!= null) {
			this.setReportingIFG(new ArrayList<String>(searchDto.getReportingIFG()));
		}
		if (searchDto.getAffiliations()!= null) {
			this.setAffiliations(new String(searchDto.getAffiliations()));
		}
		if (searchDto.getCareerInterests()!= null) {
			this.setCareerInterests(new String(searchDto.getCareerInterests()));
		}
		if (searchDto.getCustomerSuppliers()!= null) {
			this.setCustomerSuppliers(new String(searchDto.getCustomerSuppliers()));
		}
		if (searchDto.getInitiativesProjects()!= null) {
			this.setInitiativesProjects(new String(searchDto.getInitiativesProjects()));
		}
		if (searchDto.getInterests()!= null) {
			this.setInterests(new String(searchDto.getInterests()));
		}
		if (searchDto.getLanguageProficiency()!= null) {
			this.setLanguageProficiency(new ArrayList<String>(searchDto.getLanguageProficiency()));
		}
		if (searchDto.getProfessionalSummary()!= null) {
			this.setProfessionalSummary(new String(searchDto.getProfessionalSummary()));
		}
		if (searchDto.getTalentPool()!= null) {
			this.setTalentPool(new ArrayList<String>(searchDto.getTalentPool()));
		}
		if (searchDto.getSearchAllInput() != null) {
			this.setSearchAllInput(new String(searchDto.getSearchAllInput()));
		}
		if (searchDto.getSearchByCategory() != null) {
			this.setSearchByCategory(new String(searchDto.getSearchByCategory()));
		}
		if (searchDto.getAssignmentLeaderFor() != null) {
			this.setAssignmentLeaderFor(new ArrayList<String>(searchDto
					.getAssignmentLeaderFor()));
		}
		if (searchDto.getAssignmentSubBusiness() != null) {
			this.setAssignmentSubBusiness(new ArrayList<String>(searchDto
					.getAssignmentSubBusiness()));
		}
		if (searchDto.getRotationNumber() != null) {
			this.setRotationNumber(new String(searchDto
					.getRotationNumber()));
		}
		if (searchDto.getAssignmentLeaderName() != null) {
			this.setAssignmentLeaderName(new String(searchDto
					.getAssignmentLeaderName()));
		}
		if (searchDto.getAssignmentTitle() != null) {
			this.setAssignmentTitle(new String(searchDto
					.getAssignmentTitle()));
		}
		if (searchDto.getMentoring() != null) {
			this.setMentoring(new String(searchDto
					.getMentoring()));
		}
	}

	@XmlElement(name = "ssoName")
	public String ssoName;

	@XmlElement(name = "title")
	public String title;

	@XmlElement(name = "emailPhone")
	public String emailPhone;

	@XmlElement(name = "managerDetails")
	private String managerDetails;

	@XmlElement(name = "function")
	private List<String> function;

	@XmlElement(name = "jobFamily")
	private List<String> jobFamily;

	@XmlElement(name = "techDisciplineKW")
	private List<String> techDisciplineKW;

	@XmlElement(name = "techDisciplineSTD")
	private List<String> techDisciplineSTD;

	@XmlElement(name = "band")
	private List<String> band;
	
	@XmlElement(name = "ifg")
	private List<String> ifg;

	@XmlElement(name = "business")
	private List<String> business;

	@XmlElement(name = "subBusiness")
	private List<String> subBusiness;

	@XmlElement(name = "organization")
	private String organization;

	@XmlElement(name = "reportingIFG")
	private List<String> reportingIFG;

	@XmlElement(name = "reportingBusiness")
	private List<String> reportingBusiness;

	@XmlElement(name = "location")
	private String location;

	@XmlElement(name = "region")
	private List<String> region;

	@XmlElement(name = "country")
	private List<String> country;
	
	@XmlElement(name = "city")
	private List<String> city;

	@XmlElement(name="professionalSummary")
	private String professionalSummary;
	
	@XmlElement(name = "workHistory")
	private String workHistory;

	@XmlElement(name="careerInterests")
	private String careerInterests;

	@XmlElement(name="initiativesProjects")
	private String initiativesProjects;
	
	@XmlElement(name="customerSuppliers")
	private String customerSuppliers;
	
	@XmlElement(name="talentPool")
	private List<String> talentPool;
	
	@XmlElement(name = "eduTrng")
	private String eduTrng;

	@XmlElement(name="languageProficiency")
	private List<String> languageProficiency;
	
	@XmlElement(name="empExpertise")
	private List<String> empExpertise;
	
	@XmlElement(name = "leadershipProgram")
	private List<String> leadershipProgram;

	@XmlElement(name = "leadershipProgramType")
	private String leadershipProgramType;

	@XmlElement(name = "rotationNumber")
	private String rotationNumber;

	@XmlElement(name = "assignmentTitle")
	private String assignmentTitle;

	@XmlElement(name = "assignmentLeaderName")
	private String assignmentLeaderName;

	@XmlElement(name = "assignmentSubBusiness")
	private List<String> assignmentSubBusiness;

	@XmlElement(name = "assignmentLeaderFor")
	private List<String> assignmentLeaderFor;

	@XmlElement(name = "workMobility")
	private List<String> workMobility;

	@XmlElement(name = "workMobilityType")
	private String workMobilityType;

	@XmlElement(name="interests")
	private String interests;
	
	@XmlElement(name="affiliations")
	private String affiliations;
	
	@XmlElement(name = "mentoring")
	private String mentoring;

	@XmlElement(name = "resultCountLabel")
	public String resultCountLabel;
	
	@XmlElement(name = "prsnType")
	private String prsnType;

	@XmlElement(name = "directoryIncl")
	private String directoryIncl;

	@XmlElement(name = "searchAllInput")
	private String searchAllInput;

	@XmlElement(name = "searchByCategory")
	public String searchByCategory;

	public String getResultCountLabel() {
		return resultCountLabel;
	}

	public void setResultCountLabel(String resultCountLabel) {
		this.resultCountLabel = resultCountLabel;
	}

	public String getManagerDetails() {
		return managerDetails;
	}

	public void setManagerDetails(String managerDetails) {
		this.managerDetails = managerDetails;
	}

	public String getWorkHistory() {
		return workHistory;
	}

	public void setWorkHistory(String workHistory) {
		this.workHistory = workHistory;
	}

	public String getEduTrng() {
		return eduTrng;
	}

	public void setEduTrng(String eduTrng) {
		this.eduTrng = eduTrng;
	}

	public void setIfg(List<String> ifg) {
		this.ifg = ifg;
	}

	public List<String> getIfg() {
		return ifg;
	}

	public List<String> getBusiness() {
		return business;
	}

	public void setBusiness(List<String> business) {
		this.business = business;
	}

	public List<String> getSubBusiness() {
		return subBusiness;
	}

	public void setSubBusiness(List<String> subBusiness) {
		this.subBusiness = subBusiness;
	}

	public List<String> getBand() {
		return band;
	}

	public void setBand(List<String> band) {
		this.band = band;
	}

	public List<String> getFunction() {
		return function;
	}

	public void setFunction(List<String> function) {
		this.function = function;
	}

	public List<String> getRegion() {
		return region;
	}

	public void setRegion(List<String> region) {
		this.region = region;
	}

	public List<String> getCountry() {
		return country;
	}

	public void setCountry(List<String> country) {
		this.country = country;
	}
	
	public List<String> getCity() {
		return city;
	}
	
	public void setCity(List<String> city) {
		this.city = city;
	}
	
	public List<String> getJobFamily() {
		return jobFamily;
	}

	public void setJobFamily(List<String> jobFamily) {
		this.jobFamily = jobFamily;
	}

	public List<String> getLeadershipProgram() {
		return leadershipProgram;
	}

	public void setLeadershipProgram(List<String> leadershipProgram) {
		this.leadershipProgram = leadershipProgram;
	}

	public String getLeadershipProgramType() {
		return leadershipProgramType;
	}

	public void setLeadershipProgramType(String leadershipProgramType) {
		this.leadershipProgramType = leadershipProgramType;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getSsoName() {
		return ssoName;
	}

	public void setSsoName(String ssoName) {
		this.ssoName = ssoName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getEmailPhone() {
		return emailPhone;
	}

	public void setEmailPhone(String emailPhone) {
		this.emailPhone = emailPhone;
	}

	public String getPrsnType() {
		return prsnType;
	}

	public void setPrsnType(String prsnType) {
		this.prsnType = prsnType;
	}

	public List<String> getTechDisciplineKW() {
		return techDisciplineKW;
	}

	public void setTechDisciplineKW(List<String> techDisciplineKW) {
		this.techDisciplineKW = techDisciplineKW;
	}

	public List<String> getTechDisciplineSTD() {
		return techDisciplineSTD;
	}

	public void setTechDisciplineSTD(List<String> techDisciplineSTD) {
		this.techDisciplineSTD = techDisciplineSTD;
	}

	public String getDirectoryIncl() {
		return directoryIncl;
	}

	public void setDirectoryIncl(String directoryIncl) {
		this.directoryIncl = directoryIncl;
	}

	public List<String> getReportingIFG() {
		return reportingIFG;
	}

	public void setReportingIFG(List<String> reportingIFG) {
		this.reportingIFG = reportingIFG;
	}

	public List<String> getReportingBusiness() {
		return reportingBusiness;
	}

	public void setReportingBusiness(List<String> reportingBusiness) {
		this.reportingBusiness = reportingBusiness;
	}

	public String getProfessionalSummary() {
		return professionalSummary;
	}

	public void setProfessionalSummary(String professionalSummary) {
		this.professionalSummary = professionalSummary;
	}

	public String getCareerInterests() {
		return careerInterests;
	}

	public void setCareerInterests(String careerInterests) {
		this.careerInterests = careerInterests;
	}

	public String getInitiativesProjects() {
		return initiativesProjects;
	}

	public void setInitiativesProjects(String initiativesProjects) {
		this.initiativesProjects = initiativesProjects;
	}

	public String getCustomerSuppliers() {
		return customerSuppliers;
	}

	public void setCustomerSuppliers(String customerSuppliers) {
		this.customerSuppliers = customerSuppliers;
	}

	public List<String> getTalentPool() {
		return talentPool;
	}

	public void setTalentPool(List<String> talentPool) {
		this.talentPool = talentPool;
	}

	public List<String> getLanguageProficiency() {
		return languageProficiency;
	}

	public void setLanguageProficiency(List<String> languageProficiency) {
		this.languageProficiency = languageProficiency;
	}

	public List<String> getEmpExpertise() {
		return empExpertise;
	}
	
	public void setEmpExpertise(List<String> empExpertise) {
		this.empExpertise = empExpertise;
	}
	
	public String getInterests() {
		return interests;
	}

	public void setInterests(String interests) {
		this.interests = interests;
	}

	public String getAffiliations() {
		return affiliations;
	}

	public void setAffiliations(String affiliations) {
		this.affiliations = affiliations;
	}

	public String getSearchAllInput() {
		return searchAllInput;
	}

	public void setSearchAllInput(String searchAllInput) {
		this.searchAllInput = searchAllInput;
	}

	public long getId() {
		return 0;
	}

	public String getSearchByCategory() {
		return searchByCategory;
	}

	public void setSearchByCategory(String searchByCategory) {
		this.searchByCategory = searchByCategory;
	}

	public List<String> getWorkMobility() {
		return workMobility;
	}

	public void setWorkMobility(List<String> workMobility) {
		this.workMobility = workMobility;
	}

	public String getWorkMobilityType() {
		return workMobilityType;
	}

	public void setWorkMobilityType(String workMobilityType) {
		this.workMobilityType = workMobilityType;
	}

	public String getRotationNumber() {
		return rotationNumber;
	}

	public void setRotationNumber(String rotationNumber) {
		this.rotationNumber = rotationNumber;
	}

	public String getAssignmentTitle() {
		return assignmentTitle;
	}

	public void setAssignmentTitle(String assignmentTitle) {
		this.assignmentTitle = assignmentTitle;
	}

	public String getAssignmentLeaderName() {
		return assignmentLeaderName;
	}

	public void setAssignmentLeaderName(String assignmentLeaderName) {
		this.assignmentLeaderName = assignmentLeaderName;
	}

	public List<String> getAssignmentSubBusiness() {
		return assignmentSubBusiness;
	}

	public void setAssignmentSubBusiness(List<String> assignmentSubBusiness) {
		this.assignmentSubBusiness = assignmentSubBusiness;
	}

	public List<String> getAssignmentLeaderFor() {
		return assignmentLeaderFor;
	}

	public void setAssignmentLeaderFor(List<String> assignmentLeaderFor) {
		this.assignmentLeaderFor = assignmentLeaderFor;
	}

	public String getMentoring() {
		return mentoring;
	}

	public void setMentoring(String mentoring) {
		this.mentoring = mentoring;
	}

}
