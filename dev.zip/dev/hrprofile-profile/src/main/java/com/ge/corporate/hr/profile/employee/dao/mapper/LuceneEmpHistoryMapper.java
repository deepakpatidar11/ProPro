package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.dto.LuceneEmpHistoryDto;

public class LuceneEmpHistoryMapper implements RowMapper<LuceneEmpHistoryDto> {

	public static final String DATA_BUSINESS_CARD = "emh_business_card";
	public static final String DATA_GE_BUSINESS = "emh_ge_business";
	public static final String DATA_LOCATION = "emh_loacation";
	public static final String DATA_FUNCTION_DES = "emh_function_des";
	public static final String DATA_FROM_DATE = "emh_from_date";
	public static final String DATA_TO_DATE = "emh_to_date";
	public static final String DATA_MANAGER = "emh_manager";
	public static final String DATA_SSO = "sso";
	public static final String DATA_EMH_EXP_DESC = "EMH_EXP_DESC";
	
	@Override
	public LuceneEmpHistoryDto mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		LuceneEmpHistoryDto emh = new LuceneEmpHistoryDto();
		emh.setBusinessCard(rs.getString(DATA_BUSINESS_CARD));
		emh.setFromDate(rs.getDate(DATA_FROM_DATE));
		emh.setFunctionDes(rs.getString(DATA_FUNCTION_DES));
		emh.setGeBusiness(rs.getString(DATA_GE_BUSINESS));
		emh.setLocation(rs.getString(DATA_LOCATION));
		emh.setManager(rs.getString(DATA_MANAGER));
		emh.setSso(rs.getLong(DATA_SSO));
		emh.setToDate(rs.getDate(DATA_TO_DATE));
		emh.setExpDesc(rs.getString(DATA_EMH_EXP_DESC));
		return emh;
	}

}
