package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "affinityGroups")
@XmlAccessorType(XmlAccessType.FIELD)
public class AffinityGroups {

	private Long sso;

	private Short dateJoined;

	private String groupType;

	private String groupName;

	private String Position;

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public Short getDateJoined() {
		return dateJoined;
	}

	public void setDateJoined(Short dateJoined) {
		this.dateJoined = dateJoined;
	}

	public String getGroupType() {
		return groupType;
	}

	public void setGroupType(String groupType) {
		this.groupType = groupType;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getPosition() {
		return Position;
	}

	public void setPosition(String position) {
		Position = position;
	}

}
