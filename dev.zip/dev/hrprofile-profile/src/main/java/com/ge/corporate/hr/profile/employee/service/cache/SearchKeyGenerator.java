/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/

package com.ge.corporate.hr.profile.employee.service.cache;
import com.ge.corporate.hr.profile.common.cache.KeyGenerator;

/**
 * Key Generator used when jboss cache stores dtos in cache,
 * each dto stored in cache belongs to each authenticated user
 * @param <T>
 *
 */
public class SearchKeyGenerator implements KeyGenerator<String> {
	public String generateKey(
			String className, 
			String methodName,
			Object[] args) {		
	    StringBuilder key = new StringBuilder();
	    key.append(methodName);
	    if(args.length > 0){
	    	String param = (String)args[0];
	    	if(param != null){
	    		key.append("_").append(param);
	    	}
	    }
	    return key.toString();	
	}
}