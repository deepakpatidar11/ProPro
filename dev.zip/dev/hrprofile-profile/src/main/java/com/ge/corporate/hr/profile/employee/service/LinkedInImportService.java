package com.ge.corporate.hr.profile.employee.service;

public interface LinkedInImportService {

	public String requestAuthCodeUrl(String state);
	
	public String recieveAccessToken(String code);
	
	public String importLinkedInData(String token);

}
