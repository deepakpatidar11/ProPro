package com.ge.corporate.hr.profile.employee.dao;

import java.util.List;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dto.InterestAffiliationDto;
import com.ge.corporate.hr.profile.employee.model.AffinityGroups;
import com.ge.corporate.hr.profile.employee.model.Mentoring;
import com.ge.corporate.hr.profile.employee.model.OnlineNetwork;

public interface InterestAffiliationDao {

	public InterestAffiliationDto getEmployeeInterests(Long sso);

	public boolean saveProfessionalInterests(Long sso, String interests);
	public boolean saveMentoringData(Long sso, Mentoring mentoring);
	public BaseModelCollection<OnlineNetwork> getEmployeeNetworks(Long sso);

	public Mentoring getMentoringData(Long sso, boolean connectFlag);
	
	public boolean saveOnlineNetworks(Long sso,
			List<OnlineNetwork> networks);

	public BaseModelCollection<AffinityGroups> getExternalAffiliations(Long sso);

	public boolean saveExternalAffiliations(Long sso,
			List<AffinityGroups> externalAffiliations);
}
