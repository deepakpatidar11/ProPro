/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;

import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;
import com.ge.corporate.hr.profile.employee.dao.mapper.OptinSharingMapper;
import com.ge.corporate.hr.profile.employee.dao.mapper.PropertyMapper;
import com.ge.corporate.hr.profile.employee.model.OptinSharing;
import com.ge.corporate.hr.profile.employee.model.Property;

public class OptinSharingDaoImpl extends AbstractBaseDaoSupport  implements OptinSharingDao{
	
	
	public boolean setOptinSharingDao(Long principal, String type, String value){
		String query = this.getSql("setOptinSharingBySso");	
		try{			
			getJdbcTemplate().update(query.replaceAll("COL_NAME", type).replaceAll("VALUE", value),new Object[]{principal});
			logger.debug("Optin Sharing Data Updated");			
		}catch (Exception e) {
			logger.debug("Optin Sharing Data was not Updated for "+principal);
			return false;
		}				
		return true;
	}
	
	//@PreAuthorize("hasPermission(#sso, 'Education', read)")
	public OptinSharing getOptinSharingDao(Long sso){
		OptinSharing optinSharing = new OptinSharing();
		String query = this.getSql("getOptinSharingBySso");		
		try{			
			optinSharing = getJdbcTemplate().queryForObject(query, new Object[]{sso}, new OptinSharingMapper());
			logger.debug("Optin Sharing Data Loaded");			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Optin Sharing Data not found for "+sso);
		}				
		return optinSharing;	
	}
	
	public boolean hasOptinServiceAcess(Long sso, String column){
		String value = "N";
		boolean hasAccess = false;
		try{
			if(column.equalsIgnoreCase("leadership_program")){
				value = getJdbcTemplate().queryForObject(getSql("hasLPrgOptinServiceAcessBySso").replaceAll("COLUMNNAME", column),new Object[]{sso}, String.class);
			}else{
				value = getJdbcTemplate().queryForObject(getSql("hasOptinServiceAcessBySso").replaceAll("COLUMNNAME", column),new Object[]{sso}, String.class);
			}
			}catch(EmptyResultDataAccessException eex){
			logger.debug( "Optin data not found for: "+sso );
		}
		
		if(value.equalsIgnoreCase("Y")){
			hasAccess = true;
		}
		return hasAccess;
	}
	
	public List<String> optinTrainingListBySSO(Long sso){
		List<String> trainingName = null;
		boolean hasAccess = false;
		try{
			trainingName = getJdbcTemplate().queryForList(getSql("optinTrainingListBySSO"),new Object[]{sso}, String.class);
		}catch(EmptyResultDataAccessException eex){
			logger.debug( "Optin data not found for: "+sso );
		}		
		return trainingName;
	}
	
	public List<String> allTrainingListBySSO(Long sso){
		List<String> trainingName = null;
		boolean hasAccess = false;
		try{
			trainingName = getJdbcTemplate().queryForList(getSql("allTrainingListBySSO"),new Object[]{sso}, String.class);
		}catch(EmptyResultDataAccessException eex){
			logger.debug( "Optin data not found for: "+sso );
		}		
		return trainingName;
	}
	
	public boolean setTrainingListBySSO(Long principal, String training, boolean delete){
		try{

			if(delete){
				getJdbcTemplate().update(getSql("setOptinSharingTrnListBySsoDel"),new Object[]{principal,training});
			}else{
				getJdbcTemplate().update(getSql("setOptinSharingTrnListBySsoY"),new Object[]{principal,training});
			}

			logger.debug("Optin Sharing Data Updated");			
		}catch (Exception e) {
			logger.debug("Optin Sharing Data was not Updated for "+principal);
			return false;
		}			
		return true;
	}
	
	public boolean delOptinSharingTrnListBySso(Long sso){
		try{
			getJdbcTemplate().update(getSql("setOptinSharingTrnListBySsoN"),new Object[]{sso});
			logger.debug("Optin Sharing Data Updated");			
		}catch (Exception e) {
			logger.debug("Optin Sharing Data was not Updated for "+sso);
			return false;
		}			
		return true;
	}

	@Override
	public List<Property> getSharedTrainingList(Long sso) {
		List<Property> trainingName = new ArrayList<Property>();
		try{
			trainingName = getJdbcTemplate().query(getSql("getSharedTrainingList"),new Object[]{sso,sso,sso,sso,sso,sso}, new PropertyMapper());
		}catch(EmptyResultDataAccessException eex){
			logger.debug( "Optin data not found for: "+sso );
		}		
		return trainingName;
	}
	
	public boolean insertOptinSharing(OptinSharing optinSharing){
		try{
		if(optinSharing.getTrainingList()!=null && optinSharing.getTrainingList().size()>0){
			for(String training : optinSharing.getTrainingList()){
				if(!training.equalsIgnoreCase("")){
					getJdbcTemplate().update(getSql("setOptinSharingTrnListBySsoY"),new Object[]{optinSharing.getSso(),training});
				}
			}
		}
		}catch(Exception e){
			logger.debug( "Optin data not saved for: "+optinSharing.getSso() );
			return false;
		}		
		return true;
	}

	@Override
	public boolean updateOptinSharing(OptinSharing optinSharing) {
		String query = this.getSql("updateOptinSharingBySso");	
		String updatedValues = "";
		try{			
			if(optinSharing.getCareer_aspirations()!=null && !optinSharing.getCareer_aspirations().equalsIgnoreCase("")){
				updatedValues = updatedValues + ", CAREER_ASPIRATIONS=\'" + optinSharing.getCareer_aspirations() + "\'"; 
			}else{
				updatedValues = updatedValues + ", CAREER_ASPIRATIONS=\'N\'"; 
			}
			if(optinSharing.getCustomers_suppliers()!=null && !optinSharing.getCustomers_suppliers().equalsIgnoreCase("")){
				updatedValues = updatedValues + ", CUSTOMERS_SUPPLIERS=\'" + optinSharing.getCustomers_suppliers() + "\'"; 
			}else{
				updatedValues = updatedValues + ", CUSTOMERS_SUPPLIERS=\'N\'"; 
			}
			if(optinSharing.getEducation()!=null && !optinSharing.getEducation().equalsIgnoreCase("")){
				updatedValues = updatedValues + ", EDUCATION=\'" + optinSharing.getEducation() + "\'"; 
			}else{
				updatedValues = updatedValues + ", EDUCATION=\'N\'"; 
			}
			if(optinSharing.getEmp_history()!=null && !optinSharing.getEmp_history().equalsIgnoreCase("")){
				updatedValues = updatedValues + ", EMP_HISTORY=\'" + optinSharing.getEmp_history() + "\'"; 
			}else{
				updatedValues = updatedValues + ", EMP_HISTORY=\'N\'"; 
			}
			if(optinSharing.getExternal_group_affiliations()!=null && !optinSharing.getExternal_group_affiliations().equalsIgnoreCase("")){
				updatedValues = updatedValues + ", EXTERNAL_GROUP_AFFILIATIONS=\'" + optinSharing.getExternal_group_affiliations() + "\'"; 
			}else{
				updatedValues = updatedValues + ", EXTERNAL_GROUP_AFFILIATIONS=\'N\'"; 
			}
			if(optinSharing.getInitiatives_projects()!=null && !optinSharing.getInitiatives_projects().equalsIgnoreCase("")){
				updatedValues = updatedValues + ", INITIATIVES_PROJECTS=\'" + optinSharing.getInitiatives_projects() + "\'"; 
			}else{
				updatedValues = updatedValues + ", INITIATIVES_PROJECTS=\'N\'"; 
			}
			if(optinSharing.getLanguage_proficiency()!=null && !optinSharing.getLanguage_proficiency().equalsIgnoreCase("")){
				updatedValues = updatedValues + ", LANGUAGE_PROFICIENCY=\'" + optinSharing.getLanguage_proficiency() + "\'"; 
			}else{
				updatedValues = updatedValues + ", LANGUAGE_PROFICIENCY=\'N\'"; 
			}
			if(optinSharing.getOnline_networks()!=null && !optinSharing.getOnline_networks().equalsIgnoreCase("")){
				updatedValues = updatedValues + ", ONLINE_NETWORKS=\'" + optinSharing.getOnline_networks() + "\'"; 
			}else{
				updatedValues = updatedValues + ", ONLINE_NETWORKS=\'N\'"; 
			}
			if(optinSharing.getProf_personal_interests()!=null && !optinSharing.getProf_personal_interests().equalsIgnoreCase("")){
				updatedValues = updatedValues + ", PROF_PERSONAL_INTERESTS=\'" + optinSharing.getProf_personal_interests() + "\'"; 
			}else{
				updatedValues = updatedValues + ", PROF_PERSONAL_INTERESTS=\'N\'"; 
			}
			/*if(optinSharing.getProfessional_summary()!=null && !optinSharing.getProfessional_summary().equalsIgnoreCase("")){
				updatedValues = updatedValues + ", PROFESSIONAL_SUMMARY=\'" + optinSharing.getProfessional_summary() + "\'"; 
			}*/
			if(optinSharing.getWork_mobility()!=null && !optinSharing.getWork_mobility().equalsIgnoreCase("")){
				updatedValues = updatedValues + ", WORK_MOBILITY=\'" + optinSharing.getWork_mobility() + "\'"; 
			}else{
				updatedValues = updatedValues + ", WORK_MOBILITY=\'N\'"; 
			}
			//updatedValues = updatedValues + "AND last_updated_date=" + new DATE() + "where sso =\'" + optinSharing.getSso() +"\'";
			updatedValues = updatedValues.replaceFirst(", ", "");
			getJdbcTemplate().update(query.replaceAll("UPDATED_VALUES", updatedValues),new Object[]{optinSharing.getSso()});
			logger.debug("Optin Sharing Data Updated");			
		}catch (Exception e) {
			logger.debug("Optin Sharing Data was not Updated for "+ optinSharing.getSso());
			return false;
		}				
		return true;
	}
	
}
