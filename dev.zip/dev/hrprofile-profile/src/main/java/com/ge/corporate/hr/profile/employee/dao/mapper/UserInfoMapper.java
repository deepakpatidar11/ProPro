/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.UserInfo;

/**
 * Employee Maper
 * @author enrique.romero
 *
 */
public class UserInfoMapper implements RowMapper<UserInfo>{
	
	public static final String DATA_SSO = "sso";
	public static final String DATA_FIRST_NAME = "emps_first_name";
	public static final String DATA_LAST_NAME = "emps_last_name";
	public static final String DATA_PREFERRED_NAME = "emps_preferred_name";
	public static final String DATA_IFG = "emps_ifg";
	public static final String DATA_BUSINESS= "emps_business_name";
	public static final String DATA_SUBBUSINESS= "emps_subbusiness_name";
	public static final String DATA_ORG= "emps_org_name";
	public static final String DATA_FUNCTION = "emps_function";
	public static final String DATA_JOBFAMILY = "emps_job_family";
	
	public UserInfo mapRow(ResultSet rs, int rowNum) throws SQLException {		
		UserInfo employee = new UserInfo();
		
		employee.setSso(rs.getLong(DATA_SSO));		
		employee.setFirstName(rs.getString(DATA_FIRST_NAME));
		employee.setLastName(rs.getString(DATA_LAST_NAME));		
		employee.setPreferedName(rs.getString(DATA_PREFERRED_NAME));
		employee.setIndustrySegment(rs.getString(DATA_IFG));
		employee.setBusiness(rs.getString(DATA_BUSINESS));
		employee.setSubBusiness(rs.getString(DATA_SUBBUSINESS));
		employee.setOrganization(rs.getString(DATA_ORG));
		employee.setFunction(rs.getString(DATA_FUNCTION));
		employee.setJobFamily(rs.getString(DATA_JOBFAMILY));
		//ToDo  missing fields ......			
		return employee;		
	}
	
}
