package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.dto.DirectReportsDto;


public class OrgChartDirectReportsMapper implements RowMapper<DirectReportsDto>{

	
	public static final String DATA_SSO = "sso";
	public static final String DATA_FIRST_NAME = "emp_first_name";
	public static final String DATA_LAST_NAME = "emp_last_name";	
	public static final String DATA_POSITION_TITLE = "emp_title";
	public static final String DATA_MANAGER_SSO = "emp_manager";
	@Override
	public DirectReportsDto mapRow(ResultSet rs, int rowNum)throws SQLException {
	
			DirectReportsDto directReportDto= new DirectReportsDto();
			try	{
					directReportDto.setSso(rs.getLong(DATA_SSO));
					directReportDto.setFirstName(rs.getString(DATA_FIRST_NAME));
					directReportDto.setLastName(rs.getString(DATA_LAST_NAME));
					directReportDto.setTitle(rs.getString(DATA_POSITION_TITLE));
					directReportDto.setManager(rs.getLong(DATA_MANAGER_SSO));
					/*if(directReportDto.getSso().toString().startsWith("5")){
						directReportDto.setIsContingentWorker("Y");
					}else{
						directReportDto.setIsContingentWorker("N");
					}*/
					
				}catch(SQLException e){
				throw new SQLException("data not loaded");
			}

				return directReportDto;
	
	}
}
