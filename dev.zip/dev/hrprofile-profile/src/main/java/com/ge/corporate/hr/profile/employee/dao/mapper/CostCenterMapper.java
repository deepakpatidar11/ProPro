/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao.mapper;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.WorkAssignmentRestricted;


public class CostCenterMapper implements RowMapper<WorkAssignmentRestricted> {
	
	public static final String DATA_COST_CENTER = "EMP_COST_CENTER_CODE";
	public static final String DATA_BUC = "WA_BUC";
	public static final String DATA_ADN = "WA_ADN";
	public static final String LDGR_CST_CTR = "WA_OPRTNG_LDGR_CST_CTR";
	public static final String LDGR_BUC = "WA_OPRTNG_LDGR_BUC";
	public static final String LDGR_CC = "WA_OPRTNG_LDGR_CC";
	public static final String LDGR_PL ="WA_OPRTNG_LDGR_PL";
	public static final String LDGR_PRI_CD = "WA_OPRTNG_LDGR_PRI_CD";
	public static final String LDGR_REF_CD = "WA_OPRTNG_LDGR_REF_CD";
	public static final String ENT_STD_FLAG = "WA_BUC_ENT_STD_FLAG";
	
	public static final String DATA_HEADCOUNT_COST_CENTER_CODE = "EMP_HEADCOUNT_COST_CENTER_CODE";
	
	
	public WorkAssignmentRestricted mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		WorkAssignmentRestricted assignment = new WorkAssignmentRestricted();	
		assignment.setEnterpriseStandard(rs.getString(ENT_STD_FLAG));
		assignment.setCostCenter(rs.getString(DATA_COST_CENTER));
		assignment.setBuc(rs.getString(DATA_BUC));
		assignment.setAdn(rs.getString(DATA_ADN));
		assignment.setLdgrCostCenter(rs.getString(LDGR_CST_CTR));
		assignment.setLdgrBuc(rs.getString(LDGR_BUC));
		assignment.setLdgrCompanyLine(rs.getString(LDGR_CC));
		assignment.setLdgrProductLine(rs.getString(LDGR_PL));
		assignment.setLdgrProjectCode(rs.getString(LDGR_PRI_CD));
		assignment.setLdgrRefId(rs.getString(LDGR_REF_CD));
		//assignment.setHeadcountCostCenterCode(rs.getString(DATA_HEADCOUNT_COST_CENTER_CODE));
		
		return assignment;		
	}
}
