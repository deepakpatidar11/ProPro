/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

public class Currency extends AbstractBaseModelSupport {

	private static final long serialVersionUID = 2987535884008808310L;
	
	private String currency;
	private Double ammount;
	
	private String currencyConverted;
	private Double ammountConverted;
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public Double getAmmount() {
		return ammount;
	}
	public void setAmmount(Double ammount) {
		this.ammount = ammount;
	}
	public String getCurrencyConverted() {
		return currencyConverted;
	}
	public void setCurrencyConverted(String currencyConverted) {
		this.currencyConverted = currencyConverted;
	}
	public Double getAmmountConverted() {
		return ammountConverted;
	}
	public void setAmmountConverted(Double ammountConverted) {
		this.ammountConverted = ammountConverted;
	}
	
	
}
