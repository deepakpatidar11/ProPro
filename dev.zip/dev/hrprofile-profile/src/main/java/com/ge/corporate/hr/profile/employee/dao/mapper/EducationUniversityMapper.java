package com.ge.corporate.hr.profile.employee.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.employee.model.EducationUniversity;

public class EducationUniversityMapper implements RowMapper<EducationUniversity>{
	public static final String UNIVERSITY = "university";
	
	public EducationUniversity mapRow(ResultSet rs, int rowNum) throws SQLException {
		EducationUniversity university = new EducationUniversity();
		university.setId(rs.getString(UNIVERSITY));
		university.setUniversity(rs.getString(UNIVERSITY));
		return university;
	}

}
