/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class AutoCompleteViewModel extends AbstractBaseModelSupport {

	private static final long serialVersionUID = -5775495099065784003L;

	List<AutoCompleteRowModel> rows = new ArrayList<AutoCompleteRowModel>();
	
	public AutoCompleteViewModel() {}
	
	public AutoCompleteViewModel(List<AutoCompleteRowModel> rows) {
		this.rows = rows;
	}
	
	public List<AutoCompleteRowModel> getRows() {
		return rows;
	}

	public void setRows(List<AutoCompleteRowModel> rows) {
		this.rows = rows;
	}
	
	
}
