/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="dottedLineManager")
@XmlAccessorType(XmlAccessType.FIELD)
public class DottedLineManager extends AbstractBaseModelSupport{
	
	private static final long serialVersionUID = 46981221793287345L;
	
	@XmlAttribute(name="sso")
	private Long sso; //SSO Id

	@XmlElement(name="dottedLineManager")
	private Long dottedLineManager;//SSO DOTTED LINE MANAGER
	
	@XmlElement(name="dottedLineManagerName")
	private String dottedLineManagerName;
	
	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}

	public Long getDottedLineManager() {
		return dottedLineManager;
	}

	public void setDottedLineManager(Long dottedLineManager) {
		this.dottedLineManager = dottedLineManager;
	}

	public String getDottedLineManagerName() {
		return dottedLineManagerName;
	}

	public void setDottedLineManagerName(String dottedLineManagerName) {
		this.dottedLineManagerName = dottedLineManagerName;
	}

	
}
