/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.dto.ContingAssignmentDto;
import com.ge.corporate.hr.profile.employee.dto.ContingWorkMgmntDto;
import com.ge.corporate.hr.profile.employee.dto.JVAssignmentDto;
import com.ge.corporate.hr.profile.employee.dto.PersonalInfoDto;
import com.ge.corporate.hr.profile.employee.model.EmployeeExpertise;
import com.ge.corporate.hr.profile.employee.model.ProfileCompleteness;
import com.ge.corporate.hr.profile.employee.model.UserInfo;
import com.ge.corporate.hr.profile.employee.ws.dto.EmployeeBasicInfoDto;
import com.ge.corporate.hr.profile.employee.ws.dto.EmployeeDto;

public interface EmployeeProfileService {
	/**
	 * 
	 * @param personalInfo
	 * @return
	 */
	public PersonalInfoDto getPersonalInfo(PersonalInfoDto personalInfo);	
	
	/**
	 * returns a list of Employees with Basic information this methods is used by WS 
	 * @param ssoList
	 * @return
	 */
	public List<EmployeeBasicInfoDto> getEmployeeBasicInfoList(List<Long> ssoList);
	
	/**
	 * returns a list of Employees with Assignment information, this methods is used by WS
	 * @param ssoList
	 * @return
	 */
	public List<EmployeeDto> getEmployeeInfoList(List<Long> ssoList);

	public PersonalInfoDto getContingentPersonalInfo(
			PersonalInfoDto personalInfo);

	public ContingAssignmentDto getContingentWorkAssgnmtInfo(Long sso,
			ContingAssignmentDto contingAssignmentDto);

	public ContingWorkMgmntDto getContingentWorkMgmntInfo(Long sso,
			ContingWorkMgmntDto contingWorkMgmntDto);
	
	/*public void sensitiveDataPopupService(Long sso, String flag);
	
	public boolean isValidSensitiveDataPopupService(Long sso);
	
	public void sensitiveDataPopupDeleteRolesService(Long sso);*/
	
	public boolean isValidSSO(Long sso);

	public boolean showInfoPopupStatusBySSOService(Long sso);
	
	public boolean showWhatsNewPopupBySSOService(Long sso);
	
	public void infoPopupInsertBySSOService(Long sso, String flag);
	
	public void whatsnewInsertBySSOService(Long sso, String flag);
	
	public UserInfo getLoggedUserInfo(Long sso);
	
	public ProfileCompleteness getProfileCompleteness(Long sso, Boolean expertiseFlag);
	
	public ProfileCompleteness getProfileBreakdown(Long sso);
	
	public String escapeSpecialCharacters(String s);

	public boolean addConnection(Long sso, Long connectSSO, int connectionType);

	public boolean deleteConnection(Long sso, Long connectSSO, int connectionType);
	
	public BaseModelCollection<EmployeeExpertise> getExpertiseListBySSO(Long sso);
	
	public BaseModelCollection<EmployeeExpertise> updateEmpExperties(Long sso, List<EmployeeExpertise> expertises);
	
	public Map<String, List<Integer>> getEmpMentoringInterestBySSO(Long sso);

	public void setExpertiseAsString(PersonalInfoDto personalInfo);
	
	public PersonalInfoDto getJVPersonalInfo(
			PersonalInfoDto personalInfo);

	public JVAssignmentDto getJVAssgnmtInfo(Long sso,
			JVAssignmentDto jvAssignmentDto);

	public void captureLoginMetrics(String page, Long ssoViewed, Boolean isCW, List<String> rolesForContext, HttpSession session, String userAgent);
	
	public void insertExpertisePopupBySSOService(Long loggedSSO, String flag);

	public boolean showExpertiseEmptyPopupBySSOService(Long loggedSSO);
}