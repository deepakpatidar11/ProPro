/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;

@XmlRootElement(name="directReportsDto")
@XmlAccessorType(XmlAccessType.FIELD)
public class DirectReportsDto extends AbstractBaseDtoSupport{	
	
	/**
	 * Serial id
	 */
	private static final long serialVersionUID = 1L;
	@XmlElement(name="sso")
	private Long sso;
	@XmlElement(name="firstName")
	private String firstName;
	@XmlElement(name="lastName")	
	private String lastName;
	@XmlElement(name="title")
	private String title;
	@XmlElement(name="manager")
	private Long manager;
	@XmlElement(name = "isContingentWorker")
	private String isContingentWorker;
	@XmlElement(name = "isLongTermSuspend")
	private String isLongTermSuspend;

	public long getId() {
		return (sso==null)?0:sso.longValue();
	}	
	public Long getSso() {
		return sso;
	}	
	public void setSso(Long sso) {
		this.sso = sso;
	}	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getLastName() {
		return lastName;
	}
	public Long getManager() {
		return manager;
	}
	public void setManager(Long manager) {
		this.manager = manager;
	}	
	public String getIsContingentWorker() {
		return isContingentWorker;
	}
	public void setIsContingentWorker(String isContingentWorker) {
		this.isContingentWorker = isContingentWorker;
	}
	public String getIsLongTermSuspend() {
		return isLongTermSuspend;
	}
	public void setIsLongTermSuspend(String isLongTermSuspend) {
		this.isLongTermSuspend = isLongTermSuspend;
	}
	
}
