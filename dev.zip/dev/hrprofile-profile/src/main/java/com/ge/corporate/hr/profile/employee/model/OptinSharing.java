/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.model;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

@XmlRootElement(name="optinSharing")
@XmlAccessorType(XmlAccessType.FIELD)
public class OptinSharing extends AbstractBaseModelSupport{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 120570252065628774L;

	@XmlElement(name="sso")
	private Long sso;
	@XmlElement(name="emp_history")
	private String emp_history;	
	@XmlElement(name="education")
	private String education;	
	@XmlElement(name="training")
	private String training;
	@XmlElement(name="trainingList")
	private List<String> trainingList;
	@XmlElement(name="sharedTrainingList")
	private List<Property> sharedTrainingList;
	@XmlElement(name="last_updated_date")
	private Date last_updated_date;	
	
	@XmlElement(name="language_proficiency")
	private String language_proficiency;
	@XmlElement(name="professional_summary")
	private String professional_summary; 
	@XmlElement(name="work_mobility")
	private String work_mobility; 
	@XmlElement(name="current_job")
	private String current_job;
	@XmlElement(name="career_aspirations")
	private String career_aspirations; 
	@XmlElement(name="initiatives_projects")
	private String initiatives_projects;
	@XmlElement(name="customers_suppliers")
	private String customers_suppliers;
	@XmlElement(name="online_networks")
	private String online_networks; 
	@XmlElement(name="prof_personal_interests")
	private String prof_personal_interests;
	@XmlElement(name="external_group_affiliations")
	private String external_group_affiliations;
	@XmlElement(name="mentoring")
	private String mentoring;
	@XmlElement(name="connections")
	private String connections;
	
	public Long getSso() {
		return sso;
	}
	public void setSso(Long sso) {
		this.sso = sso;
	}
	public String getEmp_history() {
		return emp_history;
	}
	public void setEmp_history(String emp_history) {
		this.emp_history = emp_history;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getTraining() {
		return training;
	}
	public void setTraining(String training) {
		this.training = training;
	}
	public List<String> getTrainingList() {
		return trainingList;
	}
	public void setTrainingList(List<String> trainingList) {
		this.trainingList = trainingList;
	}
	public Date getLast_updated_date() {
		return last_updated_date;
	}
	public void setLast_updated_date(Date last_updated_date) {
		this.last_updated_date = last_updated_date;
	}
	public String getLanguage_proficiency() {
		return language_proficiency;
	}
	public void setLanguage_proficiency(String language_proficiency) {
		this.language_proficiency = language_proficiency;
	}
	public String getProfessional_summary() {
		return professional_summary;
	}
	public void setProfessional_summary(String professional_summary) {
		this.professional_summary = professional_summary;
	}
	public String getWork_mobility() {
		return work_mobility;
	}
	public void setWork_mobility(String work_mobility) {
		this.work_mobility = work_mobility;
	}
	public String getCurrent_job() {
		return current_job;
	}
	public void setCurrent_job(String current_job) {
		this.current_job = current_job;
	}
	public String getCareer_aspirations() {
		return career_aspirations;
	}
	public void setCareer_aspirations(String career_aspirations) {
		this.career_aspirations = career_aspirations;
	}
	public String getInitiatives_projects() {
		return initiatives_projects;
	}
	public void setInitiatives_projects(String initiatives_projects) {
		this.initiatives_projects = initiatives_projects;
	}
	public String getCustomers_suppliers() {
		return customers_suppliers;
	}
	public void setCustomers_suppliers(String customers_suppliers) {
		this.customers_suppliers = customers_suppliers;
	}
	public String getOnline_networks() {
		return online_networks;
	}
	public void setOnline_networks(String online_networks) {
		this.online_networks = online_networks;
	}
	public String getProf_personal_interests() {
		return prof_personal_interests;
	}
	public void setProf_personal_interests(String prof_personal_interests) {
		this.prof_personal_interests = prof_personal_interests;
	}
	public String getExternal_group_affiliations() {
		return external_group_affiliations;
	}
	public void setExternal_group_affiliations(String external_group_affiliations) {
		this.external_group_affiliations = external_group_affiliations;
	}
	public List<Property> getSharedTrainingList() {
		return sharedTrainingList;
	}
	public void setSharedTrainingList(List<Property> sharedTrainingList) {
		this.sharedTrainingList = sharedTrainingList;
	}
	public String getMentoring() {
		return mentoring;
	}
	public void setMentoring(String mentoring) {
		this.mentoring = mentoring;
	}
	public String getConnections() {
		return connections;
	}
	public void setConnections(String connections) {
		this.connections = connections;
	}		
}
