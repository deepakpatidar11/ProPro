/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.CAS;
import com.ge.corporate.hr.profile.employee.model.SixSigma;
import com.ge.corporate.hr.profile.employee.model.Training;
/**
 * Training Dao interface
 * @author enrique.romero
 *
 */
public interface TrainingDao {
	
	/**
	 * Returns Employee Training List by program id
	 * @param sso Employee SSO
	 * @param programId
	 * @return Training Model
	 */
	public BaseModelCollection<Training> getEmployeeTrainingBySso(Long sso);
	public BaseModelCollection<Training> getEmployeeTrainingAllBySso(Long sso);
	public BaseModelCollection<Training> getEmployeeTrainingOptinBySso(Long sso);
	public BaseModelCollection<SixSigma> getSixSigmaBySso(Long sso);
	public BaseModelCollection<CAS> getCASDataBySso(Long sso);

}
