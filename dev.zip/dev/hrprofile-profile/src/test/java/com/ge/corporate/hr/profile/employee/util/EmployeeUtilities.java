/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.util;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class EmployeeUtilities {
	
	public static final String QUERY_EMPLOYEE = "SELECT sso FROM employee WHERE rownum < 11 ORDER BY sso DESC";
	protected SimpleJdbcTemplate simpleJdbcTemplate;
	
	
	@Autowired
	protected void setDataSource(DataSource dataSource) {
		this.simpleJdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}
	
	public Long getRandomSso(){		
		Long sso = null;			
		Random  randomGenerator = new Random();
		
		//Validate minimal information
		List<Map<String, Object>> mappedResultList = simpleJdbcTemplate.queryForList(QUERY_EMPLOYEE);
	
		assertNotNull("Employee table is empty",mappedResultList);		
		assertTrue("There is not enough infromation to test", mappedResultList.size() > 0 );
		
		//Get random index
		int index = randomGenerator.nextInt(9);		
		//Validate getEmployeeBySso
		Map<String, Object> map = mappedResultList.get(index);
		sso =  ((BigDecimal)map.get("sso")).longValue();				
			
		return sso;		
	}
}
