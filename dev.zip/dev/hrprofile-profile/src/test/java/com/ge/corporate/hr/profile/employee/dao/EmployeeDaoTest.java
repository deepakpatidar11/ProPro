/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import static org.junit.Assert.assertNotNull;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.test.context.ContextConfiguration;

import com.ge.corporate.hr.profile.common.dao.BaseDBTest;
import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.employee.model.AuthoritySupervisorHierarchy;
import com.ge.corporate.hr.profile.employee.model.Employee;
import com.ge.corporate.hr.profile.employee.model.Person;
import com.ge.corporate.hr.profile.employee.model.ShortProfile;
import com.ge.corporate.hr.profile.employee.util.EmployeeUtilities;


@ContextConfiguration(locations = {"classpath:employee-dao-config.xml","classpath:employee-sql-repository.xml"})
public class EmployeeDaoTest extends BaseDBTest{
	
	@Resource(name="employeeDao")
	private EmployeeDao employeeDao;
	
	
	private static final String QUERY_DIRECT_REP = "SELECT e.sso FROM employee e INNER JOIN work_assignment wa ON e.sso = wa.wa_manager " +
													"WHERE rownum = 1";
	private static final String QUERY_SEARCH = "SELECT COUNT(*) FROM employee e "+ 
											   "WHERE  e.emp_last_name LIKE '%smith%'"; 
	
	@Autowired
	private EmployeeUtilities util;
	
	/**
	 * Tests Load Employee By Sso 
	 */
	@Test
	public void loadEmployeeBySsoTest(){
		Long sso = null;
		Employee e = null;

		//Get a random sso
		sso = util.getRandomSso();
		
		e = employeeDao.getEmployeeBySso(sso.longValue());
		
		assertNotNull("getEmployeeBySso returns null", e);		
		//Testing some data that should no be null
		assertNotNull("First Name is null",e.getFirstName());
		assertNotNull("Last Name is null", e.getLastName());	
		
	}
	
	/**
	 * Tests getDirectReportsListByManger
	 */
	@Test
	public void getDirectReportsListByManger(){
				
		Long sso = null;
		BaseModelCollection<Person> le = null;
		
		//Validate minimal information
		try{	
			
			sso = simpleJdbcTemplate.queryForLong(QUERY_DIRECT_REP);
			if(sso != null){				
				le = employeeDao.getDirectReportsListByManger(sso);				
				assertNotNull("getDirectReportsListByManger metthod returns null", le);		
				
				for(Person e:le.getList()){
					assertNotNull("First Name is null",e.getFirstName());
					assertNotNull("Last Name is null", e.getLastName());
				}
			}
		}catch (EmptyResultDataAccessException eex) {			
			// if data not found test is not going to run		
			
		}	
		
	}
	
	/**
	 * Tests searchEmployeeByParam
	 */
	@Test
	public void searchEmployeeByParam(){
		 
		Long count = null;
		BaseModelCollection<ShortProfile> profiles  = null;
		
		try{
			//Look for %Smith%
			count = simpleJdbcTemplate.queryForLong(QUERY_SEARCH);
			if(count != null){
				//if a match exits then test search 
				profiles = employeeDao.searchEmployeeByParam("smith");
				assertNotNull("searchEmployeeByParam metthod returns null", profiles);
				for( ShortProfile p : profiles.getList() ) {				
					assertNotNull("SSO is null",p.getSso());				
				}
			}	
		}catch (EmptyResultDataAccessException eex) {			
			// if data not found test is not going to run			
		}	
			
	}	
	
	/**
	 * Tests getHighAutoritySupervisorHierarchyTest
	 */
	@Test
	public void getHighAutoritySupervisorHierarchyTest(){
		
		AuthoritySupervisorHierarchy ash = null;
		try{
			
			ash = employeeDao.getHighAutoritySupervisorHierarchy();			
			assertNotNull("SSO is null",ash.getSso());	
		}catch (EmptyResultDataAccessException eex) {			
			// if data not found test is not going to run			
		}	
					
	}	
	
	
}