/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.math.BigDecimal;
import java.util.Map;

import javax.annotation.Resource;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.test.context.ContextConfiguration;

import com.ge.corporate.hr.profile.common.dao.BaseDBTest;
import com.ge.corporate.hr.profile.employee.model.WorkAssignment;
import com.ge.corporate.hr.profile.employee.util.EmployeeUtilities;


@ContextConfiguration(locations = {"classpath:employee-dao-config.xml","classpath:employee-sql-repository.xml"})
public class WorkAssignmentDaoTest extends BaseDBTest{
	
	@Resource(name="workAssignmentDao")
	private WorkAssignmentDao workAssignmentDao;
	
	
	private static final String GET_CUR_WORK_ASSIMNT = "SELECT wa.sso,  wa.wa_position_title,wa.wa_manager " +
													"FROM work_assignment wa " +
													"WHERE  wa.wa_position_title IS NOT NULL AND wa.wa_manager IS NOT NULL " +
													"AND rownum = 1";
	private static final String WORK_ASSIMNT_COUNT = "SELECT COUNT(*) FROM work_assignment ";
	
	
	@Autowired
	private EmployeeUtilities util;
	
	@Before 
	public void validateTable(){
		Long count = null;
		try{			
			count = simpleJdbcTemplate.queryForLong(WORK_ASSIMNT_COUNT);
			
			if(count.equals(0L)){				
				fail("Work Assignment Table is empty");
			}
			
		}catch (EmptyResultDataAccessException eex) {			
			// if data not found test is not going to run		
			fail("Work Assignment Table is empty");
		}	
	}
	
	/**
	 * Tests LgetCurrentWorkAssignmentBySso 
	 */
	@Test
	public void getCurrentWorkAssignmentBySsoTest(){		
		
		try{			
			Map<String, Object> map = simpleJdbcTemplate.queryForMap(GET_CUR_WORK_ASSIMNT);			
			Long sso = ((BigDecimal)map.get("sso")).longValue();
			
			
			
			//Get a random sso
			sso = util.getRandomSso();
			
			if(sso!= null && sso != 0){
				
				WorkAssignment wa = workAssignmentDao.getCurrentWorkAssignmentBySso(sso);
				assertEquals("Positition Title is not Equal",wa.getPositionTitle().toUpperCase(), map.get("wa_position_title"));
				assertEquals("Mannager is not Equal", wa.getManager(),map.get("wa_manager"));
			}		
			
		}catch (EmptyResultDataAccessException eex) {			
			// if data not found test is not going to run		
			fail("Work Assignment Table is empty");
		}
		
	}
	
	
}