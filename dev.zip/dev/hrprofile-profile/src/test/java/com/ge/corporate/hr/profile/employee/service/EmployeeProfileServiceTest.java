/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.employee.service;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import javax.annotation.Resource;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;

import com.ge.corporate.hr.profile.common.model.BaseModelCollection;
import com.ge.corporate.hr.profile.common.service.BaseServiceTest;
import com.ge.corporate.hr.profile.employee.dao.CompensationDao;
import com.ge.corporate.hr.profile.employee.dao.EmergencyContactDao;
import com.ge.corporate.hr.profile.employee.dao.EmployeeDao;
import com.ge.corporate.hr.profile.employee.dao.PerformanceDao;
import com.ge.corporate.hr.profile.employee.dao.WorkAssignmentDao;
import com.ge.corporate.hr.profile.employee.dto.PersonalInfoDto;
import com.ge.corporate.hr.profile.employee.model.Compensation;
import com.ge.corporate.hr.profile.employee.model.EmergencyContact;
import com.ge.corporate.hr.profile.employee.model.Employee;
import com.ge.corporate.hr.profile.employee.model.Performance;
import com.ge.corporate.hr.profile.employee.model.WorkAssignment;

@ContextConfiguration(locations = {"classpath:employee-service-config.xml", 
									"classpath:employee-dao-config.xml",
										"classpath:employee-sql-repository.xml"})	
										
public class EmployeeProfileServiceTest extends BaseServiceTest{
	
	PersonalInfoDto personalInfo;
	
	public static final Long SSO = 20000774L;	
	
	@Resource
	private EmployeeProfileService employeeProfileService;
	
	@Before 
	public void onSetup(){		
		personalInfo = new PersonalInfoDto();	
		personalInfo.setSso(SSO);				
	}
	
	/**
	 * Tests  getPersonalInfo 
	 */
	@Test
	public void getPersonalInfoTest(){
		
		PersonalInfoDto dto = null;
		
		//initializes dao Mocks
		setupMocks();
		
		//Test Service
		dto = employeeProfileService.getPersonalInfo(personalInfo);
		
		assertNotNull(dto);
		//Test some values
		assertEquals("IT Architect",dto.getTitle());
		assertEquals("Spouse",dto.getEmergencyContactRelationship());
		
	}
	
	/**
	 * Setup the mocks for daos used by employeeProfileService
	 */
	public void setupMocks(){
		
		Employee employee = new Employee();
		WorkAssignment wassignment = new WorkAssignment();
		Performance performance = new  Performance();
		Compensation compensation = new Compensation();
		EmergencyContact contact = new EmergencyContact();
		
		//Create a Mock Objects for the interface we would like to simulate,
		EmployeeDao employeeDao = EasyMock.createMock(EmployeeDao.class);
		WorkAssignmentDao wassignmentDao = EasyMock.createMock(WorkAssignmentDao.class);
		PerformanceDao performanceDao = EasyMock.createMock(PerformanceDao.class);
		CompensationDao compensationDao = EasyMock.createMock(CompensationDao.class);
		EmergencyContactDao emergencyContactDao = EasyMock.createMock(EmergencyContactDao.class);
		
		//Set Employee Information
		employee.setSso(SSO);		
		employee.setFirstName("Antony");
		employee.setLastName("Wilson");
		
		//Set WorkAssignment Information from "WorkAssignment" data group
		wassignment.setPositionTitle("IT Architect");
		wassignment.setIfg("GE");
		wassignment.setBusinessSegment("GE");
		wassignment.setBusinessSegment("GE");
		wassignment.setSubBusiness("GE");
			//TODO insert more information to WorkAssignment if needed
		
		//Set WorkAssignment Information  from "WorkAssignment-restricted" data group
		//wassignment.setBand("LPB");
		
		//Set Performance Information
		performance.setOverallRating("1000.00");
		
		//Set Compensation Information
		compensation.setSalary(10000L);
		
		//Set Emergency Contact
		contact.setFullName("Lname, Fname");
		contact.setTypeDescription("Spouse");
			//TODO insert more information
			
		
		//--- Record the expected behavior ----
		
		EasyMock.expect(employeeDao.getEmployeeBySso(SSO)).andReturn(employee);
		//the method getEmployeeBySso is used two times into service
		EasyMock.expectLastCall().andReturn(employee);
		
		BaseModelCollection<Performance> performancelist = new BaseModelCollection<Performance>();
		performancelist.add(performance);
		
		EasyMock.expect(wassignmentDao.getCurrentWorkAssignmentBySso(SSO)).andReturn(wassignment);
		//EasyMock.expect(wassignmentDao.getCurrentWorkAssignmentRestrictedBySso(SSO)).andReturn(wassignment);
		//EasyMock.expect(performanceDao.getPerformanceBySso(SSO)).andReturn(performancelist);
		EasyMock.expect(compensationDao.getCurrentCompensationBySso(SSO)).andReturn(compensation);
		EasyMock.expect(emergencyContactDao.getEmergencyContactBySso(SSO)).andReturn(contact);
		
		//Switch the Mock Object to replay state.
		EasyMock.replay(employeeDao);	
		EasyMock.replay(wassignmentDao);	
		EasyMock.replay(performanceDao);	
		EasyMock.replay(compensationDao);	
		EasyMock.replay(emergencyContactDao);
		
		//set the mock Daos to service
		((EmployeeProfileServiceImpl)employeeProfileService).setEmployeeDao(employeeDao);
		((EmployeeProfileServiceImpl)employeeProfileService).setAssignmentDao(wassignmentDao);
		((EmployeeProfileServiceImpl)employeeProfileService).setEmergencyContactDao(emergencyContactDao);
		
	}
	
}
