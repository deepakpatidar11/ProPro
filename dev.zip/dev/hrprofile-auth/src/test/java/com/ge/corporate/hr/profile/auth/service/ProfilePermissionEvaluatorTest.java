/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.test.context.ContextConfiguration;

import com.ge.corporate.hr.profile.auth.model.ProfileAuthority;
import com.ge.corporate.hr.profile.auth.model.User;

@ContextConfiguration(locations = {"classpath:auth-dao-config.xml",
									"classpath:auth-sql-repository.xml"})

public class ProfilePermissionEvaluatorTest {
	
	public static final String ROLE_SELF 		= "ROLE_SELF"; // This is not an actual role, this is  used for applying self exclusion rules
	public static final String ROLE_EMPLOYEE 	= "ROLE_EMPLOYEE";
	
	public static final String ORG				= "ORGANIZATION";
	public static final String FUNCTION 		= "FUNCTION";
	public static final String COUNTRY 			= "COUNTRY";
	public static final String PAYROLL 			= "PAYROLL";
	public static final String REGION 			= "REGION";
	public static final String PROGRAM 			= "PROGRAM";
	public static final String EMPLOYEE 		= "EMPLOYEE";
	
	private User OrgManager;
	
	@Before
	public void setAuthenticationTokens(){
		
		//ORG_MGR
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		authorities.add( new ProfileAuthority("ORG_MGR",ORG,"1") );
		authorities.add( new ProfileAuthority("ORG_MGR",PAYROLL,"1") );
		authorities.add( new ProfileAuthority("ORG_MGR",FUNCTION,"1") );
		authorities.add( new ProfileAuthority("ORG_MGR",REGION,"1") );
		authorities.add( new ProfileAuthority("ORG_MGR",COUNTRY,"1") );
		authorities.add( new ProfileAuthority("ORG_MGR",PROGRAM,"1") );
		authorities.add( new ProfileAuthority("ORG_MGR",EMPLOYEE,"1") );
		OrgManager.setAuthorities(authorities);
		
		
		//SecurityContextHolder.getContext().setAuthentication(auth);
	}
	
	@Test
	public void profilePermissionEvaluatorTest(){
		//TODO complete test
	}

}
