/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.dto;

import java.util.ArrayList;
import java.util.List;

import com.ge.corporate.hr.profile.auth.model.AuthAdminRolesProfile;
import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;


public class AuthAdminRolesDto extends AbstractBaseDtoSupport{
	
	private static final long serialVersionUID = 7441501630635139413L;
	
	@SuppressWarnings("unused")
	private List<AuthAdminRolesProfile> lstAutProfiles = new ArrayList<AuthAdminRolesProfile>();

	public long getId() {
		return 0;
	}
	

}
