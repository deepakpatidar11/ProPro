/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.auth.model.AuthAdminRolesProfile;
import com.ge.corporate.hr.profile.auth.model.ProfileRoles;


public class RolesDataGroupAuthorityMapper  implements RowMapper<ProfileRoles> {

	public static final String ROLE_NAME 	= "ROLE_NAME";
	public static final String ROLE_ID 		= "ROLE_ID"; 
	public static final String DG_NAME 		= "DG_NAME";
	public static final String DG_ID 		= "DG_ID";
	List<AuthAdminRolesProfile> roles 		=  new ArrayList<AuthAdminRolesProfile>();
	
	
	
	public ProfileRoles mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		ProfileRoles role 					= new ProfileRoles();
		
		
		
		role.setRoleId(rs.getLong(ROLE_ID));
		role.setRoleName(rs.getString(ROLE_NAME));
	
		
		
		return role;
	}
}