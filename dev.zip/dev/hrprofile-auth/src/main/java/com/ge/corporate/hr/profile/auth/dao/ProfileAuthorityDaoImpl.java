/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.util.Assert;

import com.ge.corporate.hr.profile.auth.dao.mapper.ProfileAuthorityMapper;
import com.ge.corporate.hr.profile.auth.model.ProfileAuthority;
import com.ge.corporate.hr.profile.auth.model.User;
import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.cache.MethodSignatureKeyGenerator;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;
import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;

public class ProfileAuthorityDaoImpl extends  AbstractBaseDaoSupport implements ProfileAuthorityDao {

	
	public Collection<GrantedAuthority> loadByUser(User user) {
		Assert.notNull(user);
		
		return loadByUser(user.getSso());
	}
	
	/*	 
	@Cache(
			nodeName="/profile/auth/dao/ProfileAuthorityDao",
			keyGeneratorClass=DefaultCacheKeyGenerator.class	
	
	)*/
	public Collection<GrantedAuthority> loadByUser(Long sso) {
		Collection<ProfileAuthority> authorities = new ArrayList<ProfileAuthority>();
		
		try{
			authorities = getJdbcTemplate().query( getSql("loadAuthorityByUser") , new Object[]{sso, sso, sso}, new ProfileAuthorityMapper());
		}catch(EmptyResultDataAccessException eex){
			logger.debug("User" + sso + "has no authorities");
		}
				
		return new ArrayList<GrantedAuthority>( authorities );
	}
	
	@Cache(
			nodeName="/profile/auth/dao/ProfileAuthorityDao",
			keyGeneratorClass=MethodSignatureKeyGenerator.class,
			cacheName=InfinispanCacheFactory.AUTHDAOCACHE
	)	
	public List<ProfileAuthority> loadByUserAndRole(Long sso, String role) {
		List<ProfileAuthority> authorities = null;
		
		try{
			authorities = getJdbcTemplate().query( getSql("loadByUserAndRole") , new Object[]{sso, sso, role}, new ProfileAuthorityMapper());
		}catch(EmptyResultDataAccessException eex){
			logger.debug("User" + sso + "has no authorities");
		}
				
		return authorities;
	}
	
	
	
	
}
