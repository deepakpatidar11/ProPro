/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.util;

import java.util.Collection;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import com.ge.corporate.hr.profile.auth.model.User;

public class PersonAuthUtil {

	private static final long serialVersionUID = -4704264448024693738L;
	
	public static User getPrincipal(){
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		User principal = null;
		
		if(auth != null){
			
			Object rawPrincipal = auth.getPrincipal();
			
			if(rawPrincipal instanceof User){
				principal = (User) auth.getPrincipal();
			}
		}
		
		return principal;
	}
	
	public static Collection<GrantedAuthority> getAuthorities(){
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		return auth.getAuthorities();
	}
	
	/**
	 * Gets SSO of the default user 
	 * @return
	 */
	public static Long getLoggedSSO(){
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		Long sso = null;
		User userDetails = null;
		
		if(auth != null){
			userDetails = (User) auth.getPrincipal();
			sso = userDetails.getSso();			
		}
		
		return sso;
	}
	
	
	public static boolean hasRole(String role){		
		boolean isRolePresent = false;     
		for (GrantedAuthority grantedAuthority : getAuthorities()) {       
			isRolePresent = grantedAuthority.getAuthority().equals(role);       
			if (isRolePresent){
				break;        
			}
		}     
		return isRolePresent;   
	}
	
	
	public static boolean hasRole(Collection<GrantedAuthority> authorities, String role) {     
		boolean isRolePresent = false;     
		for (GrantedAuthority grantedAuthority : authorities) {       
			isRolePresent = grantedAuthority.getAuthority().equals(role);       
			if (isRolePresent){
				break;     
			}
		}     
		return isRolePresent;   
	}
	
}