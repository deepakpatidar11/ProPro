package com.ge.corporate.hr.profile.auth.service;

import java.util.List;

import com.ge.corporate.hr.profile.auth.ws.dto.AggregatedRoleDto;

public interface SecurityDetailsService {
	/**
	 * 
	 * @param sso
	 * @return
	 */
	public List<AggregatedRoleDto> getAggregatedAuthorities(Long sso);
	
	/**
	 * 
	 * @param loggedSso
	 * @param viewedSso
	 * @return
	 */
	public List<String> getGrantingRole(Long loggedSso, Long viewedSso);

}
