/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.ge.corporate.hr.profile.auth.dao.AuthorizationDao;
import com.ge.corporate.hr.profile.auth.dao.DataGroupDao;
import com.ge.corporate.hr.profile.auth.model.DataGroup;
import com.ge.corporate.hr.profile.auth.model.GroupedProfileAuthority;
import com.ge.corporate.hr.profile.auth.model.ProfileAuthority;
import com.ge.corporate.hr.profile.auth.model.User;
import com.ge.corporate.hr.profile.auth.util.PersonAuthUtil;
import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.cache.MethodSignatureKeyGenerator;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;

@Service("authorityEvaluator")
public class ProfileAuthorityEvaluator {
	
	protected final Log logger = LogFactory.getLog(getClass());
	
	public static final String ROLE_SELF 		= "ROLE_SELF"; // This is not an actual role, this is  used for applying self exclusion rules
	public static final String ROLE_EMPLOYEE 	= "ROLE_EMPLOYEE";
	
	public static final String ROLE_ORGANIZATION_MANAGER 	= "ORG_MGR";
	public static final String ROLE_SUPERVISOR 	= "SUPV";
	public static final String ROLE_MANAGER 	= "MGR";
	public static final String ROLE_DOTTED_LINE_MANAGER 	= "DLM";
	public static final String ROLE_SA 	= "ROLE_SA";
	public static final String ROLE_SPONSOR 	= "SPONSOR";
	public static final String ROLE_HRM 	= "HRM";
	
	public static final String ORG				= "ORGANIZATION";
	public static final String FUNCTION 		= "FUNCTION";
	public static final String COUNTRY 			= "COUNTRY";
	public static final String PAYROLL 			= "PAYROLL";
	public static final String REGION 			= "REGION";
	public static final String PROGRAM 			= "PROGRAM";
	public static final String EMPLOYEE 		= "EMPLOYEE";
	
	@Resource(name="dataGroupDao")
	protected DataGroupDao dataGroupDao;
	@Resource(name="authDao")
	protected AuthorizationDao authDao;
	
	
	/**
	 * 
	 * 
	 * @param user
	 * @param grantedAuthorities
	 * @param sso
	 * @return
	 */
	@Cache(
			nodeName="/profile/auth/ProfileAuthorityEvaluator",
			keyGeneratorClass=MethodSignatureKeyGenerator.class,
			cacheName=InfinispanCacheFactory.AUTHEVALCACHE
	)
	public List<DataGroup> getDataGroupsForContext(User user, Collection<GrantedAuthority> grantedAuthorities, Long sso){
		return getDataGroupsForContext(user, grantedAuthorities, sso.toString());
	}
	/**
	 * 
	 * @param user
	 * @param grantedAuthorities
	 * @param sso
	 * @return
	 */
	@Cache(
			nodeName="/profile/auth/ProfileAuthorityEvaluator",
			keyGeneratorClass=MethodSignatureKeyGenerator.class,
			cacheName=InfinispanCacheFactory.AUTHEVALCACHE
	)
	public List<DataGroup> getDataGroupsForContext(User user, Collection<GrantedAuthority> grantedAuthorities, String sso){
		
		Assert.notNull(dataGroupDao);
		Assert.notNull(user);
		Assert.notNull(grantedAuthorities);
		
		List<DataGroup> dataGroups = null;
		
		User principal = user;
		Collection<ProfileAuthority> authorities = castToProfileAuthority(grantedAuthorities);
		Long accessedSso = Long.parseLong(sso);
		
		dataGroups = loadDataGroupForRole(principal, authorities, accessedSso );
		
		return dataGroups;
	}
	/**
	 * 
	 * @param user
	 * @param grantedAuthorities
	 * @param sso
	 * @return
	 */
	@Cache(
			nodeName="/profile/auth/ProfileAuthorityEvaluator",
			keyGeneratorClass=MethodSignatureKeyGenerator.class,
			cacheName=InfinispanCacheFactory.AUTHEVALCACHE
	)
	public Map<String, DataGroup> getDataGroupsForContextAsMap(User user, Collection<GrantedAuthority> grantedAuthorities, Long sso){
		List<DataGroup> dataGroups = getDataGroupsForContext(user, grantedAuthorities, sso);
			 
		Map<String, DataGroup> dataGroupsMap = new Hashtable<String, DataGroup>();
		
		if(dataGroups != null){
			for(DataGroup dg : dataGroups){
				dataGroupsMap.put(dg.getName(), dg);
			}
		}
		
		return dataGroupsMap;
	}
	
	public Map<String, DataGroup> getDataGroupsForContextAsMapBypass(User user, Collection<GrantedAuthority> grantedAuthorities, Long sso){
		List<DataGroup> dataGroups = getDataGroupsForContext(user, grantedAuthorities, sso);
			 
		Map<String, DataGroup> dataGroupsMap = new Hashtable<String, DataGroup>();
		
		if(dataGroups != null){
			for(DataGroup dg : dataGroups){
				dataGroupsMap.put(dg.getName(), dg);
			}
		}
		
		return dataGroupsMap;
	}
	/**
	 * Determine based on the user relationship what role corresponds to the current transaction.
	 * Role determination is based on the filter type (Org, Employee, or Direct).
	 * When someone is watching himself a default role called SELF is applied overwriting 
	 * all existing roles that could have applied based on different relationships.
	 * 
	 * 
	 * @param principal
	 * @param authorities
	 * @param accessedSso
	 * @return
	 */
	public List<String> getRoleForContext(User principal, Collection<ProfileAuthority> authorities, Long accessedSso){
		
		List<String> roles = new ArrayList<String>();
		String overrideRole="";
		
		if(isSA(authorities)){
			roles.add( ROLE_SA );
			return roles;
		}
		
		if(isSelfAccess(principal, accessedSso)){
			roles.add( ROLE_SELF );
			return roles;
		}
		
		if(isContingentWorker(accessedSso)){			
			if(isSponsor(principal.getSso(),accessedSso)){
				roles.add( ROLE_SPONSOR );
				return roles;
			}
		}
		
		if(isJointVentureEmployee(accessedSso)){			
			if(isJVSponsor(principal.getSso(),accessedSso)){
				roles.add( ROLE_SPONSOR );
				return roles;
			}
		}
		
		for(ProfileAuthority profileAuth: authorities){
			
			GroupedProfileAuthority auth = (GroupedProfileAuthority) profileAuth ; 

			Map<String, Boolean> accessTable = new Hashtable<String, Boolean>();
			
			for(String filter : auth.getFilterTypes()){
				accessTable.put(filter, isDirectDomain(principal.getSso(), auth, accessedSso, filter) );							
			}
			
			if(isReleated(accessTable)){
				roles.add(auth.getAuthority());
			}
			
		}
		
		//Establish Supervisor Relationship
		if(isDirectReport(principal.getSso(), accessedSso)){
			roles.add( ROLE_SUPERVISOR );
			roles.add( ROLE_MANAGER );
			if(!roles.contains(ROLE_ORGANIZATION_MANAGER)){
				roles.add(ROLE_ORGANIZATION_MANAGER);
			}
		}
				
		//Establish Dotted Line Report Relationship
		if(isDottedLineDirectReport(principal.getSso(), accessedSso)){
			roles.add( ROLE_DOTTED_LINE_MANAGER );
		}
		
		if(isHRMofRecordsByEmpSso(principal.getSso(), accessedSso)){
			roles.add( ROLE_HRM );
		}
		
		if(roles.contains(ROLE_ORGANIZATION_MANAGER)){
			overrideRole=authDao.isOverrideRoleBySSO(principal.getSso(), accessedSso);
			if(	!overrideRole.equalsIgnoreCase("")){
				roles.clear();
				roles.add(overrideRole);
			}
		}
		
		/*if(skipSensitiveRoles(principal.getSso())){
				roles.clear();
				roles.add( ROLE_EMPLOYEE );
		}*/
		
		//No relationship could be determined
		if(roles.isEmpty()){
			roles.add( ROLE_EMPLOYEE );
		}
		
		return roles;
	}
	
	private boolean isReleated(Map<String, Boolean> accessTable){
		boolean granted = true;
		
		for(String filter : accessTable.keySet() ){
			
			granted &= accessTable.get(filter);
			
		}
		
		return granted;
	}
	/**
	 * Returns all existent DataGroups
	 * @return
	 */
	public List<DataGroup> getAllDataGroups(){
		return dataGroupDao.load();
	}		
	
	
	/**
	 * Determine based on the user relationship what role corresponds to the current transaction.
	 * @return
	 */
	public List<String> getAutorizedRoles(User principal, Collection<GrantedAuthority>  authorities){
		Collection<ProfileAuthority > profiles = castToProfileAuthority(authorities);
		List<String> roles = new ArrayList<String>();
		
		for(ProfileAuthority profileAuth: profiles){
			
			String role = profileAuth.getAuthority();
			
			roles.add(role);
		}
		
		if(isDottedLineManager(principal.getSso())){
			roles.add( ROLE_DOTTED_LINE_MANAGER );
		}
		
		return roles;
	}
	
	/**
	 * 
	 * @param principalSso
	 * @param accessedSso
	 * @param authorities
	 * @return
	 */
	public List<String> getRoleForContext(Long principalSso, Long accessedSso, Collection<GrantedAuthority> authorities){
		
		User principal = new User();
		principal.setSso(principalSso);
		
		Collection<ProfileAuthority > collectionProfiles = castToProfileAuthority(authorities);
				
		return getRoleForContext(principal, collectionProfiles, accessedSso);
	}
		
	/*****
	 * 
	 * @param principal
	 * @param accessedSso
	 * @param authorities
	 * @return
	 */
	public List<String> getRoleForContext(User principal, Long accessedSso, Collection<GrantedAuthority> authorities){
		Collection<ProfileAuthority > collectionProfiles = castToProfileAuthority(authorities);
		return getRoleForContext(principal, collectionProfiles, accessedSso);
	}
	
	/**
	 * Loads Data groups for an explicit relationship
	 * @param role
	 * @return
	 */
	private List<DataGroup> loadDataGroupForRole(User principal, Collection<ProfileAuthority> authorities, Long accessedSso){
		List<DataGroup> dataGropus = null;
		List<String> roles = null;
		
		if(hasRole( castToGrantedAuthority(authorities), "ROLE_SA")){
			dataGropus = dataGroupDao.loadForSA(accessedSso);
		}else{
			roles = getRoleForContext(principal, authorities, accessedSso);
			dataGropus = dataGroupDao.loadByRole(roles,accessedSso);
		}
		
		
		return dataGropus;
	}
	
	
	/**
	 * Determines if an employee has a direct relationship with another.
	 * @return
	 */
	public Boolean isDirectReport(Long principalSso, Long sso){
		Boolean directlyRelated = false;
		
		if( authDao.getEmployeeIdByHierarchy(principalSso, sso) != null ){
			directlyRelated = true;
		}
		
		return directlyRelated;
	}
	
	/**
	 * Determines if an employee has a dotted line direct relationship with another.
	 * @return
	 */
	public Boolean isDottedLineDirectReport(Long principalSso, Long sso){
		Boolean directlyRelated = false;
		
		if( authDao.getEmployeeIdByDottedLine(principalSso, sso) != null ){
			directlyRelated = true;
		}
		
		return directlyRelated;
	}
	
	public Boolean isHRMofRecordsByEmpSso(Long principalSso, Long sso){
		Boolean isHRMofRecord = false;
		
		if( authDao.getEmployeeIdByHRMofRecords(principalSso, sso) != null ){
			isHRMofRecord = true;
		}
		
		return isHRMofRecord;
	}
	
	
	/**
	 * Determines if an employee has a dotted line direct relationship with another.
	 * @return
	 */
	public Boolean isDottedLineManager(Long principalSso){
		Boolean directlyRelated = false;
		
		if( authDao.isDottedLineManagerBySso(principalSso) != null ){
			directlyRelated = true;
		}
		
		return directlyRelated;
	}
	
	/**
	 * Determines if an employee is a HRM.
	 * @return
	 */
	public Boolean isHRManager(Long principalSso){
		Boolean directlyRelated = false;
		
		if( authDao.isHRManagerBySso(principalSso) != null ){
			directlyRelated = true;
		}
		
		return directlyRelated;
	}
	/**
	 * Determines if the employee belongs of a certain org.
	 * 
	 * @param auth
	 * @param sso
	 * @return
	 */
	public Boolean isOrgRelated(Long principalSso, GroupedProfileAuthority auth, Long sso){
		
		Boolean orgRelated = false;
		
		if(auth.hasFilter(ORG) ){
			orgRelated = ( authDao.getPermOrgIdByOrgHierarchy(principalSso, sso, auth.getFilterValues(ORG) ) != null );
		}
		
		return orgRelated;
	}
	/**
	 * Determines if the following type of relationships exist:
	 * 
	 * payroll, region, function, program
	 * 
	 * @param auth
	 * @param sso
	 * @return
	 */
	public Boolean isDirectDomain(Long principalSso, GroupedProfileAuthority auth, Long sso, String currentFilter){
		Boolean domainRelated = false;
		Long employeeId = null;
		
		if(auth.getFilterType(currentFilter) != null ){
			
			logger.debug("Evaluating "+currentFilter+" filter for "+principalSso + " Filters:" + auth.getFilterValues(currentFilter)  );
			
			employeeId = authDao.getEmployeeIdByDirectDomain(principalSso, sso, currentFilter,  auth.getFilterValues(currentFilter));
			
		}
		
		domainRelated = (employeeId != null);
		
		
		return domainRelated;
	}
	
	/**
	 * Determines if user is accessing himself.
	 * @return
	 */
	private boolean isSelfAccess(User principal, Long accessedSso){
		boolean selfAccess = false;
		
		if(principal.getSso().equals(accessedSso )){
			selfAccess = true;
		}
		
		return selfAccess;
	}
	
	/**
	 * Determines if an employee has a contingent worker.
	 * @return
	 */
	public Boolean isContingentWorker(Long sso){
		Boolean contingentWorker = false;
		
		if( authDao.isContingentWorkerBySso(sso) != null ){
			contingentWorker = true;
		}
		
		return contingentWorker;
	}
	
	/**
	 * Convert standard Collection<GrantedAuthority> to Collection<ProfileAuthority>
	 * @param authorities
	 * @return
	 */
	public Collection<ProfileAuthority> castToProfileAuthority(Collection<GrantedAuthority> grantedAuthorities){
		
		Collection<ProfileAuthority> authorities = new ArrayList<ProfileAuthority>();
		
		for(GrantedAuthority auth : grantedAuthorities){
			authorities.add((ProfileAuthority) auth);
		}
		
		return authorities;
	}
	
	public Collection<GrantedAuthority> castToGrantedAuthority(Collection<ProfileAuthority> grantedAuthorities){
		
		Collection<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		
		for(ProfileAuthority auth : grantedAuthorities){
			authorities.add((GrantedAuthority) auth);
		}
		
		return authorities;
	}
	
	/**
	 * 
	 * @param authorities
	 */
	
	public DataGroupDao getDataGroupDao() {
		return dataGroupDao;
	}
	public void setDataGroupDao(DataGroupDao dataGroupDao) {
		this.dataGroupDao = dataGroupDao;
	}
	
	public AuthorizationDao getAuthDao() {
		return authDao;
	}
	public void setAuthDao(AuthorizationDao authDao) {
		this.authDao = authDao;
	}
	
	/*** Check if a role is present in the authorities of current user    
	 * * @param authorities all authorities assigned to current user    
	 * * @param role required authority    
	 * * @return true if role is present in list 
	 * of authorities assigned to current user, false otherwise    */   
	public Boolean hasRole(Collection<GrantedAuthority> authorities, String role) {     
		boolean isRolePresent = false;     
		for (GrantedAuthority grantedAuthority : authorities) {       
			isRolePresent = grantedAuthority.getAuthority().equals(role);       
			if (isRolePresent){
				break;     
			}
		}     
		return isRolePresent;   
	}
	
	public Boolean hasRole(String role){
		return hasRole(PersonAuthUtil.getAuthorities(), role);
	}
	
	public Boolean hasAnyRole(List<String> roles){
		boolean hasAccess = false;     
		if( authDao.hasHRPopulationListAcessBySso(PersonAuthUtil.getLoggedSSO(),roles) != null ){
			hasAccess = true;
		}		
		return hasAccess;
	}

	public Boolean hasHRPropulationAcess(){
		boolean hasAccess = false;     
		if( authDao.hasHRPopulationAcessBySso(PersonAuthUtil.getLoggedSSO()) != null ){
			hasAccess = true;
		}		
		return hasAccess; 
	}
	
	
	public Boolean isSA(Collection<ProfileAuthority> profileAuthorities) {
		return hasRole( castToGrantedAuthority( profileAuthorities ), ROLE_SA);
	}
	
	public Boolean isSA(){
		return hasRole(ROLE_SA);
	}
	
	public Boolean isOrgManager(Collection<ProfileAuthority> profileAuthorities) {
		return hasRole( castToGrantedAuthority( profileAuthorities ), ROLE_ORGANIZATION_MANAGER);
	}
	
	public Boolean isSelf(Long sso){
		return PersonAuthUtil.getLoggedSSO().equals(sso);
	}
	
	@Cache(
			nodeName="/profile/auth/ProfileAuthorityEvaluator",
			keyGeneratorClass=MethodSignatureKeyGenerator.class,
			cacheName=InfinispanCacheFactory.AUTHEVALCACHE
	)
	public Boolean hasAbsoluteDataGroupAccess(Long sso, String dataGroup){
		
		Boolean hasAccess = false;
		
		if(!isSA()){
			List<String> dataGroups = authDao.loadPotentialDataGroups(sso);
			
			for(String currentDataGroup : dataGroups){
				if(currentDataGroup.equals(dataGroup)){
					hasAccess = true;
					break;
				}
			}
		}else{
			hasAccess = true;
		}
		
		return hasAccess;
	}
	
	public Boolean isSponsor(Long principal, Long sso) {
		Boolean supervisor = false;
		
		if( authDao.isSponsorBySso(principal,sso) != null ){
			supervisor = true;
		}
		
		return supervisor;
	}
	
	public Boolean isDirectoryEmployee(Long sso) {
		Boolean supervisor = false;
		
		if( authDao.isDirectoryEmployeeBySso(sso) != null ){
			supervisor = true;
		}
		
		return supervisor;
	}
	
	/*public Boolean skipSensitiveRoles(Long principal) {
		Boolean skip = false;
		
		if( authDao.skipSensitiveRolesBySso(principal) != null ){
			skip = true;
		}
		
		return skip;
	}*/
	
	public Boolean isGEAlstomEmployee(Long sso) {
		Boolean alstom = false;
		
		if( authDao.isGEAlstomEmpBySso(sso) != null ){
			alstom = true;
		}
		
		return alstom;
	}
	
	public Boolean isGEBakerHughesEmployee(Long sso) {
		Boolean bakerHughes = false;
		
		if( authDao.isGEBakerHughesEmpBySso(sso) != null ){
			bakerHughes = true;
		}
		
		return bakerHughes;
	}
	
	public Boolean isGEGasAndOilEmployee(Long sso) {
		Boolean OilAndGas = false;
		
		if( authDao.isGEGasAndOilEmpBySso(sso) != null ){
			OilAndGas = true;
		}
		
		return OilAndGas;
	}
	
	public Boolean isPDUser(Long sso) {
		Boolean pdUser = false;
		
		if( authDao.isPDUserBySso(sso) != null ){
			pdUser = true;
		}
		
		return pdUser;
	}
	
	public Boolean isLeadershipProgramMemberBySso(Long sso) {
		Boolean member = false;
		
		if( authDao.isLeadershipProgramMemberBySso(sso) != null ){
			member = true;
		}
		
		return member;
	}
	
	public Boolean isJointVentureEmployee(Long sso){
		Boolean isJointVentureEmployee = false;
		
		if( authDao.isJointVentureEmployeeBySso(sso) != null ){
			isJointVentureEmployee = true;
		}
		
		return isJointVentureEmployee;
	}
	
	public Boolean isJVSponsor(Long principal, Long sso) {
		Boolean supervisor = false;
		
		if( authDao.isJVSponsorBySso(principal,sso) != null ){
			supervisor = true;
		}
		
		return supervisor;
	}
}
