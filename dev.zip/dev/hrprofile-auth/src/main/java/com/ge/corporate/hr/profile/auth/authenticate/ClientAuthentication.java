/**
 * 
 */
package com.ge.corporate.hr.profile.auth.authenticate;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.bind.DatatypeConverter;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

@Component
public class ClientAuthentication {
	@Value("${env}")
	String env;
	
	@Value("${fedURL}")
	String fedURL;
	
	@Value("${clientid}")
	String clientId;
	
	@Value("${clientsecret}")
	String clientSecret;
	
	private static Logger log = Logger.getLogger(ClientAuthentication.class);
	public String getAccessToken() throws IOException{
		log.info("Environment Name:" + env);
		/*log.info("URL and query strings:"+fedURL+ " " + clientId + " " + clientSecret);*/
		try {
			// Generation of access token
			URL url = new URL(fedURL);
			HttpURLConnection conn = (HttpURLConnection)url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Authorization", "Basic " + DatatypeConverter.printBase64Binary((clientId + ":" + clientSecret).getBytes()));
			
			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				log.info("HTTP status code : " + conn.getResponseCode());
			}
			
			JsonParser parser = new JsonFactory().createParser(conn.getInputStream());
			String accessToken = null;
			while(parser.nextToken()!=JsonToken.END_OBJECT){
				if("access_token".equals(parser.getCurrentName())){
					accessToken=parser.getValueAsString();
				}
			}
			conn.disconnect();
			return accessToken;
			
		} catch (MalformedURLException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		}
	}
}
