/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
/**
 * 
 */
package com.ge.corporate.hr.profile.auth.dto;

import java.io.Serializable;
import java.util.List;

import com.ge.corporate.hr.profile.auth.model.DataGroup;
import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;


/**
 * @author francisco.blanco
 *
 */



public class AuthProfileDto extends AbstractBaseDtoSupport implements  Serializable{

	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<DataGroup> lstDataGroup;
	 
	 private Long ssoLogged;
	 
	 private Long ssoAssigned;
 
 

 	public List<DataGroup> getLstDataGroup() {
 		return lstDataGroup;
 	}

 	public void setLstDataGroup(List<DataGroup> lstDataGroup) {
 		this.lstDataGroup = lstDataGroup;
 	}

	public Long getSsoLogged() {
		return ssoLogged;
	}

	public void setSsoLogged(Long ssoLogged) {
		this.ssoLogged = ssoLogged;
	}

	public Long getSsoAssigned() {
		return ssoAssigned;
	}

	public void setSsoAssigned(Long ssoAssigned) {
		this.ssoAssigned = ssoAssigned;
	}

	public long getId() {
		return 0;
	}
 
 
 

}
