/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.dao;

import java.util.List;



import com.ge.corporate.hr.profile.auth.model.User;
import com.ge.corporate.hr.profile.auth.ws.dto.AggregatedFilterDto;


public interface UserDao  {
	
	public User loadBySSO(final Long sso);
	public List<User> loadUsersByRoleAndFilters(String roleName, List<AggregatedFilterDto> filters );
	public List<User> loadUsersByFilters(List<AggregatedFilterDto> filters );	
	public List<User> loadUsersByRole(String roleName);	
	public List<User> loadUsersByFilterSet(List<AggregatedFilterDto> filters);
	public List<Long> loadMyClientsSsoByListSso(List<Long> ssoList);	
	public List<Long> loadMyClientsSsoBySso(Long sso);
	
}
