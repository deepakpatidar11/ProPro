/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.ws.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;

/**
 * 
 * @author hector.nevarez
 *
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name="subjectFilterSet")
public class AggregatedFilterSetDto extends AbstractBaseDtoSupport {

	private static final long serialVersionUID = -1033864421382042140L;
	
	@XmlElement(name="agregatedFilterList")
	private List<AggregatedFilterDto> agregatedFilterList;

	public List<AggregatedFilterDto> getAgregatedFilterList() {
		return agregatedFilterList;
	}

	public void setAgregatedFilterList(List<AggregatedFilterDto> agregatedFilterList) {
		this.agregatedFilterList = agregatedFilterList;
	}

	public long getId() {		
		return 0;
	}
	
}
