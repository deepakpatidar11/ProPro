/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.filters;

import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedCredentialsNotFoundException;
import org.springframework.security.web.authentication.preauth.RequestHeaderAuthenticationFilter;
import org.springframework.util.Assert;

public class HrpRequestHeaderAuthenticationFilter extends RequestHeaderAuthenticationFilter{
	private String principalRequestHeader = "SM_USER";
    private boolean exceptionIfHeaderMissing = true;
	private static Log logger = LogFactory.getLog(HrpRequestHeaderAuthenticationFilter.class);
    
	protected Object getPreAuthenticatedPrincipal(HttpServletRequest request) {
		String principal = getPrincipal(request);
		
        if (principal == null && exceptionIfHeaderMissing) {
            throw new PreAuthenticatedCredentialsNotFoundException(principalRequestHeader
                    + " User not authenticated.");
        }
        return principal;
	}
	/**
	 * Enables local testing on SiteMinder-less environment. 
	 * System properties are required to be set on startup for it to work:
	 * 	
	 * 	 app.environment=local 
	 *   default.sso=[SSO]
	 *  
	 *  Where [SSO] is the SSO that will be used to log into de application.
	 *  
	 * @param request
	 * @return
	 */
	protected String getPrincipal(HttpServletRequest request) {
		
		String principal = null;
		
		if(request.getHeader(principalRequestHeader) != null ){
			principal = request.getHeader(principalRequestHeader);
			logger.debug("Principal "+principal+" found when requesting:" + request.getRequestURL());
		}else if (System.getProperty("app.environment")!= null &&  System.getProperty("app.environment").equals("local")){
			principal = System.getProperty("default.sso");
			logger.debug("Debug principal found when requesting:" + request.getRequestURL());
		}
		
		return principal;
	}
	
	 public void setPrincipalRequestHeader(String principalRequestHeader) {
        Assert.hasText(principalRequestHeader, "principalRequestHeader must not be empty or null");
        this.principalRequestHeader = principalRequestHeader;
	 }
	 
	 public void setExceptionIfHeaderMissing(boolean exceptionIfHeaderMissing) {
        this.exceptionIfHeaderMissing = exceptionIfHeaderMissing;
    }
}
