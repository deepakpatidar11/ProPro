/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
/**
 * 
 */
package com.ge.corporate.hr.profile.auth.dao;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.ge.corporate.hr.profile.auth.model.DataGroup;
import com.ge.corporate.hr.profile.auth.model.ProfileRoles;

/**
 * @author francisco.blanco
 *
 */
public interface RolesAuthorityDao {
	
	/**
	 * 
	 * @return
	 */
	public List<ProfileRoles> getRolesList();
	/**
	 * 
	 * @param roleName
	 * @return
	 */
	public Boolean existsRole(String roleName);
	/**
	 * 
	 * @return
	 */
	public List<DataGroup> getDataGroupList();
	/**
	 * 
	 * @param roleId
	 * @return
	 */
	public List<DataGroup> getSelectDataGroupList(final String roleId);
	/**
	 * 
	 * @param roleId
	 * @return
	 */
	public boolean deleteDataGroupList(final String roleId);
	/**
	 * 
	 * @param datagroupsList
	 * @param roleId
	 */
	public void insertDataGroupList(final List<DataGroup> datagroupsList,final String roleId);
	/**
	 * 
	 * @param sso
	 * @return
	 */
	public List<String> getRoleAssigmentList(long sso);
	
	/**
	 * 
	 * @param dataGroup
	 * @return
	 */
	public List<String> getRolesListByDG(String dataGroup);
	
	/**
	 * 
	 * @param dataGroup
	 * @return
	 */
	public Map<String,Long> getRolesFilterTypeCount(Long ssoSigned, String dataGroup);
}
