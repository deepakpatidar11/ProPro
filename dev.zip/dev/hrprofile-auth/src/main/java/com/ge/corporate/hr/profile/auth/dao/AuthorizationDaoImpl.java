/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;

import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.cache.MethodSignatureKeyGenerator;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;
import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;



public class AuthorizationDaoImpl extends AbstractBaseDaoSupport implements AuthorizationDao {

	@Cache(
			nodeName="/profile/auth/dao/AuthorizationDao",
			keyGeneratorClass=MethodSignatureKeyGenerator.class,
			cacheName=InfinispanCacheFactory.AUTHDAOCACHE
	)
	public Long getEmployeeIdByDottedLine(Long principal, Long sso){
		
		Long employeeId = null;
		
		try{
			employeeId = getJdbcTemplate().queryForLong(getSql("getEmployeeIdByDottedLine"), new Object[]{principal, sso});
		}catch(EmptyResultDataAccessException eex){
			logger.debug( principal + " has no herarchical relationship with " + sso );
		}		
		return employeeId;
	}
	
	@Cache(
			nodeName="/profile/auth/dao/AuthorizationDao",
			keyGeneratorClass=MethodSignatureKeyGenerator.class,
			cacheName=InfinispanCacheFactory.AUTHDAOCACHE
	)
	public Long getEmployeeIdByHRMofRecords(Long principal, Long sso){
		
		Long employeeId = null;
		
		try{
			employeeId = getJdbcTemplate().queryForLong(getSql("getEmployeeIdByHRMofRecords"), new Object[]{principal, sso});
		}catch(EmptyResultDataAccessException eex){
			logger.debug( principal + " is not HRM of Record of " + sso );
		}		
		return employeeId;
	}
	
	
	/**
	 * Gets the employee id (sso) if the employee has a 
	 * Supervisor Hierarchy (Direct reports) relationship with the currently logged user
	 * 
	 * Supervisor Hierarchy relationships can be: 
	 * - Direct: The employee reports directly to the currently logged user. 
	 * - Indirect: The employee reports directly to a direct report of the currently logged user.
	 *  
	 * @param principal
	 * @param sso
	 * @return
	 */
	@Cache(
			nodeName="/profile/auth/dao/AuthorizationDao",
			keyGeneratorClass=MethodSignatureKeyGenerator.class,
			cacheName=InfinispanCacheFactory.AUTHDAOCACHE
	)
	public Long getEmployeeIdByHierarchy(Long principal, Long sso){
		
		Long employeeId = null;
		
		try{
			employeeId = getJdbcTemplate().queryForLong(getSql("getEmployeeIdByHierarchy"), new Object[]{principal, sso});
		}catch(EmptyResultDataAccessException eex){
			logger.debug( principal + " has no herarchical relationship with " + sso );
		}		
		return employeeId;
	}
	/**
	 * Gets the employee id (sso) if the employee has a 
	 * Org Hierarchy relationship with the currently logged user
	 * 
	 * Org Hierarchy relationships can be: 
	 * - Direct: The employee belongs to an Org to which the currently logged user also belongs 
	 * - Indirect: The employee belongs to an Org that is child to which the currently logged user 
	 *             also belongs 
	 *  
	 * @param principal
	 * @param sso
	 * @param orgId
	 * @return
	 */
	@Cache(
			nodeName="/profile/auth/dao/AuthorizationDao",
			keyGeneratorClass=MethodSignatureKeyGenerator.class,
			cacheName=InfinispanCacheFactory.AUTHDAOCACHE
	)
	public Long getPermOrgIdByOrgHierarchy(Long principal, Long sso, List<Long> orgId){		
		
		logger.debug( principal + " Evaluating Org Hierarchy relationship with " + sso + " for " + orgId  );
		return getEmployeeIdByDirectDomain(getSql("getPermOrgIdByOrgHierarchy"), principal, sso, orgId);
	}	
	
	public Long getEmployeeIdByDirectDomain( Long principal, Long sso, String currentFilter, List<Long> domainIds ) {
		
		Long domainId = null;
		String tuple=",(?,0)";
		List<Object> params = new ArrayList<Object>();
	
		params.add(sso);
			
		try{
			if(domainIds.size()<1000){
				String query = getSql("getEmployeeIdByDomain");				
				for(Long dId : domainIds){
					params.add(dId);
				}				
				params.add(currentFilter);
				domainId = getJdbcTemplate().queryForLong( dynamicPlaceHolderSet(query, domainIds) , params.toArray());	
			}else{
				String query = getSql("getEmployeeIdByDomain1000Filters");	
				StringBuilder tupleToQuery = new StringBuilder();			
				for(Long dId : domainIds){
					params.add(dId);
					tupleToQuery.append(tuple);
				}
				query = query.replace("[?]", tupleToQuery.toString().replaceFirst(",",""));				
				params.add(currentFilter);						
				domainId = getJdbcTemplate().queryForLong( query , params.toArray());
			}
		}catch(EmptyResultDataAccessException eex){
			logger.debug( principal + " has no direct domain relationship with " + sso );
		}
		
		return domainId;
	}
	
	public Long isDottedLineManagerBySso(Long principal){		
		
		Long employeeId = null;
		
		try{
			employeeId = getJdbcTemplate().queryForLong(getSql("isDottedLineManagerBySso"), principal);
			logger.debug( principal + " is a Dotted Line Manager" );
		}catch(EmptyResultDataAccessException eex){
			logger.debug( principal + " is not a Dotted Line Manager" );
		}		
		return employeeId;
	}	
	
	public Long isHRManagerBySso(Long principal){		
		
		Long employeeId = null;
		
		try{
			employeeId = getJdbcTemplate().queryForLong(getSql("isHRManagerBySso"), principal);
			logger.debug( principal + " is a HR manager" );
		}catch(EmptyResultDataAccessException eex){
			logger.debug( principal + " is not HR Manager" );
		}		
		return employeeId;
	}
	
	/**
	 * Gets the employee id (sso) if the employee has a 
	 * direct domain relationship with the currently logged user
	 * 
	 * @param query
	 * @param principal
	 * @param sso
	 * @param domainId
	 * @return
	 */
	protected Long getEmployeeIdByDirectDomain( String query, Long principal, Long sso, List<Long> domainIds){
		Long domainId = null;
		
		List<Object> params = new ArrayList<Object>();
		
		params.add(sso);
		
		for(Long dId : domainIds){
			params.add(dId);
		}
			
		try{
			domainId = getJdbcTemplate().queryForLong( dynamicPlaceHolderSet(query, domainIds) , params.toArray());
		}catch(EmptyResultDataAccessException eex){
			logger.debug( principal + " has no direct domain relationship with " + sso );
		}
		
		return domainId;
	}
	/**
	 * Loads all DG a user could have access to without taking into account any context
	 * 
	 * @param sso
	 * @return
	 */
	public List<String> loadPotentialDataGroups(Long sso){
		String sql = getSql("getPotentialDatagroups");
		List<String> dg = null;
		
		dg = getJdbcTemplate().queryForList(sql, new Object[]{sso}, String.class);
		
		return dg;	
		
	}
	
	public String isOverrideRoleBySSO(Long principal, Long sso){
		String role = "";
		try{
		role = (String) getJdbcTemplate().queryForObject( getSql("overrideRole"), new Object[]{principal,sso}, String.class);
			logger.debug( principal + " has roles to override" );
		}
		catch(EmptyResultDataAccessException eex){
			logger.debug( principal + " has no roles to override" );
		}	
		
		return role;	
		
	}
	
	public Long isContingentWorkerBySso(Long sso){		
		
		Long employeeId = null;
		
		try{
			employeeId = getJdbcTemplate().queryForLong(getSql("isContingentWorkerBySso"), sso);
			logger.debug( sso + " is a contingent worker" );
		}catch(EmptyResultDataAccessException eex){
			logger.debug( sso + " is not a contingent worker" );
		}		
		return employeeId;
	}	
	
	public Long isSponsorBySso(Long principal, Long sso){
		Long employeeId = null;	
		try{
			employeeId = getJdbcTemplate().queryForLong(getSql("isSponsorBySso"),new Object[]{principal,sso});
			logger.debug( principal + " is a Sponsor" );
		}catch(EmptyResultDataAccessException eex){
			logger.debug( principal + " is not a Sponsor" );
		}		
		return employeeId;
	}
	
	public Long isGEAlstomEmpBySso(Long sso){
		Long employeeId = null;	
		try{
			employeeId = getJdbcTemplate().queryForLong(getSql("isGEAlstomEmpBySso"),new Object[]{sso});
			logger.debug( sso + " is from GE Alstom" );
		}catch(EmptyResultDataAccessException eex){
			logger.debug( sso + " is not from GE Alstom" );
		}		
		return employeeId;
	}
	
	public Long isGEBakerHughesEmpBySso(Long sso){
		Long employeeId = null;	
		try{
			employeeId = getJdbcTemplate().queryForLong(getSql("isGEBakerHughesEmpBySso"),new Object[]{sso});
			logger.debug( sso + " is from GE Baker Hughes" );
		}catch(EmptyResultDataAccessException eex){
			logger.debug( sso + " is not from GE Baker Hughes" );
		}		
		return employeeId;
	}
	
	public Long isGEGasAndOilEmpBySso(Long sso){
		Long employeeId = null;	
		try{
			employeeId = getJdbcTemplate().queryForLong(getSql("isGEOilAndGasEmpBySso"),new Object[]{sso});
			logger.debug( sso + " is from GE Oil & Gas" );
		}catch(EmptyResultDataAccessException eex){
			logger.debug( sso + " is not from GE Oil & Gas" );
		}		
		return employeeId;
	}
		
	public Long isDirectoryEmployeeBySso(Long sso){
		Long employeeId = null;	
		try{
			employeeId = getJdbcTemplate().queryForLong(getSql("isDirectoryEmployeeBySso"),sso);
			logger.debug( sso + " is a not in Directory Employee List" );
		}catch(EmptyResultDataAccessException eex){
			logger.debug( sso + " is in Directory Employee List" );
		}		
		return employeeId;
	}
	
	public Long isPDUserBySso(Long sso){
		Long employeeId = null;	
		try{
			employeeId = getJdbcTemplate().queryForLong(getSql("isPDUserBySso"),sso);
			logger.debug( sso + " is not a PD user" );
		}catch(EmptyResultDataAccessException eex){
			logger.debug( sso + " is a PD user" );
		}		
		return employeeId;
	}
	
	public Long hasHRPopulationAcessBySso(Long principal){
		Long employeeId = null;	
		try{
			employeeId = getJdbcTemplate().queryForLong(getSql("hasHRPopulationAcessBySso"),new Object[]{principal});
			logger.debug( principal + " has access to hr population" );
		}catch(EmptyResultDataAccessException eex){
			logger.debug( principal + " does not have access to hr population" );
		}		
		return employeeId;
	}
	
	public Long hasHRPopulationListAcessBySso(Long principal, List<String> roles){
		Long employeeId = null;	
		try{
			employeeId = getJdbcTemplate().queryForLong(getSql("hasHRPopulationAcessBySso"),new Object[]{principal});
			logger.debug( principal + " has access to hr population" );
		}catch(EmptyResultDataAccessException eex){
			logger.debug( principal + " does not have access to hr population" );
		}		
		return employeeId;
	}
	
	/*public Long skipSensitiveRolesBySso(Long principal){
		Long employeeId = null;
		try{
			employeeId = getJdbcTemplate().queryForLong(getSql("skipSensitiveRolesBySso"),new Object[]{principal});
			logger.debug( principal + ": sensitive roles are bypassed" );
		}catch(EmptyResultDataAccessException eex){
			logger.debug( principal + ": sensitive roles are not bypassed" );
		}
		return employeeId;
	}*/
	
	public boolean hasOptinServiceAcess(Long sso, String column){
		String value = "N";
		boolean hasAccess = false;
		try{
			value = getJdbcTemplate().queryForObject(getSql("hasOptinServiceAcessBySso").replaceAll("COLUMNNAME", column),new Object[]{sso}, String.class);
		}catch(EmptyResultDataAccessException eex){
			logger.debug( "Optin data not found for: "+sso );
		}
		
		if(value.equalsIgnoreCase("Y")){
			hasAccess = true;
		}
		return hasAccess;
	}
	
	public Long isLeadershipProgramMemberBySso(Long sso){
		Long employeeId = null;	
		try{
			employeeId = getJdbcTemplate().queryForLong(getSql("isLeadershipProgramMemberBySso"),new Object[]{sso});
			logger.debug( sso + " is a Leadership Program Member" );
		}catch(EmptyResultDataAccessException eex){
			logger.debug( sso + " is not a Leadership Program Member" );
		}		
		return employeeId;
	}
	
	public Long isJointVentureEmployeeBySso(Long sso){		
		
		Long employeeId = null;
		
		try{
			employeeId = getJdbcTemplate().queryForLong(getSql("isJVEmployeeBySso"), new Object[]{sso});
			logger.debug( sso + " is a joint venture employee" );
		}catch(EmptyResultDataAccessException eex){
			logger.debug( sso + " is not a joint venture employee" );
		}		
		return employeeId;
	}
	
	public Long isJVSponsorBySso(Long principal, Long sso){
		Long employeeId = null;	
		try{
			employeeId = getJdbcTemplate().queryForLong(getSql("isJVSponsorBySso"),new Object[]{principal,sso});
			logger.debug( principal + " is a Joint Venture Sponsor" );
		}catch(EmptyResultDataAccessException eex){
			logger.debug( principal + " is not a Joint Venture Sponsor" );
		}		
		return employeeId;
	}
}
