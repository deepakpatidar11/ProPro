/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.NullArgumentException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.util.Assert;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import com.ge.corporate.hr.profile.auth.dao.RolesAuthorityDao;
import com.ge.corporate.hr.profile.auth.model.DataGroup;
import com.ge.corporate.hr.profile.auth.model.User;
import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.cache.MethodSignatureKeyGenerator;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;


public class ProfilePermissionEvaluator implements PermissionEvaluator {

	private static final Log logger = LogFactory.getLog( ProfilePermissionEvaluator.class );
	
	public static final String ROLE_SA 	= "ROLE_SA";
	
	private ProfileAuthorityEvaluator authorityEvaluator;
	
	@Resource(name="rolesDao")
	private RolesAuthorityDao rolesDao;
	
	
	@SuppressWarnings("restriction")
	public boolean hasPermission(Authentication authentication, Object targetDomainObject, Object permission) {
		throw new NotImplementedException();
	}
	
	@Cache(
			nodeName="/profile/auth/ProfilePermissionEvaluator",
			keyGeneratorClass=MethodSignatureKeyGenerator.class,
			cacheName=InfinispanCacheFactory.AUTHEVALCACHE
	)
	public boolean hasPermission(Authentication authentication,Serializable targetId, String targetType, Object permission) {
		
		Assert.notNull(authorityEvaluator);
		if(targetId == null){
			throw new NullArgumentException("Unable to access SSO for security check. User may not have access to basic public information");
		}
		
		logger.debug("Evaluating access for "+authentication.getName()+" To DG "+ targetType + ":" + permission + " for SSO:" + targetId);
		
		//Pre-filter authorities with targetType (data group)
		Collection<GrantedAuthority> authorities	= preFilterAuthorities(authentication.getAuthorities(),targetType );
			
		User principal 								= (User) authentication.getPrincipal();
		Collection<DataGroup> grantedDataGroups = authorityEvaluator.getDataGroupsForContext(principal, authorities, targetId.toString());																
		
		Assert.notEmpty(grantedDataGroups, "No Datagroups defined for the role");
		
		return hasAccessToDataGroup(grantedDataGroups, targetType);
	}
	
	/**
	 * Filters the Authorities removing the Roles(authority) that does not have assigned the data group.
	 * @param authoritiesToFilter
	 * @param dataGroup
	 * @return
	 */
	private Collection<GrantedAuthority> preFilterAuthorities(Collection<GrantedAuthority> authoritiesToFilter,String dataGroup){
		
		Collection<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		List<String> roles = rolesDao.getRolesListByDG(dataGroup);
		for(GrantedAuthority auth : authoritiesToFilter){
			if(roles.contains(auth.getAuthority()) || auth.getAuthority().equals(ROLE_SA)){
				authorities.add(auth);
			}
		}
		return authorities;
	}
	/**
	 * 
	 * @param grantedDataGroups
	 * @param domainObject
	 * @return
	 */
	protected Boolean hasAccessToDataGroup(Collection<DataGroup> grantedDataGroups, String domainObject){
		Boolean accessToDomainModel = false;
		
		for(DataGroup dg: grantedDataGroups){
			if(dg.getName().equalsIgnoreCase( formatDomainObjectName(domainObject) )){
				accessToDomainModel = true;
				break;
			}
		}
		
		return accessToDomainModel;
	}
	/**
	 * 
	 * @param domainObject
	 * @return
	 */
	protected String formatDomainObjectName(String domainObject){
		StringBuilder domainName = new StringBuilder(domainObject);
		String formattedDataGroupName = domainName.substring( domainName.lastIndexOf(".") + 1 ).toUpperCase().toString();
		return formattedDataGroupName;
	}
	/**
	 * 
	 * @param authorityValidator
	 */
	public void setAuthorityEvaluator(ProfileAuthorityEvaluator authorityValidator) {
		this.authorityEvaluator = authorityValidator;
	}
	/**
	 * 
	 * @return
	 */
	public ProfileAuthorityEvaluator getAuthorityEvaluator() {
		return authorityEvaluator;
	}
	
}
