/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.validator;


import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.ge.corporate.hr.profile.auth.dao.FilterDao;
import com.ge.corporate.hr.profile.auth.ws.dto.AggregatedFilterDto;

public class FilterValidator implements Validator {

	@Resource(name = "filterDao")
	private FilterDao filterDao; 
	
	public boolean supports(Class<?> clazz) {		
		return true;//HashMap.class.equals(clazz);
	}

	@SuppressWarnings("unchecked")
	public void validate(Object target, Errors errors) {
		List<AggregatedFilterDto> filterList = (List<AggregatedFilterDto> )target;

		
		for(AggregatedFilterDto filter:filterList){
			List<String> valuesList = new ArrayList<String>();
			List<String> valuesFoundList = null;
			Long filterTypeId = filterDao.getFilterTypeIdByName(filter.getFilterType());			
			
			//if filterTypeId were not found, it should be inserted to message
			if( filterTypeId <= 0 ){
				errors.rejectValue("filterType",filter.getFilterType());
			}
			
			//Validate Filter Values			
			
			for(Long val:filter.getFilterValues()){
				valuesList.add(val.toString());
			}				
			//Get filters that exists,
			valuesFoundList = filterDao.getFilterValuesByFilterValues(filter.getFilterValues());
			
			//values found must be deletted from original filter values, if 
			valuesList.removeAll(valuesFoundList);
			//if exists filter then there are some filters that does not exists
			if(valuesList.size()>0){
				for(String val:valuesList){
					errors.rejectValue("filterValues",val);
				}
			}			
		}		
	}
}
