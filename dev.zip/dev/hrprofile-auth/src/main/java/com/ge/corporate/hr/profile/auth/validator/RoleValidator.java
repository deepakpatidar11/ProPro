/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.validator;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.ge.corporate.hr.profile.auth.dao.RolesAuthorityDao;

public class RoleValidator implements Validator {

	@Resource(name = "rolesDao")
	private RolesAuthorityDao rolesDao; 
	
	public boolean supports(Class<?> clazz) {		
		return HashMap.class.equals(clazz);
	}

	@SuppressWarnings("unchecked")
	public void validate(Object target, Errors errors) {
		Map<String,String> map = (Map<String,String>)target;
		
		String roleName = map.get("roleName");	
		
		if(!rolesDao.existsRole(roleName)){
			errors.rejectValue( "roleName", "role.mame.does.not.exists");
		}
	}

}