/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.ge.corporate.hr.profile.auth.dao.RolesAuthorityDao;
import com.ge.corporate.hr.profile.auth.model.DataGroup;
import com.ge.corporate.hr.profile.auth.model.ProfileRoles;


public class ProfileRolesDetailsService  {
	
	@Resource(name = "rolesDao")
	private RolesAuthorityDao rolesDao; 
	
	public RolesAuthorityDao getRolesDao() {
		return rolesDao;
	}


	public void setRolesDao(RolesAuthorityDao rolesDao) {
		this.rolesDao = rolesDao;
	}
	/**
	 * Loads Current User logged account Info
	 */
	@PreAuthorize("hasRole('ROLE_SA')")
	public List<ProfileRoles> loadAdminRoles()
			throws UsernameNotFoundException {
	
		return rolesDao.getRolesList();
	}
	/**
	 * Loads Current User logged account Info
	 */
	@PreAuthorize("hasRole('ROLE_SA')")
	public List<DataGroup> loadAdminDataGroup()
			throws UsernameNotFoundException {
	
		return rolesDao.getDataGroupList();
	}
	/**
	 * Loads Current User logged account Info
	 */
	@PreAuthorize("hasRole('ROLE_SA')")
	public List<DataGroup> getSelectDataGroup(final String roleId)
			throws UsernameNotFoundException {
	
		return rolesDao.getSelectDataGroupList(roleId);
	}
	
	@PreAuthorize("hasRole('ROLE_SA')")
	public boolean deleteDataGroups(final String role){
		return rolesDao.deleteDataGroupList(role);
	}
	
	
	@PreAuthorize("hasRole('ROLE_SA')")
	public void insertDataGroups(final List<DataGroup> dataGroups,final String roleId){
		rolesDao.insertDataGroupList(dataGroups,roleId);
	}

}