/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.NotImplementedException;
import org.springframework.util.Assert;

/**
 * 
 * @author hector.nevarez
 *
 */
public class GroupedProfileAuthority extends ProfileAuthority {

	private static final long serialVersionUID = -5112497970629716569L;
	
	protected Map<String, List<Long>> filters;
	
	/**
	 * 
	 * @param role
	 */
	public GroupedProfileAuthority(String role) {
		super(role);
		filters = new HashMap<String, List<Long>>();
		
	}
	/**
	 * 
	 * @param authority
	 */
	public GroupedProfileAuthority(ProfileAuthority authority) {
		this(authority.getAuthority());
		
		List<Long> filterValue = new ArrayList<Long>();
		filterValue.add( Long.parseLong( authority.getFilterValue() ) );	
		
		filters.put(authority.getFilterType(), filterValue );
	}
	/**
	 * 
	 * @param role
	 * @param filterType
	 * @param filterValue
	 */
	public GroupedProfileAuthority(String role, String filterType, String filterValue){
		this(role);
		
		List<Long> filterValues = new ArrayList<Long>();
		filterValues.add( Long.parseLong( filterValue ) );	
		
		filters.put(filterType, filterValues );
		
	}
	/**
	 * 
	 * @param role
	 * @param accessType
	 * @param accessValues
	 */
	public GroupedProfileAuthority(String role, String filterType, List<Long> filterValues) {
		this(role);
		
		Assert.notNull(filterType);
		
		filters.put(filterType, filterValues ); 
	}
	/**
	 * 
	 * @param filter
	 * @return
	 */
	public List<Long> getFilterValues(String filter) {
		return filters.get(filter);
	}
	
	public Collection<String> getFilterTypes(){
		
		return filters.keySet();
	}
	
	public Map<String, List<Long>> getFilters(){
		return filters;
	}
	
	/**
	 * 
	 * @param filter
	 * @param accessValues
	 */
	public void setFilterValues(String filter, List<Long> filterValues) {
		Assert.notNull(filter);
		
		if(getFilterValues(filter) != null){
			getFilterValues(filter).addAll(filterValues);
		}else{
			filters.put(filter, filterValues ); 
		}
	}
	/**
	 * 
	 * @param filter
	 * @param filterValue
	 */
	public void setFilterValues(String filter, String filterValue) {
		try{
			setFilterValues(filter, Long.parseLong(filterValue) );
		}catch (NumberFormatException e) {
			
			setFilterValues(filter, 0L );
		}
	}
	/**
	 * 
	 * @param filter
	 * @param filterValue
	 */
	public void setFilterValues(String filter, Long filterValue) {
		if(getFilterValues(filter) != null){
			getFilterValues(filter).add(filterValue);
		}else{
			List<Long> filterValues = new ArrayList<Long>();
			filterValues.add(filterValue);
			
			filters.put(filter, filterValues );
		}
		
	}
	/**
	 * 
	 * @param filter
	 * @param filterValue
	 */
	public void addFilterValues(String filter, Long filterValue) {
		if(getFilterValues(filter) != null){
			getFilterValues(filter).add(filterValue);
		}else{
			
			List<Long> filterValues = new ArrayList<Long>();
			filterValues.add( filterValue );	
			
			filters.put(filter, filterValues ); 
		}
	}
	
	public void addFilterValues(String filter, String filterValues) {
		if(filterValues != null){
			addFilterValues( filter, Long.parseLong( filterValues ) );
		}
	}

	public String toString(){
		return getAuthority() + "|" + getFilters();
	}
	
	/**
	 * 
	 * @param filter
	 * @return
	 */
	public boolean hasFilter(String filter){
		return (getFilterType(filter) != null) ? true : false;
	}
	
	//Prevent direct call
	
	/**
	 * 
	 */
	@Deprecated
	@Override
	public String getFilterType(){
		throw new NotImplementedException();
	}
	/**
	 * 
	 * @param filter
	 * @return
	 */
	public String getFilterType(String filter){
		return (filters.containsKey(filter)) ? filter : null;
	}
	
	@Deprecated
	@Override
	public String getFilterValue(){
		throw new NotImplementedException();
	}
	
}
