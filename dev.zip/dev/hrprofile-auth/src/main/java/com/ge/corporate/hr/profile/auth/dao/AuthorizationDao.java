/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.dao;

import java.util.List;

public interface AuthorizationDao {
	
	public Long getEmployeeIdByHierarchy(Long principal, Long sso);
	
	public Long getEmployeeIdByDottedLine(Long principal, Long sso);
	
	public Long getEmployeeIdByHRMofRecords(Long principal, Long sso);
	
	public Long getPermOrgIdByOrgHierarchy(Long principal, Long sso, List<Long> orgId);
	
	public Long getEmployeeIdByDirectDomain( Long principal, Long sso, String currentFilter, List<Long> domainIds );

	public List<String> loadPotentialDataGroups(Long sso);

	public Long isDottedLineManagerBySso(Long principal);
	
	public Long isHRManagerBySso(Long principal);
	
	public String isOverrideRoleBySSO(Long principal, Long sso);

	public Long isContingentWorkerBySso(Long sso);

	public Long isSponsorBySso(Long principal, Long sso);
	
	public Long isDirectoryEmployeeBySso(Long sso);
	
	public Long isPDUserBySso(Long sso);

	public Long hasHRPopulationAcessBySso(Long principal);
	
	public Long hasHRPopulationListAcessBySso(Long principal, List<String> roles);

	/*public Long skipSensitiveRolesBySso(Long principal);*/
	
	public boolean hasOptinServiceAcess(Long sso, String column);
	
	public Long isGEAlstomEmpBySso(Long sso);
	
	public Long isGEBakerHughesEmpBySso(Long sso);
	
	public Long isGEGasAndOilEmpBySso(Long sso);
	
	public Long isLeadershipProgramMemberBySso(Long sso);
	
	public Long isJointVentureEmployeeBySso(Long sso);
	
	public Long isJVSponsorBySso(Long principal, Long sso);
	

}
