/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.ws.dto;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;
@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name="roleAssignment")
public class AggregatedRoleDto extends AbstractBaseDtoSupport {
	
	private static final long serialVersionUID = -439244686941765288L;
	
	@XmlElement(name="roleName")
	private String roleName;
	
	@XmlElementWrapper(name="subjectFilterList")
	@XmlElement(name="subjectFilter")
	private List<AggregatedFilterDto> filters;
	
	public AggregatedRoleDto(){
		filters = new ArrayList<AggregatedFilterDto>();
	}
	public AggregatedRoleDto(String roleName){
		this.roleName = roleName;
	}
	
	public long getId() {
		return 0;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public List<AggregatedFilterDto> getFilters() {
		return filters;
	}

	public void setFilters(List<AggregatedFilterDto> filters) {
		this.filters = filters;
	}
	
	@Override
	public String toString(){
		return roleName + filters;
	}

	
}
