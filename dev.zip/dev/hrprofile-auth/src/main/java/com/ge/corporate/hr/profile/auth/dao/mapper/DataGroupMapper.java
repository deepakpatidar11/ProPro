/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ge.corporate.hr.profile.auth.model.DataGroup;

public class DataGroupMapper implements RowMapper<DataGroup>{

	public static final String DATA_GRP_ID = "DG_ID";
	public static final String DATA_GRP_NAME = "DG_NAME";
	public static final String ACTION_ID = "ACTION_ID";
	public static final String ROLE_ID = "ROLE_ID";
	
	public DataGroup mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		DataGroup dg = new DataGroup();
		
		dg.setId(rs.getLong(DATA_GRP_ID));
		dg.setName(rs.getString(DATA_GRP_NAME));
		
		return dg;
		
	}

}
