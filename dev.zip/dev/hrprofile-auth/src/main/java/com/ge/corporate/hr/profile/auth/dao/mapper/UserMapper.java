/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import com.ge.corporate.hr.profile.auth.model.User;

public class UserMapper implements RowMapper<User> {
	
	public static final String PERS_SSO		= "PERS_SSO";
	public static final String USER_NAME 	= "USER_NAME";
	
	public User mapRow(ResultSet rs, int rowNum) throws SQLException {
		//TODO: Determine if user details are relevant for Authentication
		User user = new User();
		
		user.setSso( rs.getLong(PERS_SSO) );
		user.setFirstName(rs.getString(PERS_SSO));
		
		user.setUsername( rs.getString(PERS_SSO) );
		
		
		//TODO: Determine rules to adquire this
		user.setAccountNonExpired(true);
		user.setAccountNonLocked(true);
		user.setCredentialsNonExpired(true);
		user.setEnabled(true);
			
		return user;
	}

}
