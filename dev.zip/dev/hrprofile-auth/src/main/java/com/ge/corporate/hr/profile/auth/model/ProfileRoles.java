/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
/**
 * 
 */
package com.ge.corporate.hr.profile.auth.model;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

/**
 * @author francisco.blanco
 *
 */
public class ProfileRoles extends AbstractBaseModelSupport{
	
	private static final long serialVersionUID = -6988574292607183290L;
	
	
	private long roleId;
	private String roleName;
	
	
	public long getRoleId() {
		return roleId;
	}
	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	
	
	
	
	
	
 
	
	


	
	
	

}
