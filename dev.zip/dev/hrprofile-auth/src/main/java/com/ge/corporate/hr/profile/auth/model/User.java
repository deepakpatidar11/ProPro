/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.model;
import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.ge.corporate.hr.profile.common.model.AbstractBaseModelSupport;

public class User extends AbstractBaseModelSupport implements UserDetails{
	
	private static final long serialVersionUID = 1260431218961438188L;

	protected Long sso;
	
	protected String firstName;
	protected String lastName;
	protected String surName;
	
	protected String email;
	//
	protected Collection<GrantedAuthority> authorities;
	protected String userName;
	protected String password;
	protected Boolean accountNonExpired;
	protected Boolean accountNonLocked;
	protected Boolean credentialsNonExpired;
	protected Boolean enabled;
	
	
	public Long getId() {
		return sso;
	}

	public void setId(Long id) {
		this.sso = id;
	}

	public Long getSso() {
		return sso;
	}

	public void setSso(Long sso) {
		this.sso = sso;
	}
	
	public String getName() {
		return firstName + " " + lastName ;
	}
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public void setFirstName(Number firstName) {
		this.firstName = firstName.toString();
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getSurName() {
		return surName;
	}

	public void setSurName(String surName) {
		this.surName = surName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Collection<GrantedAuthority> getAuthorities() {
		return authorities;
	}
	
	public void setAuthorities(Collection<GrantedAuthority> authorities){
		this.authorities = authorities; 
	}
	
	public String getPassword() {
		return password;
	}

	public String getUsername() {
		return userName;
	}
	
	public void setUsername(String userName){
		this.userName = userName;
	}
	
	public void setUsername(Number userName){
		this.userName = userName.toString();
	}

	public boolean isAccountNonExpired() {
		return accountNonExpired;
	}

	public boolean isAccountNonLocked() {
		return accountNonLocked;
	}

	public boolean isCredentialsNonExpired() {
		return credentialsNonExpired;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setAccountNonExpired(Boolean accountNonExpired) {
		this.accountNonExpired = accountNonExpired;
	}

	public void setAccountNonLocked(Boolean accountNonLocked) {
		this.accountNonLocked = accountNonLocked;
	}

	public void setCredentialsNonExpired(Boolean credentialsNonExpired) {
		this.credentialsNonExpired = credentialsNonExpired;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}
	
}
