/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
@javax.xml.bind.annotation.XmlSchema(
	namespace = "http://hr.corporate.ge.com/xsd/security-v1",
	xmlns = { @javax.xml.bind.annotation.XmlNs( prefix = "s",
                  namespaceURI = "http://hr.corporate.ge.com/xsd/security-v1" ) },    
	elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
	
package com.ge.corporate.hr.profile.auth.ws.dto;