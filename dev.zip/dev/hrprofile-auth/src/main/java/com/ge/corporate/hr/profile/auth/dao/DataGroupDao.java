/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.dao;

import java.util.List;

import com.ge.corporate.hr.profile.auth.model.DataGroup;

public interface DataGroupDao {
	public List<DataGroup> loadByRole(List<String> roles, Long accessedSso);
	public List<DataGroup> loadByRole(String role);
	public List<DataGroup> load();
	public List<DataGroup> loadForSA(Long accesedSso);
}