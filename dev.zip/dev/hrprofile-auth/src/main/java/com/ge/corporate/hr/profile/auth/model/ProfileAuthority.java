/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.model;

import org.springframework.security.core.authority.GrantedAuthorityImpl;
/**
 * 
 * @author hector.nevarez
 *
 */
public class ProfileAuthority extends GrantedAuthorityImpl{

	private String filterType;
	private String filterValue;
	
	private static final long serialVersionUID = 5490953135679477429L;

	public ProfileAuthority(String role) {
		super(role);
	}
	
	public ProfileAuthority(String role, String filterType, String filterValue) {
		super(role);
		
		this.setFilterType(filterType);
		this.setFilterValue(filterValue); 
	}

	public void setFilterType(String filterType) {
		this.filterType = filterType;
	}

	public String getFilterType() {
		return filterType;
	}

	public void setFilterValue(String accessValue) {
		this.filterValue = accessValue;
	}

	public String getFilterValue() {
		return filterValue;
	}
	
	public String toString(){
		return getAuthority() + "|" + getFilterType() +"|"+ getFilterValue();
	}
}
