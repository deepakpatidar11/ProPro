/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.dao;

import java.util.List;

public interface FilterDao {
	public Long getFilterTypeIdByName(String type);
	public List<String> getFilterValuesByFilterValues(List<Long> values);
	public List<String> getFilerTypeNameList();
}
