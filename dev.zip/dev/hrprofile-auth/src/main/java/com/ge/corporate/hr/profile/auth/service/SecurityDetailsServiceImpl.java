package com.ge.corporate.hr.profile.auth.service;

import java.util.Collection;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Service;

import com.ge.corporate.hr.profile.auth.ws.dto.AggregatedRoleDto;

@Service("securityDetails")
public class SecurityDetailsServiceImpl implements SecurityDetailsService{
	
	@Resource(name="authorityEvaluator")
	private ProfileAuthorityEvaluator authEvaluator;
	
	@Resource(name="profileUserDetailsService")
	private ProfileUserDetailsService userService;
	
	/**
	 * 
	 * @param sso
	 * @return
	 */
	public List<AggregatedRoleDto> getAggregatedAuthorities(Long sso){
		return userService.getAggregatedRoleList(sso);
	}
	/**
	 * 
	 * @param loggedSso
	 * @param viewedSso
	 * @return
	 */
	public List<String> getGrantingRole(Long loggedSso, Long viewedSso){
		
		Collection<GrantedAuthority> authorities = userService.getUserAuthorities(loggedSso);
		List<String> grantingRoles = authEvaluator.getRoleForContext(loggedSso, viewedSso, authorities);
		
		return grantingRoles;
	}
	
}
