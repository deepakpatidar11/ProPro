/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.ge.corporate.hr.profile.auth.dao.mapper.DataGroupMapper;
import com.ge.corporate.hr.profile.auth.dao.mapper.RolesDataGroupAuthorityMapper;
import com.ge.corporate.hr.profile.auth.model.DataGroup;
import com.ge.corporate.hr.profile.auth.model.ProfileRoles;
import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.cache.MethodSignatureKeyGenerator;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;
import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;

/**
 * @author francisco.blanco
 *
 */
public class RolesAuthorityDaoImp extends  AbstractBaseDaoSupport implements RolesAuthorityDao{


	@Cache(
			nodeName="/profile/auth/dao/RolesAuthorityDao",
			keyGeneratorClass=MethodSignatureKeyGenerator.class,
			cacheName=InfinispanCacheFactory.AUTHDAOCACHE
	)
	public List<ProfileRoles> getRolesList(){
		Collection<ProfileRoles> roles = new ArrayList<ProfileRoles>();

		roles = getJdbcTemplate().query(getSql("getRolesList"),new RolesDataGroupAuthorityMapper());

		return new ArrayList<ProfileRoles>(roles);
	}
	
	@Cache(
			nodeName="/profile/auth/dao/RolesAuthorityDao",
			keyGeneratorClass=MethodSignatureKeyGenerator.class,
			cacheName=InfinispanCacheFactory.AUTHDAOCACHE
	)
	
	public List<String> getRolesListByDG(String dataGroup){
		List<String> roles =null;
		
		roles = getJdbcTemplate().queryForList(getSql("getRolesListByDG"),new Object[]{dataGroup},String.class);

		return roles;
	}
	
	@Cache(
			nodeName="/profile/auth/dao/RolesAuthorityDao",
			keyGeneratorClass=MethodSignatureKeyGenerator.class,
			cacheName=InfinispanCacheFactory.AUTHDAOCACHE
	)
	
	public Boolean existsRole(String roleName){
		@SuppressWarnings("unused")
		Long roleId = 0L;
		try{	
			roleId = getJdbcTemplate().queryForLong(getSql("existsRole"),new Object[]{roleName});
			return true;
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Role not found");
			return false;
		}
	}	
	
	@Cache(
			nodeName="/profile/auth/dao/RolesAuthorityDao",
			keyGeneratorClass=MethodSignatureKeyGenerator.class,
			cacheName=InfinispanCacheFactory.AUTHDAOCACHE
	)
	public List<DataGroup> getDataGroupList(){
		Collection<DataGroup> datagroupsLst = new ArrayList<DataGroup>();

		datagroupsLst = getJdbcTemplate().query(getSql("getDataGroupList"),new DataGroupMapper());

		return new ArrayList<DataGroup>(datagroupsLst);
	}


	public List<DataGroup> getSelectDataGroupList(final String roleId){

		Collection<DataGroup> datagroupsLst = new ArrayList<DataGroup>();

		datagroupsLst = getJdbcTemplate().query(getSql("getRolesWithDG"),new Object[]{roleId} ,new DataGroupMapper());

		return new ArrayList<DataGroup>(datagroupsLst);
	}

	/*****
	 * 
	 * @param roleId
	 * @return
	 */
	public boolean deleteDataGroupList(final String roleId){

		int i = getJdbcTemplate().update(getSql("removeDataGroups"),new Object[]{roleId});

		return i==1?true:false;
	}

	/*****
	 * 
	 * @param datagroupsList
	 * @return
	 */
	public void insertDataGroupList(final List<DataGroup> datagroupsList,final String roleId){

		for(DataGroup datagroup:datagroupsList){
			getJdbcTemplate().update(getSql("insertRoleDataGroups"),new Object[]{datagroup.getName(),roleId});
		}
	}
	/**
	 * 
	 */
	public List<String> getRoleAssigmentList(long sso){
		
		List<String> roleAssigment = new ArrayList<String>();
		
		roleAssigment = getJdbcTemplate().queryForList(getSql("getSimpleRoleAssigments"), String.class, new Object[]{sso});
		
		return roleAssigment;
	}
	
	/**
	 * 
	 * @param ssoSigned
	 * @param dataGroup
	 * @return
	 */
	public Map<String,Long> getRolesFilterTypeCount(Long ssoSigned, String dataGroup){	
		SqlRowSet rowSet = null;
		
		Map<String,Long> roles = new HashMap<String,Long>();
		
		rowSet = getJdbcTemplate().queryForRowSet(getSql("getRolesFilterTypeCount") , new Object[]{dataGroup,ssoSigned,ssoSigned});
		while(rowSet.next()){
			roles.put(rowSet.getString("role_name"), rowSet.getLong("filter_count"));
		}
		
		return roles;		
	}

}
