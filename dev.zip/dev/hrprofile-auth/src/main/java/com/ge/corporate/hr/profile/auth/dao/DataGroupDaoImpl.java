/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;

import com.ge.corporate.hr.profile.auth.dao.mapper.DataGorupAllMapper;
import com.ge.corporate.hr.profile.auth.dao.mapper.DataGroupMapper;
import com.ge.corporate.hr.profile.auth.model.DataGroup;
import com.ge.corporate.hr.profile.common.cache.Cache;
import com.ge.corporate.hr.profile.common.cache.MethodSignatureKeyGenerator;
import com.ge.corporate.hr.profile.common.cache.infinispan.InfinispanCacheFactory;
import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;


public class DataGroupDaoImpl extends AbstractBaseDaoSupport implements DataGroupDao {
	
	/**
	 * 
	 */
	@Cache(
			nodeName="/profile/auth/dao/DataGroupDao",
			keyGeneratorClass=MethodSignatureKeyGenerator.class,
			cacheName=InfinispanCacheFactory.AUTHDAOCACHE
	)
	public List<DataGroup> loadByRole(List<String> roles,Long accessedSso){
		
		List<DataGroup> dataGroups = new ArrayList<DataGroup>();
		String sql = getSql("loadByRoleWithAccessedSso");
		for(String role : roles ){
			try{
				dataGroups.addAll( getJdbcTemplate().query(sql, new Object[]{role,role,role,accessedSso,role,accessedSso}, new DataGroupMapper()) );
			}catch(EmptyResultDataAccessException eex){
				logger.debug("Role " + role + " has no data groups set");
			}
		}		
		dataGroups = (dataGroups.isEmpty()) ? null: dataGroups;		
		return dataGroups;
	}
	

	/**
	 * 
	 */
	@Cache(
			nodeName="/profile/auth/dao/DataGroupDao",
			keyGeneratorClass=MethodSignatureKeyGenerator.class,
			cacheName=InfinispanCacheFactory.AUTHDAOCACHE
	)
	public List<DataGroup> loadByRole(String role){
		
		List<DataGroup> dataGroups = null;
		
		try{
			dataGroups = getJdbcTemplate().query(getSql("loadByRole"), new Object[]{role}, new DataGroupMapper());
		}catch(EmptyResultDataAccessException eex){
			logger.debug("Role " + role + " has no data groups set");
		}
		
		return dataGroups;
	}


	@Cache(
			nodeName="/profile/auth/dao/DataGroupDao",
			keyGeneratorClass=MethodSignatureKeyGenerator.class,
			cacheName=InfinispanCacheFactory.AUTHDAOCACHE
	)
	public List<DataGroup> load() {
		List<DataGroup> dataGroups = null;
		
		try{
			dataGroups = getJdbcTemplate().query(getSql("loadAllDataGroups"), new DataGorupAllMapper());
		}catch(EmptyResultDataAccessException eex){
			logger.debug("Unable to load all DataGroups: " + eex.getMessage());
		}
		
		return dataGroups;
	}
	
	@Cache(
			nodeName="/profile/auth/dao/DataGroupDao",
			keyGeneratorClass=MethodSignatureKeyGenerator.class,
			cacheName=InfinispanCacheFactory.AUTHDAOCACHE
	)
	public List<DataGroup> loadForSA(Long accesedSso) {
		List<DataGroup> dataGroups = null;
		
		try{
			dataGroups = getJdbcTemplate().query(getSql("loadDataGroupsForSA"),new Object[]{accesedSso,accesedSso}, new DataGorupAllMapper());
		}catch(EmptyResultDataAccessException eex){
			logger.debug("Unable to load all DataGroups for SA: " + eex.getMessage());
		}
		
		return dataGroups;
	}
	
}
