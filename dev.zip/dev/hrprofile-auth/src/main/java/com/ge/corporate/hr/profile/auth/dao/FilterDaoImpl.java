/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;

import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;

public class FilterDaoImpl extends AbstractBaseDaoSupport implements FilterDao{

	public Long getFilterTypeIdByName(String type) {
		Long filterTypeId = 0L;
		try{	
			filterTypeId = getJdbcTemplate().queryForLong(getSql("getFilterTypeIdByName"),new Object[]{type});			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Filter Type not found");			
		}
		return filterTypeId;
	}
	
	/**
	 * Get all filters values that founds in t_filter table
	 * @param values
	 * @return
	 */
	public List<String> getFilterValuesByFilterValues(List<Long> values) {
		List<String> filtValues = null;
		List<String> filtValuesString = new ArrayList<String>();
		String query = getSql("getFilterValuesByFilterValues");
		
		for(Long val:values){
			filtValuesString.add(val.toString());
		}		
		try{				
			filtValues = getJdbcTemplate().queryForList(dynamicPlaceHolderSet(query, filtValuesString),filtValuesString.toArray(), String.class);			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Filter Type not found");			
		}
		return filtValues;
	}
	
	public List<String> getFilerTypeNameList() {
		List<String> filtTypes = null;
		String query = getSql("getFilerTypeNameList");
		
		try{				
			filtTypes = getJdbcTemplate().queryForList(query,String.class);			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Filter Types  not found");			
		}
		return filtTypes;
	}
}
