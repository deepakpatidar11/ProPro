/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
/**
 * 
 */
package com.ge.corporate.hr.profile.auth.dto;

import java.io.Serializable;
import java.util.List;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;


/**
 * @author francisco.blanco
 *
 */



public class AuthRoleProfileDto extends AbstractBaseDtoSupport implements  Serializable{

	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<String> rolesForContext;
	private List<String> roles;
	
	
	 
	 public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public List<String> getRolesForContext() {
		return rolesForContext;
	}

	public void setRolesForContext(List<String> rolesForContext) {
		this.rolesForContext = rolesForContext;
	}



	private Long ssoLogged;
	 
	 private Long ssoAssigned;
 	

	public Long getSsoLogged() {
		return ssoLogged;
	}

	public void setSsoLogged(Long ssoLogged) {
		this.ssoLogged = ssoLogged;
	}

	public Long getSsoAssigned() {
		return ssoAssigned;
	}

	public void setSsoAssigned(Long ssoAssigned) {
		this.ssoAssigned = ssoAssigned;
	}

	public long getId() {
		return 0;
	}
 
 
 

}
