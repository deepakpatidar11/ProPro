/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.model;

import java.io.Serializable;
import java.util.Set;

public class DataGroup implements Serializable{

	private static final long serialVersionUID = -7384557663191506L;
	
	protected Long id;
	protected String name;
	protected Set<String> elements;
	
	public DataGroup(){
	}
	
	public DataGroup(Long id, String name){
		this.name = name;
		this.id = id;
	}
	
	public DataGroup(String name){
		this.name = name;
	}
	
	public Long getId() {
		return (id != null) ? id : 0;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Set<String> getElements() {
		return elements;
	}
	public void setElements(Set<String> elements) {
		this.elements = elements;
	}
	
	@Override
	public String toString(){
		return "[" + name + "]";
	}
	
	@Override
	public int hashCode(){
		return name.hashCode();
	}
	
	@Override
	public boolean equals(Object compareTo){
		boolean isEqual = false;
		
		if(this.getClass().isAssignableFrom(compareTo.getClass())){
			DataGroup compareToDG = (DataGroup) compareTo;
			
			isEqual = (this.getName().equals(compareToDG.getName()));
		}
		
		return isEqual;
	}
		
}
