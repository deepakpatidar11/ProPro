/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.util.Assert;

import com.ge.corporate.hr.profile.auth.dao.mapper.UserMapper;
import com.ge.corporate.hr.profile.auth.model.User;
import com.ge.corporate.hr.profile.auth.ws.dto.AggregatedFilterDto;
import com.ge.corporate.hr.profile.common.dao.AbstractBaseDaoSupport;

public class UserDaoImpl extends AbstractBaseDaoSupport implements UserDao {


	public static final String ORG				= "ORGANIZATION";
	public static final String FUNCTION 		= "FUNCTION";
	public static final String COUNTRY 			= "COUNTRY";
	public static final String PAYROLL 			= "PAYROLL";
	public static final String REGION 			= "REGION";
	public static final String PROGRAM 			= "PROGRAM";
	public static final String EMPLOYEE 		= "EMPLOYEE";
	
	private static final String PLACEHOLDER_SEP_OR = " OR ";	
	private static final String PLACEHOLDER_SEP_INTERSECT = " INTERSECT ";
	
	/**
	 * Loads User by SSO id
	 * @param sso 
	 */
	public User loadBySSO(Long sso) {
		Assert.notNull(sso, "SSO is required");
		User user = null;
		try{
			user = getJdbcTemplate().queryForObject(getSql("loadUserBySSO"), new Object[]{sso.intValue()}, new UserMapper());			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("User " + sso + " Not found");
		}
		return user;
	}
		
	/**
	 * Loads Users by role name and Filters provided
	 * @param roleName
	 * @param filters
	 * @return
	 */
	public List<User> loadUsersByRoleAndFilters(String roleName, List<AggregatedFilterDto> filters ){
		String sql = getSql("loadUsersByRoleAndFilters");
		List<User> users = null;
		
		//Process sql replace
		sql = replaceInternalSection(sql,filters);
		
		if(sql!=null && sql.length()>0){		
			users = getJdbcTemplate().query(sql, new Object[]{roleName}, new UserMapper());
		}
		
		return users;		
	}
	
	/**
	 * Loads users by filters provided
	 * @param filters
	 * @return
	 */
	public List<User> loadUsersByFilters(List<AggregatedFilterDto> filters ){
		String sql = getSql("loadUsersByFilters");
		List<User> users = null;		
		
		sql = replaceInternalSection(sql,filters);
		
		if(sql!=null && sql.length()>0){			
			users = getJdbcTemplate().query(sql, new UserMapper());
		}
		
		return users;		
	}
	
	private String replaceInternalSection(String sql,List<AggregatedFilterDto> filters){
		String newSql;
		Boolean first = true;
		String newIntSection="";
		//Process sql replace
		String internalSection = sql.substring(sql.indexOf('[')+1, sql.indexOf(']'));
		for(AggregatedFilterDto filter:filters){
					
			String filterType = filter.getFilterType();
			List<Long> values = filter.getFilterValues();
		
			for(int cc = 0; cc < values.size(); cc++){
				String internalProcTemp = internalSection;				
				internalProcTemp = internalProcTemp.replace("!1" ,values.get(cc).toString());
				internalProcTemp = internalProcTemp.replace("!2" ,filterType);
				if(first){
					newIntSection += internalProcTemp;
				}else{
					newIntSection += PLACEHOLDER_SEP_OR + internalProcTemp;
				}				
				first = false;
			}
		}		
		newSql = sql.replace("[" + internalSection + "]", newIntSection);
		return newSql;
	}
	
	
	/**
	 * 
	 * @param roleName
	 * @param filters
	 * @return
	 */
	public List<User> loadUsersByRole(String roleName){
		String sql = getSql("loadUsersByRole");
		List<User> users = null;
		//Process sql replace
		try{
			users = getJdbcTemplate().query(sql, new Object[]{roleName}, new UserMapper());
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("None user was found");
		}
		return users;		
	}
		
	public List<User> loadUsersByFilterSet(List<AggregatedFilterDto> filters){
		String intersect="";
		String sql="";
		List<User> users = new ArrayList<User>();
		List<Long> values = new ArrayList<Long>();
		
		//Parse query
		for(AggregatedFilterDto filter : filters){					
			String filterType = filter.getFilterType();
			
			if(sql.length()>0){
				intersect = PLACEHOLDER_SEP_INTERSECT;			
			}
			if(filterType != null ){
				if(filterType.equals(ORG)){					
					sql += intersect + "(" + dynamicPlaceHolderSet(getSql("loadUsersByOrgFilter"), filter.getFilterValues()) + ")";
					values.addAll(filter.getFilterValues());
				}else if(filterType.equals(PAYROLL)){
					sql += intersect + "(" + dynamicPlaceHolderSet(getSql("getUsersByPayRoll"), filter.getFilterValues()) + ")";
					values.addAll(filter.getFilterValues());
				}else if(filterType.equals(REGION)){
					sql += intersect + "(" + dynamicPlaceHolderSet(getSql("getUsersByRegion"), filter.getFilterValues()) + ")";
					values.addAll(filter.getFilterValues());
				}else if(filterType.equals(COUNTRY)){
					sql += intersect + "(" + dynamicPlaceHolderSet(getSql("getUsersByCountry"), filter.getFilterValues()) + ")";
					values.addAll(filter.getFilterValues());
				}else if(filterType.equals(FUNCTION)){
					sql += intersect + "(" + dynamicPlaceHolderSet(getSql("getUsersByFunction"), filter.getFilterValues()) + ")";
					values.addAll(filter.getFilterValues());
				}else if(filterType.equals(PROGRAM)){
					sql += intersect + "(" + dynamicPlaceHolderSet(getSql("getUsersByProgram"), filter.getFilterValues()) + ")";
					values.addAll(filter.getFilterValues());
				}
			}
		}		
		try{			
			if(sql != null && sql.length() > 0 ){
				users = getJdbcTemplate().query(sql, values.toArray(), new UserMapper());
			}else{				
				logger.error("Filters type provided does not match with filters in database");				
			}		
			
		}catch (EmptyResultDataAccessException eex) {
			logger.debug("Users Not found for filters");
		}
		return users;		
	}
	
	public List<Long> loadMyClientsSsoByListSso(List<Long> ssoList){
		String sql = getSql("loadMyClientsSsoBySso");
		List<Long> clients = null;
		
		clients = getJdbcTemplate().queryForList(dynamicPlaceHolderSet(sql, ssoList) , ssoList.toArray(), Long.class);
		
		return clients;	
	}
	
	public List<Long> loadMyClientsSsoBySso(Long sso){
		String sql = getSql("loadMyClientsSsoBySso");
		List<Long> clients = null;
		
		clients = getJdbcTemplate().queryForList(sql, new Object[]{sso}, Long.class);
		
		return clients;	
	}
	
//	@Cacheable(
//			cacheName="/profile/auth/dao/UserDao",
//			keyGeneratorClass=DefaultCacheKeyGenerator.class	
//	)	
//	public List<Long> getUserListByDataGroup(Long ssoSigned, String dataGroup) {
//		List<Long> ssoListReturn = new ArrayList<Long>();
//		List<Long> ssoList = null;
//		
//		SqlRowSet rowSet;
//		rowSet = getJdbcTemplate().queryForRowSet(getSql("getRolesFilterTypeCount") , new Object[]{dataGroup,ssoSigned,ssoSigned});
//		
//		while(rowSet.next()){
//			ssoList = getJdbcTemplate().queryForList(getSql("getUsersByDataGroup"),new Object[]{ssoSigned,rowSet.getString("role_name"),rowSet.getLong("filter_count")}, Long.class); 
//			ssoListReturn.addAll(ssoList);
//		}
//		
//		return ssoListReturn;
//	}
//	
}
