/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.ws.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.ge.corporate.hr.profile.common.dto.AbstractBaseDtoSupport;

/**
 * 
 * @author hector.nevarez
 *
 */
@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name="subjectFilter")
public class AggregatedFilterDto extends AbstractBaseDtoSupport {

	private static final long serialVersionUID = -1033864421382042140L;
	
	@XmlElement(name="filterType")
	private String filterType;
	
	@XmlElementWrapper(name="filterValues")
	@XmlElement(name="filterValue")
	private List<Long> filterValues;
	
	@XmlTransient
	public long getId() {
		return 0;
	}
	
	public AggregatedFilterDto(){
		
	}
	
	public AggregatedFilterDto(String filterType){
		this.filterType = filterType;
	}
	
	public String getFilterType() {
		return filterType;
	}

	public void setFilterType(String filterType) {
		this.filterType = filterType;
	}

	public List<Long> getFilterValues() {
		return filterValues;
	}

	public void setFilterValues(List<Long> filterValue) {
		this.filterValues = filterValue;
	}
	
	@Override
	public String toString(){
		return filterType + filterValues;
	}

	
}
