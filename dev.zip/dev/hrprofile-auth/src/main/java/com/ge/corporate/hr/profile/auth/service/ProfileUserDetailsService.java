/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.service;

import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.AuthenticationUserDetailsService;

import com.ge.corporate.hr.profile.auth.dao.ProfileAuthorityDao;
import com.ge.corporate.hr.profile.auth.model.User;
import com.ge.corporate.hr.profile.auth.ws.dto.AggregatedFilterDto;
import com.ge.corporate.hr.profile.auth.ws.dto.AggregatedFilterSetDto;
import com.ge.corporate.hr.profile.auth.ws.dto.AggregatedRoleDto;
/**
 * 
 * @author hector.nevarez
 *
 */
public interface ProfileUserDetailsService extends AuthenticationUserDetailsService {
	/**
	 * 
	 * @param authorityDao
	 */
	public void setAuthorityDao(ProfileAuthorityDao authorityDao);
	/**
	 * 
	 * @param sso
	 * @return
	 */
	public List<AggregatedRoleDto> getAggregatedRoleList(Long sso);
	/**
	 * 
	 * @param sso
	 * @return
	 */
	public Collection<GrantedAuthority> getUserAuthorities(Long sso);
	
	/**
	 * Returns the set of users who have the given role with the given filter	 * 
	 * @param roleName
	 * @param filters
	 * @param includeChildren
	 * @return
	 */
	public List<User> getSubjectsHavingRole(String roleName,List<AggregatedFilterDto> filters);
		
	/**
	 * Returns a subset of the GE population based only on the provided filter
	 * @param filters
	 * @return
	 */
	public List<User> getSubjectsHavingFilter(List<AggregatedFilterSetDto> filterSets);
	
	
	/**
	 * Returns a of the GE population related to the sso whit role
	 * @param sso
	 * @param roleName
	 * @return
	 */
	public List<User> getRelatedSubjects(Long sso, String roleName);
	
}
