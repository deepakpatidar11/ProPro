/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.dao;

import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;

import com.ge.corporate.hr.profile.auth.model.ProfileAuthority;
import com.ge.corporate.hr.profile.auth.model.User;


public interface ProfileAuthorityDao {
	public Collection<GrantedAuthority> loadByUser(User user);
	
	public Collection<GrantedAuthority> loadByUser(Long sso);
	public List<ProfileAuthority> loadByUserAndRole(Long sso, String role);
}
