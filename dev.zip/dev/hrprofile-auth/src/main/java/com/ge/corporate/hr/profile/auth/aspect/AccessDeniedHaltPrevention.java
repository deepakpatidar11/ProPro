/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.aspect;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.annotation.Order;
import org.springframework.security.access.AccessDeniedException;

/**
 * Used to prevent application to halt after a AccessDenied exception is thrown
 * 
 * @author hector.nevarez
 *
 */
@Aspect
@Order(value=2)
public class AccessDeniedHaltPrevention {
	private final Log logger = LogFactory.getLog(AccessDeniedHaltPrevention.class);
	
	@Around("execution(@org.springframework.security.access.prepost.PreAuthorize * *(..))")
	public Object preventAccessDeniedHalting(ProceedingJoinPoint pjp) throws Throwable{
		Object retVal = null;
		try{
			retVal = pjp.proceed();
		}catch(AccessDeniedException ade){
			logger.debug("** Access Denied ** -For- "+pjp.getKind());
		}catch(Exception t){
			throw t;
		}
		return retVal;
	}
	
}
