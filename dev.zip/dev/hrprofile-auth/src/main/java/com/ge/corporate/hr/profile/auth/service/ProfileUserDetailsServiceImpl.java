/*******************************************************************************
 * Copyright � 2011 General Electric. ALL RIGHTS RESERVED. 
 *
 *  This file contains proprietary and GE CONFIDENTIAL Information.
 *
 *  Use, disclosure or reproduction is prohibited.
 *
 *  Filename:
 *  Created on 08/23/2011
 *
 *  @author COPR CIS HR Profile Development Team
 *  @version 1.0
 *     
 *******************************************************************************/
package com.ge.corporate.hr.profile.auth.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.Validator;

import com.ge.corporate.hr.profile.auth.dao.FilterDao;
import com.ge.corporate.hr.profile.auth.dao.ProfileAuthorityDao;
import com.ge.corporate.hr.profile.auth.dao.RolesAuthorityDao;
import com.ge.corporate.hr.profile.auth.dao.UserDao;
import com.ge.corporate.hr.profile.auth.model.GroupedProfileAuthority;
import com.ge.corporate.hr.profile.auth.model.ProfileAuthority;
import com.ge.corporate.hr.profile.auth.model.ProfileRoles;
import com.ge.corporate.hr.profile.auth.model.User;
import com.ge.corporate.hr.profile.auth.ws.dto.AggregatedFilterDto;
import com.ge.corporate.hr.profile.auth.ws.dto.AggregatedFilterSetDto;
import com.ge.corporate.hr.profile.auth.ws.dto.AggregatedRoleDto;

public class ProfileUserDetailsServiceImpl implements ProfileUserDetailsService {
	
	private final Log logger = LogFactory.getLog(ProfileUserDetailsServiceImpl.class);
	
	@Resource(name = "roleValidator")
	private Validator roleValidator;
	
	@Resource(name = "filterValidator")
	private Validator filterValidator;
	
	@Resource(name = "authorityDao")
	private ProfileAuthorityDao authorityDao; 
	
	@Resource(name = "userDao")
	private UserDao userDao;
	
	@Resource(name = "rolesDao")
	private RolesAuthorityDao rolesDao;
	
	@Resource(name = "filterDao")
	private FilterDao filterDao; 
	
	private static final String DEFAULT_ROLE = "ROLE_EMPLOYEE";
	private static final String DEFAULT_FILTER = "EMPLOYEE";
	private static final String DEFAULT_FILTER_VALUE = "0";	
	
	
	/**
	 * Loads Current User logged account Info
	 */
	public UserDetails loadUserDetails(Authentication token)
			throws UsernameNotFoundException {
		Long sso = null;		
		try{
			sso= Long.valueOf( token.getName() );
		}catch(NumberFormatException nfe){
			throw new UsernameNotFoundException("Unable to authenticate User - Invalid SSO.");
		}
			
		User user = getPublicUserDetails(sso);
		token.setAuthenticated(true);
		
		Collection<GrantedAuthority> authorities = getUserAuthorities(user.getSso());
			
		user.setAuthorities(authorities);
		
		
		return user;
	}
	
	public void setAuthorityDao(ProfileAuthorityDao authorityDao){
		this.authorityDao = authorityDao;
	}
	/**
	 * Aggregates Filter Values into single role - filter groups
	 * @param user
	 * @return
	 */
	public Collection<GrantedAuthority> getUserAuthorities(Long sso){
		Collection<GrantedAuthority> authorities = authorityDao.loadByUser(sso);
		Collection<GrantedAuthority> aggregatedAuthorities = new ArrayList<GrantedAuthority>();
		
		GroupedProfileAuthority groupedAuthority = null;
		
		
		if(authorities != null && authorities.size() > 0){
			
			//currentAuthority.getAuthority() -- Current Role Name
			
			for(GrantedAuthority grantedAuthority: authorities){
				ProfileAuthority currentAuthority = (ProfileAuthority) grantedAuthority;
				//Group by Role
				if(groupedAuthority == null){ //First Iteration
					
					groupedAuthority = new GroupedProfileAuthority(currentAuthority.getAuthority());
					
				}else if( !groupedAuthority.getAuthority().equals(currentAuthority.getAuthority()) ){ //Role Changed
					
					aggregatedAuthorities.add(groupedAuthority);
					groupedAuthority = new GroupedProfileAuthority(currentAuthority.getAuthority());
					
				} // Its the same role
					
				groupedAuthority.setFilterValues(currentAuthority.getFilterType(), currentAuthority.getFilterValue());
				
			}
		}else{ // Set Default Authority
			groupedAuthority = new GroupedProfileAuthority( DEFAULT_ROLE ,DEFAULT_FILTER, DEFAULT_FILTER_VALUE );
		}
		
		aggregatedAuthorities.add(groupedAuthority);
		
		return aggregatedAuthorities;
	}
	
	public List<AggregatedRoleDto> getAggregatedRoleList(Long sso){
		List<AggregatedRoleDto> aggregatedRoles = null;
				
		Collection<GrantedAuthority> authorities = getUserAuthorities(sso);
		if(authorities!= null && authorities.size()>0){			
			aggregatedRoles = new ArrayList<AggregatedRoleDto>();
			
			for(GrantedAuthority grantedAuth: authorities){
				GroupedProfileAuthority auth = (GroupedProfileAuthority) grantedAuth;
				
				List<AggregatedFilterDto> filters = new ArrayList<AggregatedFilterDto>();
				
				AggregatedRoleDto role = new AggregatedRoleDto(auth.getAuthority());
				
				for(String filterType: auth.getFilters().keySet()){					
					AggregatedFilterDto filter = new AggregatedFilterDto(filterType);
					filter.setFilterValues(auth.getFilters().get(filterType));
						
					filters.add(filter);					
				}
				role.setFilters(filters);				
				aggregatedRoles.add(role);
				
			}
		}
		return aggregatedRoles;
	}
	
	
	private User getPublicUserDetails(long sso){
		User user = new User();
		
		user.setSso( sso );
		user.setFirstName(sso);
		user.setUsername( sso );
		
		user.setAccountNonExpired(true);
		user.setAccountNonLocked(true);
		user.setCredentialsNonExpired(true);
		user.setEnabled(true);
		
		return user;
	}
	
	/**
	 * Returns the set of users who have the given role with the given filter	 * 
	 * @param roleName
	 * @param filters
	 * @param includeChildren
	 * @return
	 */
	public List<User> getSubjectsHavingRole(String roleName,List<AggregatedFilterDto> filters){		
		//		
		List<User> users = new ArrayList<User>();
		
		//Validate Role		
		validateRole(roleName);
		
		//if error exists a exception is thrown
		validateFilters(filters);
		
		//Returns the set of users who have the given role with the given filter
		if(filters!= null && filters.size()>0){			
			users.addAll(userDao.loadUsersByRoleAndFilters(roleName, filters));
		}else{
			users.addAll(userDao.loadUsersByRole(roleName));
		}		
		return users;		
	}
	
	 /**
	  * Returns a subset of the GE population based only on the provided filter
	  * @param filters
	  * @return
	  */
	public List<User> getSubjectsHavingFilter(List<AggregatedFilterSetDto> filterSets){				
		List<User> users = null;
		
		//Validate input Filters
		//if error exists a exception is thrown 
		validateFiltersSet(filterSets);
		
		//Returns the set of users who have the given filter
		if(filterSets!= null && filterSets.size()>0){			
			users = new ArrayList<User>();			
			for(AggregatedFilterSetDto filterSet : filterSets){				
				users.addAll(userDao.loadUsersByFilterSet(filterSet.getAgregatedFilterList()));
			}
		}	
		
		return users;		
	}	
	
	
	/**
	  * Returns a subset of the GE population based only on the provided filter
	  * @param filters
	  * @return
	  */
	public List<User> getRelatedSubjects(Long sso, String roleName){					
		List<User> users = null;
		List<ProfileAuthority> authorities = null;
		List<AggregatedFilterDto> filterList = new ArrayList<AggregatedFilterDto>();
		String filterType = "";
		
		// Validate role
		validateRole(roleName);
		
		//Get Authorities by user and Role
		authorities = authorityDao.loadByUserAndRole(sso, roleName);
		List<Long> filtValues = null;
		
		//Map authorities to List of AggregatedFilterDto
		if(authorities!=null){
			AggregatedFilterDto filter = null; 
			for(ProfileAuthority auth:authorities ){
				if(filterType.equals(auth.getFilterType())){				
					filtValues.add(Long.parseLong(auth.getFilterValue()));
				}else{					 
					filtValues = new ArrayList<Long>();
					filter = new AggregatedFilterDto();
					filter.setFilterType(auth.getFilterType());
					filter.setFilterValues(filtValues);
					filtValues.add(Long.parseLong(auth.getFilterValue()));
					filterType = auth.getFilterType();					
				}
				filterList.add(filter);
			}
		}
		
		//Returns the set of users who have the given filter
		if(filterList != null && filterList.size()> 0){
			users = userDao.loadUsersByFilterSet(filterList);
		}		
		return users;		
	}		
	
	private void validateRole(String roleName ){
		
		Map<String,String> map = new HashMap<String,String>();				
		map.put("roleName", roleName);
		BindingResult result = new MapBindingResult(map,"errors");
		
		//execute role Validation		
		roleValidator.validate(map, result);
		//for now the only error that exists is that roleName does not exists
		if(result.hasErrors()){
			
			//roleName does not exist
			List<ProfileRoles> roles = rolesDao.getRolesList();
			StringBuilder message = new StringBuilder();
			message.append("Input Error - Role name is not valid");							
			logger.error(message);
			
			if(roles!= null && roles.size()>0){
				Boolean firstTime  = true;
				message.append("\n possible roles that you can use are: [");
				
				for(ProfileRoles role:roles){					
					if(firstTime == false){
						message.append(", ");						
					}		
					message.append(role.getRoleName());
					firstTime = false;
				}				
				message.append("]");
			}			
			throw new IllegalArgumentException(message.toString());
		}	
	}
	
	private void validateFilters(List<AggregatedFilterDto> filterList){
		StringBuilder filterTypeMessage = new StringBuilder();
		StringBuilder filterValuesMessage = new StringBuilder();		
		StringBuilder errorMessage = new StringBuilder();
		
		if(validateFilterList(filterList,filterTypeMessage,filterValuesMessage)){
			errorMessage.append(concatenateFilterErrors(filterTypeMessage,filterValuesMessage));
			throw new IllegalArgumentException(errorMessage.toString());
		}
	}
	
	
	private void validateFiltersSet(List<AggregatedFilterSetDto> filterSets){
		Boolean hasErrors = false;
		StringBuilder filterTypeMessage = new StringBuilder();
		StringBuilder filterValuesMessage = new StringBuilder();		
		StringBuilder errorMessage = new StringBuilder();
		
		for(AggregatedFilterSetDto filterSet:filterSets){	
			Boolean errors = false;
			errors = validateFilterList(filterSet.getAgregatedFilterList(),filterTypeMessage,filterValuesMessage);
			if(errors && hasErrors==false){
				hasErrors = true;
			}
		}		
		
		if(hasErrors){
			errorMessage.append(concatenateFilterErrors(filterTypeMessage,filterValuesMessage));
			throw new IllegalArgumentException(errorMessage.toString());
		}
	}
	
	
	private boolean validateFilterList(List<AggregatedFilterDto> filterDto, StringBuilder filterTypeMessage,StringBuilder filterValuesMessage ){
		Boolean hasErrors = false;
		
		Map<String,List<AggregatedFilterDto>> map = new HashMap<String,List<AggregatedFilterDto>>();
		BindingResult result = new MapBindingResult(map,"errors");
		
		map.put("filterType", filterDto);
		map.put("filterValues", filterDto);
		
		filterValidator.validate(filterDto, result);
		
		if(result.hasErrors()){
			hasErrors = true;
			for(FieldError error:result.getFieldErrors("filterType")){
				if(filterTypeMessage.length()>0){
					filterTypeMessage.append(",");						
				}	
				filterTypeMessage.append(error.getCode());				
			}
			for(FieldError error:result.getFieldErrors("filterValues")){
				if(filterValuesMessage.length()>0){
					filterValuesMessage.append(",");						
				}	
				filterValuesMessage.append(error.getCode());				
			}				
		}
		return hasErrors;
	}
	
	private StringBuilder concatenateFilterErrors(StringBuilder filterTypeMessage,StringBuilder filterValuesMessage){
		StringBuilder errorMessage = new StringBuilder("Input Error - ");
		//Concatenate Error Strings
		
		if(filterTypeMessage.length()>0){
			List<String> filterTypeList;
			errorMessage.append("Next Filter(s) type are not valid: ");
			errorMessage.append(filterTypeMessage);
			//get possible Filter Types			
			filterTypeList = filterDao.getFilerTypeNameList();
			errorMessage.append("\nPosible Filter Types are: ");
			errorMessage.append(filterTypeList.toString());
		}
		
		if(filterValuesMessage.length()>0){
			errorMessage.append("\nNext Flter Value(s) are not valid: ");
			errorMessage.append(filterValuesMessage);			
		}
		return errorMessage;
		
	}
	
}
